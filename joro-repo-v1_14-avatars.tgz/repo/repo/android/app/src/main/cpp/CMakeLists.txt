cmake_minimum_required(VERSION 3.18)
project(joro_native CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# JORO sources live in <repo>/src (android/app/src/main/cpp -> 5 levels up)
set(JORO_SRC ${CMAKE_CURRENT_SOURCE_DIR}/../../../../../src)

# One library for the app: the referee (calibration games) + the board/opening helpers + the training (engine in-process).
add_library(joro_native SHARED
  native_jni.cpp
  ${JORO_SRC}/board.cpp ${JORO_SRC}/eval.cpp ${JORO_SRC}/experience.cpp ${JORO_SRC}/search.cpp ${JORO_SRC}/tunables.cpp ${JORO_SRC}/embed.cpp
  ${JORO_SRC}/trainer.cpp ${JORO_SRC}/gate.cpp ${JORO_SRC}/san.cpp ${JORO_SRC}/pgn.cpp ${JORO_SRC}/opstats.cpp ${JORO_SRC}/tuner.cpp ${JORO_SRC}/appapi.cpp)
target_include_directories(joro_native PRIVATE ${JORO_SRC})
