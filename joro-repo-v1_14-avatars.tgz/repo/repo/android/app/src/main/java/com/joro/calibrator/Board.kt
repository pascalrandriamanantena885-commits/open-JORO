package com.joro.calibrator

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.roundToInt

/**
 * Board colours = the four board SVGs of android/design/svg/board (square_<theme>_light / _dark, plain 450 x 450 squares).
 * The pieces are the SVGs in android/design/svg/pieces, rendered once to PNGs (res/drawable-nodpi, pc_wk ... pc_bp) by android/tools/svg_to_png.js
 * (the SVGs embed a shadow bitmap and use mix-blend-mode, which Android cannot draw itself).
 */
enum class BoardTheme(val label: String, val light: Color, val dark: Color) {
    BROWN("Brown", Color(0xFF7C4C3E), Color(0xFF512A2A)),
    GRAY("Gray", Color(0xFF595959), Color(0xFF363636));

    fun next(): BoardTheme = if (this == BROWN) GRAY else BROWN
}

/** The chosen theme, remembered between launches (SharedPreferences "joro"); read once in MainActivity.onCreate. */
object BoardStyle {
    var theme by mutableStateOf(BoardTheme.BROWN)
        private set
    private var loaded = false

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("joro", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val i = runCatching { prefs(ctx).getInt("boardTheme", 0) }.getOrDefault(0)
        theme = BoardTheme.values().getOrElse(i) { BoardTheme.BROWN }
    }

    fun toggle(ctx: Context) {
        theme = theme.next()
        runCatching { prefs(ctx).edit().putInt("boardTheme", theme.ordinal).apply() }
    }
}

// The PNGs were rendered at 0.8 px per SVG unit and a board square is 450 units: 360 px of PNG = one square.
// Every piece uses the same factor, so a pawn stays smaller than a king (as drawn in the SVGs).
private const val SQUARE_PX_IN_PNG = 360f

/** FEN letters (upper case = white) -> piece picture. */
@Composable
fun pieceImages(): Map<Char, ImageBitmap> = mapOf(
    'K' to ImageBitmap.imageResource(R.drawable.pc_wk), 'Q' to ImageBitmap.imageResource(R.drawable.pc_wq),
    'R' to ImageBitmap.imageResource(R.drawable.pc_wr), 'B' to ImageBitmap.imageResource(R.drawable.pc_wb),
    'N' to ImageBitmap.imageResource(R.drawable.pc_wn), 'P' to ImageBitmap.imageResource(R.drawable.pc_wp),
    'k' to ImageBitmap.imageResource(R.drawable.pc_bk), 'q' to ImageBitmap.imageResource(R.drawable.pc_bq),
    'r' to ImageBitmap.imageResource(R.drawable.pc_br), 'b' to ImageBitmap.imageResource(R.drawable.pc_bb),
    'n' to ImageBitmap.imageResource(R.drawable.pc_bn), 'p' to ImageBitmap.imageResource(R.drawable.pc_bp)
)

@Composable
fun ChessBoard(
    view: BoardView, flipped: Boolean, selected: Int?, targets: Set<Int>, last: Pair<Int, Int>?, onTap: (Int) -> Unit
) {
    val theme = BoardStyle.theme
    val images = pieceImages()
    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f)) {
        val cell = maxWidth / 8
        Column {
            for (row in 0 until 8) {
                Row {
                    for (col in 0 until 8) {
                        val file = if (flipped) 7 - col else col
                        val rank = if (flipped) row else 7 - row
                        val sq = rank * 8 + file
                        val dark = (file + rank) % 2 == 0              // a1 is a dark square
                        val isLast = last != null && (sq == last.first || sq == last.second)
                        val ch = view.cells[sq]
                        val piece = if (ch != '.') images[ch] else null
                        val isTarget = sq in targets
                        Canvas(Modifier.size(cell).clickable { onTap(sq) }) {
                            val side = size.width
                            drawRect(if (dark) theme.dark else theme.light)
                            if (isLast) drawRect(Color(0x66FFD54F))               // last move: translucent amber over the square
                            if (sq == selected) drawRect(Color(0x99FFEB3B))
                            if (piece != null) {
                                val k = side / SQUARE_PX_IN_PNG
                                val w = (piece.width * k).roundToInt()
                                val h = (piece.height * k).roundToInt()
                                drawImage(
                                    piece,
                                    dstOffset = IntOffset(((side - w) / 2f).roundToInt(), ((side - h) / 2f).roundToInt()),
                                    dstSize = IntSize(w, h),
                                    filterQuality = FilterQuality.High
                                )
                            }
                            if (isTarget) {                                           // light marks: visible on the dark boards
                                if (piece != null) drawCircle(Color(0xCCFFFFFF), radius = side * 0.46f, style = Stroke(width = side * 0.07f))
                                else drawCircle(Color(0xAAFFFFFF), radius = side / 6f)
                            }
                        }
                    }
                }
            }
        }
    }
}
