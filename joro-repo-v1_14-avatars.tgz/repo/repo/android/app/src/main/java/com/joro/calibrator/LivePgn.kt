package com.joro.calibrator

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * PGN of a LIVE game (not of training): standard tags (with SetUp / FEN when the game started from an edited position), the moves in
 * standard notation, and for every JORO move a [%eval] comment (White's point of view) that the usual PGN viewers show as a graph.
 * Written only when the user asks (save / share / copy); a live game never writes anything by itself.
 */
object LivePgn {
    fun fileName(): String =
        "joro-live-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".pgn"

    /** "1-0", "0-1", "1/2-1/2", or "*" while the game is not finished / was stopped. */
    fun resultTag(s: LiveState): String {
        val first = s.result.trim().substringBefore(' ')
        return if (first == "1-0" || first == "0-1" || first == "1/2-1/2") first else "*"
    }

    /** "+0.35" -> "0.35", "+M3" -> "#3", "-M2" -> "#-2" (the [%eval] notation). */
    private fun evalTag(e: String): String = when {
        e.startsWith("+M") -> "#" + e.substring(2)
        e.startsWith("-M") -> "#-" + e.substring(2)
        else -> e.removePrefix("+")
    }

    private fun quote(v: String) = v.replace("\\", "\\\\").replace("\"", "'")

    private fun comment(m: LiveMove): String = when {
        m.who != "JORO" -> ""
        m.fromExp -> "{experience" + (if (m.planD) ", plan D" else "") + "}"
        else -> "{[%eval ${evalTag(m.eval)},${m.depth}] plan ${when (m.plan) { 1 -> "A"; 2 -> "B"; 3 -> "C"; else -> "-" }}" + (if (m.planD) "+D" else "") + "}"
    }

    fun build(s: LiveState, date: Date = Date()): String {
        val result = resultTag(s)
        val sb = StringBuilder()
        fun tag(k: String, v: String) { sb.append('[').append(k).append(" \"").append(quote(v)).append("\"]\n") }
        tag("Event", "JORO Live")
        tag("Site", "JORO Calibrator")
        tag("Date", SimpleDateFormat("yyyy.MM.dd", Locale.US).format(date))
        tag("Round", "-")
        tag("White", s.white.ifEmpty { "?" })
        tag("Black", s.black.ifEmpty { "?" })
        tag("Result", result)
        if (s.openingName.isNotEmpty() && s.startFen.isEmpty() && s.openingName != "Position de depart") tag("Opening", s.openingName)
        if (s.startFen.isNotEmpty()) { tag("SetUp", "1"); tag("FEN", s.startFen) }
        tag("PlyCount", s.moves.size.toString())
        tag("Annotator", "JORO")
        if (s.result.isNotEmpty()) tag("Termination", s.result.substringAfter(' ').trim().ifEmpty { "normal" })
        sb.append('\n')

        // moves: the opening part as one block, then every played move with its comment
        val opening = LiveController.withStart(s.startFen) { Native.movesToSan(s.moves.take(s.openingLen).toIntArray()) } ?: ""
        val numRe = Regex("(\\d+)\\.")
        var moveNo = numRe.findAll(opening).lastOrNull()?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val tokens = ArrayList<String>()
        if (opening.isNotEmpty()) tokens.addAll(opening.split(' ').filter { it.isNotEmpty() })
        var afterComment = false
        s.log.forEach { m ->
            val label = m.label.trim()
            val hasNo = label.contains('.')
            if (hasNo) numRe.find(label)?.groupValues?.get(1)?.toIntOrNull()?.let { moveNo = it }
            // a black move that follows a comment needs its number again ("12... Nf6")
            if (!hasNo && afterComment && moveNo > 0) tokens.add("$moveNo...")
            tokens.addAll(label.split(' ').filter { it.isNotEmpty() })
            val c = comment(m)
            afterComment = c.isNotEmpty()
            if (c.isNotEmpty()) tokens.addAll(c.split(' '))
        }
        tokens.add(result)

        // 80 columns
        var line = StringBuilder()
        tokens.forEach { t ->
            if (line.isNotEmpty() && line.length + 1 + t.length > 80) { sb.append(line).append('\n'); line = StringBuilder() }
            if (line.isNotEmpty()) line.append(' ')
            line.append(t)
        }
        if (line.isNotEmpty()) sb.append(line).append('\n')
        return sb.toString()
    }

    /** Writes the PGN to a chosen document (system "save as"). Returns true on success. */
    fun writeTo(ctx: Context, text: String, uri: Uri): Boolean = runCatching {
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)); true } ?: false
    }.getOrDefault(false)

    /** Writes the PGN in the app cache and returns a shareable content:// uri (share sheet: Lichess, Drive, Messenger, ...). */
    fun toShareUri(ctx: Context, text: String): Uri? = runCatching {
        val dir = File(ctx.cacheDir, "live").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.endsWith(".pgn") }?.forEach { it.delete() }     // keep only the latest PGN
        val f = File(dir, fileName())
        f.writeText(text, Charsets.UTF_8)
        FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    }.getOrNull()
}
