package com.joro.calibrator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Keeps the SPSA tuning alive when the app is closed (foreground service + wake lock + notification with Pause / Atsaha). */
class TuneService : Service() {
    companion object {
        const val ACTION_STOP = "com.joro.calibrator.TUNE_STOP"
        const val ACTION_PAUSE = "com.joro.calibrator.TUNE_PAUSE"
        const val ACTION_RESUME = "com.joro.calibrator.TUNE_RESUME"
        private const val CHANNEL = "tuning"
        private const val ID_RUN = 5
        private const val ID_DONE = 6
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wake: PowerManager.WakeLock? = null
    private var lastUpdate = 0L
    private var lastPaused = false

    private fun acquireWake() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (wake == null) wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "joro:tuning").apply { setReferenceCounted(false) }
        wake?.let { if (!it.isHeld) it.acquire(12L * 60 * 60 * 1000) }
    }
    private fun releaseWake() { wake?.let { if (it.isHeld) it.release() } }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "JORO tuning", NotificationManager.IMPORTANCE_LOW))
        startForeground(ID_RUN, build("JORO tuning", "Manomboka...", 0, 0, true))
        acquireWake()

        scope.launch {
            TuneController.state.collect { st ->
                if (st.running) {
                    val now = System.currentTimeMillis()
                    val pauseChanged = st.paused != lastPaused
                    if (pauseChanged) { lastPaused = st.paused; if (st.paused) releaseWake() else acquireWake() }   // battery: no wake lock in pause
                    if (pauseChanged || now - lastUpdate >= 1500) {
                        lastUpdate = now
                        val title = (if (st.paused) "PAUSE - " else "") + if (st.verifying) "JORO fakana-pahaizana" else "JORO tuning"
                        val text = if (st.verifying) "batch ${st.verifyBatchesDone}/${st.verifyBatchesTotal}  +${st.verifyW} =${st.verifyD} −${st.verifyL}"
                                   else "iteration ${st.iteration}  lalao ${st.games}  farany +${st.lastW} =${st.lastD} −${st.lastL}"
                        val total = if (st.verifying) st.verifyBatchesTotal else st.maxIterations
                        val done = if (st.verifying) st.verifyBatchesDone else st.iteration
                        nm.notify(ID_RUN, build(title, text, done, total, true))
                    }
                } else {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    nm.notify(ID_DONE, build("Tuning vita", "iteration ${st.iteration}  lalao ${st.games}", 0, 0, false))
                    stopSelf()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> TuneController.stop()
            ACTION_PAUSE -> TuneController.setPaused(true)
            ACTION_RESUME -> TuneController.setPaused(false)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    private fun build(title: String, text: String, done: Int, total: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(title).setContentText(text)
            .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(ongoing)
        if (ongoing) {
            b.setProgress(total, done.coerceAtMost(total), total == 0)     // total 0 = no fixed end: indeterminate bar
            val stop = PendingIntent.getService(
                this, 7, Intent(this, TuneService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
            )
            val pr = PendingIntent.getService(
                this, 8, Intent(this, TuneService::class.java).setAction(if (lastPaused) ACTION_RESUME else ACTION_PAUSE), PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(0, if (lastPaused) "Tohizo" else "Pause", pr)
            b.addAction(0, "Atsaha", stop)
        } else b.setAutoCancel(true)
        return b.build()
    }
}
