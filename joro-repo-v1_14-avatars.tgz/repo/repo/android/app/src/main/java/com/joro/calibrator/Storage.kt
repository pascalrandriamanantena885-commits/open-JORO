package com.joro.calibrator

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

/** Result of "Ampiharo update": the release number and every file made for it (engine v*, zip, style, C++ header). */
data class UpdateResult(val release: Int, val files: List<File>)

data class ExpInfo(val version: Int, val entries: Long, val hasStyle: Boolean, val styleId: String, val styleName: String) {
    fun describe(): String =
        "$entries entries" + if (hasStyle) " | style $styleName ($styleId)" else " | no style"
}

/** Files of the app: engines, experience, history. Everything stays on the phone. */
class Storage(private val ctx: Context) {
    private val nativeDir: String get() = ctx.applicationInfo.nativeLibraryDir
    val bundledJoro: File get() = File(nativeDir, "libjoro.so")
    val stockfish: File get() = File(nativeDir, "libstockfish.so")
    val importedJoro: File get() = File(ctx.filesDir, "engines/joro_imported")
    val expFile: File get() = File(ctx.filesDir, "experience/joro.exp")
    val tuningDir: File get() = File(ctx.filesDir, "tuning")
    val tuneStateFile: File get() = File(tuningDir, "tune.state")        // SPSA state (resumable)
    val tunedStyleFile: File get() = File(tuningDir, "tuned.style")      // candidate: the tuned values after the last iteration
    val activeStyleFile: File get() = File(tuningDir, "active.style")    // the tuning that was applied (style weights + search constants)
    private val historyFile: File get() = File(ctx.filesDir, "history.json")

    /** The imported (updated) engine wins over the one bundled in the APK. */
    fun joroFile(): File = if (importedJoro.exists()) importedJoro else bundledJoro
    fun joroSource(): String = if (importedJoro.exists()) "imported" else "bundled"

    // ------------------------------------------------------------------ experience
    fun readExpInfo(f: File): ExpInfo? {
        if (!f.exists() || f.length() < 104) return null
        return try {
            val raw = ByteArray(104)
            DataInputStream(f.inputStream()).use { it.readFully(raw) }
            val b = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
            if (raw[0] != 'J'.code.toByte() || raw[1] != 'E'.code.toByte() || raw[2] != 'X'.code.toByte() || raw[3] != 'P'.code.toByte()) return null
            val version = b.getInt(4)
            val n = b.getInt(8).toLong() and 0xFFFFFFFFL
            val flags = b.getInt(12)
            val sid = b.getLong(16)
            var end = 24
            while (end < 40 && raw[end].toInt() != 0) end++
            val name = String(raw, 24, end - 24, Charsets.US_ASCII)
            if (version != 2) return null
            val body = 104 + n * 16
            if (f.length() < body) return null
            if (f.length() > body) {          // optional footer "JSTY": style parameters that do not fit the header, stored by name
                val tail = ByteArray(4)
                java.io.RandomAccessFile(f, "r").use { it.seek(body); it.readFully(tail) }
                if (String(tail, Charsets.US_ASCII) != "JSTY") return null
            }
            ExpInfo(version, n, (flags and 1) != 0, String.format(Locale.US, "%016x", sid), name)
        } catch (e: Exception) {
            null
        }
    }

    fun currentExpInfo(): ExpInfo? = readExpInfo(expFile)

    fun importExperience(uri: Uri): Result<ExpInfo> = runCatching {
        val tmp = File(ctx.cacheDir, "import.exp")
        ctx.contentResolver.openInputStream(uri)!!.use { input -> tmp.outputStream().use { input.copyTo(it) } }
        val info = readExpInfo(tmp) ?: run {
            tmp.delete()
            error("Tsy experience JORO mety ity fichier ity (header JEXP v2 / habe tsy mety)")
        }
        expFile.parentFile!!.mkdirs()
        tmp.copyTo(expFile, overwrite = true)
        tmp.delete()
        info
    }

    fun deleteExperience() { expFile.delete() }

    // ------------------------------------------------------------------ engine
    /** Imports a new JORO executable (arm64, built by build_engines_android.sh / the GitHub workflow). */
    fun importEngine(uri: Uri): Result<String> = runCatching {
        val tmp = File(ctx.filesDir, "engines/joro_new")
        tmp.parentFile!!.mkdirs()
        ctx.contentResolver.openInputStream(uri)!!.use { input -> tmp.outputStream().use { input.copyTo(it) } }
        tmp.setExecutable(true, false)
        tmp.setReadable(true, false)
        val e = UciEngine(tmp.absolutePath, "probe")
        if (!e.start()) {
            tmp.delete()
            error("Tsy mety hampandeha ny fichier (tsy executable arm64, na voasakana ny Android ny fampiasana azy avy ao anaty tahiry app).")
        }
        val ok = e.handshake()
        val name = e.idName
        e.quit()
        if (!ok || !name.startsWith("JORO")) {
            tmp.delete()
            error("Tsy mamaly UCI toa JORO ilay fichier.")
        }
        importedJoro.delete()
        if (!tmp.renameTo(importedJoro)) { tmp.copyTo(importedJoro, overwrite = true); tmp.delete() }
        importedJoro.setExecutable(true, false)
        name
    }

    fun removeImportedEngine() { importedJoro.delete() }

    // ------------------------------------------------------------------ PGN of the calibrations
    private val pgnDir: File get() = File(ctx.filesDir, "pgn")

    fun newPgnFile(ts: Long): File {
        pgnDir.mkdirs()
        return File(pgnDir, "JORO_vs_Stockfish_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(ts)) + ".pgn")
    }
    // ---- files of the training: PGN of every game (JORO_train_0001.pgn ...), per-opening table (CSV), Stockfish ladder level
    val trainPgnPrefix: String get() { pgnDir.mkdirs(); return File(pgnDir, "JORO_train").absolutePath }
    val trainStatsFile: File get() { pgnDir.mkdirs(); return File(pgnDir, "JORO_train_stats.csv") }
    val ladderFile: File get() = File(ctx.filesDir, "experience/joro.ladder")
    fun trainFiles(): List<String> =
        (pgnDir.listFiles() ?: emptyArray()).filter { it.name.startsWith("JORO_train") && it.length() > 0 }.map { it.name }.sorted()
    fun pgnFile(name: String): File? {
        if (name.isEmpty()) return null
        val f = File(pgnDir, File(name).name)
        return if (f.exists() && f.length() > 0) f else null
    }
    fun deletePgn(name: String) { pgnFile(name)?.delete() }

    fun copyTo(uri: Uri, file: File) {
        ctx.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
    }

    // ------------------------------------------------------------------ JORO update = JORO engine + experience
    private val updatesDir: File get() = File(ctx.filesDir, "updates")
    private val prefs get() = ctx.getSharedPreferences("joro", Context.MODE_PRIVATE)

    fun releaseNo(): Int = prefs.getInt("release", 0)
    fun releaseLabel(): String = if (releaseNo() == 0) "" else "U${releaseNo()}"

    fun expSha(): String {
        if (!expFile.exists()) return "none"
        val md = MessageDigest.getInstance("SHA-1")
        expFile.inputStream().use { i -> val buf = ByteArray(8192); while (true) { val n = i.read(buf); if (n < 0) break; md.update(buf, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }.substring(0, 8)
    }

    /** Every file of the releases: joro-v<n>-arm64 (engine), JORO-update-U<n>.zip, joro-v<n>.style, joro_tuned_v<n>.h. */
    fun listUpdates(): List<String> =
        (updatesDir.listFiles() ?: emptyArray()).filter { it.isFile && !it.name.endsWith(".tmp") }.sortedByDescending { it.lastModified() }.map { it.name }
    fun updateFile(name: String): File? = File(updatesDir, File(name).name).takeIf { it.exists() }
    fun deleteUpdate(name: String) { updateFile(name)?.delete() }

    /** Packs the engine in use + the current experience into one zip (the new JORO version). */
    fun createUpdate(sm: Summary?): Result<UpdateResult> = runCatching {
        check(expFile.exists()) { "Tsy misy experience hataovana JORO update." }
        val engine = joroFile()
        check(engine.exists()) { "Tsy hita ny moteur JORO." }
        val probe = UciEngine(engine.absolutePath, "probe")
        var name = "JORO"
        if (probe.start() && probe.handshake() && probe.idName.isNotEmpty()) name = probe.idName.replace(Regex(" v\\d+$"), "")   // a packed engine says "JORO 0.4 v5"
        probe.quit()
        val n = releaseNo() + 1
        val info = readExpInfo(expFile)
        val man = JSONObject()
        man.put("format", 1); man.put("release", n); man.put("label", "$name U$n"); man.put("engine", name)
        man.put("created", System.currentTimeMillis()); man.put("expSha", expSha())
        if (info != null) { man.put("entries", info.entries); man.put("styleId", info.styleId); man.put("styleName", info.styleName) }
        val tuning = activeStyleFile.takeIf { it.exists() }       // SPSA tuning applied on this phone (style weights + search constants)
        man.put("tuned", tuning != null)
        if (sm != null) {
            val c = JSONObject()
            c.put("overall", Elo.overallText(sm)); c.put("tc", sm.tcText); c.put("engine", sm.engineName)
            c.put("levels", JSONArray(sm.levels.map { "SF ${it.elo}: +${it.w} =${it.d} -${it.l} -> ${Elo.levelText(it)}" }))
            man.put("calibration", c)
        }
        updatesDir.mkdirs()
        val zip = File(updatesDir, "JORO-update-U$n.zip")
        ZipOutputStream(FileOutputStream(zip)).use { z ->
            z.putNextEntry(ZipEntry("manifest.json")); z.write(man.toString(2).toByteArray(Charsets.UTF_8)); z.closeEntry()
            z.putNextEntry(ZipEntry("joro")); engine.inputStream().use { it.copyTo(z) }; z.closeEntry()
            z.putNextEntry(ZipEntry("joro.exp")); expFile.inputStream().use { it.copyTo(z) }; z.closeEntry()
            if (tuning != null) { z.putNextEntry(ZipEntry("active.style")); tuning.inputStream().use { it.copyTo(z) }; z.closeEntry() }
        }
        // The same release as a single engine file: the tuning (style + search + plans) and the experience are packed INSIDE the
        // executable (src/embed.h), so it can be loaded as it is by another chess app / program, without any side file.
        val files = mutableListOf(zip)
        val engOut = File(updatesDir, "joro-v$n-arm64")
        val err = Native.packEngine(engine.absolutePath, engOut.absolutePath, tuning?.absolutePath ?: "", expFile.absolutePath, "v$n")
        check(err.isEmpty()) { "Tsy afaka namorona ny moteur v$n: $err" }
        engOut.setExecutable(true, false)
        val chk = UciEngine(engOut.absolutePath, "probe")
        val okEngine = chk.start() && chk.handshake() && chk.idName.startsWith("JORO") && chk.idName.endsWith("v$n")
        chk.quit()
        if (!okEngine) { engOut.delete(); zip.delete(); error("Tsy mandeha ny moteur v$n vao noforonina (UCI handshake). Tsy nisy update natao.") }
        files.add(0, engOut)
        if (tuning != null) {                                              // for the code: the tuned values, as a JSON style and as a C++ header
            val styleOut = File(updatesDir, "joro-v$n.style")
            tuning.copyTo(styleOut, overwrite = true)
            files.add(styleOut)
            val header = Native.tuningHeader(tuning.absolutePath, "v$n")
            if (header.isNotEmpty()) { val h = File(updatesDir, "joro_tuned_v$n.h"); h.writeText(header); files.add(h) }
        }
        prefs.edit().putInt("release", n).apply()
        UpdateResult(n, files)
    }

    /** Installs a JORO update zip (engine + experience) made by another phone / by this app. */
    fun importUpdate(uri: Uri): Result<String> = runCatching {
        val tmpZip = File(ctx.cacheDir, "update.zip")
        ctx.contentResolver.openInputStream(uri)!!.use { input -> tmpZip.outputStream().use { input.copyTo(it) } }
        val engTmp = File(ctx.filesDir, "engines/joro_new")
        val expTmp = File(ctx.cacheDir, "update.exp")
        val styleTmp = File(ctx.cacheDir, "update.style")
        styleTmp.delete()
        engTmp.parentFile!!.mkdirs()
        var manifestText: String? = null
        var hasEngine = false
        var hasExp = false
        var hasStyle = false
        ZipInputStream(tmpZip.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                when (e.name) {
                    "manifest.json" -> manifestText = z.readBytes().toString(Charsets.UTF_8)
                    "joro" -> { engTmp.outputStream().use { z.copyTo(it) }; hasEngine = true }
                    "joro.exp" -> { expTmp.outputStream().use { z.copyTo(it) }; hasExp = true }
                    "active.style" -> { styleTmp.outputStream().use { z.copyTo(it) }; hasStyle = true }
                }
                z.closeEntry()
                e = z.nextEntry
            }
        }
        tmpZip.delete()
        val mt = manifestText ?: error("Tsy JORO update ity zip ity (tsy misy manifest.json).")
        val man = JSONObject(mt)
        check(hasExp && readExpInfo(expTmp) != null) { "Experience ao anaty update tsy mety." }
        if (hasStyle) {                                           // the tuning must be a style file with a "weights" object
            val ok = runCatching { JSONObject(styleTmp.readText()).getJSONObject("weights") }.isSuccess
            if (!ok) { styleTmp.delete(); error("Ny tuning (active.style) ao anaty update dia tsy mety.") }
        }
        if (hasEngine) {
            engTmp.setExecutable(true, false)
            val e = UciEngine(engTmp.absolutePath, "probe")
            val ok = e.start() && e.handshake() && e.idName.startsWith("JORO")
            e.quit()
            if (!ok) { engTmp.delete(); error("Ny moteur ao anaty update dia tsy mandeha (arm64 UCI JORO).") }
            importedJoro.delete()
            if (!engTmp.renameTo(importedJoro)) { engTmp.copyTo(importedJoro, overwrite = true); engTmp.delete() }
            importedJoro.setExecutable(true, false)
        }
        expFile.parentFile!!.mkdirs()
        expTmp.copyTo(expFile, overwrite = true)
        expTmp.delete()
        // The update is the WHOLE JORO of its maker: its tuning replaces the local one (an update without tuning = built-in values).
        // The header of the experience already carries the style weights; only the search constants need active.style.
        tuningDir.mkdirs()
        if (hasStyle) {
            styleTmp.copyTo(activeStyleFile, overwrite = true)
            styleTmp.delete()
            Native.applyTuning(activeStyleFile.absolutePath, "")
        } else {
            activeStyleFile.delete()
            Native.applyTuning("", "")
        }
        prefs.edit().putInt("release", man.optInt("release", releaseNo())).apply()
        man.optString("label", "JORO update") + if (hasStyle) " + tuning" else ""
    }

    // ------------------------------------------------------------------ history
    fun loadHistory(): List<Summary> {
        return try {
            if (!historyFile.exists()) return emptyList()
            val arr = JSONArray(historyFile.readText())
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addHistory(sm: Summary) {
        val all = loadHistory() + sm
        val arr = JSONArray()
        all.takeLast(200).forEach { arr.put(toJson(it)) }
        historyFile.writeText(arr.toString())
    }

    fun clearHistory() { historyFile.delete() }

    private fun toJson(s: Summary): JSONObject {
        val o = JSONObject()
        o.put("t", s.timestamp); o.put("engine", s.engineName); o.put("exp", s.experience); o.put("tc", s.tcText)
        o.put("overall", s.overall ?: JSONObject.NULL); o.put("ob", s.overallBound.name); o.put("partial", s.partial)
        o.put("pgn", s.pgn); o.put("sha", s.expSha)
        val a = JSONArray()
        for (r in s.levels) {
            val j = JSONObject()
            j.put("elo", r.elo); j.put("w", r.w); j.put("d", r.d); j.put("l", r.l)
            j.put("score", r.score); j.put("est", r.estimate); j.put("hw", r.halfWidth); j.put("b", r.bound.name)
            a.put(j)
        }
        o.put("levels", a)
        return o
    }

    private fun fromJson(o: JSONObject): Summary {
        val a = o.getJSONArray("levels")
        val levels = (0 until a.length()).map {
            val j = a.getJSONObject(it)
            LevelResult(j.getInt("elo"), j.getInt("w"), j.getInt("d"), j.getInt("l"), j.getDouble("score"),
                j.getDouble("est"), j.getDouble("hw"), Bound.valueOf(j.getString("b")))
        }
        return Summary(o.getLong("t"), o.getString("engine"), o.getString("exp"), o.getString("tc"), levels,
            if (o.isNull("overall")) null else o.getDouble("overall"), Bound.valueOf(o.getString("ob")), o.getBoolean("partial"),
            o.optString("pgn", ""), o.optString("sha", "none"))
    }
}
