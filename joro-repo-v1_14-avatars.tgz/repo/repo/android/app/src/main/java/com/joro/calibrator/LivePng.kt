package com.joro.calibrator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.FileProvider
import java.io.File

/**
 * PNG picture of a LIVE game (not of training): header, both player names, the board with the last move, the result, JORO's last
 * evaluation and the moves in standard notation. Drawn directly with android.graphics, so it does not depend on what is on screen
 * and has the same size on every phone.
 */
object LivePng {
    private const val W = 1080            // picture width in pixels
    private const val MARGIN = 40
    private const val BOARD = W - 2 * MARGIN

    private val BG = Color.parseColor("#0F1115")
    private val PANEL = Color.parseColor("#1A1E26")
    private val TEXT = Color.WHITE
    private val SUB = Color.parseColor("#B5BCC9")
    private val ACCENT = Color.parseColor("#A9C8FF")

    private val pieceRes = mapOf(
        'K' to R.drawable.pc_wk, 'Q' to R.drawable.pc_wq, 'R' to R.drawable.pc_wr, 'B' to R.drawable.pc_wb,
        'N' to R.drawable.pc_wn, 'P' to R.drawable.pc_wp,
        'k' to R.drawable.pc_bk, 'q' to R.drawable.pc_bq, 'r' to R.drawable.pc_br, 'b' to R.drawable.pc_bb,
        'n' to R.drawable.pc_bn, 'p' to R.drawable.pc_bp
    )

    private fun tp(color: Int, size: Float, bold: Boolean = false, mono: Boolean = false) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        textSize = size
        typeface = Typeface.create(if (mono) Typeface.MONOSPACE else Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    /** One line of text clipped with "..." so a long engine name never leaves the picture. */
    private fun fit(text: String, paint: TextPaint, maxWidth: Float): String =
        android.text.TextUtils.ellipsize(text, paint, maxWidth, android.text.TextUtils.TruncateAt.END).toString()

    fun render(ctx: Context, s: LiveState, flipped: Boolean, theme: BoardTheme): Bitmap? {
        val arr = s.moves.toIntArray()
        val board = parseBoard(Native.boardInfo(arr)) ?: return null
        val last = s.moves.lastOrNull()?.let { Pair(moveFrom(it), moveTo(it)) }

        // ---- text blocks first: their height decides the height of the picture
        val movesPaint = tp(TEXT, 30f, mono = true)
        val movesText = if (s.sanLine.isEmpty()) (if (s.startFen.isEmpty()) "(position de depart)" else "(position edited)") else s.sanLine
        val movesLayout = StaticLayout.Builder.obtain(movesText, 0, movesText.length, movesPaint, W - 2 * MARGIN - 40)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(6f, 1f).build()

        val lastJoro = s.log.lastOrNull { it.who == "JORO" }
        val infoLines = ArrayList<String>()
        if (s.openingName.isNotEmpty()) infoLines.add("Opening: ${s.openingName}")
        if (s.startFen.isNotEmpty()) infoLines.add("FEN: ${s.startFen}")
        if (lastJoro != null) {
            infoLines.add(
                "JORO " + lastJoro.label + "   " +
                    (if (lastJoro.fromExp) "experience (tsy nisy fikarohana)" else "eval ${lastJoro.eval}  depth ${lastJoro.depth}") +
                    "   plan " + when (lastJoro.plan) { 1 -> "A"; 2 -> "B"; 3 -> "C"; else -> "-" } + (if (lastJoro.planD) " + D" else "")
            )
        }
        if (s.expInfo.isNotEmpty()) infoLines.add(s.expInfo)

        val headerH = 110
        val nameH = 70
        val resultH = 90
        val infoH = if (infoLines.isEmpty()) 0 else 30 + infoLines.size * 44
        val movesH = movesLayout.height + 70
        val footerH = 70
        val height = headerH + nameH + BOARD + nameH + resultH + infoH + movesH + footerH

        val bmp = Bitmap.createBitmap(W, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(BG)

        var y = 0f
        // ---- header
        c.drawText("JORO", MARGIN.toFloat(), 70f, tp(ACCENT, 56f, bold = true))
        val sub = tp(SUB, 30f)
        val tag = if (s.running) "Lalao Live (mbola mandeha)" else "Lalao Live"
        c.drawText(tag, W - MARGIN - sub.measureText(tag), 66f, sub)
        y += headerH

        // ---- top player, board, bottom player
        val nameP = tp(TEXT, 38f, bold = true)
        val topIsBlack = !flipped
        val topName = if (topIsBlack) s.black else s.white
        val botName = if (topIsBlack) s.white else s.black
        fun drawName(name: String, isWhite: Boolean, top: Float) {
            val r = RectF(MARGIN.toFloat(), top + 6f, (W - MARGIN).toFloat(), top + nameH - 6f)
            c.drawRoundRect(r, 16f, 16f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = PANEL })
            val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (isWhite) Color.WHITE else Color.BLACK }
            c.drawCircle(r.left + 30f, r.centerY(), 13f, dot)
            c.drawCircle(r.left + 30f, r.centerY(), 13f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = SUB; style = Paint.Style.STROKE; strokeWidth = 2f
            })
            // round JORO / Stockfish picture (same icons as the app, see PlayerAvatar)
            val resId = when {
                name.startsWith("JORO", ignoreCase = true) -> R.drawable.joro_avatar
                name.contains("Stockfish", ignoreCase = true) -> R.drawable.stockfish_avatar
                else -> 0
            }
            var textX = r.left + 70f
            if (resId != 0) {
                val bmp = android.graphics.BitmapFactory.decodeResource(ctx.resources, resId)
                if (bmp != null) {
                    val rad = (r.height() - 16f) / 2f
                    val cx = r.left + 62f + rad
                    val save = c.save()
                    val clip = android.graphics.Path().apply { addCircle(cx, r.centerY(), rad, android.graphics.Path.Direction.CW) }
                    c.clipPath(clip)
                    c.drawBitmap(bmp, null, RectF(cx - rad, r.centerY() - rad, cx + rad, r.centerY() + rad), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                    c.restoreToCount(save)
                    textX = cx + rad + 18f
                }
            }
            c.drawText(fit(name.ifEmpty { "-" }, nameP, r.right - textX - 20f), textX, r.centerY() + 13f, nameP)
        }
        drawName(topName, !topIsBlack, y)
        y += nameH

        val bx = MARGIN.toFloat()
        val by = y
        drawBoard(c, ctx, board, flipped, last, theme, bx, by)
        y += BOARD

        drawName(botName, topIsBlack, y)
        y += nameH

        // ---- result bar
        val resultText = when {
            s.result.isNotEmpty() -> s.result
            s.running -> "Mbola mandeha"
            s.message.isNotEmpty() -> s.message
            else -> ""
        }
        if (resultText.isNotEmpty()) {
            val rp = tp(if (s.result.isNotEmpty()) ACCENT else SUB, 36f, bold = true)
            val r = RectF(MARGIN.toFloat(), y + 12f, (W - MARGIN).toFloat(), y + resultH - 8f)
            c.drawRoundRect(r, 16f, 16f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = PANEL })
            c.drawText(fit(resultText, rp, r.width() - 40f), r.left + 20f, r.centerY() + 13f, rp)
        }
        y += resultH

        // ---- info lines
        if (infoLines.isNotEmpty()) {
            val ip = tp(SUB, 30f)
            var ly = y + 30f + 30f
            infoLines.forEach { line ->
                c.drawText(fit(line, ip, (W - 2 * MARGIN).toFloat()), MARGIN.toFloat(), ly, ip)
                ly += 44f
            }
            y += infoH
        }

        // ---- moves
        val r = RectF(MARGIN.toFloat(), y + 10f, (W - MARGIN).toFloat(), y + movesH - 10f)
        c.drawRoundRect(r, 16f, 16f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = PANEL })
        c.save()
        c.translate(r.left + 20f, r.top + 25f)
        movesLayout.draw(c)
        c.restore()
        y += movesH

        // ---- footer
        val fp = tp(SUB, 24f)
        val foot = "JORO Calibrator  -  ${s.moves.size} plies"
        c.drawText(foot, (W - fp.measureText(foot)) / 2f, y + 42f, fp)
        return bmp
    }

    private fun drawBoard(c: Canvas, ctx: Context, view: BoardView, flipped: Boolean, last: Pair<Int, Int>?, theme: BoardTheme, ox: Float, oy: Float) {
        val sq = BOARD / 8f
        val light = Paint().apply { color = theme.light.toArgb() }
        val dark = Paint().apply { color = theme.dark.toArgb() }
        val hl = Paint().apply { color = Color.argb(0x66, 0xFF, 0xD5, 0x4F) }
        val pieces = HashMap<Char, Bitmap>()
        pieceRes.forEach { (ch, id) ->
            val o = BitmapFactory.Options().apply { inScaled = false }
            BitmapFactory.decodeResource(ctx.resources, id, o)?.let { pieces[ch] = it }
        }
        val pp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val coord = tp(Color.argb(190, 255, 255, 255), 22f, bold = true)
        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val file = if (flipped) 7 - col else col
                val rank = if (flipped) row else 7 - row
                val s = rank * 8 + file
                val left = ox + col * sq
                val top = oy + row * sq
                c.drawRect(left, top, left + sq, top + sq, if ((file + rank) % 2 == 0) dark else light)   // a1 is a dark square
                if (last != null && (s == last.first || s == last.second)) c.drawRect(left, top, left + sq, top + sq, hl)
                val ch = view.cells[s]
                val bm = if (ch != '.') pieces[ch] else null
                if (bm != null) {
                    val k = sq / 360f                                   // 360 px of PNG = one square (same factor as ChessBoard)
                    val w = bm.width * k
                    val h = bm.height * k
                    val dst = RectF(left + (sq - w) / 2f, top + (sq - h) / 2f, left + (sq + w) / 2f, top + (sq + h) / 2f)
                    c.drawBitmap(bm, null, dst, pp)
                }
                if (col == 0) c.drawText(('1' + rank).toString(), left + 6f, top + 24f, coord)
                if (row == 7) c.drawText(('a' + file).toString(), left + sq - 20f, top + sq - 8f, coord)
            }
        }
        pieces.values.forEach { it.recycle() }
    }

    /** File name like joro-live-20261118-1432.png */
    fun fileName(): String =
        "joro-live-" + java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(java.util.Date()) + ".png"

    /** Writes the picture to a chosen document (system "save as"). Returns true on success. */
    fun writeTo(ctx: Context, bmp: Bitmap, uri: Uri): Boolean = runCatching {
        ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } ?: false
    }.getOrDefault(false)

    /** Writes the picture in the app cache and returns a shareable content:// uri (share sheet: Messenger, Drive, ...). */
    fun toShareUri(ctx: Context, bmp: Bitmap): Uri? = runCatching {
        val dir = File(ctx.cacheDir, "live").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }                       // keep only the latest picture
        val f = File(dir, fileName())
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    }.getOrNull()
}
