package com.joro.calibrator

import kotlin.math.abs

/**
 * Board editor of the Training tab. Works on 64 cells indexed like BoardView.cells: index = rank * 8 + file (a1 = 0, h8 = 63),
 * upper case = White, lower case = Black, '.' = empty. No native call here: the position is only turned into a FEN, which the
 * engine then uses as the start position of the training.
 */
object BoardEditor {
    const val STANDARD_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    fun startCells(): List<Char> {
        val back = "RNBQKBNR"
        val c = MutableList(64) { '.' }
        for (f in 0 until 8) {
            c[f] = back[f]; c[8 + f] = 'P'
            c[48 + f] = 'p'; c[56 + f] = back[f].lowercaseChar()
        }
        return c
    }

    /** Castling rights are not asked: a right exists when the king and the rook stand on their home squares. */
    private fun castling(c: List<Char>): String {
        val sb = StringBuilder()
        if (c[4] == 'K' && c[7] == 'R') sb.append('K')
        if (c[4] == 'K' && c[0] == 'R') sb.append('Q')
        if (c[60] == 'k' && c[63] == 'r') sb.append('k')
        if (c[60] == 'k' && c[56] == 'r') sb.append('q')
        return if (sb.isEmpty()) "-" else sb.toString()
    }

    fun toFen(c: List<Char>, whiteToMove: Boolean): String {
        val sb = StringBuilder()
        for (r in 7 downTo 0) {
            var empty = 0
            for (f in 0 until 8) {
                val ch = c[r * 8 + f]
                if (ch == '.') { empty++; continue }
                if (empty > 0) { sb.append(empty); empty = 0 }
                sb.append(ch)
            }
            if (empty > 0) sb.append(empty)
            if (r > 0) sb.append('/')
        }
        sb.append(if (whiteToMove) " w " else " b ").append(castling(c)).append(" - 0 1")
        return sb.toString()
    }

    /** Short readable name that tells two edited positions apart in the per-opening table. */
    fun nameOf(fen: String): String = "Position edited " + Integer.toHexString(fen.hashCode()).takeLast(4)

    private fun isWhite(ch: Char) = ch.isUpperCase()

    /** Is square [sq] attacked by the given colour? */
    private fun attacked(c: List<Char>, sq: Int, byWhite: Boolean): Boolean {
        val f = sq % 8
        val r = sq / 8
        fun at(ff: Int, rr: Int): Char = if (ff in 0..7 && rr in 0..7) c[rr * 8 + ff] else '#'
        val pawn = if (byWhite) 'P' else 'p'
        val pr = if (byWhite) r - 1 else r + 1
        if (at(f - 1, pr) == pawn || at(f + 1, pr) == pawn) return true
        val knight = if (byWhite) 'N' else 'n'
        for ((df, dr) in listOf(1 to 2, 2 to 1, -1 to 2, -2 to 1, 1 to -2, 2 to -1, -1 to -2, -2 to -1)) {
            if (at(f + df, r + dr) == knight) return true
        }
        val king = if (byWhite) 'K' else 'k'
        for (df in -1..1) for (dr in -1..1) if ((df != 0 || dr != 0) && at(f + df, r + dr) == king) return true
        val queen = if (byWhite) 'Q' else 'q'
        val rook = if (byWhite) 'R' else 'r'
        val bishop = if (byWhite) 'B' else 'b'
        for ((df, dr) in listOf(1 to 0, -1 to 0, 0 to 1, 0 to -1, 1 to 1, 1 to -1, -1 to 1, -1 to -1)) {
            val diagonal = df != 0 && dr != 0
            var ff = f + df
            var rr = r + dr
            while (ff in 0..7 && rr in 0..7) {
                val p = c[rr * 8 + ff]
                if (p != '.') {
                    if (p == queen || (diagonal && p == bishop) || (!diagonal && p == rook)) return true
                    break
                }
                ff += df; rr += dr
            }
        }
        return false
    }

    /** null = the position can be played; otherwise the reason (Malagasy), shown under the board. */
    fun validate(c: List<Char>, whiteToMove: Boolean): String? {
        if (c.size != 64) return "Board tsy mety."
        val wk = c.indices.filter { c[it] == 'K' }
        val bk = c.indices.filter { c[it] == 'k' }
        if (wk.size != 1) return "Mila Roi fotsy tokana (ankehitriny: ${wk.size})."
        if (bk.size != 1) return "Mila Roi mainty tokana (ankehitriny: ${bk.size})."
        for (i in c.indices) if ((c[i] == 'P' || c[i] == 'p') && (i / 8 == 0 || i / 8 == 7)) return "Tsy mety ny pion eo amin'ny rang voalohany na farany."
        if (c.count { it == 'P' } > 8 || c.count { it == 'p' } > 8) return "Mihoatra ny pion 8 ny iray tafiny."
        if (c.count { it != '.' && isWhite(it) } > 16 || c.count { it != '.' && !isWhite(it) } > 16) return "Mihoatra ny 16 ny kapila an'ny iray tafiny."
        if (abs(wk[0] % 8 - bk[0] % 8) <= 1 && abs(wk[0] / 8 - bk[0] / 8) <= 1) return "Tsy azo mifanila ny roi roa."
        if (c.all { it == '.' || it == 'K' || it == 'k' }) return "Roi roa ihany: material tsy ampy (draw avy hatrany)."
        // the side that does NOT move cannot be in check (it would mean the previous move was illegal)
        if (whiteToMove && attacked(c, bk[0], byWhite = true)) return "Ao anaty echec ny Roi mainty fa ny Fotsy no mandroso: tsy azo."
        if (!whiteToMove && attacked(c, wk[0], byWhite = false)) return "Ao anaty echec ny Roi fotsy fa ny Mainty no mandroso: tsy azo."
        return null
    }
}
