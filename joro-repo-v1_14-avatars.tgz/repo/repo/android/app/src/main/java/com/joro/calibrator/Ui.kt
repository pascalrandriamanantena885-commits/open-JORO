package com.joro.calibrator

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Shared building blocks, so every tab has the same structure:
 *   Page { SectionHeader + JoroCard { ... } + JoroCard { ... } }
 * "Hover" on a phone = the pressed state: the card rises (elevation) and shrinks very slightly while the finger is down.
 */

/** Scrollable page with the same margins and spacing on every tab. */
@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

/** Title + optional one-line help of a group of cards. */
@Composable
fun SectionHeader(title: String, hint: String = "") {
    Column(Modifier.padding(start = 4.dp, top = 4.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        if (hint.isNotEmpty()) Text(hint, style = MaterialTheme.typography.bodySmall)
    }
}

/**
 * A card with rounded corners, a thin outline and a press ("hover") effect.
 * [onClick] == null -> a plain card that still reacts a little to touch is NOT wanted (it would look tappable): no effect then.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JoroCard(
    modifier: Modifier = Modifier,
    title: String = "",
    onClick: (() -> Unit)? = null,
    padded: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val elevation by animateDpAsState(if (pressed && onClick != null) 8.dp else 1.dp, label = "cardElevation")
    val scale by animateFloatAsState(if (pressed && onClick != null) 0.985f else 1f, label = "cardScale")
    val shape = RoundedCornerShape(18.dp)
    val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    val border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (pressed) 0.9f else 0.35f))
    val body: @Composable ColumnScope.() -> Unit = {
        Column(Modifier.fillMaxWidth().padding(if (padded) 14.dp else 0.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (title.isNotEmpty()) Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
    if (onClick != null) {
        Card(
            onClick = onClick, interactionSource = source, shape = shape, colors = colors, border = border,
            elevation = CardDefaults.cardElevation(defaultElevation = elevation),
            modifier = modifier.fillMaxWidth().scale(scale), content = body
        )
    } else {
        Card(
            shape = shape, colors = colors, border = border,
            elevation = CardDefaults.cardElevation(defaultElevation = elevation),
            modifier = modifier.fillMaxWidth(), content = body
        )
    }
}

/** Small rounded label: "Draw 3", "Plan B", "Eval +0.35"... */
@Composable
fun Chip(text: String, highlight: Boolean = false) {
    Surface(
        shape = RoundedCornerShape(50),
        color = if (highlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
        contentColor = if (highlight) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        Text(text, Modifier.padding(horizontal = 12.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall)
    }
}

/** A label on the left and a value on the right (info rows inside a card). */
@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.width(8.dp))
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

/** Two big numbers side by side (e.g. Elo / games). */
@Composable
fun BigStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

/** Row of a switch + its explanation (the same look on every tab). */
@Composable
fun SwitchRow(checked: Boolean, onChange: (Boolean) -> Unit, text: String, enabled: Boolean = true) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        androidx.compose.material3.Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
    }
}


/**
 * Default picture of a player (round): JORO or Stockfish. One place for every screen that shows a player, so the same icon appears
 * everywhere. The name decides (starts with "JORO" -> JORO, contains "Stockfish" -> Stockfish); any other name shows nothing.
 * The same PNGs (512 px, transparent corners) are in android/design/avatars/ for use outside this app.
 */
@Composable
fun PlayerAvatar(name: String, size: androidx.compose.ui.unit.Dp = 32.dp) {
    val res = when {
        name.startsWith("JORO", ignoreCase = true) -> R.drawable.joro_avatar
        name.contains("Stockfish", ignoreCase = true) -> R.drawable.stockfish_avatar
        else -> return
    }
    Image(
        painterResource(res), contentDescription = name, contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(CircleShape)
    )
}
