package com.joro.calibrator

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private fun onlyDigits(v: String) = v.filter { it.isDigit() }

/** Tuned-vs-start games: score, Elo with a 95% interval and a plain verdict. */
private fun verifyLine(w: Int, d: Int, l: Int): String {
    val n = w + d + l
    if (n == 0) return "Mbola tsy misy lalao fakana-pahaizana."
    val p = (w + 0.5 * d) / n
    val v = (w * (1 - p) * (1 - p) + d * (0.5 - p) * (0.5 - p) + l * p * p) / n
    val se = Math.sqrt(v / n)
    fun elo(q: Double): Double { val c = q.coerceIn(0.001, 0.999); return -400.0 * Math.log10(1.0 / c - 1.0) }
    val verdict = when {
        p - 1.96 * se > 0.5 -> "Nihatsara tokoa (95%)."
        p + 1.96 * se < 0.5 -> "Nihena (95%): aza ampiharina."
        else -> "Tsy mbola mazava (mila lalao maro kokoa; 200+ farafahakeliny)."
    }
    return String.format(
        Locale.US, "tuned vs fanombohana: +%d =%d −%d (%d lalao)  %.1f%%\nElo %+.0f  [%+.0f ; %+.0f]\n%s",
        w, d, l, n, 100 * p, elo(p), elo(p - 1.96 * se), elo(p + 1.96 * se), verdict
    )
}

@Composable
fun TuneTab() {
    val ctx = LocalContext.current
    val t by TuneController.state.collectAsState()
    val running = t.running
    val cores = Runtime.getRuntime().availableProcessors()
    var pairs by remember { mutableStateOf("8") }
    var ms by remember { mutableStateOf("40") }
    var threads by remember { mutableStateOf((cores / 2).coerceIn(1, 4).toString()) }
    var maxIter by remember { mutableStateOf("0") }
    var verifyBatches by remember { mutableStateOf("10") }
    var tuneStyle by remember { mutableStateOf(true) }
    var tuneSearch by remember { mutableStateOf(true) }
    var tunePlans by remember { mutableStateOf(true) }
    var resume by remember { mutableStateOf(true) }
    var note by remember { mutableStateOf("") }
    var rev by remember { mutableIntStateOf(0) }                       // bumped after apply / reset to re-read the files
    val hasCandidate = remember(running, rev) { TuneController.hasCandidate(ctx) }
    val hasActive = remember(running, rev) { TuneController.hasActive(ctx) }

    Page {
        JoroCard(title = "SPSA tuning") {
            Text(
                "JORO manao lalao amin'ny tenany amin'ny lanja style (own_king, pins, king_hunt...) sy ny constants an'ny search (futility, null move, LMR...) " +
                    "miova kely roa lafiny. Ny lafiny mandresy no arahina; averina an'arivony. Ny valiny dia averina mampitovy (EMA) mba tsy ho tabataba.",
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                "Azo atao pause/tohizo na oviana na oviana: ny lalao mandry amin'ny hetsika manaraka (tsy misy CPU). " +
                    "Voatahiry isaky ny iteration, ka tsy very na dia tapaka aza ny app.",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(if (hasActive) "Tuning mihandry: eny" else "Tuning mihandry: tsia", highlight = hasActive)
                Chip("${cores} core")
            }
        }

        JoroCard(title = "Fikirana") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(pairs, { pairs = onlyDigits(it) }, label = { Text("Opening/iteration") }, enabled = !running, singleLine = true,
                    modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(ms, { ms = onlyDigits(it) }, label = { Text("ms/hetsika") }, enabled = !running, singleLine = true,
                    modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(threads, { threads = onlyDigits(it) }, label = { Text("Miaraka (threads)") }, enabled = !running, singleLine = true,
                    modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(maxIter, { maxIter = onlyDigits(it) }, label = { Text("Iteration max (0 = tsy misy)") }, enabled = !running, singleLine = true,
                    modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Text("Lalao isaky ny iteration: ${2 * (pairs.toIntOrNull() ?: 8).coerceAtLeast(1)}  (misy ${cores} core ao amin'ny finday: tazony ny threads <= ${(cores / 2).coerceAtLeast(1)})", style = MaterialTheme.typography.bodySmall)
        }

        JoroCard(title = "Inona no tononina") {
            SwitchRow(tuneStyle, { tuneStyle = it }, "Ny lanja style (14)", enabled = !running)
            SwitchRow(tuneSearch, { tuneSearch = it }, "Ny constants an'ny search (7)", enabled = !running)
            SwitchRow(tunePlans, { tunePlans = it }, "Ny plan A / B / C (18: lanja sy toerana)", enabled = !running)
            SwitchRow(resume, { resume = it }, "Tohizo ny tuning teo aloha (raha misy)", enabled = !running)
        }

        if (!running) {
            Button(
                onClick = {
                    rev++
                    note = TuneController.start(
                        ctx,
                        TuneParams(
                            pairs = (pairs.toIntOrNull() ?: 8).coerceIn(1, 64),
                            movetimeMs = (ms.toIntOrNull() ?: 40).coerceIn(5, 2000),
                            threads = (threads.toIntOrNull() ?: 2).coerceIn(1, 8),
                            tuneStyle = tuneStyle, tuneSearch = tuneSearch, tunePlans = tunePlans, resume = resume,
                            maxIterations = (maxIter.toIntOrNull() ?: 0).coerceAtLeast(0)
                        )
                    ) ?: ""
                },
                enabled = tuneStyle || tuneSearch || tunePlans,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (resume) "Hanomboka / hanohy" else "Hanomboka vaovao") }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { TuneController.setPaused(!t.paused) }, modifier = Modifier.weight(1f)) {
                    Text(if (t.paused) "Tohizo (play)" else "Pause")
                }
                OutlinedButton(onClick = { TuneController.stop() }, modifier = Modifier.weight(1f)) { Text("Atsaha") }
            }
            if (t.paused) {
                Text(
                    if (t.sleeping) "PAUSE: matory ny moteur, tsy mampiasa CPU."
                    else "PAUSE: miandry ny hetsika manaraka...",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Text("Mitohy ao ambadika (notification), na dia akatona aza ny app.", style = MaterialTheme.typography.bodySmall)
        }

        if (t.running || t.iteration > 0) {
            JoroCard(title = if (t.verifying) "Fakana-pahaizana" else "Fandrosoana") {
                if (t.verifying) {
                    Text("Batch ${t.verifyBatchesDone}/${t.verifyBatchesTotal}", fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(
                        progress = { if (t.verifyBatchesTotal == 0) 0f else t.verifyBatchesDone.toFloat() / t.verifyBatchesTotal },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    Row(Modifier.fillMaxWidth()) {
                        BigStat("iteration", "${t.iteration}", Modifier.weight(1f))
                        BigStat("lalao", "${t.games}", Modifier.weight(1f))
                    }
                    if (t.maxIterations > 0) {
                        LinearProgressIndicator(progress = { (t.iteration.toFloat() / t.maxIterations).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    }
                    if (t.iteration > 0) {
                        Text("Iteration farany (lafiny \"+\"): +${t.lastW} =${t.lastD} −${t.lastL}", style = MaterialTheme.typography.bodySmall)
                        if (t.recent.isNotEmpty()) {
                            Text("W−L (40 farany): " + t.recent.takeLast(16).joinToString(" ") { String.format(Locale.US, "%+d", it) },
                                fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
        if (t.message.isNotEmpty()) Text(t.message, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
        if (note.isNotEmpty()) Text(note, color = MaterialTheme.colorScheme.error)

        if (t.table.isNotEmpty()) {
            JoroCard(title = "Parametra: fanombohana → ankehitriny (EMA)") {
                Text(t.table, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            }
        }

        JoroCard(title = "Fakana-pahaizana (tena ilaina)") {
            Text(
                "Ny SPSA irery dia tsy porofo fa nihatsara. Ity dia mampifandray ny style voatono amin'ny style fanombohana (lalao 2 x opening x batch). " +
                    "Ampiharo ihany raha miseho ho \"nihatsara tokoa\".",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(verifyBatches, { verifyBatches = onlyDigits(it) }, label = { Text("Batch") }, enabled = !running, singleLine = true,
                    modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedButton(
                    onClick = {
                        rev++
                        note = TuneController.start(
                            ctx,
                            TuneParams(
                                pairs = (pairs.toIntOrNull() ?: 8).coerceIn(1, 64),
                                movetimeMs = (ms.toIntOrNull() ?: 40).coerceIn(5, 2000),
                                threads = (threads.toIntOrNull() ?: 2).coerceIn(1, 8),
                                tuneStyle = tuneStyle, tuneSearch = tuneSearch, tunePlans = tunePlans,
                                verifyBatches = (verifyBatches.toIntOrNull() ?: 10).coerceIn(1, 1000)
                            )
                        ) ?: ""
                    },
                    enabled = !running && hasCandidate,
                    modifier = Modifier.weight(1f)
                ) { Text("Fakafakao") }
            }
            Text(verifyLine(t.verifyW, t.verifyD, t.verifyL), fontFamily = FontFamily.Monospace, fontSize = 13.sp)
        }

        JoroCard(title = "Ampiharo") {
            Text("Dingana: 1) Tuning  2) Fakafakao  3) Ampiharo ny tuning  4) tab Calibrate  5) \"Ampiharo update\" -> JORO v* (moteur azo alefa).", style = MaterialTheme.typography.bodySmall)
            Text(
                "Ny valiny dia mody ny moteur anaty app (training), ny style ao amin'ny joro.exp, ary ny Calibrate (UCI StyleFile). " +
                    "Tsy very ny entries ao amin'ny joro.exp; ny taloha dia voatahiry amin'ny joro.exp.prestyle. " +
                    "Ny JORO update zip (Hafa > Import) dia mitondra ny tuning manontolo (style + search); rehefa import-ina amin'ny finday hafa dia mody ny an'ny mpamorona.",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { note = TuneController.apply(ctx); rev++ }, enabled = !running && hasCandidate, modifier = Modifier.weight(1f)) {
                    Text("Ampiharo ny tuning")
                }
                OutlinedButton(onClick = { note = TuneController.reset(ctx); rev++ }, enabled = !running && hasActive, modifier = Modifier.weight(1f)) {
                    Text("Averina ny tany am-boalohany")
                }
            }
        }

        if (t.log.isNotEmpty()) {
            JoroCard(title = "Log") {
                t.log.takeLast(6).forEach { Text(it, fontSize = 13.sp, fontFamily = FontFamily.Monospace) }
            }
        }
        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
            Text("Battery: avelao hiasa foana ny app")
        }
    }
}
