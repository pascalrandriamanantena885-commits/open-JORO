package com.joro.calibrator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

/**
 * Matrix calibration: JORO vs Stockfish (UCI_LimitStrength + UCI_Elo) for several levels at once.
 * Games of all levels are interleaved in one queue and played by [CalibConfig.concurrency] workers,
 * so every level progresses evenly and the total time stays short.
 * Every finished game is appended to [pgnFile] (standard PGN, with the result).
 */
class MatchRunner(
    private val joroPath: String,
    private val sfPath: String,
    private val expPath: String?,
    private val cfg: CalibConfig,
    private val openings: List<String>,
    private val pgnFile: File?,
    private val playerLabel: String,                 // e.g. "JORO 0.3 U1 +exp 1a2b3c4d"
    private val stylePath: String?,                  // applied SPSA tuning (style + search constants), or null
    private val onStats: (Map<Int, LevelStats>) -> Unit,
    private val onLog: (String) -> Unit
) {
    private class Task(val level: Int, val game: Int)

    /** What a finished game leaves behind (for the PGN). */
    private class GameLog {
        var fen: String = ""
        var joroWhite: Boolean = true
        var moves: List<String> = emptyList()
        var reason: String = "unterminated"
    }

    private val lock = Any()
    private val pgnLock = Any()
    private val round = AtomicInteger(0)
    private val stats = LinkedHashMap<Int, LevelStats>()
    @Volatile var joroName: String = ""
        private set
    @Volatile var sfName: String = ""
        private set

    init {
        for (lv in cfg.levels) stats[lv] = LevelStats(lv, cfg.gamesPerLevel)
    }

    suspend fun run() = coroutineScope {
        val queue = ConcurrentLinkedQueue<Task>()
        for (g in 0 until cfg.gamesPerLevel) for (lv in cfg.levels) queue.add(Task(lv, g))   // interleaved levels
        val jobs = List(cfg.concurrency) { idx -> launch(Dispatchers.IO) { worker(idx, queue) } }
        jobs.joinAll()
    }

    private suspend fun worker(idx: Int, queue: ConcurrentLinkedQueue<Task>) {
        val job = currentCoroutineContext()[Job]
        val cancelled: () -> Boolean = { job?.isActive == false }
        val joro = UciEngine(joroPath, "joro$idx")
        val sf = UciEngine(sfPath, "sf$idx")
        try {
            if (!joro.start()) { onLog("JORO tsy afaka nandeha: $joroPath"); return }
            if (!sf.start()) { onLog("Stockfish tsy afaka nandeha: $sfPath"); return }
            if (!joro.handshake()) { onLog("JORO tsy mamaly UCI"); return }
            if (!sf.handshake()) { onLog("Stockfish tsy mamaly UCI"); return }
            joroName = joro.idName
            sfName = sf.idName
            joro.setOption("Hash", cfg.hashMb.toString())
            joro.setOption("MoveOverhead", "50")
            if (expPath != null && cfg.useExperience) {
                joro.setOption("ExperienceFile", expPath)
                joro.setOption("UseExperience", "true")
            } else {
                joro.setOption("UseExperience", "false")
            }
            if (stylePath != null) joro.setOption("StyleFile", stylePath)   // after ExperienceFile: the tuned style wins
            sf.setOption("Threads", "1")
            sf.setOption("Hash", cfg.hashMb.toString())
            sf.setOption("UCI_LimitStrength", "true")
            while (true) {
                currentCoroutineContext().ensureActive()
                val t = queue.poll() ?: break
                val log = GameLog()
                val r = playGame(joro, sf, t, cancelled, log) ?: continue
                appendPgn(t, r, log)
                record(t.level, r)
            }
        } finally {
            joro.quit()
            sf.quit()
        }
    }

    private fun record(level: Int, r: Int) {
        val snapshot: Map<Int, LevelStats>
        synchronized(lock) {
            val s = stats[level]!!
            stats[level] = when {
                r > 0 -> s.copy(w = s.w + 1)
                r < 0 -> s.copy(l = s.l + 1)
                else -> s.copy(d = s.d + 1)
            }
            snapshot = LinkedHashMap(stats)
        }
        onStats(snapshot)
    }

    // ------------------------------------------------------------------ PGN
    private fun sec(ms: Long): String =
        if (ms % 1000 == 0L) (ms / 1000).toString() else String.format(Locale.US, "%.2f", ms / 1000.0)

    private fun appendPgn(t: Task, r: Int, g: GameLog) {
        val f = pgnFile ?: return
        val result = when {
            r == 0 -> "1/2-1/2"
            (r > 0) == g.joroWhite -> "1-0"
            else -> "0-1"
        }
        val sf = "Stockfish UCI_Elo ${t.level}"
        val sb = StringBuilder()
        fun tag(k: String, v: String) { sb.append('[').append(k).append(" \"").append(v.replace("\"", "'")).append("\"]\n") }
        tag("Event", "JORO calibration vs Stockfish UCI_Elo")
        tag("Site", "JORO Calibrator (Android)")
        tag("Date", SimpleDateFormat("yyyy.MM.dd", Locale.US).format(Date()))
        tag("Round", round.incrementAndGet().toString())
        tag("White", if (g.joroWhite) playerLabel else sf)
        tag("Black", if (g.joroWhite) sf else playerLabel)
        tag("Result", result)
        if (g.joroWhite) tag("BlackElo", t.level.toString()) else tag("WhiteElo", t.level.toString())
        tag("TimeControl", sec(cfg.baseMs) + "+" + sec(cfg.incMs))
        tag("Termination", g.reason)
        tag("SetUp", "1")
        tag("FEN", g.fen)
        sb.append('\n')
        val text = Native.sanFromUci(g.fen, g.moves.joinToString(" ")) + (if (g.moves.isEmpty()) "" else " ") + result
        var col = 0
        for (w in text.split(' ')) {                    // wrap at 80 columns
            if (col + w.length + 1 > 80) { sb.append('\n'); col = 0 }
            if (col > 0) { sb.append(' '); col++ }
            sb.append(w); col += w.length
        }
        sb.append("\n\n")
        synchronized(pgnLock) {
            try { f.appendText(sb.toString()) } catch (_: Exception) { }
        }
    }

    // ------------------------------------------------------------------ one game
    /** Result from JORO's point of view: +1 win, 0 draw, -1 loss; null = cancelled. */
    private fun playGame(joro: UciEngine, sf: UciEngine, t: Task, cancelled: () -> Boolean, log: GameLog): Int? {
        fun end(res: Int, reason: String): Int { log.reason = reason; return res }
        sf.setOption("UCI_Elo", t.level.toString())
        joro.send("ucinewgame")
        sf.send("ucinewgame")
        val fen = openings[(t.game / 2) % openings.size] + " 0 1"   // both colours play the same opening
        val joroWhite = t.game % 2 == 0
        log.fen = fen
        log.joroWhite = joroWhite
        if (!joro.isReady(8000, cancelled) || !sf.isReady(8000, cancelled)) {
            if (cancelled()) return null
            onLog("Engine tsy mamaly isready")
            return end(0, "abandoned")
        }
        val startSide = if (fen.split(" ")[1] == "w") 0 else 1
        val moves = ArrayList<String>()
        log.moves = moves
        val remaining = longArrayOf(cfg.baseMs, cfg.baseMs)
        var streak = 0
        var streakSign = 0

        while (true) {
            if (cancelled()) return null
            val status = Referee.nativeStatus(fen, moves.joinToString(" "))
            if (status != Referee.ONGOING) {
                val whiteWon: Boolean? = when (status) {
                    Referee.WHITE_MATES -> true
                    Referee.BLACK_MATES -> false
                    Referee.ILLEGAL -> ((startSide + moves.size - 1) % 2 == 1)   // last mover made an illegal move
                    else -> null                                                  // draw
                }
                if (status == Referee.ILLEGAL) {
                    onLog("Move tsy ara-dalàna: ${moves.lastOrNull()}")
                    moves.removeAt(moves.size - 1)                                // not part of the record
                }
                val reason = when (status) {
                    Referee.WHITE_MATES, Referee.BLACK_MATES -> "checkmate"
                    3 -> "stalemate"
                    4 -> "50-move rule"
                    5 -> "threefold repetition"
                    6 -> "insufficient material"
                    else -> "rules infraction"
                }
                return end(outcome(whiteWon, joroWhite), reason)
            }
            if (moves.size >= 300) return end(0, "move limit")

            val stm = (startSide + moves.size) % 2                 // 0 = white to move
            val jMoves = (stm == 0) == joroWhite
            val engine = if (jMoves) joro else sf
            val posCmd = if (moves.isEmpty()) "position fen $fen" else "position fen $fen moves ${moves.joinToString(" ")}"
            engine.send(posCmd)
            val t0 = System.nanoTime()
            engine.send("go wtime ${remaining[0]} btime ${remaining[1]} winc ${cfg.incMs} binc ${cfg.incMs}")
            var lastScore: Int? = null
            val bm = engine.readUntil("bestmove", remaining[stm] + 2000, cancelled) { l ->
                val sc = parseScore(l)
                if (sc != null) lastScore = sc
            }
            val spent = (System.nanoTime() - t0) / 1_000_000L
            if (cancelled()) return null
            if (bm == null) {                       // crash or hard timeout => that side loses
                engine.send("stop")
                engine.isReady(3000, cancelled)     // swallows a late "bestmove" before the next game
                onLog((if (jMoves) "JORO" else "Stockfish") + " tsy namaly (crash/timeout)")
                return end(if (jMoves) -1 else 1, "abandoned")
            }
            if (spent > remaining[stm] + 150) {     // flag fell
                return end(if (jMoves) -1 else 1, "time forfeit")
            }
            remaining[stm] = remaining[stm] - spent + cfg.incMs
            val parts = bm.split(" ")
            val mv = if (parts.size > 1) parts[1] else "0000"
            if (mv == "0000" || mv == "(none)") return end(if (jMoves) -1 else 1, "rules infraction")
            moves.add(mv)

            // adjudication: both engines see >= 9 pawns for the same side during 8 consecutive plies
            val sc = lastScore
            if (sc != null) {
                val w = if (stm == 0) sc else -sc
                if (Math.abs(w) >= 900) {
                    val sg = if (w > 0) 1 else -1
                    streak = if (sg == streakSign) streak + 1 else 1
                    streakSign = sg
                } else { streak = 0; streakSign = 0 }
                if (streak >= 8) return end(outcome(streakSign > 0, joroWhite), "adjudication")
            }
        }
    }

    private fun outcome(whiteWon: Boolean?, joroWhite: Boolean): Int = when (whiteWon) {
        null -> 0
        else -> if (whiteWon == joroWhite) 1 else -1
    }

    private fun parseScore(line: String): Int? {
        if (!line.startsWith("info") || line.contains("bound")) return null
        val p = line.split(" ")
        val i = p.indexOf("score")
        if (i < 0 || i + 2 >= p.size) return null
        val v = p[i + 2].toIntOrNull() ?: return null
        return when (p[i + 1]) {
            "cp" -> v
            "mate" -> if (v > 0) 30000 else -30000
            else -> null
        }
    }
}
