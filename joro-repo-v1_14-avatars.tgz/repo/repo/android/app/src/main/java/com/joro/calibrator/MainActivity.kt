package com.joro.calibrator

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BoardStyle.load(applicationContext)
        setContent {
            JoroTheme {
                Surface(modifier = Modifier.fillMaxSize()) { App(vm) }
            }
        }
    }
}

/** Opens the system "save as" screen for a file of the app (PGN or JORO update zip). */
class Exporter(val pgn: (String) -> Unit, val zip: (String) -> Unit, val csv: (String) -> Unit = {}, val file: (String) -> Unit = {})

@Composable
fun App(vm: MainViewModel) {
    val s by vm.ui.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    val pgnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-chess-pgn")) { uri ->
        if (uri != null) vm.exportTo(uri)
    }
    val zipLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) vm.exportTo(uri)
    }
    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) vm.exportTo(uri)
    }
    val anyLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) vm.exportTo(uri)
    }
    val exporter = remember {
        Exporter(
            file = { name -> vm.prepareExport(vm.updateFileOf(name)); anyLauncher.launch(name) },
            pgn = { name -> vm.prepareExport(vm.pgnFileOf(name)); pgnLauncher.launch(name) },
            zip = { name -> vm.prepareExport(vm.updateFileOf(name)); zipLauncher.launch(name) },
            csv = { name -> vm.prepareExport(vm.pgnFileOf(name)); csvLauncher.launch(name) }
        )
    }

    // 0 Calibrate, 1 Training, 2 Live, 3 Tantara, 4 Hafa (Import + Tune live behind it: 5 items max in a bottom bar)
    var more by remember { mutableIntStateOf(0) }          // inside "Hafa": 0 menu, 1 Import, 2 Tune
    androidx.activity.compose.BackHandler(enabled = tab == 4 && more != 0) { more = 0 }

    val items = listOf(
        NavItem("Calibrate", Icons.Filled.CheckCircle),
        NavItem("Training", Icons.Filled.Refresh),
        NavItem("Live", Icons.Filled.PlayArrow),
        NavItem("Tantara", Icons.Filled.List),
        NavItem("Hafa", Icons.Filled.Menu)
    )
    val title = when {
        tab == 4 && more == 1 -> "Import"
        tab == 4 && more == 2 -> "Tune"
        else -> items[tab].label
    }
    Scaffold(
        topBar = {
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (tab == 4 && more != 0) {
                    IconButton(onClick = { more = 0 }) { Icon(Icons.Filled.ArrowBack, contentDescription = "Miverina") }
                }
                Column(Modifier.weight(1f)) {
                    Text("JORO", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
                // a run in progress is visible from every screen
                if (s.running) Chip("Calibrate mandeha", highlight = true)
                else if (s.train.running) Chip("Training mandeha", highlight = true)
            }
        },
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { i, item ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { if (tab == i && i == 4) more = 0; tab = i },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label, fontSize = 12.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                0 -> CalibrateTab(vm, s, exporter)
                1 -> TrainTab(vm, s, exporter)
                2 -> LiveTab(vm)
                3 -> HistoryTab(vm, s, exporter)
                else -> when (more) {
                    1 -> ImportTab(vm, s, exporter)
                    2 -> TuneTab()
                    else -> MoreTab(onImport = { more = 1 }, onTune = { more = 2 })
                }
            }
        }
    }
}

private class NavItem(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

/** Icon in a round tinted badge + the title of a card. */
@Composable
private fun CardHeader(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            Modifier.size(44.dp).background(MaterialTheme.colorScheme.primary, androidx.compose.foundation.shape.CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary) }
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        Icon(Icons.Filled.KeyboardArrowRight, contentDescription = null)
    }
}

/** "Hafa": the two screens that are used less often, shown as big cards. */
@Composable
fun MoreTab(onImport: () -> Unit, onTune: () -> Unit) {
    Page {
        SectionHeader("Fitaovana", "Ireo tab tsy fampiasaina matetika")
        JoroCard(onClick = onImport) {
            CardHeader(Icons.Filled.Share, "Import")
            Text("JORO update, experience (.exp) ary moteur arm64 vaovao. Export sy fizarana ny fichier.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Chip("update"); Chip(".exp"); Chip("moteur") }
        }
        JoroCard(onClick = onTune) {
            CardHeader(Icons.Filled.Settings, "Tune")
            Text("SPSA tuning: style, search ary plan A / B / C. Fakana-pahaizana sy fampiharana.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Chip("SPSA"); Chip("verify"); Chip("apply") }
        }
    }
}

private fun num(v: String) = v.filter { it.isDigit() || it == '.' }

@Composable
fun CalibrateTab(vm: MainViewModel, s: UiState, exporter: Exporter) {
    val ctx = LocalContext.current
    Page {
        JoroCard(title = "JORO ankehitriny") {
            Text(s.joroInfo + if (s.release.isNotEmpty()) "  (${s.release})" else "", style = MaterialTheme.typography.bodyMedium)
            Text("Experience: ${s.expInfo}", style = MaterialTheme.typography.bodySmall)
        }

        JoroCard(title = "Fikirana") {
            OutlinedTextField(
                value = vm.levelsText, onValueChange = { vm.levelsText = it },
                label = { Text("Stockfish UCI_Elo (1320-3190), ohatra 2500, 2600, 2700, 3000") },
                enabled = !s.running, modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(vm.gamesText, { vm.gamesText = num(it) }, label = { Text("Lalao/level") },
                    enabled = !s.running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(vm.concurrencyText, { vm.concurrencyText = num(it) }, label = { Text("Miaraka") },
                    enabled = !s.running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(vm.baseSecText, { vm.baseSecText = num(it) }, label = { Text("Fotoana (s)") },
                    enabled = !s.running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(vm.incMsText, { vm.incMsText = num(it) }, label = { Text("Inc (ms)") },
                    enabled = !s.running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(vm.hashText, { vm.hashText = num(it) }, label = { Text("Hash MB") },
                    enabled = !s.running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            SwitchRow(vm.useExperience, { vm.useExperience = it }, "Ampiasaina ny experience (joro.exp)", enabled = !s.running)
        }

        if (!s.running) {
            Button(onClick = { vm.start() }, modifier = Modifier.fillMaxWidth()) { Text("Hanomboka calibrate") }
        } else {
            OutlinedButton(onClick = { vm.stop() }, modifier = Modifier.fillMaxWidth()) { Text("Atsaha (mitahiry valiny ampahany)") }
            Text("Mitohy ao ambadika ny calibrate (notification), na dia akatona aza ny app.", style = MaterialTheme.typography.bodySmall)
        }
        if (s.message.isNotEmpty()) Text(s.message, color = MaterialTheme.colorScheme.error)

        if (s.stats.isNotEmpty()) {
            JoroCard(title = "Fandrosoana") {
                s.stats.values.sortedBy { it.elo }.forEach { st ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("SF ${st.elo}:  ${st.played}/${st.planned}   +${st.w} =${st.d} \u2212${st.l}", fontFamily = FontFamily.Monospace, fontSize = 15.sp)
                        LinearProgressIndicator(progress = { if (st.planned == 0) 0f else st.played.toFloat() / st.planned }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }
        s.summary?.let { SummaryCard(vm, s, it, exporter) }
        if (s.exportMessage.isNotEmpty()) Text(s.exportMessage)
        if (s.log.isNotEmpty()) {
            JoroCard(title = "Log") {
                s.log.takeLast(6).forEach { Text(it, fontSize = 14.sp, fontFamily = FontFamily.Monospace) }
            }
        }
        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
            Text("Battery: avelao hiasa foana ny app")
        }
    }
}

/** PGN + "accept as JORO update" buttons of one calibration run. */
@Composable
fun RunActions(vm: MainViewModel, s: UiState, sm: Summary, exporter: Exporter) {
    val hasPgn = sm.pgn.isNotEmpty() && vm.pgnSize(sm.pgn) > 0
    if (hasPgn) {
        Text("PGN: ${sm.pgn} (${vm.pgnSize(sm.pgn) / 1024} KB)", fontSize = 14.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { exporter.pgn(sm.pgn) }) { Text("Export PGN") }
            OutlinedButton(onClick = { vm.deletePgn(sm.pgn) }) { Text("Fafao PGN") }
        }
    }
    val canAccept = !sm.partial && sm.expSha != "none" && sm.expSha == s.expSha && !s.running
    if (canAccept) {
        Button(onClick = { vm.createUpdate(sm) }) { Text("Ampiharo update (JORO v*)") }
    }
}

@Composable
fun SummaryCard(vm: MainViewModel, s: UiState, sm: Summary, exporter: Exporter) {
    val ctx = LocalContext.current
    JoroCard(padded = false) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Valiny" + if (sm.partial) " (ampahany)" else "", fontWeight = FontWeight.Bold)
            Text("JORO ${Elo.overallText(sm)} Elo", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("${sm.engineName}\nExperience: ${sm.experience}\nTC: ${sm.tcText}", fontSize = 14.sp)
            sm.levels.forEach { r ->
                Text("SF ${r.elo}  +${r.w} =${r.d} \u2212${r.l}  ${String.format(Locale.US, "%.1f", r.score * 100)}%  \u2192 ${Elo.levelText(r)}",
                    fontFamily = FontFamily.Monospace, fontSize = 14.sp)
            }
            val m = remember(sm) { Elo.mle(sm.levels) }
            val next = remember(sm) { Elo.suggestLevels(m, sm.levels.map { it.elo }) }
            Text("Auto-level (calcul amin'ny level rehetra)", fontWeight = FontWeight.Bold)
            Text(Elo.advice(m, sm.levels.size), fontSize = 15.sp)
            if (next.isNotEmpty()) {
                Text("Level natoro manaraka: ${next.joinToString(", ")}", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = { vm.levelsText = next.joinToString(", ") }, enabled = !s.running) { Text("Ampiasao ireo level ireo") }
            }
            Text("Ny UCI_Elo an'i Stockfish dia nasiana calibration amin'ny time control hafa: ampiasao hampitahana ny version JORO.", fontSize = 14.sp)
            OutlinedButton(onClick = {
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, Elo.toText(sm)) }
                ctx.startActivity(Intent.createChooser(i, "Zarao ny valiny"))
            }) { Text("Zarao ny valiny") }
            RunActions(vm, s, sm, exporter)
        }
    }
}

@Composable
fun HistoryTab(vm: MainViewModel, s: UiState, exporter: Exporter) {
    Page {
        if (s.history.isEmpty()) {
            JoroCard(title = "Tantara") { Text("Mbola tsy misy calibrate natao.", style = MaterialTheme.typography.bodySmall) }
        }
        if (s.exportMessage.isNotEmpty()) Text(s.exportMessage)
        s.history.forEachIndexed { i, sm ->
            val prev = s.history.getOrNull(i + 1)
            val mc = Elo.mle(sm.levels)
            val mp = if (prev != null) Elo.mle(prev.levels) else null
            val cur = mc.elo
            val before = mp?.elo
            val delta = if (cur != null && mp != null && before != null && mc.bound == Bound.NONE && mp.bound == Bound.NONE) cur - before else null
            JoroCard(title = DateFormat.getDateTimeInstance().format(Date(sm.timestamp))) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Chip("JORO ${Elo.overallText(sm)} Elo", highlight = true)
                    if (sm.partial) Chip("ampahany")
                    if (delta != null) Chip("${if (delta >= 0) "+" else ""}${Elo.fmt(delta)} vs teo aloha")
                }
                Text("${sm.engineName}\nExp: ${sm.experience}\n${sm.tcText}", style = MaterialTheme.typography.bodySmall)
                Text(sm.levels.joinToString("  ") { "${it.elo}:${String.format(Locale.US, "%.0f", it.score * 100)}%" }, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                RunActions(vm, s, sm, exporter)
            }
        }
        if (s.history.isNotEmpty()) OutlinedButton(onClick = { vm.clearHistory() }, modifier = Modifier.fillMaxWidth()) { Text("Fafao ny tantara") }
    }
}

/** Share sheet: another app (chess app, file manager, mail...) receives a release file. */
fun shareFile(ctx: android.content.Context, f: java.io.File) {
    val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    val mime = when {
        f.name.endsWith(".zip") -> "application/zip"
        f.name.endsWith(".h") || f.name.endsWith(".style") -> "text/plain"
        else -> "application/octet-stream"
    }
    val send = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(send, f.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun ImportTab(vm: MainViewModel, s: UiState, exporter: Exporter) {
    val ctx = LocalContext.current
    val expPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importExperience(uri) }
    val enginePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importEngine(uri) }
    val updatePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importUpdate(uri) }
    Page {
        JoroCard(padded = false) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("JORO update (moteur + experience)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Tuning + experience nekena = JORO version vaovao (v*). Mamoaka: joro-v*-arm64 (moteur UCI misy ny tuning sy ny experience anatiny, azo atao amin'ny app chess na logiciel hafa), ny zip an'ny JORO app hafa, ny .style ary ny joro_tuned_v*.h (ho an'ny code).", fontSize = 14.sp)
                Text("Version ankehitriny: ${if (s.release.isEmpty()) "tsy misy update" else s.release}", fontSize = 15.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.createUpdate(null) }) { Text("Ampiharo update") }
                    OutlinedButton(onClick = { updatePicker.launch(arrayOf("*/*")) }) { Text("Import update") }
                }
                s.updates.forEach { name ->
                    Column {
                        Text(name, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { if (name.endsWith(".zip")) exporter.zip(name) else exporter.file(name) }) { Text("Export") }
                            OutlinedButton(onClick = { vm.updateFileOf(name)?.let { shareFile(ctx, it) } }) { Text("Partager") }
                            OutlinedButton(onClick = { vm.deleteUpdate(name) }) { Text("Fafao") }
                        }
                    }
                }
            }
        }
        JoroCard(padded = false) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Experience (joro.exp)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Ankehitriny: ${s.expInfo}", fontSize = 15.sp)
                Text("Ny fichier avy amin'ny trainer. Ny style ao anatiny no ampiasain'ny moteur.", fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { expPicker.launch(arrayOf("*/*")) }) { Text("Import .exp") }
                    OutlinedButton(onClick = { vm.deleteExperience() }) { Text("Fafao") }
                }
            }
        }
        JoroCard(padded = false) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Moteur JORO", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(s.joroInfo, fontSize = 15.sp)
                Text("Fichier executable arm64 vaovao (avy amin'ny build GitHub). Hosedraina avy hatrany ny UCI alohan'ny handraisana azy.", fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { enginePicker.launch(arrayOf("*/*")) }) { Text("Import moteur") }
                    OutlinedButton(onClick = { vm.removeImportedEngine() }) { Text("Moteur an'ny APK") }
                }
            }
        }
        if (s.importMessage.isNotEmpty()) Text(s.importMessage, fontSize = 15.sp)
    }
}
