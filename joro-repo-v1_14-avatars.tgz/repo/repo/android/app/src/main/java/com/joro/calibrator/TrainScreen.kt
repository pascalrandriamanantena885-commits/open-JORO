package com.joro.calibrator

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun digits(v: String) = v.filter { it.isDigit() }

@Composable
fun TrainTab(vm: MainViewModel, s: UiState, exporter: Exporter) {
    val t = s.train
    val running = t.running
    var menuOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var pending by remember { mutableStateOf<List<Int>>(emptyList()) }

    val moves = vm.openingMoves
    val arr = remember(moves) { moves.toIntArray() }
    val board = remember(moves, vm.customFen, running) { vm.withStart { parseBoard(Native.boardInfo(arr)) } }
    val legal = remember(moves, vm.customFen, running) { vm.withStart { Native.legalMoves(arr).toList() } ?: emptyList() }
    val san = remember(moves, vm.customFen, running) { vm.withStart { Native.movesToSan(arr) } ?: "" }
    val lastMove = moves.lastOrNull()?.let { Pair(moveFrom(it), moveTo(it)) }
    // live view: while the training runs the board follows the game being played (moves polled only while this tab is shown)
    DisposableEffect(running) {
        if (running) TrainingController.setWatching(true)
        onDispose { TrainingController.setWatching(false) }
    }
    val liveArr = remember(t.live) { t.live.toIntArray() }
    val liveBoard = remember(t.live) { if (t.live.isEmpty()) null else parseBoard(Native.boardInfo(liveArr)) }
    val liveSan = remember(t.live) { if (t.live.isEmpty()) "" else Native.movesToSan(liveArr) }
    val liveLast = t.live.lastOrNull()?.let { Pair(moveFrom(it), moveTo(it)) }
    val sel = selected
    val targets = if (sel == null) emptySet() else legal.filter { moveFrom(it) == sel }.map { moveTo(it) }.toSet()

    val onTap: (Int) -> Unit = tap@{ sq ->
        if (running || board == null) return@tap
        val from = selected
        if (from != null) {
            val cand = legal.filter { moveFrom(it) == from && moveTo(it) == sq }
            if (cand.size == 1) { vm.playOpeningMove(cand[0]); selected = null; return@tap }
            if (cand.size > 1) { pending = cand; selected = null; return@tap }
        }
        val piece = board.cells[sq]
        val own = piece != '.' && (piece.isUpperCase() == board.whiteToMove)
        selected = if (own && legal.any { moveFrom(it) == sq }) sq else null
    }

    Page {
        // ---- 1. opening
        JoroCard(title = "Opening: ${vm.openingName}") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val pad = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
                Box(Modifier.weight(1f)) {
                    OutlinedButton(onClick = { menuOpen = true }, enabled = !running, modifier = Modifier.fillMaxWidth(), contentPadding = pad) { Text("Preset", maxLines = 1) }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        OpeningPresets.all.forEach { p ->
                            DropdownMenuItem(text = { Text(p.name) }, onClick = { vm.selectPreset(p); selected = null; menuOpen = false })
                        }
                    }
                }
                OutlinedButton(onClick = { vm.undoOpening(); selected = null }, enabled = !running, modifier = Modifier.weight(1f), contentPadding = pad) { Text("Hanafoana", maxLines = 1) }
                OutlinedButton(onClick = { vm.resetOpening(); selected = null }, enabled = !running, modifier = Modifier.weight(1f), contentPadding = pad) { Text("Reset", maxLines = 1) }
                OutlinedButton(onClick = { vm.flipped = !vm.flipped }, modifier = Modifier.weight(1f), contentPadding = pad) { Text("Reverse", maxLines = 1) }
            }
            OutlinedButton(
                onClick = { if (vm.editing) vm.editing = false else vm.openEditor() },
                enabled = !running, modifier = Modifier.fillMaxWidth()
            ) { Text(if (vm.editing) "Akatony ny editor board" else "Edit board (apetaka ny kapila)") }
            if (vm.customFen.isNotEmpty() && !vm.editing) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Chip("Position edited", highlight = true) }
                Text(vm.customFen, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                Text("Ity position ity no hanombohan'ny training (JORO vs JORO na vs Stockfish araka ny safidinao), ary mianatra ny experience. Ny Preset na Reset dia mamerina ny position mahazatra.", style = MaterialTheme.typography.bodySmall)
            }
            if (vm.editing && !running) {
                BoardEditorPanel(vm)
            } else {
                if (running && liveBoard != null) {
                    ChessBoard(liveBoard, vm.flipped, null, emptySet(), liveLast, {})
                    Text(
                        (if (t.paused) (if (t.sleeping) "PAUSE - natory ny training" else "Pause: miandry ny dingana farany...") else "Live: lalao ${t.game + 1}") +
                            "   ${t.live.size} plies",
                        fontWeight = FontWeight.Bold, fontSize = 14.sp
                    )
                    Text(liveSan.takeLast(160), fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                } else if (board == null && vm.customFen.isNotEmpty()) {
                    Text("Tsy azo aseho ny board mandritra ny lalao Live na training hafa.", style = MaterialTheme.typography.bodySmall)
                } else if (board != null) {
                    ChessBoard(board, vm.flipped, selected, targets, lastMove, onTap)
                    val st = when (board.status) { 1 -> "Check"; 2 -> "Checkmate"; 3 -> "Stalemate"; else -> "" }
                    Text((if (board.whiteToMove) "White no mandroso" else "Black no mandroso") + if (st.isNotEmpty()) " - $st" else "", style = MaterialTheme.typography.bodySmall)
                }
                val boardCtx = LocalContext.current
                OutlinedButton(onClick = { BoardStyle.toggle(boardCtx) }, modifier = Modifier.fillMaxWidth()) { Text("Loko board: ${BoardStyle.theme.label}") }
                if (pending.isNotEmpty()) {
                    val imgs = pieceImages()
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Promotion:")
                        pending.forEach { m ->
                            val promo = movePromo(m)
                            val label = when (promo) { 5 -> "Dame"; 4 -> "Tour"; 3 -> "Fou"; else -> "Cavalier" }
                            val letter = when (promo) { 5 -> 'q'; 4 -> 'r'; 3 -> 'b'; else -> 'n' }
                            val key = if (board?.whiteToMove != false) letter.uppercaseChar() else letter
                            Button(onClick = { vm.playOpeningMove(m); pending = emptyList() }) {
                                imgs[key]?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(32.dp)) }
                                Text(label)
                            }
                        }
                    }
                }
                Text(if (san.isEmpty()) "(position de depart)" else san, fontFamily = FontFamily.Monospace, fontSize = 15.sp)
                OutlinedTextField(
                    value = vm.sanInput, onValueChange = { vm.sanInput = it }, enabled = !running,
                    label = { Text("Apetaho eto ny lalao (ohatra 1.e4 e5 2.Nf3 Nc6)") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(onClick = { vm.applySan(); selected = null }, enabled = !running, modifier = Modifier.fillMaxWidth()) { Text("Ampiasao ity lalao ity") }
            }
        }

        // ---- 2. strength of the two sides
        JoroCard(title = "Heriny ny mpilalao") {
            SwitchRow(vm.trainByTime, { vm.trainByTime = it }, if (vm.trainByTime) "Fotoana isaky ny hetsika (ms)" else "Depth isaky ny hetsika", enabled = !running)
            Text("Ny mpilalao mahery (lalina kokoa) dia mifandimby fotsy/mainty isaky ny lalao: tsy mitovy ny hetsika, tsy dia misy draw.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (vm.trainByTime) {
                    OutlinedTextField(vm.trainMsWeakText, { vm.trainMsWeakText = digits(it) }, label = { Text("ms malemy") },
                        enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(vm.trainMsStrongText, { vm.trainMsStrongText = digits(it) }, label = { Text("ms mahery") },
                        enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                } else {
                    OutlinedTextField(vm.trainDepthText, { vm.trainDepthText = digits(it) }, label = { Text("Depth malemy") },
                        enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(vm.trainDepthStrongText, { vm.trainDepthStrongText = digits(it) }, label = { Text("Depth mahery") },
                        enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
            }
        }

        // ---- 3. when to stop
        JoroCard(title = "Lalao sy fijanonana") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(vm.trainGamesText, { vm.trainGamesText = digits(it) }, label = { Text("Lalao max") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(vm.trainHashText, { vm.trainHashText = digits(it) }, label = { Text("Hash MB") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(vm.trainConfirmText, { vm.trainConfirmText = digits(it) }, label = { Text("Fandresena misesy") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(vm.trainStableText, { vm.trainStableText = digits(it) }, label = { Text("Lalao tsy mampianatra") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            OutlinedTextField(vm.trainVaryText, { vm.trainVaryText = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Fiovana % amin'ny hetsika voalohany (faharoa tsara indrindra)") },
                enabled = !running, singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        }

        // ---- 4. options
        JoroCard(title = "Safidy") {
            SwitchRow(vm.trainGate, { vm.trainGate = it }, "Fanamarinana A/B aorian'ny training: raha ratsy kokoa ny experience vaovao dia miverina ny taloha.", enabled = !running)
            SwitchRow(vm.trainDrawFail, { vm.trainDrawFail = it }, "Ny draw dia tsy fandresena (mitady variation hafa)", enabled = !running)
            SwitchRow(vm.trainBatch, { vm.trainBatch = it }, "Ny preset ${OpeningPresets.all.size} rehetra, miandalana", enabled = !running)
        }

        // ---- 5. Stockfish
        JoroCard(title = "Stockfish") {
            SwitchRow(vm.trainVsSf, { vm.trainVsSf = it }, "Mifangaro: JORO vs JORO + Stockfish ambaratonga (ladder) + Stockfish heriny rehetra. Ny hetsika Stockfish dia tsy ianarana; mifandimby fotsy/mainty isaky ny lalao.", enabled = !running)
            if (vm.trainVsSf) {
                Text("Ny tahan'ny lalao (isa fotsiny, mifampitaha):", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(vm.trainMixSelfText, { vm.trainMixSelfText = digits(it) }, label = { Text("JORO") },
                        enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(vm.trainMixLadderText, { vm.trainMixLadderText = digits(it) }, label = { Text("Ladder") },
                        enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(vm.trainMixMaxText, { vm.trainMixMaxText = digits(it) }, label = { Text("SF max") },
                        enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(vm.trainLadderNeedText, { vm.trainLadderNeedText = digits(it) }, label = { Text("Ladder: fandresena") },
                        enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(vm.trainLadderWindowText, { vm.trainLadderWindowText = digits(it) }, label = { Text("amin'ny lalao farany") },
                        enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                Text("Miakatra ny ambaratonga Stockfish (UCI_Elo 1320 ... 3190) rehefa nandresy ${vm.trainLadderNeedText} amin'ny ${vm.trainLadderWindowText} lalao farany teo amin'io ambaratonga io i JORO. Tazonina ny ambaratonga eo anelanelan'ny training.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(vm.trainSfTimeText, { vm.trainSfTimeText = digits(it) }, label = { Text("Stockfish: ms isaky ny hetsika") },
                    enabled = !running, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
        }

        // ---- 6. start / pause / stop
        Text("Experience: ${s.expInfo}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(start = 4.dp))
        if (!running) Button(onClick = { vm.startTraining() }, modifier = Modifier.fillMaxWidth()) { Text("Hanomboka training") }
        else {
            Button(onClick = { TrainingController.setPaused(!t.paused) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (t.paused) "Tohizo" else "Pause (hitsitsy battery)")
            }
            OutlinedButton(onClick = { vm.stopTraining() }, modifier = Modifier.fillMaxWidth()) { Text("Atsaha (voatahiry ny efa nianarana)") }
            Text("Mitohy ao ambadika ny training (notification, misy Pause/Tohizo), na dia akatona aza ny app. Tsy mihinana batterie ny Pause.", style = MaterialTheme.typography.bodySmall)
        }
        if (s.trainMessage.isNotEmpty()) Text(s.trainMessage, color = MaterialTheme.colorScheme.error)
        if (!running && t.message.isNotEmpty()) Text(t.message)

        // ---- 7. progress and results
        if (running || t.openingTotal > 0) {
            JoroCard(title = "${t.openingName}  (${t.openingIndex}/${t.openingTotal})") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Lalao ${t.game}/${t.maxGames}", highlight = true)
                    Chip("White ${t.white}"); Chip("Black ${t.black}"); Chip("Draw ${t.draws}")
                }
                LinearProgressIndicator(progress = { if (t.maxGames == 0) 0f else (t.game.toFloat() / t.maxGames).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                Text("Vaovao: +${t.newBad} BAD  +${t.newGood} brilliant/great   Entries: ${t.entries}", style = MaterialTheme.typography.bodySmall)
            }
        }
        t.results.forEach { r ->
            JoroCard(title = r.name) {
                Text("${r.games} lalao  W${r.white} B${r.black} D${r.draws}  +${r.newBad} BAD  +${r.newGood} brilliant", fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                Text(r.verdict, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (!running && t.table.isNotEmpty()) {
            JoroCard(title = "Tabilao isaky ny opening (ampitahaina amin'ny training teo aloha)") {
                Box(Modifier.horizontalScroll(rememberScrollState())) {
                    Text(t.table, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
                Text("UP = nandroso, DOWN = nihemotra, = tsy niova, NEW = opening vaovao. Mat fohy kokoa na variation mat vaovao = fandrosoana.", style = MaterialTheme.typography.bodySmall)
            }
        }
        val files = remember(t.running, t.table, vm.trainFilesRev) { vm.trainFiles() }
        if (!running && files.isNotEmpty()) {
            JoroCard(title = "Lalao voatahiry (PGN misy marika !! ! ? ??) sy tabilao CSV") {
                files.forEach { name ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("$name (${vm.pgnSize(name) / 1024} KB)", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { if (name.endsWith(".csv")) exporter.csv(name) else exporter.pgn(name) }) { Text("Export") }
                        OutlinedButton(onClick = { vm.deleteTrainFile(name) }) { Text("Fafao") }
                    }
                }
            }
        }
        if (t.log.isNotEmpty()) {
            JoroCard(title = "Log") {
                t.log.takeLast(8).forEach { Text(it, fontSize = 12.sp, fontFamily = FontFamily.Monospace) }
            }
        }
    }
}

/** The editor of the Training tab. */
@Composable
private fun BoardEditorPanel(vm: MainViewModel) {
    BoardEditorPanelCore(
        brush = vm.editBrush, onBrush = { vm.editBrush = it },
        cells = vm.editCells, white = vm.editWhite, onWhite = { vm.editWhite = it },
        flipped = vm.flipped, message = vm.editMessage,
        onTap = { vm.editTap(it) }, onStandard = { vm.editStandard() }, onClear = { vm.editClear() }, onApply = { vm.editApply() }
    )
}

/**
 * The editor itself (shared by the Training and the Live tab): pick a piece in the palette, tap squares to put it (tap the same
 * piece again to remove it). It only edits what it is given; each tab keeps its own state.
 */
@Composable
fun BoardEditorPanelCore(
    brush: Char, onBrush: (Char) -> Unit,
    cells: List<Char>, white: Boolean, onWhite: (Boolean) -> Unit,
    flipped: Boolean, message: String,
    onTap: (Int) -> Unit, onStandard: () -> Unit, onClear: () -> Unit, onApply: () -> Unit
) {
    val imgs = pieceImages()
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
    @Composable
    fun PieceBrush(ch: Char) {
        val on = brush == ch
        Box(
            Modifier.size(46.dp)
                .background(if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f) else androidx.compose.ui.graphics.Color.Transparent, shape)
                .border(if (on) 2.dp else 1.dp, if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), shape)
                .clickable { onBrush(ch) },
            contentAlignment = Alignment.Center
        ) {
            val img = imgs[ch]
            if (img != null) Image(bitmap = img, contentDescription = ch.toString(), modifier = Modifier.size(38.dp))
            else Text("\u2715", fontSize = 20.sp, fontWeight = FontWeight.Bold)      // eraser
        }
    }
    Text("Safidio ny kapila, avy eo tsindrio ny efijery. Tsindrio indray ny kapila mitovy hanafoana azy.", style = MaterialTheme.typography.bodySmall)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { "KQRBNP".forEach { PieceBrush(it) } }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { "kqrbnp".forEach { PieceBrush(it) }; }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { PieceBrush('.') }
    ChessBoard(BoardView(cells.toCharArray(), white, 0), flipped, null, emptySet(), null, onTap)
    Text("Mandroso:", style = MaterialTheme.typography.bodySmall)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (white) Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("Fotsy") }
        else OutlinedButton(onClick = { onWhite(true) }, modifier = Modifier.weight(1f)) { Text("Fotsy") }
        if (!white) Button(onClick = {}, modifier = Modifier.weight(1f)) { Text("Mainty") }
        else OutlinedButton(onClick = { onWhite(false) }, modifier = Modifier.weight(1f)) { Text("Mainty") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = onStandard, modifier = Modifier.weight(1f)) { Text("Mahazatra", maxLines = 1) }
        OutlinedButton(onClick = onClear, modifier = Modifier.weight(1f)) { Text("Foano", maxLines = 1) }
    }
    if (message.isNotEmpty()) Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    Button(onClick = onApply, modifier = Modifier.fillMaxWidth()) { Text("Ampiasao ity position ity") }
}
