package com.joro.calibrator

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun liveDigits(v: String) = v.filter { it.isDigit() }

private fun planName(p: Int): String = when (p) { 1 -> "A"; 2 -> "B"; 3 -> "C"; else -> "-" }

/**
 * Live tab: a game JORO vs JORO or JORO vs Stockfish (strength chosen), from an opening built on the board / a preset / pasted.
 * Only to watch how JORO plays. Nothing is learned and joro.exp is never written (it is only read, and that can be switched off).
 */
@Composable
fun LiveTab(vm: MainViewModel) {
    val s by LiveController.state.collectAsState()
    val ctx = LocalContext.current
    val hasGame = s.white.isNotEmpty()

    Page {
        if (hasGame) LiveGameView(vm, s) else LiveSetupView(vm)
        if (vm.liveMessage.isNotEmpty()) Text(vm.liveMessage, color = MaterialTheme.colorScheme.error)
        if (hasGame && !s.running) {
            // a finished game stays on screen until the user asks for a new one
            Button(onClick = { LiveController.clear() }, modifier = Modifier.fillMaxWidth()) { Text("Lalao vaovao") }
        }
        JoroCard(title = "Fijery") {
            Text("Lalao Live: fijerena fotsiny. Tsy mianatra ary tsy manova ny experience (joro.exp); ny Training ihany no manova azy.", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { BoardStyle.toggle(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Loko board: ${BoardStyle.theme.label}") }
        }
    }
}

/** A toggle button: filled when selected, outlined otherwise (all the same width in a row). */
@Composable
private fun RowScope.Choice(selected: Boolean, label: String, onClick: () -> Unit) {
    if (selected) Button(onClick = {}, modifier = Modifier.weight(1f)) { Text(label, maxLines = 1) }
    else OutlinedButton(onClick = onClick, modifier = Modifier.weight(1f)) { Text(label, maxLines = 1) }
}

/** Name of a player with a white / black dot, shown above and below the board. */
@Composable
private fun PlayerRow(name: String, white: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            Modifier.size(16.dp)
                .background(if (white) androidx.compose.ui.graphics.Color.White else androidx.compose.ui.graphics.Color.Black, CircleShape)
                .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
        )
        PlayerAvatar(name, 32.dp)
        Text(name.ifEmpty { "-" }, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1)
    }
}

/** PNG of the game on screen: save (system "save as") or share (Messenger, Drive, ...). Works during the game and after it. */
@Composable
private fun PngCard(vm: MainViewModel, s: LiveState) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<Bitmap?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        val b = pending
        if (uri != null && b != null) {
            val ok = LivePng.writeTo(ctx, b, uri)
            Toast.makeText(ctx, if (ok) "PNG voatahiry" else "Tsy voatahiry ny PNG", Toast.LENGTH_SHORT).show()
        }
        pending = null
    }
    JoroCard(title = "Sary PNG") {
        Text(
            "Sary iray misy ny board, ny anaran'ny mpilalao, ny valiny, ny eval farany an'i JORO ary ny hetsika rehetra." +
                if (s.running) " Maka ny toerana ankehitriny ny lalao mbola mandeha." else "",
            style = MaterialTheme.typography.bodySmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val b = LiveController.withStart(s.startFen) { LivePng.render(ctx, s, vm.liveFlipped, BoardStyle.theme) }
                    if (b == null) Toast.makeText(ctx, "Tsy afaka namorona ny sary", Toast.LENGTH_SHORT).show()
                    else { pending = b; saver.launch(LivePng.fileName()) }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Tahiry PNG", maxLines = 1) }
            OutlinedButton(
                onClick = {
                    val b = LiveController.withStart(s.startFen) { LivePng.render(ctx, s, vm.liveFlipped, BoardStyle.theme) }
                    val uri = if (b != null) LivePng.toShareUri(ctx, b) else null
                    if (uri == null) Toast.makeText(ctx, "Tsy afaka namorona ny sary", Toast.LENGTH_SHORT).show()
                    else {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "image/png"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Zarao ny sary").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Zarao PNG", maxLines = 1) }
        }
    }
}

/** PGN of the finished game: save (system "save as"), share (Lichess, Drive, ...) or copy the text. */
@Composable
private fun PgnCard(s: LiveState) {
    val ctx = LocalContext.current
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    var pending by remember { mutableStateOf<String?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-chess-pgn")) { uri ->
        val t = pending
        if (uri != null && t != null) {
            val ok = LivePgn.writeTo(ctx, t, uri)
            Toast.makeText(ctx, if (ok) "PGN voatahiry" else "Tsy voatahiry ny PGN", Toast.LENGTH_SHORT).show()
        }
        pending = null
    }
    JoroCard(title = "PGN") {
        Text(
            "Ny lalao feno amin'ny format PGN: anaran'ny mpilalao, valiny, hetsika rehetra, ary ny eval an'i JORO isaky ny hetsika (azo jerena ao amin'ny Lichess na ny mpamaky PGN hafa)." +
                if (s.startFen.isNotEmpty()) " Misy FEN ny position nanombohana." else "",
            style = MaterialTheme.typography.bodySmall
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { pending = LivePgn.build(s); saver.launch(LivePgn.fileName()) },
                modifier = Modifier.weight(1f)
            ) { Text("Tahiry PGN", maxLines = 1) }
            OutlinedButton(
                onClick = {
                    val text = LivePgn.build(s)
                    val uri = LivePgn.toShareUri(ctx, text)
                    if (uri == null) Toast.makeText(ctx, "Tsy afaka namorona ny PGN", Toast.LENGTH_SHORT).show()
                    else {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "application/x-chess-pgn"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            putExtra(Intent.EXTRA_TEXT, text)          // apps that only take text still get the game
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Zarao ny PGN").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Zarao PGN", maxLines = 1) }
            OutlinedButton(
                onClick = {
                    clipboard.setText(androidx.compose.ui.text.AnnotatedString(LivePgn.build(s)))
                    Toast.makeText(ctx, "PGN voakopia", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f)
            ) { Text("Adikao", maxLines = 1) }
        }
    }
}

@Composable
private fun LiveGameView(vm: MainViewModel, s: LiveState) {
    val arr = remember(s.moves) { s.moves.toIntArray() }
    // the native helpers read the game's start position (edited or standard); recomputed when the game ends
    val board = remember(s.moves, s.startFen, s.running) { LiveController.withStart(s.startFen) { parseBoard(Native.boardInfo(arr)) } }
    val last = s.moves.lastOrNull()?.let { Pair(moveFrom(it), moveTo(it)) }

    val top = if (vm.liveFlipped) s.white else s.black
    val bottom = if (vm.liveFlipped) s.black else s.white
    val status = when {
        s.result.isNotEmpty() -> s.result
        s.running && s.paused -> "PAUSE"
        s.running -> s.thinking.ifEmpty { "..." }
        else -> s.message
    }

    JoroCard(title = "Lalao") {
        PlayerRow(top, white = vm.liveFlipped)
        if (board != null) ChessBoard(board, vm.liveFlipped, null, emptySet(), last, {})
        PlayerRow(bottom, white = !vm.liveFlipped)
        if (status.isNotEmpty()) Text(status, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        if (s.message.isNotEmpty() && s.result.isNotEmpty()) Text(s.message, style = MaterialTheme.typography.bodySmall)
        if (s.openingName.isNotEmpty()) Text("Opening: ${s.openingName}   (${s.expInfo})", style = MaterialTheme.typography.bodySmall)
        if (s.startFen.isNotEmpty()) Text("FEN: ${s.startFen}", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (s.running) {
                Button(onClick = { LiveController.setPaused(!s.paused) }, modifier = Modifier.weight(1f)) { Text(if (s.paused) "Tohizo" else "Pause", maxLines = 1) }
                OutlinedButton(onClick = { LiveController.stop() }, modifier = Modifier.weight(1f)) { Text("Atsaha", maxLines = 1) }
            }
            OutlinedButton(onClick = { vm.liveFlipped = !vm.liveFlipped }, modifier = Modifier.weight(1f)) { Text("Reverse", maxLines = 1) }
        }
    }

    // what JORO did with its last move: evaluation, depth, plan, memory
    val lastJoro = s.log.lastOrNull { it.who == "JORO" }
    if (lastJoro != null) {
        JoroCard(title = "Hetsika farany an'i JORO: ${lastJoro.label}") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (lastJoro.fromExp) Chip("experience", highlight = true)
                else { Chip("eval ${lastJoro.eval}", highlight = true); Chip("depth ${lastJoro.depth}") }
                Chip("plan ${planName(lastJoro.plan)}")
                if (lastJoro.planD) Chip("plan D", highlight = true)
            }
            if (lastJoro.planD) {
                Text(
                    if (lastJoro.dPly > 0) "Plan D: nihamina ho amin'ny toerana fantatry ny experience (${when (lastJoro.dKind) { 2 -> "toe-javatra tsara"; 3 -> "toe-javatra ratsy, hialana"; 4 -> "toe-javatra tsara akaiky, haleha any"; else -> "hetsika tsara" }}, aorian'ny ${lastJoro.dPly} plies)."
                    else "Plan D: tsy mandroso ny plan A/B/C; nitady toerana fantatry ny experience fa tsy mbola hita akaiky.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (lastJoro.fromExp) Text("Avy amin'ny experience (tsy nisy fikarohana)", style = MaterialTheme.typography.bodySmall)
            else Text("Eval avy amin'ny fijerin'ny Fotsy", style = MaterialTheme.typography.bodySmall)
            if (lastJoro.rejected > 0) Text("Brain nandà hetsika ${lastJoro.rejected}", style = MaterialTheme.typography.bodySmall)
        }
    }

    PngCard(vm, s)
    // PGN: only once the game is over (finished or stopped), so the file is the whole game
    if (!s.running && s.moves.size > s.openingLen) PgnCard(s)

    if (s.sanLine.isNotEmpty() || s.log.isNotEmpty()) {
        JoroCard(title = "Hetsika (${s.log.size} aorian'ny opening)") {
            if (s.sanLine.isNotEmpty()) Text(s.sanLine, fontFamily = FontFamily.Monospace, fontSize = 14.sp)
            s.log.takeLast(12).forEach { m ->
                val info = when {
                    m.who != "JORO" -> "SF"
                    m.fromExp -> "exp"
                    else -> "${m.eval} d${m.depth} ${planName(m.plan)}" + if (m.planD) "+D" else ""
                }
                Text("${m.label.padEnd(10)} ${m.who.take(5).padEnd(6)} $info", fontSize = 13.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun LiveSetupView(vm: MainViewModel) {
    var menuOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var pending by remember { mutableStateOf<List<Int>>(emptyList()) }

    val moves = vm.liveOpeningMoves
    val arr = remember(moves) { moves.toIntArray() }
    val fenKey = vm.liveCustomFen
    val board = remember(moves, fenKey) { vm.liveWithStart { parseBoard(Native.boardInfo(arr)) } }
    val legal = remember(moves, fenKey) { vm.liveWithStart { Native.legalMoves(arr).toList() } ?: emptyList() }
    val san = remember(moves, fenKey) { vm.liveWithStart { Native.movesToSan(arr) } ?: "" }
    val lastMove = moves.lastOrNull()?.let { Pair(moveFrom(it), moveTo(it)) }
    val sel = selected
    val targets = if (sel == null) emptySet() else legal.filter { moveFrom(it) == sel }.map { moveTo(it) }.toSet()

    val onTap: (Int) -> Unit = tap@{ sq ->
        if (board == null) return@tap
        val from = selected
        if (from != null) {
            val cand = legal.filter { moveFrom(it) == from && moveTo(it) == sq }
            if (cand.size == 1) { vm.livePlayOpeningMove(cand[0]); selected = null; return@tap }
            if (cand.size > 1) { pending = cand; selected = null; return@tap }
        }
        val piece = board.cells[sq]
        val own = piece != '.' && (piece.isUpperCase() == board.whiteToMove)
        selected = if (own && legal.any { moveFrom(it) == sq }) sq else null
    }

    // ---- who plays
    JoroCard(title = "Mpilalao") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Choice(!vm.liveVsSf, "JORO vs JORO") { vm.liveVsSf = false }
            Choice(vm.liveVsSf, "JORO vs Stockfish") { vm.liveVsSf = true }
        }
        if (vm.liveVsSf) {
            Text("JORO milalao:", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Choice(vm.liveJoroWhite, "Fotsy") { vm.liveJoroWhite = true }
                Choice(!vm.liveJoroWhite, "Mainty") { vm.liveJoroWhite = false }
            }
        }
    }
    if (vm.liveVsSf) {
        JoroCard(title = "Herin'ny Stockfish (UCI_Elo 1320 - 3190)") {
            SwitchRow(vm.liveSfMax, { vm.liveSfMax = it }, "Heriny rehetra (tsy voafetra)")
            if (!vm.liveSfMax) {
                OutlinedTextField(
                    vm.liveSfEloText, { vm.liveSfEloText = liveDigits(it) }, label = { Text("UCI_Elo") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(1500, 2000, 2500, 3000).forEach { e ->
                        OutlinedButton(onClick = { vm.liveSfEloText = e.toString() }, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) {
                            Text("$e", maxLines = 1)
                        }
                    }
                }
            }
            OutlinedTextField(
                vm.liveSfMsText, { vm.liveSfMsText = liveDigits(it) }, label = { Text("Stockfish: ms isaky ny hetsika") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
    }
    JoroCard(title = "Fotoana sy experience") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                vm.liveJoroMsText, { vm.liveJoroMsText = liveDigits(it) }, label = { Text("JORO: ms/hetsika") },
                singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
                vm.liveDelayText, { vm.liveDelayText = liveDigits(it) }, label = { Text("Fiandrasana (ms)") },
                singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
        SwitchRow(vm.liveUseExp, { vm.liveUseExp = it }, "JORO mampiasa ny experience (vakiana fotsiny, tsy voasoratra). Vonoy raha tianao hojerena ny moteur tsy misy fitadidiana.")
    }

    // ---- opening
    JoroCard(title = "Opening: ${vm.liveOpeningName}") {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.weight(1f)) {
                OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) { Text("Preset", maxLines = 1) }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    OpeningPresets.all.forEach { p ->
                        DropdownMenuItem(text = { Text(p.name) }, onClick = { vm.liveSelectPreset(p); selected = null; menuOpen = false })
                    }
                }
            }
            OutlinedButton(onClick = { vm.liveUndoOpening(); selected = null }, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) { Text("Hanafoana", maxLines = 1) }
            OutlinedButton(onClick = { vm.liveResetOpening(); selected = null }, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) { Text("Reset", maxLines = 1) }
            OutlinedButton(onClick = { vm.liveFlipped = !vm.liveFlipped }, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)) { Text("Reverse", maxLines = 1) }
        }
        OutlinedButton(
            onClick = { if (vm.liveEditing) vm.liveEditing = false else { vm.liveOpenEditor(); selected = null; pending = emptyList() } },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (vm.liveEditing) "Akatony ny editor board" else "Edit board (apetaka ny kapila)") }
        if (vm.liveCustomFen.isNotEmpty() && !vm.liveEditing) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Chip("Position edited", highlight = true) }
            Text(vm.liveCustomFen, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            Text("Ity position ity no hanombohan'ny lalao Live. Ny Preset, ny lalao apetaka na Reset dia mamerina ny position mahazatra.", style = MaterialTheme.typography.bodySmall)
        }
        if (vm.liveEditing) {
            BoardEditorPanelCore(
                brush = vm.liveEditBrush, onBrush = { vm.liveEditBrush = it },
                cells = vm.liveEditCells, white = vm.liveEditWhite, onWhite = { vm.liveEditWhite = it },
                flipped = vm.liveFlipped, message = vm.liveEditMessage,
                onTap = { vm.liveEditTap(it) }, onStandard = { vm.liveEditStandard() }, onClear = { vm.liveEditClear() }, onApply = { vm.liveEditApply() }
            )
        } else if (board == null && vm.liveCustomFen.isNotEmpty()) {
            Text("Tsy azo aseho ny board mandritra ny training: andraso ny faran'izany.", style = MaterialTheme.typography.bodySmall)
        } else if (board != null) {
            ChessBoard(board, vm.liveFlipped, selected, targets, lastMove, onTap)
            val st = when (board.status) { 1 -> "Check"; 2 -> "Checkmate"; 3 -> "Stalemate"; else -> "" }
            Text((if (board.whiteToMove) "White no mandroso" else "Black no mandroso") + if (st.isNotEmpty()) " - $st" else "", style = MaterialTheme.typography.bodySmall)
        }
        if (pending.isNotEmpty() && !vm.liveEditing) {
            val imgs = pieceImages()
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Promotion:")
                pending.forEach { m ->
                    val promo = movePromo(m)
                    val label = when (promo) { 5 -> "Dame"; 4 -> "Tour"; 3 -> "Fou"; else -> "Cavalier" }
                    val letter = when (promo) { 5 -> 'q'; 4 -> 'r'; 3 -> 'b'; else -> 'n' }
                    val key = if (board?.whiteToMove != false) letter.uppercaseChar() else letter
                    Button(onClick = { vm.livePlayOpeningMove(m); pending = emptyList() }) {
                        imgs[key]?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(32.dp)) }
                        Text(label)
                    }
                }
            }
        }
        if (!vm.liveEditing) Text(if (san.isEmpty()) (if (vm.liveCustomFen.isEmpty()) "(position de depart)" else "(position edited)") else san, fontFamily = FontFamily.Monospace, fontSize = 15.sp)
        OutlinedTextField(
            value = vm.liveSanInput, onValueChange = { vm.liveSanInput = it },
            label = { Text("Apetaho eto ny lalao (ohatra 1.e4 e5 2.Nf3 Nc6)") }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(onClick = { vm.liveApplySan(); selected = null }, modifier = Modifier.fillMaxWidth()) { Text("Ampiasao ity lalao ity") }
    }

    Button(onClick = { vm.startLive() }, enabled = !vm.liveEditing, modifier = Modifier.fillMaxWidth()) { Text("Hanomboka lalao") }
}
