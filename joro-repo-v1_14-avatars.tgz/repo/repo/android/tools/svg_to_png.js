// Renders android/design/svg/pieces/*.svg to transparent PNGs in app/src/main/res/drawable-nodpi (pc_wk.png ... pc_bp.png).
// Android cannot draw these SVGs (they embed a shadow bitmap and use mix-blend-mode), so Chromium renders them once.
//   node android/tools/svg_to_png.js            (needs the `playwright` package and its Chromium)
// ONE scale for every piece: the board squares are 450 x 450 units and the pieces are drawn on the same grid, so a pawn stays smaller
// than a king. SCALE px per unit; ChessBoard divides by (450 * SCALE) = 360 to draw a piece in a square of any size.
const fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const SCALE = 0.8;
const root = path.join(__dirname, '..');
const src = path.join(root, 'design/svg/pieces');
const out = path.join(root, 'app/src/main/res/drawable-nodpi');
const NAMES = { king: 'k', queen: 'q', rook: 'r', bishop: 'b', knight: 'n', pawn: 'p' };
(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ deviceScaleFactor: 1 });
  for (const f of fs.readdirSync(src).filter(n => n.endsWith('.svg'))) {
    const m = f.match(/^([wb])_(\w+)\.svg$/);
    if (!m || !NAMES[m[2]]) throw new Error('unexpected file ' + f);
    const text = fs.readFileSync(path.join(src, f), 'utf8');
    const vb = text.match(/viewBox="0 0 (\d+) (\d+)"/);
    const w = Math.round(vb[1] * SCALE), h = Math.round(vb[2] * SCALE);
    const uri = 'data:image/svg+xml;base64,' + Buffer.from(text).toString('base64');
    await page.setViewportSize({ width: w, height: h });
    await page.setContent(`<html><body style="margin:0;background:transparent"><img style="display:block" width="${w}" height="${h}" src="${uri}"></body></html>`);
    await page.waitForFunction(() => document.querySelector('img').complete);
    const name = `pc_${m[1]}${NAMES[m[2]]}.png`;
    await page.locator('img').screenshot({ path: path.join(out, name), omitBackground: true });
    console.log(name, w + 'x' + h);
  }
  await browser.close();
})();
