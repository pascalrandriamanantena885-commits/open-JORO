cmake_minimum_required(VERSION 3.10)
project(JORO CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
set(CMAKE_CXX_FLAGS_RELEASE "-O3")

# core library : reused as-is by the Android app (JNI) later
add_library(joro_core STATIC
  src/board.cpp src/eval.cpp src/experience.cpp src/search.cpp src/tunables.cpp src/embed.cpp)
target_include_directories(joro_core PUBLIC src)

find_package(Threads REQUIRED)
add_executable(joro src/main.cpp src/uci.cpp)
target_link_libraries(joro joro_core Threads::Threads)

# trainer: self-play learning loop (also compiled into the Android app via JNI)
add_library(joro_trainer STATIC src/trainer.cpp src/gate.cpp src/san.cpp src/pgn.cpp src/opstats.cpp)
target_link_libraries(joro_trainer joro_core)
add_executable(joro_train src/train_main.cpp)
target_link_libraries(joro_train joro_trainer Threads::Threads)

# A/B test of two styles at equal time per move
add_executable(joro_match src/match_main.cpp)
target_link_libraries(joro_match joro_core Threads::Threads)

# SPSA tuner of the style weights and search constants (also compiled into the Android app via JNI)
add_library(joro_tuner STATIC src/tuner.cpp)
target_link_libraries(joro_tuner joro_core)
add_executable(joro_tune src/tune_main.cpp)
target_link_libraries(joro_tune joro_tuner Threads::Threads)

# put the tuning (+ experience + version label) inside an engine file, or extract / export it as a C++ header
add_executable(joro_pack src/pack_main.cpp)
target_link_libraries(joro_pack joro_core)

# live-game API test (the experience file must stay untouched by a live game)
add_executable(joro_live_test tests/live_test.cpp src/appapi.cpp)
target_link_libraries(joro_live_test joro_trainer joro_tuner joro_core Threads::Threads)

# Plan D (experience steering) test
add_executable(joro_plan_d_test tests/plan_d_test.cpp)
target_link_libraries(joro_plan_d_test joro_core Threads::Threads)

# Situation memory test (experience kind 2, Plan D, the trainer's analysis)
add_executable(joro_situation_test tests/situation_test.cpp)
target_link_libraries(joro_situation_test joro_trainer joro_core Threads::Threads)
