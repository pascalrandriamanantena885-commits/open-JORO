// JORO - opstats.h : table per opening (wins, mate length, stored mating variations, progress), kept between runs
// in a CSV so that a training can be compared with the previous one.
#pragma once
#include "trainer.h"
#include <map>
#include <string>
#include <vector>

namespace joro {

// What one run of the trainer produced for ONE opening.
struct OpeningRow {
    int run = 0;                 // run number (1, 2, ...)
    std::string date;
    std::string id;              // hash of start position + opening moves
    std::string label;           // the opening moves (or a free label)
    int games = 0;
    int selfGames = 0;           // JORO vs JORO
    int sfGames = 0, sfWin = 0, sfDraw = 0, sfLoss = 0;   // JORO vs an external engine, JORO point of view
    int maxLadder = 0;           // highest Stockfish UCI_Elo met in this run (0 = none)
    int mates = 0;               // games that ended in a CHECKMATE won by JORO
    int shortestMate = 0;        // plies after the opening, shortest of those mates (0 = none)
    int sitRun = 0;        // situations NEWLY stored in this run
    int sitTotal = 0;      // ... stored over all runs
    int newBad = 0, brilliant = 0, great = 0;
    // computed when compared with the previous run of the same opening
    bool hasPrev = false;
    int progress = 0;            // > 0 better, < 0 worse, 0 same
    double sfScore() const { return sfGames ? (sfWin + 0.5 * sfDraw) / sfGames : -1; }
    double mateRate() const { return games ? double(mates) / games : 0; }
};

std::string openingId(const std::string& fen, const std::vector<std::string>& moves);

// Collects the games of one opening during a run.
class OpeningAcc {
public:
    OpeningAcc(const std::string& id, const std::string& label) { row.id = id; row.label = label; }
    void add(const GameRecord& rec, int newBad, int opponentElo);   // opponentElo: ladder level of the game, 0 otherwise
    OpeningRow row;
};

class OpeningStats {
public:
    explicit OpeningStats(const std::string& path) : path(path) {}
    bool load();                                         // missing file = empty history (true)
    int nextRun() const { return lastRun + 1; }
    // fills sitTotal / progress of `r` by comparing with the latest earlier row of the same id
    void compare(OpeningRow& r, OpeningRow* prevOut = nullptr) const;
    bool append(const std::vector<OpeningRow>& rows) const;
    const OpeningRow* previous(const std::string& id) const;
    // printable table of this run, with the previous run next to it
    std::string table(const std::vector<OpeningRow>& rows) const;
private:
    std::string path;
    std::vector<OpeningRow> history;
    std::map<std::string, size_t> lastIdx;
    int lastRun = 0;
};

} // namespace joro
