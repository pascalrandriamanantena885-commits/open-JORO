// JORO - embed.h : a JORO engine file that carries its own tuning (+ optionally its experience) and a version label.
//
// Why: chess apps and other programs only load an engine executable. The SPSA-tuned style weights, search constants and plan
// parameters (and the experience) must therefore travel INSIDE the file. They are appended after the executable:
//
//   [ original executable ][ tuning JSON ][ experience bytes ][ label text ]
//   [ u64 tuningLen ][ u64 expLen ][ u64 labelLen ][ "JOROEMB1" ]            (little-endian, the last 32 bytes of the file)
//
// ELF / Mach-O loaders ignore trailing bytes, so the file still runs as before. At start the engine reads its own file
// (/proc/self/exe or argv[0]); UCI options (StyleFile, ExperienceFile, Style_*, Search_*) set afterwards still win.
// Packing an already packed engine replaces the old payload (the executable part is found by removing the footer).
#pragma once
#include <string>
#include <vector>

namespace joro {

struct EmbeddedPayload {
    bool valid = false;
    std::string tuning;           // style + search JSON (same text as a tuning / .style file); may be empty
    std::vector<char> exp;        // joro.exp bytes; may be empty
    std::string label;            // e.g. "v5"
    size_t exeSize = 0;           // size of the executable part
};

// Reads the payload of the engine file at `path`. Returns false when the file carries none (valid stays false).
bool readEmbedded(const std::string& path, EmbeddedPayload& out, std::string* err = nullptr);

// Writes a copy of `inEngine` (its own payload, if any, is dropped) + the new payload to `outEngine`. expPath / tuningText may be empty.
bool packEngine(const std::string& inEngine, const std::string& outEngine, const std::string& tuningText, const std::string& expPath,
                const std::string& label, std::string* err = nullptr);

// C++ header text with the tuned values as named constants (for pasting the tuning into code):  style[] and search[] of {name, value}.
std::string tuningAsHeader(const std::string& tuningText, const std::string& label);

// Path of the running executable ("" when unknown): /proc/self/exe, else `argv0`.
std::string selfExePath(const char* argv0 = nullptr);

} // namespace joro
