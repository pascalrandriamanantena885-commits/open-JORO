#include "uci.h"
int main(int, char** argv) { joro::uciLoop(argv[0]); return 0; }
