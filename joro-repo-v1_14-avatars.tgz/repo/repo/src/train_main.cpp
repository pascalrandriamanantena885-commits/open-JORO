// JORO - train_main.cpp : command line trainer (same code is used by the Android app through JNI)
#include "trainer.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <cstring>
#include <map>
#include "gate.h"
#include "opponent.h"
#include "opstats.h"
#include "pgn.h"
#include <ctime>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>

using namespace joro;

// ---- a UCI engine as a child process (CLI only; the Android app has its own UciEngine.kt)
struct UciProc {
    pid_t pid = -1;
    FILE* in = nullptr;    // engine stdout
    FILE* out = nullptr;   // engine stdin
    bool start(const std::string& path) {
        int a[2], b[2];
        if (pipe(a) || pipe(b)) return false;
        pid = fork();
        if (pid < 0) return false;
        if (pid == 0) {
            dup2(a[0], 0); dup2(b[1], 1);
            close(a[0]); close(a[1]); close(b[0]); close(b[1]);
            execl(path.c_str(), path.c_str(), (char*)nullptr);
            _exit(127);
        }
        close(a[0]); close(b[1]);
        out = fdopen(a[1], "w");
        in = fdopen(b[0], "r");
        return out && in;
    }
    void send(const std::string& s) { fprintf(out, "%s\n", s.c_str()); fflush(out); }
    bool waitFor(const char* prefix, std::string* line = nullptr) {
        char buf[4096];
        while (fgets(buf, sizeof buf, in)) {
            if (strncmp(buf, prefix, strlen(prefix)) == 0) { if (line) *line = buf; return true; }
        }
        return false;
    }
    ~UciProc() { if (pid > 0) { if (out) { send("quit"); fclose(out); } kill(pid, SIGKILL); waitpid(pid, nullptr, 0); if (in) fclose(in); } }
};

static void usage() {
    printf("joro_train --opening \"e2e4 e7e5 ...\" | --openings FILE   [options]\n"
           "  --fen FEN         start position (default: startpos)\n"
           "  --in FILE         continue from an existing experience file\n"
           "  --out FILE        experience file to write (default joro.exp)\n"
           "  --depth N         alias of --depth-weak\n"
           "  --games N         max games per opening (200)\n"
           "  --stable N        stop after N games that taught nothing (3)\n"
           "  --confirm N       stop when the same side wins N games in a row (5)\n"
           "  --depth-weak N / --depth-strong N   weak and strong side (defaults 5 / 8); the strong side alternates colour each game\n"
           "  --ms-weak MS / --ms-strong MS       use time per move instead of depth (default off); --equal = both sides alike\n"
           "  --gate N          after training: N games per opening, new experience vs the previous one (default 2; 0 = off);\n"
           "                    the old file is kept as OUT.bak, and restored if the new one scores under 45%%\n"
           "  --gate-ms MS      time per move in the gate (default 60)\n"
           "  --no-situations   do not learn situations (good / bad) from the games\n"
           "  --no-brain        switch the Variation Brain off in self-play\n"
           "  --no-great        keep only brilliant moves (no GREAT moves)\n"
           "  --great-margin N  cp by which a GREAT move must beat the alternatives (default 60)\n"
           "  --all-good        (old behaviour) store every move of the winner as GOOD, not only brilliant ones\n"
           "  --draw-ok         a draw is accepted (default: a draw is a failure)\n"
           "  --hash MB         hash per side (16)\n"
           "  --vs ENGINE       JORO vs an external UCI engine (e.g. stockfish). Only JORO's moves are learned from.\n"
           "  --joro white|black  colour played by JORO in --vs mode (default white)\n"
           "  --movetime MS     time per move of the external engine (default 1000), full strength\n"
           "  --vs-opt n=v      UCI option for the external engine (repeatable, e.g. Threads=1)\n"
           "  --mix self=N,ladder=N,max=N  (needs --vs) who JORO plays, game after game, as proportions: JORO itself, Stockfish on the\n"
           "                    ladder (UCI_Elo, goes up when JORO wins --ladder-need of the last --ladder-window games), Stockfish at\n"
           "                    full strength. JORO's colour alternates every game. Without --mix, --vs keeps the old behaviour.\n"
           "  --ladder-levels a,b,c   UCI_Elo levels (default 1320,1500,1700,1900,2100,2300,2500,2700,2900,3190; clamped to the engine's range)\n"
           "  --ladder-need N / --ladder-window M   level up after N wins in the last M ladder games (default 3 / 3)\n"
           "  --ladder-file F   where the ladder level is kept between runs (default OUT.ladder); --ladder-reset starts at the bottom\n"
           "  --vary-first PCT  chance (default 5) that JORO's first move after the opening is its 2nd best (if within --vary-loss cp, default 60)\n"
           "  --seed N          random seed (default: random)\n"
           "  --pgn PREFIX      write every game as PREFIX_0001.pgn ... (default: OUT without extension + _games); --no-pgn = off\n"
           "  --pgn-split N     games per PGN file (default 100; 0 = one file)\n"
           "  --stats FILE      per-opening table kept between runs (CSV, default OUT.stats.csv); --no-stats = off\n"
           "  --adjudicate      old behaviour: decide a game at |eval|>=900cp for 6 moves (default: only checkmate wins)\n"
           "  --style-file F    JORO style file (styles/joro.style). The experience is bound to this style\n"
           "  --set name=value  override one style weight (e.g. --set enemy_king=120)\n");
}

int main(int argc, char** argv) {
    initTables();
    TrainConfig cfg;
    std::string fen = START_FEN, in, out = "joro.exp", openingStr, openingsFile;
    std::string vsPath, joroColor = "white";
    int movetime = 1000;
    std::vector<std::string> vsOpts;
    int gateGames = 2, gateMs = 60;
    std::string mixStr, levelsStr, ladderFile, pgnPrefix, statsFile;
    int ladderNeed = 3, ladderWindow = 3, pgnSplit = 100;
    bool ladderReset = false, noPgn = false, noStats = false;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        auto next = [&]() -> std::string { return i + 1 < argc ? argv[++i] : ""; };
        if (a == "--opening") openingStr = next();
        else if (a == "--openings") openingsFile = next();
        else if (a == "--fen") fen = next();
        else if (a == "--in") in = next();
        else if (a == "--out") out = next();
        else if (a == "--depth" || a == "--depth-weak") cfg.depth = atoi(next().c_str());
        else if (a == "--depth-strong") cfg.depthStrong = atoi(next().c_str());
        else if (a == "--ms-weak") cfg.moveTimeWeak = atoi(next().c_str());
        else if (a == "--ms-strong") cfg.moveTimeStrong = atoi(next().c_str());
        else if (a == "--equal") cfg.depthStrong = 0, cfg.moveTimeStrong = 0;
        else if (a == "--games") cfg.maxGames = atoi(next().c_str());
        else if (a == "--stable") cfg.stableLimit = atoi(next().c_str());
        else if (a == "--confirm") cfg.confirmWins = atoi(next().c_str());
        else if (a == "--hash") cfg.hashMB = atoi(next().c_str());
        else if (a == "--draw-ok") cfg.drawIsFail = false;
        else if (a == "--all-good") cfg.brilliantOnly = false;
        else if (a == "--no-great") cfg.great = false;
        else if (a == "--no-brain") cfg.brain = false;
        else if (a == "--no-situations") cfg.situations = false;
        else if (a == "--gate") gateGames = atoi(next().c_str());
        else if (a == "--gate-ms") gateMs = atoi(next().c_str());
        else if (a == "--vs") vsPath = next();
        else if (a == "--joro") joroColor = next();
        else if (a == "--movetime") movetime = atoi(next().c_str());
        else if (a == "--vs-opt") vsOpts.push_back(next());
        else if (a == "--adjudicate") cfg.adjudicate = true;
        else if (a == "--mix") mixStr = next();
        else if (a == "--ladder-levels") levelsStr = next();
        else if (a == "--ladder-need") ladderNeed = atoi(next().c_str());
        else if (a == "--ladder-window") ladderWindow = atoi(next().c_str());
        else if (a == "--ladder-file") ladderFile = next();
        else if (a == "--ladder-reset") ladderReset = true;
        else if (a == "--vary-first") cfg.varyFirstPct = atof(next().c_str());
        else if (a == "--vary-loss") cfg.varyMaxLoss = atoi(next().c_str());
        else if (a == "--seed") cfg.seed = (unsigned)strtoul(next().c_str(), nullptr, 10);
        else if (a == "--pgn") pgnPrefix = next();
        else if (a == "--no-pgn") noPgn = true;
        else if (a == "--pgn-split") pgnSplit = atoi(next().c_str());
        else if (a == "--stats") statsFile = next();
        else if (a == "--no-stats") noStats = true;
        else if (a == "--great-margin" && i + 1 < argc) cfg.greatMargin = atoi(argv[++i]);
        else if (a == "--style-file") {
            std::string err;
            if (!cfg.style.load(next(), &err)) { printf("cannot load style: %s\n", err.c_str()); return 1; }
        } else if (a == "--set") {
            std::string kv = next();
            size_t eq = kv.find('=');
            if (eq == std::string::npos || !cfg.style.set(kv.substr(0, eq), atoi(kv.c_str() + eq + 1))) { usage(); return 1; }
        } else { usage(); return 1; }
    }
    std::vector<std::string> lines;
    if (!openingStr.empty()) lines.push_back(openingStr);
    if (!openingsFile.empty()) {
        std::ifstream f(openingsFile);
        std::string l;
        while (std::getline(f, l)) if (!l.empty() && l[0] != '#') lines.push_back(l);
    }
    if (lines.empty()) { usage(); return 1; }

    printf("style: %s id %016llx\n", cfg.style.name.c_str(), (unsigned long long)cfg.style.id());
    Experience exp;
    if (!in.empty()) {
        std::string err;
        if (!exp.load(in, &err)) { printf("cannot load %s (%s)\n", in.c_str(), err.c_str()); return 1; }
        printf("loaded %zu entries from %s\n", exp.size(), in.c_str());
        if (!exp.compatibleWith(cfg.style)) {
            printf("ERROR: %s was made with another style (%016llx). Use the same --style-file, or start a new file.\n", in.c_str(), (unsigned long long)exp.styleId());
            return 1;
        }
    }
    exp.setStyle(cfg.style);
    const Experience base = exp;                       // what the gate compares the new experience with
    if (FILE* fo = fopen(out.c_str(), "rb")) {         // keep the previous file as OUT.bak
        fclose(fo);
        std::ifstream src(out, std::ios::binary);
        std::ofstream dst(out + ".bak", std::ios::binary | std::ios::trunc);
        dst << src.rdbuf();
    }
    std::vector<std::pair<std::string, std::vector<std::string>>> trained;   // (fen, opening moves) of every trained opening

    Trainer tr(exp, cfg);
    UciProc sf;
    OpponentPlan plan(cfg.seed ? cfg.seed + 1 : 0);
    plan.need = ladderNeed; plan.window = ladderWindow;
    if (!mixStr.empty() && !plan.parseMix(mixStr)) { printf("bad --mix (use self=N,ladder=N,max=N)\n"); return 1; }
    if (!levelsStr.empty() && !plan.parseLevels(levelsStr)) { printf("bad --ladder-levels\n"); return 1; }
    const bool mixGiven = !mixStr.empty();
    if (vsPath.empty() && (plan.wLadder > 0 || plan.wMax > 0)) { printf("--mix with ladder/max needs --vs ENGINE\n"); return 1; }
    if (!mixGiven && !vsPath.empty()) { plan.wSelf = 0; plan.wLadder = 0; plan.wMax = 100; }   // old behaviour: full strength only
    if (ladderFile.empty()) ladderFile = out + ".ladder";
    if (!ladderReset && plan.wLadder > 0) plan.loadLevel(ladderFile);
    bool limitOptionKnown = false;
    if (!vsPath.empty()) {
        if (!sf.start(vsPath)) { printf("cannot start %s\n", vsPath.c_str()); return 1; }
        sf.send("uci");
        int eloLo = 1320, eloHi = 3190;
        {   // read the options until uciok: UCI_Elo range
            char buf[4096];
            bool ok = false;
            while (fgets(buf, sizeof buf, sf.in)) {
                if (strncmp(buf, "uciok", 5) == 0) { ok = true; break; }
                if (strstr(buf, "name UCI_Elo ")) {
                    const char* mn = strstr(buf, " min "); const char* mx = strstr(buf, " max ");
                    if (mn) eloLo = atoi(mn + 5);
                    if (mx) eloHi = atoi(mx + 5);
                }
                if (strstr(buf, "name UCI_LimitStrength")) limitOptionKnown = true;
            }
            if (!ok) { printf("%s does not speak UCI\n", vsPath.c_str()); return 1; }
        }
        plan.clampLevels(eloLo, eloHi);
        if (!ladderReset && plan.wLadder > 0) plan.loadLevel(ladderFile);
        for (auto& o : vsOpts) { size_t eq = o.find('='); if (eq != std::string::npos) sf.send("setoption name " + o.substr(0, eq) + " value " + o.substr(eq + 1)); }
        sf.send("isready");
        sf.waitFor("readyok");
    }
    auto engineMove = [&](const std::string& startFen, const std::vector<Move>& mv) -> Move {
        std::string pos = "position fen " + startFen;
        if (!mv.empty()) { pos += " moves"; for (Move x : mv) pos += " " + Board::moveToStr(x); }
        sf.send(pos);
        sf.send("go movetime " + std::to_string(movetime));
        std::string line;
        if (!sf.waitFor("bestmove", &line)) return MOVE_NONE;
        char t[16] = {0};
        sscanf(line.c_str(), "bestmove %15s", t);
        Board b;
        b.setFen(startFen);
        for (Move x : mv) b.makeMove(x);
        return b.parseMove(t);
    };
    OpponentSpec curSpec;
    int curElo = -1;                                   // UCI_Elo currently set in the engine (-1 = none, 0 = limit off)
    tr.beforeGame = [&](int gameNo) -> std::string {
        curSpec = plan.next();
        if (curSpec.kind == OpponentSpec::SELF) { tr.setOpponent(WHITE, Trainer::OpponentFn()); return curSpec.label; }
        int want = curSpec.kind == OpponentSpec::LADDER ? curSpec.elo : 0;
        if (want != curElo) {
            if (want > 0) { sf.send("setoption name UCI_LimitStrength value true"); sf.send("setoption name UCI_Elo value " + std::to_string(want)); }
            else sf.send("setoption name UCI_LimitStrength value false");
            curElo = want;
        }
        sf.send("ucinewgame");
        sf.send("isready");
        sf.waitFor("readyok");
        int side = mixGiven ? ((gameNo & 1) ? BLACK : WHITE) : (joroColor == "black" ? BLACK : WHITE);
        tr.setOpponent(side, engineMove);
        return curSpec.label;
    };
    if (!vsPath.empty()) {
        printf("opponents: self %d : ladder %d : max %d  (Stockfish %d ms/move)\n", plan.wSelf, plan.wLadder, plan.wMax, movetime);
        if (plan.wLadder > 0) printf("ladder: level %d of %zu = UCI_Elo %d (up after %d wins in the last %d)\n", plan.level + 1, plan.levels.size(), plan.levels[plan.level], plan.need, plan.window);
        if (plan.wLadder > 0 && !limitOptionKnown) printf("warning: %s has no UCI_LimitStrength option, the ladder will not limit it\n", vsPath.c_str());
        if (cfg.varyFirstPct > 0) printf("first-move variety: %.1f%%\n", cfg.varyFirstPct);
    }
    if (pgnPrefix.empty()) {
        pgnPrefix = out;
        size_t dot = pgnPrefix.rfind('.'), sl = pgnPrefix.find_last_of("/\\");
        if (dot != std::string::npos && (sl == std::string::npos || dot > sl)) pgnPrefix = pgnPrefix.substr(0, dot);
        pgnPrefix += "_games";
    }
    PgnWriter pgn(pgnPrefix, pgnSplit);
    if (statsFile.empty()) statsFile = out + ".stats.csv";
    OpeningStats history(statsFile);
    history.load();
    const int runNo = history.nextRun();
    char dateBuf[16];
    { time_t now = time(nullptr); strftime(dateBuf, sizeof dateBuf, "%Y-%m-%d", localtime(&now)); }
    OpeningAcc* curAcc = nullptr;
    std::string curLabel;
    struct OppSum { int games = 0, w = 0, d = 0, l = 0; };
    std::map<std::string, OppSum> perOpp;              // opponent label -> JORO's results (self-play: w = white wins, l = black wins)
    tr.onGame = [&](int g, const GameRecord& r, int nb, int ng) {
        printf("  game %3d: %-7s %3zu plies (%s) vs %s  +bad %d +brilliant %d +situations %d%s\n", g,
               r.result == 1 ? "1-0" : (r.result == -1 ? "0-1" : "1/2-1/2"), r.moves.size(), r.reason.c_str(), r.opponent.c_str(), nb, ng, r.sitNew,
               r.variedPly >= 0 ? "  [varied first move]" : "");
        OppSum& os = perOpp[r.opponent];
        os.games++;
        if (r.joroSide < 0) { if (r.result == 1) os.w++; else if (r.result == -1) os.l++; else os.d++; }
        else {
            int sc = r.result == 0 ? 0 : (((r.result == 1) == (r.joroSide == WHITE)) ? 1 : -1);
            if (sc > 0) os.w++; else if (sc < 0) os.l++; else os.d++;
            if (plan.report(curSpec, sc > 0 ? 1.0 : (sc == 0 ? 0.5 : 0.0))) {
                printf("  ladder: JORO beat Stockfish %d (%d of %d) -> next level UCI_Elo %d\n", curSpec.elo, plan.need, plan.window, plan.levels[plan.level]);
                plan.saveLevel(ladderFile);
            }
        }
        if (curAcc) curAcc->add(r, nb, curSpec.kind == OpponentSpec::LADDER ? curSpec.elo : 0);
        if (!noPgn && !pgn.add(r, "JORO training: " + curLabel)) printf("  cannot write PGN %s\n", pgn.currentFile().c_str());
        fflush(stdout);
    };
    std::vector<OpeningRow> openingRows;
        for (size_t k = 0; k < lines.size(); k++) {
        std::string lineFen = fen, body = lines[k];
        std::istringstream is(body);
        std::vector<std::string> mv;
        std::string t;
        while (is >> t) mv.push_back(t);
        printf("opening %zu/%zu: %s\n", k + 1, lines.size(), body.c_str());
        std::string err;
        const std::string oid = openingId(lineFen, mv);
        curLabel = body.substr(0, 40);
        OpeningAcc acc(oid, curLabel);
        curAcc = &acc;
        TrainStats st = tr.trainOpening(lineFen, mv, &err);
        curAcc = nullptr;
        if (!err.empty()) { printf("  error: %s\n", err.c_str()); continue; }
        if (acc.row.games > 0) {
            acc.row.run = runNo;
            acc.row.date = dateBuf;
            history.compare(acc.row);
            openingRows.push_back(acc.row);
        }
        printf("  => games %d  W %d  B %d  D %d | new bad %d, new brilliant/great %d, exhausted %d | entries %zu\n", st.games,
               st.whiteWins, st.blackWins, st.draws, st.newBad, st.newGood, st.exhausted, exp.size());
        if (st.games > 0) trained.push_back({lineFen, mv});
        if (!exp.save(out)) { printf("cannot write %s\n", out.c_str()); return 1; }
    }
    if (!openingRows.empty()) {
        printf("per opening (run %d; \"prev>now\" = shortest mate, in moves, previous run > this run):\n%s", runNo, history.table(openingRows).c_str());
        if (!noStats) {
            if (history.append(openingRows)) printf("table saved in %s (compare with the next run)\n", statsFile.c_str());
            else printf("cannot write %s\n", statsFile.c_str());
        }
    }
    if (!perOpp.empty()) {
        printf("per opponent:\n");
        for (auto& kv : perOpp) {
            const OppSum& o = kv.second;
            if (kv.first == "JORO") printf("  %-16s %4d games  white %d, black %d, draws %d\n", kv.first.c_str(), o.games, o.w, o.l, o.d);
            else printf("  %-16s %4d games  JORO +%d =%d -%d  (%.1f%%)\n", kv.first.c_str(), o.games, o.w, o.d, o.l, o.games ? 100.0 * (o.w + 0.5 * o.d) / o.games : 0.0);
        }
        if (plan.wLadder > 0) printf("  ladder level now: UCI_Elo %d\n", plan.levels[plan.level]);
    }
    if (!noPgn && pgn.games() > 0) printf("PGN: %d games in %d file(s), last %s\n", pgn.games(), pgn.files(), pgn.currentFile().c_str());
    if (gateGames > 0 && !trained.empty()) {
        std::vector<GateStart> starts;
        size_t step = std::max<size_t>(1, (trained.size() + 7) / 8);          // at most 8 starts, evenly spread
        for (size_t i = 0; i < trained.size(); i += step) {
            GateStart gs;
            gs.fen = trained[i].first;
            Board b;
            b.setFen(gs.fen);
            for (auto& s : trained[i].second) { Move x = b.parseMove(s); if (!x) break; b.makeMove(x); gs.moves.push_back(x); }
            starts.push_back(gs);
        }
        printf("gate: new experience vs previous, %zu starts x %d games at %d ms/move ...\n", starts.size(), gateGames, gateMs);
        fflush(stdout);
        GateResult gr = gateExperience(exp, base, starts, gateGames, gateMs);
        printf("gate: new vs old  +%d =%d -%d  (new scores %.1f%%)\n", gr.wins, gr.draws, gr.losses, 100.0 * gr.score());
        if (gr.score() < 0.45) {
            exp.save(out + ".rejected");
            Experience restore = base;
            restore.save(out);
            printf("REJECTED: the new experience scores under 45%%. Previous experience restored in %s, the new one kept as %s.rejected\n",
                   out.c_str(), out.c_str());
            return 0;
        }
        printf("ACCEPTED (previous file kept as %s.bak)\n", out.c_str());
    }
    printf("saved %s (%zu entries)\n", out.c_str(), exp.size());
    return 0;
}
