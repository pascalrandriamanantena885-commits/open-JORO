// JORO - eval.h : static evaluation driven by the JORO playing style (see styles/joro.style)
#pragma once
#include "board.h"
#include <string>

namespace joro {

// One weight per module of the JORO style document. Weights are percentages (100 = nominal),
// except contempt (centipawns).
enum StyleParam {
    SP_OWN_KING,    // DKD  : own king safety
    SP_ENEMY_KING,  // DKD  : pressure on the enemy king
    SP_PINS,        // TBDA : pins / x-rays against valuable pieces
    SP_LOOSE,       // TBDA : hanging pieces, overloaded defenders
    SP_COMP,        // SI   : compensation for sacrificed material
    SP_OUTPOST,     // DSI  : outposts
    SP_POTENTIAL,   // DSI  : squares that can be prepared (potential outposts, files toward the king)
    SP_OPENING,     // PASI : opening principles (development, centre, castling)
    SP_ENDGAME,     // PASI : endgame (king activity, conversion, drawish scaling)
    SP_STRUCT,      // DPSI : pawn structure
    SP_PASSERS,     // DPSI : passed pawns
    SP_INITIATIVE,  // IPC  : threats, space, tempo
    SP_ACTIVITY,    // piece activity / mobility
    SP_CONTEMPT,    // cp, > 0 avoids draws
    SP_KING_HUNT,   // KHTI : king hunting & trap intelligence (escape squares, isolation, mating nets)
    SP_COUNT
};

struct Style {
    std::string name = "JORO";
    int w[SP_COUNT];

    Style();
    static const char* paramName(int i);        // e.g. "own_king"
    uint64_t id() const;                        // hash of the weights : ties experience <-> style
    uint64_t legacyId() const;                  // id of the same style without the modules added after v0.3 (KHTI)
    bool load(const std::string& path, std::string* err = nullptr);  // simple JSON
    bool loadText(const std::string& json, std::string* err = nullptr);
    bool save(const std::string& path) const;
    bool set(const std::string& param, int value);
    int& contempt() { return w[SP_CONTEMPT]; }
    int contempt() const { return w[SP_CONTEMPT]; }
};

// ---- King Position Classifier (JORO study: where is the enemy king and how good is its shield?)
enum KingPos { KP_SHORT, KP_LONG, KP_CENTER, KP_EXPOSED, KP_EDGE, KP_OTHER };

struct KingProfile {
    int type = KP_OTHER;     // KingPos
    int shieldPawns = 0;     // own pawns on the 3 shield files, ranks 2-3 (relative to the king's side)
    int shieldMissing = 3;   // 3 - shieldPawns
    int openFiles = 0;       // shield files without any own pawn
    int fileLo = 0, fileHi = 0;   // the 3 files that make the shield region
};

KingProfile classifyKing(const Board& b, int color);
const char* kingPosName(int t);

// ---- JORO plans (identity). The attacker c chooses a plan against the king of colour c^1:
//   PLAN_A : the enemy king can still castle -> make castling impossible (attack the transit squares, check, pressure)  [priority]
//   PLAN_B : the king is castled (or stuck uncastled) and soft -> make it unsafe (weak squares, rook lifts, 3-pawn storm, sacrifices)
//   PLAN_C : the king is too well defended -> queen hunt (trap the queen, played like a king hunt)
// B and C alternate depending on how hard the king is; A always wins when it applies.
//   PLAN_D : (search level, see search.h) A / B / C are stalled and the experience (joro.exp) is loaded -> steer the game toward
//            positions JORO already knows (forcing moves, checks, sacrifices). Never returned by selectPlan(): the searcher decides it.
enum Plan { PLAN_NONE, PLAN_A, PLAN_B, PLAN_C, PLAN_D };
// Plan parameters (SPSA tunable, carried by SearchParams: see tunables.h). `pp` = array of PP_COUNT ints, nullptr = defaults.
enum PlanParam {
    PP_A_TRANSIT,    // A : bonus per castling transit square we control
    PP_A_CHECK,      // A : enemy king in check while it still has castling rights
    PP_A_STUCK,      // A : every castling side is denied (king stuck in the centre)
    PP_B_WEAK,       // B : per weak king-zone square (hit by us, no enemy pawn can cover it)
    PP_B_LIFT,       // B : per rook lift toward the king (max 2)
    PP_B_STORM3,     // B : 3 pawns advanced on the shield files
    PP_B_SHIELD,     // B : >= 2 shield pawns missing
    PP_C_SAFE,       // C : per square the enemy queen has lost (7 - safe squares)
    PP_C_ATT,        // C : enemy queen attacked
    PP_C_LESSER,     // C : ... by a lesser piece
    PP_C_TRAP,       // C : queen with no safe square and attacked
    PP_W_A,          // % scale of the whole plan A bonus
    PP_W_B,          // % scale of the whole plan B bonus
    PP_W_C,          // % scale of the whole plan C bonus
    PP_HARD_DEF,     // selection : the king is "hard" (-> C) when it has at least this many defenders within 3 squares
    PP_PHASE_MIN,    // selection : no plan below this material phase (0..24)
    PP_COMP_THRESH,  // sacrifice compensation threshold while a plan is active (40 without a plan)
    PP_LMR_RELIEF,   // search : plies of late-move reduction removed for a move that serves the plan
    PP_COUNT
};
struct PlanParamDef { const char* name; int def, lo, hi, step; };   // step = SPSA perturbation size
const PlanParamDef& planParamDef(int i);

int selectPlan(const Board& b, int attacker, const int* pp = nullptr);
const char* planName(int plan);

// Optional report of evaluate(): the plan (A / B / C) each colour follows and the bonus that plan alone gives (0 = the plan makes no progress).
struct PlanReport { int plan[2] = {PLAN_NONE, PLAN_NONE}; int bonus[2] = {0, 0}; };

// score in centipawns from the side-to-move point of view
int evaluate(const Board& b, const Style& st, const int* planParams = nullptr, PlanReport* report = nullptr);

extern const int PIECE_VAL[7];

} // namespace joro
