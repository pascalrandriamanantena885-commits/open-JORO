// JORO - experience.cpp
#include "experience.h"
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace joro {

static const uint32_t EXP_VERSION = 2;

void Experience::clear() {
    tcache.ok = false;
    map.clear();
    total = 0;
    nSit = 0;
    styleSet = false;
    extra.clear();
}

void Experience::add(U64 key, Move m, int kind, int value, int inc) {
    if (kind == EXP_SIT) tcache.ok = false;
    auto& v = map[key];
    for (auto& e : v) {
        if (e.move == m && e.kind == kind) {
            int oc = e.count, nc = std::min(255, oc + inc);
            e.value = (int16_t)((e.value * oc + value * inc) / std::max(1, oc + inc));
            e.count = (uint8_t)nc;
            return;
        }
    }
    ExpEntry e;
    e.key = key;
    e.move = m;
    e.value = (int16_t)value;
    e.kind = (uint8_t)kind;
    e.count = (uint8_t)std::min(255, std::max(1, inc));
    v.push_back(e);
    total++;
    if (kind == EXP_SIT) nSit++;
}

void Experience::addSituation(U64 key, uint32_t code, int value, int inc) {
    value = std::max(-SIT_CAP, std::min(SIT_CAP, value));
    add(key, code, EXP_SIT, value, inc);   // same key + same code: count grows, value is the running average
}

int Experience::sitScore(U64 key) const {
    auto it = map.find(key);
    if (it == map.end()) return 0;
    int sum = 0;
    for (auto& e : it->second)
        if (e.kind == EXP_SIT) {
            const int conf = e.move >= SIT_PATTERN ? PAT_CONF : SIT_CONF;
            sum += e.value * std::min<int>(e.count, conf) / conf;
        }
    return std::max(-SIT_CAP, std::min(SIT_CAP, sum));
}

SitFeat situationFeatures(const Board& b, int us) {
    const int them = us ^ 1;
    int np[2] = {0, 0}, pc[2][7] = {{0}}, mat[2] = {0, 0};
    for (int s = 0; s < 64; s++) {
        const int p = b.sq[s];
        if (!p) continue;
        const int t = typeOf(p), c = colorOf(p);
        pc[c][t]++;
        if (t != KING) mat[c] += PIECE_VAL[t];
        if (t > PAWN && t < KING) np[c] += PIECE_VAL[t];
    }
    const int total = np[0] + np[1];
    const int phase = total > 5200 ? 0 : total > 3600 ? 1 : total > 2400 ? 2 : 3;
    const int d = mat[us] - mat[them];
    const int bal = d <= -300 ? 0 : d < -100 ? 1 : d <= 100 ? 2 : d < 300 ? 3 : 4;
    auto kingState = [&](int c) {   // 0 = castled / king moved, rights gone; 1 = can still castle; 2 = lost the rights without castling
        const int rights = b.castling & (c == WHITE ? (CR_WK | CR_WQ) : (CR_BK | CR_BQ));
        if (rights) return 1;
        return b.kingSq[c] == (c == WHITE ? 4 : 60) ? 2 : 0;
    };
    auto pawnB = [](int n) { return n <= 4 ? 0 : n <= 6 ? 1 : 2; };
    SitFeat f;
    int i = 0;
    f.v[i++] = (int8_t)phase;                                  f.v[i++] = (int8_t)bal;
    f.v[i++] = pc[us][QUEEN] > 0;                              f.v[i++] = pc[them][QUEEN] > 0;
    f.v[i++] = (int8_t)std::min(2, pc[us][ROOK]);              f.v[i++] = (int8_t)std::min(2, pc[them][ROOK]);
    f.v[i++] = (int8_t)std::min(3, pc[us][KNIGHT] + pc[us][BISHOP]);
    f.v[i++] = (int8_t)std::min(3, pc[them][KNIGHT] + pc[them][BISHOP]);
    f.v[i++] = (int8_t)pawnB(pc[us][PAWN]);                    f.v[i++] = (int8_t)pawnB(pc[them][PAWN]);
    f.v[i++] = (int8_t)kingState(us);                          f.v[i++] = (int8_t)kingState(them);
    return f;
}

U64 signatureOf(const SitFeat& f) {
    U64 h = 0x9E3779B97F4A7C15ULL;
    for (int i = 0; i < SIT_NF; i++) { h ^= (U64)(f.v[i] + 1); h *= 0x100000001B3ULL; h ^= h >> 29; }
    return h ^ 0xA5A5A5A5DEADBEEFULL;
}

U64 situationSignature(const Board& b) { return signatureOf(situationFeatures(b, b.side)); }

// feature indices
enum { F_PHASE, F_BAL, F_QUS, F_QTHEM, F_RUS, F_RTHEM, F_MUS, F_MTHEM, F_PUS, F_PTHEM, F_KUS, F_KTHEM };

int sitDistance(const SitFeat& c, const SitFeat& t) {
    int d = 0;
    // what only goes one way: the phase never goes back, pieces and pawns that are gone do not come back (cost 1 per step down: a capture
    // or a trade; queens 2; pawn buckets 2)
    if (t.v[F_PHASE] < c.v[F_PHASE]) d += SIT_IMPOSSIBLE * (c.v[F_PHASE] - t.v[F_PHASE]);
    auto down = [&](int i, int cost) {
        const int diff = c.v[i] - t.v[i];
        d += diff >= 0 ? diff * cost : -diff * SIT_IMPOSSIBLE;
    };
    down(F_QUS, 2);   down(F_QTHEM, 2);
    down(F_RUS, 1);   down(F_RTHEM, 1);
    down(F_MUS, 1);   down(F_MTHEM, 1);
    down(F_PUS, 2);   down(F_PTHEM, 2);
    // the material balance can move both ways (a capture, a sacrifice, a recapture)
    d += std::abs(c.v[F_BAL] - t.v[F_BAL]);
    // king state: castling (1 -> 0) or giving up the rights (1 -> 2) is one move; walking the king after losing the rights is longer;
    // the rights never come back. The ENEMY king is not ours to move: twice the cost.
    auto king = [&](int i, int mul) {
        const int a = c.v[i], b = t.v[i];
        int k = 0;
        if (a == b) k = 0;
        else if (a == 1) k = 1;
        else if (a == 2 && b == 0) k = 3;
        else k = SIT_IMPOSSIBLE;
        d += k * mul;
    };
    king(F_KUS, 1);
    king(F_KTHEM, 2);
    return d;
}

int Experience::patCount(U64 key) const {
    auto it = map.find(key);
    if (it == map.end()) return 0;
    int n = 0;
    for (auto& e : it->second)
        if (e.kind == EXP_SIT && e.move >= SIT_PATTERN) n += e.count;
    return n;
}

const std::vector<SitTarget>& Experience::goodTargets() const {
    std::lock_guard<std::mutex> lk(tcache.mx);
    if (tcache.ok) return tcache.v;
    tcache.v.clear();
    // 1. the signatures of the good patterns (the key is a hash: it is decoded by walking every possible feature combination)
    std::unordered_map<U64, int> good;
    for (auto& kv : map) {
        bool pat = false;
        for (auto& e : kv.second) if (e.kind == EXP_SIT && e.move >= SIT_PATTERN) pat = true;
        if (!pat) continue;
        const int sc = sitScore(kv.first);
        if (sc >= SIT_TARGET_MIN) good[kv.first] = sc;
    }
    if (!good.empty()) {
        static const int lim[SIT_NF] = {4, 5, 2, 2, 3, 3, 4, 4, 3, 3, 3, 3};
        SitFeat f;
        std::memset(&f, 0, sizeof f);
        for (;;) {
            auto it = good.find(signatureOf(f));
            if (it != good.end()) tcache.v.push_back({f, it->second});
            int i = SIT_NF - 1;
            while (i >= 0 && ++f.v[i] >= lim[i]) f.v[i--] = 0;
            if (i < 0) break;
        }
        std::sort(tcache.v.begin(), tcache.v.end(), [](const SitTarget& a, const SitTarget& b) { return a.value > b.value; });
        if ((int)tcache.v.size() > SIT_MAX_TARGETS) tcache.v.resize(SIT_MAX_TARGETS);
    }
    tcache.ok = true;
    return tcache.v;
}

const char* sitName(uint32_t c) {
    if (c >= SIT_PATTERN) return "pattern";
    switch (c) {
        case SIT_BAD_OPENING: return "bad opening";
        case SIT_WEAK_KING: return "weak king";
        case SIT_QUEEN_TRADE: return "queen trade";
        case SIT_EXCHANGE: return "exchange";
        case SIT_BAD_SACRIFICE: return "bad sacrifice";
        case SIT_LOSING_ENDGAME: return "losing endgame";
        case SIT_MATE_ATTACK: return "mating attack";
        case SIT_FAST_MATE: return "fast mate";
        case SIT_PRESSURE: return "pressure";
        case SIT_SAC_WIN: return "winning sacrifice";
        case SIT_WIN_ENDGAME: return "winning endgame";
        case SIT_SHORT_WIN: return "short win";
        default: return "?";
    }
}

static int countOf(const std::unordered_map<U64, std::vector<ExpEntry>>& map, U64 key, Move m, int kind) {
    auto it = map.find(key);
    if (it == map.end()) return 0;
    for (auto& e : it->second)
        if (e.move == m && e.kind == kind) return e.count;
    return 0;
}
int Experience::goodCount(U64 key, Move m) const { return countOf(map, key, m, EXP_GOOD); }
int Experience::badCount(U64 key, Move m) const { return countOf(map, key, m, EXP_BAD); }

Move Experience::bestGood(U64 key, const Move* cands, int n, int* value) const {
    auto it = map.find(key);
    if (it == map.end()) return MOVE_NONE;
    Move best = MOVE_NONE;
    int bestNet = 0, bestVal = -32768;
    for (auto& e : it->second) {
        if (e.kind != EXP_GOOD) continue;
        bool legal = false;
        for (int i = 0; i < n; i++)
            if (cands[i] == e.move) { legal = true; break; }
        if (!legal) continue;
        int net = e.count - badCount(key, e.move);
        if (net <= 0) continue;
        if (net > bestNet || (net == bestNet && e.value > bestVal)) {
            best = e.move;
            bestNet = net;
            bestVal = e.value;
        }
    }
    if (value) *value = bestVal;
    return best;
}

Experience::Probe Experience::probe(U64 key) const {
    Probe p;
    auto it = map.find(key);
    if (it == map.end()) return p;
    p.sit = sitScore(key);
    for (auto& e : it->second) {
        if (e.kind == EXP_SIT) continue;
        const int bad = badCount(key, e.move);
        if (e.kind == EXP_BAD) {
            if (e.count > goodCount(key, e.move)) p.trap = true;
            continue;
        }
        const int net = e.count - bad;
        if (net <= 0) continue;
        if (p.kind == 0 || e.value > p.value) { p.kind = 1; p.value = e.value; p.net = net; }
    }
    return p;
}

void Experience::merge(const Experience& o) {
    for (auto& kv : o.map)
        for (auto& e : kv.second) add(e.key, e.move, e.kind, e.value, e.count);
    if (o.styleSet && !styleSet) { styleSet = true; std::memcpy(st, o.st, sizeof st); extra = o.extra; styleIdv = o.styleIdv; std::memcpy(styleName, o.styleName, 16); }
}

void Experience::setStyle(const Style& s) {
    styleSet = true;
    std::memset(st, 0, sizeof st);
    extra.clear();
    for (int i = 0; i < SP_COUNT; i++) {
        if (i < EXP_HEADER_PARAMS) st[i] = s.w[i];
        else if (s.w[i] != 0) extra.emplace_back(Style::paramName(i), s.w[i]);
    }
    styleIdv = s.id();
    std::memset(styleName, 0, 16);
    std::strncpy(styleName, s.name.c_str(), 15);
}
int Experience::weight(int i) const {
    if (i < 0 || i >= SP_COUNT) return 0;
    if (i < EXP_HEADER_PARAMS) return st[i];
    for (auto& e : extra)
        if (e.first == Style::paramName(i)) return e.second;
    return 0;
}
bool Experience::getStyle(Style& s) const {
    if (!styleSet) return false;
    for (int i = 0; i < SP_COUNT; i++) s.w[i] = weight(i);
    s.name = std::string(styleName, strnlen(styleName, 16));
    return true;
}

bool Experience::save(const std::string& path) const {
    std::vector<ExpEntry> all;
    all.reserve(total);
    for (auto& kv : map)
        for (auto& e : kv.second) all.push_back(e);
    std::sort(all.begin(), all.end(), [](const ExpEntry& a, const ExpEntry& b) {
        if (a.key != b.key) return a.key < b.key;
        if (a.move != b.move) return a.move < b.move;
        return a.kind < b.kind;
    });
    FILE* f = fopen(path.c_str(), "wb");
    if (!f) return false;
    uint32_t ver = EXP_VERSION, n = (uint32_t)all.size(), flags = styleSet ? 1 : 0;
    bool ok = fwrite("JEXP", 1, 4, f) == 4 && fwrite(&ver, 4, 1, f) == 1 && fwrite(&n, 4, 1, f) == 1 &&
              fwrite(&flags, 4, 1, f) == 1 && fwrite(&styleIdv, 8, 1, f) == 1 &&
              fwrite(styleName, 1, 16, f) == 16 && fwrite(st, 4, 16, f) == 16;
    if (ok && n) ok = fwrite(all.data(), sizeof(ExpEntry), n, f) == n;
    if (ok && !extra.empty()) {                                   // footer: only when a parameter does not fit the header
        uint32_t cnt = (uint32_t)extra.size();
        ok = fwrite("JSTY", 1, 4, f) == 4 && fwrite(&cnt, 4, 1, f) == 1;
        for (auto& e : extra) {
            char nm[16] = {0};
            std::strncpy(nm, e.first.c_str(), 15);
            int32_t v = e.second;
            ok = ok && fwrite(nm, 1, 16, f) == 16 && fwrite(&v, 4, 1, f) == 1;
        }
    }
    fclose(f);
    return ok;
}

bool Experience::load(const std::string& path, std::string* err) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) { if (err) *err = "cannot open " + path; return false; }
    return loadFrom(f, path, err);   // closes f
}

// An experience carried inside the engine file (see embed.h): read it from memory.
bool Experience::loadMem(const void* data, size_t size, std::string* err) {
#if defined(_WIN32)
    if (err) *err = "embedded experience not supported on this platform";
    return false;
#else
    FILE* f = fmemopen(const_cast<void*>(data), size, "rb");
    if (!f) { if (err) *err = "cannot read the embedded experience"; return false; }
    return loadFrom(f, "<embedded>", err);   // closes f
#endif
}

bool Experience::loadFrom(FILE* f, const std::string& path, std::string* err) {
    char magic[4];
    uint32_t ver = 0, n = 0, flags = 0;
    int32_t s[16];
    uint64_t sid = 0;
    char sname[16];
    bool ok = fread(magic, 1, 4, f) == 4 && memcmp(magic, "JEXP", 4) == 0 && fread(&ver, 4, 1, f) == 1 &&
              fread(&n, 4, 1, f) == 1 && fread(&flags, 4, 1, f) == 1 &&
              fread(&sid, 8, 1, f) == 1 && fread(sname, 1, 16, f) == 16 && fread(s, 4, 16, f) == 16;
    if (!ok || ver != EXP_VERSION) {
        fclose(f);
        if (err) *err = "bad header / version in " + path;
        return false;
    }
    std::vector<ExpEntry> all(n);
    if (n && fread(all.data(), sizeof(ExpEntry), n, f) != n) {
        fclose(f);
        if (err) *err = "truncated file " + path;
        return false;
    }
    // optional footer. Trailing bytes without the "JSTY" magic are ignored; a footer that starts with it but is damaged makes the load
    // fail: the style would be wrong (parameters silently off) although the entries are fine.
    std::vector<std::pair<std::string, int32_t>> ext;
    char fm[4];
    bool badFooter = false;
    if (fread(fm, 1, 4, f) == 4 && memcmp(fm, "JSTY", 4) == 0) {
        uint32_t cnt = 0;
        if (fread(&cnt, 4, 1, f) != 1 || cnt > 4096) badFooter = true;
        for (uint32_t i = 0; i < cnt && !badFooter; i++) {
            char nm[16];
            int32_t v = 0;
            if (fread(nm, 1, 16, f) != 16 || fread(&v, 4, 1, f) != 1) badFooter = true;
            else ext.emplace_back(std::string(nm, strnlen(nm, 16)), v);
        }
    }
    fclose(f);
    if (badFooter) {
        if (err) *err = "damaged style footer in " + path;
        return false;
    }
    clear();
    extra.clear();
    for (auto& e : all) add(e.key, e.move, e.kind, e.value, e.count);
    if (flags & 1) { styleSet = true; std::memcpy(st, s, sizeof st); extra = ext; styleIdv = sid; std::memcpy(styleName, sname, 16); }
    return true;
}

} // namespace joro
