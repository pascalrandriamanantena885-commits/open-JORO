#pragma once
namespace joro { void uciLoop(const char* argv0 = nullptr); }
