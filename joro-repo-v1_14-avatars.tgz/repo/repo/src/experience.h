// JORO - experience.h : the patchable "experience" file (joro.exp)
//
// File layout (little endian), version 2:
//   header 104 bytes : magic "JEXP" | u32 version(=2) | u32 nEntries | u32 flags (bit0 = has style)
//                      | u64 styleId | char styleName[16] | i32 style[16] (weights, see StyleParam)
//   entries (16 bytes each) : u64 key | u32 move | i16 value | u8 kind (0 good, 1 bad, 2 situation) | u8 count
//                      kind 2 = SITUATION (see SitCode): `move` holds the situation code, `value` is signed from the point of view of the
//                      side to move at `key` (> 0 good for it, < 0 bad for it). The file layout / version are unchanged; an engine that
//                      predates situations ignores them in the move logic (goodCount / bestGood only look at kind 0 and 1).
//   optional footer (only when needed) : "JSTY" | u32 count | count x { char name[16]; i32 value }
// The experience belongs to the style that produced it (styleId = hash of the weights).
//
// Adding an eval term later never breaks an existing joro.exp:
//  * StyleParam values are APPEND-ONLY (a new one goes just before SP_COUNT). Parameters 0..EXP_HEADER_PARAMS-1 live in the header
//    by index (exactly as before: the file stays byte-identical, 104 + 16 n bytes, while the new terms are off = 0).
//  * Parameters from EXP_HEADER_PARAMS on are written in the footer BY NAME, only when non-zero. A missing one means "off" (0),
//    which is also how Style::id() treats it, so an old experience stays compatible with a style whose new term is off.
//  * Unknown names found in a footer are kept as they are when the file is saved again (a newer file survives an older engine).
//  * A footer that starts with "JSTY" but is damaged makes the load fail (never a silently wrong style); other trailing bytes are ignored.
//  * An older C++ reader ignores the footer (it never checks the file size); the Android Storage.readExpInfo accepts it (see its check).
#pragma once
#include <cstdio>
#include "eval.h"
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace joro {

// Style parameters stored by index in the 16 header slots. Production value 16; the tests lower it to push real parameters into the footer.
#ifndef EXP_HEADER_PARAMS
#define EXP_HEADER_PARAMS 16
#endif
static_assert(EXP_HEADER_PARAMS >= 1 && EXP_HEADER_PARAMS <= 16, "the header has 16 slots");

enum ExpKind : uint8_t { EXP_GOOD = 0, EXP_BAD = 1, EXP_SIT = 2 };

// Situations JORO learns to tell apart (stored in the `move` field of a kind-2 entry). A situation is attached to the POSITION where it
// appeared (the position after the move that created it), not to a move: the search meets the same position again by transposition.
// BAD ones are the ones JORO must not walk into again, GOOD ones the ones it should look for.
enum SitCode : uint32_t {
    SIT_NONE = 0,
    // ---- bad (stored with a negative value for the side that suffers them)
    SIT_BAD_OPENING = 1,      // an opening that gave the game away early (big drop in the opening, game lost)
    SIT_WEAK_KING = 2,        // own king weakened (castling rights thrown away, shield torn, king exposed) -> lost
    SIT_QUEEN_TRADE = 3,      // queens exchanged and the game was lost afterwards
    SIT_EXCHANGE = 4,         // other piece exchange that led to a lost endgame
    SIT_BAD_SACRIFICE = 5,    // a sacrifice that brought nothing (the game was lost, perhaps by checkmate)
    SIT_LOSING_ENDGAME = 6,   // entering the endgame already worse, and losing it
    // ---- good (stored with a positive value for the side that enjoys them)
    SIT_MATE_ATTACK = 16,     // a position of a line that ended in CHECKMATE (the nearer to the mate, the stronger)
    SIT_FAST_MATE = 17,       // the mate came early (opening / early middlegame)
    SIT_PRESSURE = 18,        // the opponent only defends (no check, no capture) while we keep the initiative: weaknesses follow
    SIT_SAC_WIN = 19,         // a piece given away that led to a won game
    SIT_WIN_ENDGAME = 20,     // entering an endgame that was won
    SIT_SHORT_WIN = 21,       // won without ever reaching the endgame: the best kind of win
    // The named codes above are only EXAMPLES of what the analysis can recognise. Every other kind of situation is learned as a
    // PATTERN: the key is not an exact position but a signature of its features (see situationSignature), the value is how the games
    // that went through such a position ended. It generalises to positions JORO has never seen.
    SIT_PATTERN = 64
};
inline bool sitIsGood(uint32_t c) { return c >= 16 && c < SIT_PATTERN; }
// Signature of the FEATURES of a position seen by the side to move (phase, queens, material balance, rooks / minors / pawns of each
// side, castling state of both kings). Positions that look alike share it; side-to-move relative, so it works for both colours.
U64 situationSignature(const Board& b);
const char* sitName(uint32_t code);

// FEATURES of a position seen by colour `us` (the same 12 numbers that situationSignature hashes, in the same order): phase 0-3, material
// balance bucket 0-4, queen us / them, rooks us / them (0-2), minors us / them (0-3), pawn bucket us / them (0-2), king state us / them
// (0 = castled or king moved, 1 = can still castle, 2 = rights lost without castling).
constexpr int SIT_NF = 12;
struct SitFeat { int8_t v[SIT_NF]; };
SitFeat situationFeatures(const Board& b, int us);
U64 signatureOf(const SitFeat& f);          // situationSignature(b) == signatureOf(situationFeatures(b, b.side))
// DIRECTED distance from the situation `cur` to the situation `tgt` (about the number of events needed: trades, captures, sacrifices,
// castling). What cannot come back (a captured queen, pieces that are gone, a king that already moved) costs SIT_IMPOSSIBLE per step.
constexpr int SIT_IMPOSSIBLE = 8;
int sitDistance(const SitFeat& cur, const SitFeat& tgt);
// A GOOD situation of the experience that can be used as a goal: a learned pattern with a positive balanced score.
struct SitTarget { SitFeat f; int value; };

struct ExpEntry {
    U64 key;
    uint32_t move;
    int16_t value;
    uint8_t kind;
    uint8_t count;
};
static_assert(sizeof(ExpEntry) == 16, "ExpEntry must be 16 bytes");

class Experience {
public:
    bool load(const std::string& path, std::string* err = nullptr);
    bool loadMem(const void* data, size_t size, std::string* err = nullptr);   // same format, from memory
    bool loadFrom(FILE* f, const std::string& what, std::string* err = nullptr);   // takes the FILE* (always closed)
    bool save(const std::string& path) const;

    // record a move for a position key. inc = how many times it was seen
    void add(U64 key, Move m, int kind, int value = 0, int inc = 1);
    // Situation memory (replaces the old etude / mating-variation memory). `value` is signed from the point of view of the side
    // to move at `key`. Seen again in another game the entry grows in confidence (count) and its value is averaged, so a
    // situation that sometimes wins and sometimes loses ends up near zero: the experience stays balanced.
    void addSituation(U64 key, uint32_t code, int value, int inc = 1);
    // Balanced score (cp, side to move at `key`) of everything known about the position: sum over its situations of
    // value * min(count, SIT_CONF) / SIT_CONF, clamped to +-SIT_CAP. 0 = nothing known / balanced.
    static constexpr int SIT_CONF = 3, SIT_CAP = 400, PAT_CONF = 20;   // PAT_CONF: times a pattern must be seen for full weight
    int sitScore(U64 key) const;
    size_t sitCount() const { return nSit; }
    int patCount(U64 key) const;   // how many times patterns with this signature were seen (0 = this kind of situation is NEW to the experience)
    // Good pattern situations (best first, at most SIT_MAX_TARGETS), decoded back to features. Built on first use, rebuilt after a change.
    static constexpr int SIT_MAX_TARGETS = 64, SIT_TARGET_MIN = 20;
    const std::vector<SitTarget>& goodTargets() const;
    int goodCount(U64 key, Move m) const;
    int badCount(U64 key, Move m) const;
    bool isBad(U64 key, Move m) const { return badCount(key, m) > goodCount(key, m); }
    // best "good" move among candidates (net count > 0); returns MOVE_NONE if none
    Move bestGood(U64 key, const Move* cands, int n, int* value = nullptr) const;

    // What the experience knows about a position, for the side to move there (used by Plan D to steer toward known positions).
    //   kind 0 = no known move, 1 = a known good move (net count > 0). value = the stored value of that entry, net = its count minus its
    //   bad count, trap = a known BAD move exists there, sit = sitScore(key) (situation memory, side to move).
    struct Probe { int kind = 0; int value = 0; int net = 0; bool trap = false; int sit = 0; };
    Probe probe(U64 key) const;

    void merge(const Experience& o);
    void clear();
    size_t size() const { return total; }

    void setStyle(const Style& s);
    bool getStyle(Style& s) const;
    bool hasStyle() const { return styleSet; }
    uint64_t styleId() const { return styleIdv; }
    // usable with this style? same id, or made before the newest modules (KHTI) existed
    bool compatibleWith(const Style& s) const { return !styleSet || styleIdv == s.id() || styleIdv == s.legacyId(); }
    // made with a style that predates KHTI (module off): can be upgraded to the current style
    bool isLegacy() const { return styleSet && weight(SP_KING_HUNT) == 0; }
    // weight of style parameter i as stored in this file (header or footer; a parameter the file does not know = 0 = off)
    int weight(int i) const;

private:
    std::unordered_map<U64, std::vector<ExpEntry>> map;
    struct TargetCache {   // copyable (a copy starts empty and is rebuilt on first use)
        std::mutex mx;
        std::vector<SitTarget> v;
        bool ok = false;
        TargetCache() = default;
        TargetCache(const TargetCache&) {}
        TargetCache& operator=(const TargetCache&) { v.clear(); ok = false; return *this; }
    };
    mutable TargetCache tcache;
    size_t total = 0, nSit = 0;
    bool styleSet = false;
    int32_t st[16] = {0};
    std::vector<std::pair<std::string, int32_t>> extra;   // footer: parameters >= EXP_HEADER_PARAMS, by name, non-zero only
    uint64_t styleIdv = 0;
    char styleName[16] = {0};
};

} // namespace joro
