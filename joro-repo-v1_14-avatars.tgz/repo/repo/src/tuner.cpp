#include "tuner.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <map>
#include <random>
#include <sstream>
#include <thread>

namespace joro {

// ------------------------------------------------------------------------------------------------ starts
std::vector<TuneStart> parseTuneStarts(const std::string& text) {
    std::vector<TuneStart> out;
    std::istringstream is(text);
    std::string line;
    while (std::getline(is, line)) {
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
        size_t a = line.find_first_not_of(' ');
        if (a == std::string::npos || line[a] == '#') continue;
        line = line.substr(a);
        TuneStart s;
        if (line.find('/') != std::string::npos) {                 // a FEN; complete a 4-field EPD with the clocks
            std::istringstream fs(line);
            std::vector<std::string> f;
            std::string t;
            while (fs >> t) f.push_back(t);
            if (f.size() < 4) continue;
            std::string fen = f[0] + " " + f[1] + " " + f[2] + " " + f[3] + " " + (f.size() > 4 ? f[4] : "0") + " " + (f.size() > 5 ? f[5] : "1");
            Board b;
            if (!b.setFen(fen)) continue;
            s.fen = fen;
        } else {                                                    // UCI moves from the standard start
            s.fen = START_FEN;
            std::istringstream ms(line);
            std::string t;
            Board b;
            b.setFen(s.fen);
            bool ok = true;
            while (ms >> t) {
                Move m = b.parseMove(t);
                if (!m) { ok = false; break; }
                b.makeMove(m);
                s.moves.push_back(t);
            }
            if (!ok) continue;
        }
        out.push_back(s);
    }
    return out;
}

// ------------------------------------------------------------------------------------------------ parameters
Tuner::Tuner(const TuneConfig& cfg, std::vector<TuneStart> starts, const Style& base, const SearchParams& baseSp)
    : cfg_(cfg), starts_(std::move(starts)), baseStyle_(base), baseSp_(baseSp) {
    initTables();
    cfg_.threads = std::max(1, std::min(cfg_.threads, 8));
    cfg_.pairs = std::max(1, cfg_.pairs);
    cfg_.emaWindow = std::max(1, cfg_.emaWindow);
    if (cfg_.tuneStyle)
        for (int i = 0; i < SP_COUNT; i++) {
            if (i == SP_CONTEMPT) continue;                         // contempt interacts with draws: set it by hand
            defs_.push_back({Style::paramName(i), true, i, i == SP_KING_HUNT ? 5 : 0, i == SP_KING_HUNT ? 200 : 300, 15.0});   // king_hunt 0 would make an experience "legacy"
        }
    if (cfg_.tuneSearch) {
        const struct { int idx, lo, hi; double c; } S[] = {
            {SPR_RFP_MARGIN, 40, 300, 15}, {SPR_RFP_DEPTH, 1, 6, 1}, {SPR_NULL_BASE, 1, 4, 1}, {SPR_NULL_DIV, 3, 10, 1},
            {SPR_DELTA, 80, 500, 30}, {SPR_LMR_START, 1, 8, 1}, {SPR_LMR_MORE, 4, 16, 2}};
        for (auto& s : S) defs_.push_back({SearchParams::paramName(s.idx), false, s.idx, s.lo, s.hi, s.c});
    }
    if (cfg_.tunePlans)   // JORO plans A/B/C: bonuses, plan weights, selection thresholds, LMR relief
        for (int i = 0; i < PP_COUNT; i++) {
            const PlanParamDef& d = planParamDef(i);
            defs_.push_back({d.name, false, SPR_PLAN_FIRST + i, d.lo, d.hi, (double)d.step});
        }
    for (auto& d : defs_) {
        int v = d.style ? baseStyle_.w[d.idx] : baseSp_.v[d.idx];
        v = std::max(d.lo, std::min(d.hi, v));
        init_.push_back(v);
        theta_.push_back(v);
        avg_.push_back(v);
    }
    for (int t = 0; t < cfg_.threads; t++) {
        poolA_.emplace_back(new Searcher());
        poolB_.emplace_back(new Searcher());
        for (Searcher* s : {poolA_.back().get(), poolB_.back().get()}) {
            s->quiet = true;
            s->setHash(cfg_.hashMB);
            s->moveOverhead = 2;          // movetime really is the time per move
            s->useExperience = false;
        }
    }
}

int Tuner::clampi(int i, int v) const { return std::max(defs_[i].lo, std::min(defs_[i].hi, v)); }

void Tuner::apply(const std::vector<int>& vals, Style& st, SearchParams& sp) const {
    for (size_t i = 0; i < defs_.size(); i++) {
        if (defs_[i].style) st.w[defs_[i].idx] = vals[i];
        else sp.v[defs_[i].idx] = vals[i];
    }
}

Style Tuner::tunedStyle() const {
    Style st = baseStyle_;
    SearchParams sp = baseSp_;
    std::vector<int> v;
    for (size_t i = 0; i < defs_.size(); i++) v.push_back(clampi((int)i, (int)std::lround(avg_[i])));
    apply(v, st, sp);
    st.name = "JORO-tuned";
    return st;
}
SearchParams Tuner::tunedSearch() const {
    Style st = baseStyle_;
    SearchParams sp = baseSp_;
    std::vector<int> v;
    for (size_t i = 0; i < defs_.size(); i++) v.push_back(clampi((int)i, (int)std::lround(avg_[i])));
    apply(v, st, sp);
    return sp;
}
bool Tuner::exportTuned(const std::string& path) const { return saveTuning(path, tunedStyle(), tunedSearch()); }

std::string Tuner::table() const {
    std::string out;
    char buf[160];
    for (size_t i = 0; i < defs_.size(); i++) {
        int a = clampi((int)i, (int)std::lround(avg_[i]));
        snprintf(buf, sizeof buf, "%-14s %4d -> %4d  (%+d)%s\n", defs_[i].name, init_[i], a, a - init_[i], a != init_[i] ? "" : "");
        out += buf;
    }
    return out;
}

// ------------------------------------------------------------------------------------------------ pause / stop
void Tuner::stop() {
    stopped_ = true;
    for (auto& s : poolA_) s->stopFlag = true;
    for (auto& s : poolB_) s->stopFlag = true;
    std::lock_guard<std::mutex> lk(mu_);
    cv_.notify_all();
}
void Tuner::setPaused(bool p) {
    std::lock_guard<std::mutex> lk(mu_);
    paused_ = p;
    cv_.notify_all();
}
bool Tuner::isWaiting() const { return paused_ && active_ > 0 && sleeping_ >= active_; }

void Tuner::gate() {
    if (!paused_) return;
    std::unique_lock<std::mutex> lk(mu_);
    sleeping_++;
    cv_.wait(lk, [&] { return !paused_ || stopped_; });
    sleeping_--;
}

// ------------------------------------------------------------------------------------------------ games
// +1 A wins, -1 B wins, 0 draw, 2 aborted. A game decided for 6 moves in a row (|eval| >= 900 cp) is adjudicated.
int Tuner::playGame(Searcher& A, Searcher& B, const TuneStart& st, bool aWhite) {
    Board b;
    if (!b.setFen(st.fen)) return 0;
    for (const std::string& s : st.moves) {
        Move m = b.parseMove(s);
        if (!m) return 0;
        b.makeMove(m);
    }
    Searcher& white = aWhite ? A : B;
    Searcher& black = aWhite ? B : A;
    white.clear();
    black.clear();
    int streak = 0, sign = 0;
    for (int ply = 0; ply < cfg_.maxPlies; ply++) {
        gate();
        if (stopped_) return 2;
        Move mv[256];
        if (b.genLegal(mv) == 0) {
            int w = b.inCheck() ? (b.side == WHITE ? -1 : 1) : 0;   // white's view
            return aWhite ? w : -w;
        }
        if (b.isDraw()) return 0;
        Searcher& s = b.side == WHITE ? white : black;
        s.stopFlag = false;
        Limits lim;
        if (cfg_.nodes > 0) lim.nodes = cfg_.nodes;
        else lim.movetime = cfg_.movetimeMs;
        SearchResult r = s.go(b, lim);
        if (stopped_) return 2;
        int w = b.side == WHITE ? r.score : -r.score;
        if (std::abs(w) >= 900) {
            int sg = w > 0 ? 1 : -1;
            streak = sg == sign ? streak + 1 : 1;
            sign = sg;
        } else { streak = 0; sign = 0; }
        if (streak >= 6) return aWhite ? sign : -sign;
        if (r.best == MOVE_NONE) return 0;
        b.makeMove(r.best);
    }
    return 0;
}

bool Tuner::runGames(const std::vector<Game>& games, const std::vector<int>& valsA, const std::vector<int>& valsB, std::vector<int>& res) {
    Style sa = baseStyle_, sb = baseStyle_;
    SearchParams pa = baseSp_, pb = baseSp_;
    apply(valsA, sa, pa);
    apply(valsB, sb, pb);
    res.assign(games.size(), 0);
    std::atomic<size_t> next{0};
    std::atomic<bool> aborted{false};
    const int nt = std::min<int>(cfg_.threads, (int)games.size());
    for (int t = 0; t < nt; t++) {
        poolA_[t]->style = sa; poolA_[t]->sp = pa;
        poolB_[t]->style = sb; poolB_[t]->sp = pb;
    }
    active_ = nt;
    sleeping_ = 0;
    std::vector<std::thread> th;
    for (int t = 0; t < nt; t++)
        th.emplace_back([&, t] {
            for (;;) {
                size_t g = next++;
                if (g >= games.size() || stopped_) break;
                int r = playGame(*poolA_[t], *poolB_[t], starts_[games[g].start], games[g].aWhite);
                if (r == 2) { aborted = true; break; }
                res[g] = r;
            }
        });
    for (auto& t : th) t.join();
    active_ = 0;
    return !aborted && !stopped_;
}

static void pickStarts(std::mt19937& rng, size_t n, int pairs, std::vector<int>& out) {
    std::vector<int> idx(n);
    for (size_t i = 0; i < n; i++) idx[i] = (int)i;
    std::shuffle(idx.begin(), idx.end(), rng);
    for (int i = 0; i < pairs; i++) out.push_back(idx[(size_t)i % n]);   // without repeats while there are enough starts
}

int Tuner::step(TuneStep& out) {
    if (stopped_) return 2;
    if (starts_.empty() || defs_.empty()) return -1;
    const int n = (int)defs_.size();
    std::mt19937 rng(cfg_.seed * 2654435761u + (unsigned)iter_ * 40503u + 17u);
    const double ck = 1.0 / std::pow(1.0 + iter_, 0.101);
    std::vector<int> plus(n), minus(n), dir(n);
    for (int i = 0; i < n; i++) {
        dir[i] = (rng() & 1) ? 1 : -1;
        double delta = std::max(0.5, defs_[i].c * ck);             // >= 0.5 so that the rounded + and - values differ
        plus[i] = clampi(i, (int)std::lround(theta_[i] + dir[i] * delta));
        minus[i] = clampi(i, (int)std::lround(theta_[i] - dir[i] * delta));
        if (plus[i] == minus[i]) {                                  // squeezed against a bound: keep the two sides apart
            if (plus[i] < defs_[i].hi) plus[i]++; else minus[i]--;
        }
    }
    std::vector<int> pick;
    pickStarts(rng, starts_.size(), cfg_.pairs, pick);
    std::vector<Game> games;
    for (int s : pick) { games.push_back({s, true}); games.push_back({s, false}); }
    std::vector<int> res;
    if (!runGames(games, plus, minus, res)) return 2;               // aborted: theta is left untouched
    int w = 0, d = 0, l = 0;
    for (int r : res) { if (r > 0) w++; else if (r < 0) l++; else d++; }
    const double G = (double)games.size();
    const double score = (w - l) / G;                                // A = theta+ ; in [-1, 1]
    const double ak = cfg_.eta / std::pow(1.0 + iter_ / cfg_.decay, 0.602);
    const double alpha = 2.0 / (cfg_.emaWindow + 1);
    for (int i = 0; i < n; i++) {
        theta_[i] += ak * defs_[i].c * dir[i] * score;
        theta_[i] = std::max((double)defs_[i].lo, std::min((double)defs_[i].hi, theta_[i]));
        avg_[i] += alpha * (theta_[i] - avg_[i]);
    }
    iter_++;
    games_ += (long long)games.size();
    out.iter = iter_;
    out.games = games_;
    out.w = w; out.d = d; out.l = l;
    return 0;
}

int Tuner::verifyStep(int& w, int& d, int& l) {
    w = d = l = 0;
    if (stopped_) return 2;
    if (starts_.empty() || defs_.empty()) return -1;
    std::vector<int> tuned(defs_.size());
    for (size_t i = 0; i < defs_.size(); i++) tuned[i] = clampi((int)i, (int)std::lround(avg_[i]));
    std::mt19937 rng(cfg_.seed * 7919u + (unsigned)(vW_ + vD_ + vL_) + 99991u);
    std::vector<int> pick;
    pickStarts(rng, starts_.size(), cfg_.pairs, pick);
    std::vector<Game> games;
    for (int s : pick) { games.push_back({s, true}); games.push_back({s, false}); }
    std::vector<int> res;
    if (!runGames(games, tuned, init_, res)) return 2;
    for (int r : res) { if (r > 0) w++; else if (r < 0) l++; else d++; }
    vW_ += w; vD_ += d; vL_ += l;
    return 0;
}

std::string Tuner::verifyText() const {
    const int n = vW_ + vD_ + vL_;
    if (n == 0) return "no verification games yet";
    const double p = (vW_ + 0.5 * vD_) / n;
    const double var = (vW_ * (1 - p) * (1 - p) + vD_ * (0.5 - p) * (0.5 - p) + vL_ * p * p) / n;
    const double se = std::sqrt(var / n);
    auto elo = [](double q) { q = std::max(0.001, std::min(0.999, q)); return -400.0 * std::log10(1.0 / q - 1.0); };
    char buf[200];
    snprintf(buf, sizeof buf, "tuned vs start: +%d =%d -%d (%d games) score %.1f%%  Elo %+.0f  [%+.0f ; %+.0f] 95%%", vW_, vD_, vL_, n, 100 * p,
             elo(p), elo(p - 1.96 * se), elo(p + 1.96 * se));
    return buf;
}

// ------------------------------------------------------------------------------------------------ state
bool Tuner::saveState(const std::string& path) const {
    std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp);
        if (!f) return false;
        f << "JTUNE 1\niter " << iter_ << "\ngames " << games_ << "\nverify " << vW_ << " " << vD_ << " " << vL_ << "\n";
        char buf[200];
        for (size_t i = 0; i < defs_.size(); i++) {
            snprintf(buf, sizeof buf, "p %s %d %.6f %.6f\n", defs_[i].name, init_[i], theta_[i], avg_[i]);
            f << buf;
        }
        f.flush();
        if (!f) return false;
    }
    return std::rename(tmp.c_str(), path.c_str()) == 0;
}

bool Tuner::loadState(const std::string& path, std::string* err) {
    std::ifstream f(path);
    if (!f) { if (err) *err = "no state file"; return false; }
    std::string line, tag;
    int ver = 0, it = 0, vw = 0, vd = 0, vl = 0;
    long long gm = 0;
    std::map<std::string, std::vector<double>> P;
    if (!std::getline(f, line) || sscanf(line.c_str(), "JTUNE %d", &ver) != 1 || ver != 1) { if (err) *err = "bad state file"; return false; }
    while (std::getline(f, line)) {
        std::istringstream is(line);
        is >> tag;
        if (tag == "iter") is >> it;
        else if (tag == "games") is >> gm;
        else if (tag == "verify") is >> vw >> vd >> vl;
        else if (tag == "p") {
            std::string name; double a, b, c;
            if (is >> name >> a >> b >> c) P[name] = {a, b, c};
        }
    }
    iter_ = it; games_ = gm; vW_ = vw; vD_ = vd; vL_ = vl;
    for (size_t i = 0; i < defs_.size(); i++) {
        auto k = P.find(defs_[i].name);
        if (k == P.end()) continue;
        init_[i] = clampi((int)i, (int)std::lround(k->second[0]));
        theta_[i] = std::max((double)defs_[i].lo, std::min((double)defs_[i].hi, k->second[1]));
        avg_[i] = std::max((double)defs_[i].lo, std::min((double)defs_[i].hi, k->second[2]));
    }
    return true;
}

bool Tuner::appendCsv(const std::string& path, const TuneStep& s) const {
    bool fresh = false;
    { std::ifstream t(path); fresh = !t.good() || t.peek() == std::ifstream::traits_type::eof(); }
    std::ofstream f(path, std::ios::app);
    if (!f) return false;
    if (fresh) {
        f << "iter,W,D,L";
        for (auto& d : defs_) f << "," << d.name;
        f << "\n";
    }
    f << s.iter << "," << s.w << "," << s.d << "," << s.l;
    for (size_t i = 0; i < defs_.size(); i++) f << "," << clampi((int)i, (int)std::lround(avg_[i]));
    f << "\n";
    return (bool)f;
}

} // namespace joro
