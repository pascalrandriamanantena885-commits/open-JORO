// JORO - trainer.cpp
#include "trainer.h"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <random>
#include <thread>

namespace joro {

static bool insufficientMaterial(const Board& b) {
    int minors = 0;
    for (int s = 0; s < 64; s++) {
        int t = typeOf(b.sq[s]);
        if (t == PAWN || t == ROOK || t == QUEEN) return false;
        if (t == KNIGHT || t == BISHOP) minors++;
    }
    return minors <= 1;
}

Trainer::Trainer(Experience& e, const TrainConfig& c) : exp(e), cfg(c), stopped(false), rng(c.seed ? c.seed : std::random_device{}()) {
    sv.quiet = true;
    sv.style = cfg.style;
    sv.setHash(8);
    sv.useExperience = false;   // the verification must judge the position, not the memory
    for (Searcher* s : {&sw, &sb}) {
        s->quiet = true;
        s->style = cfg.style;
        s->setHash(cfg.hashMB);
        s->setExperience(&exp);
        s->useExperience = true;
        s->brain = cfg.brain;
    }
    sv.brain = false;
}

void Trainer::stop() {
    stopped = true;
    sw.stopFlag = true;
    sb.stopFlag = true;
}

bool Trainer::playGame(const std::string& startFen, const std::vector<std::string>& opening, GameRecord& rec,
                       std::string* err) {
    Board b;
    if (!b.setFen(startFen)) { if (err) *err = "bad FEN"; return false; }
    std::vector<Move> mv;
    for (auto& s : opening) {
        Move m = b.parseMove(s);
        if (m == MOVE_NONE) { if (err) *err = "illegal opening move " + s; return false; }
        b.makeMove(m);
        mv.push_back(m);
    }
    return playGame(startFen, mv, rec, err);
}

bool Trainer::playGame(const std::string& startFen, const std::vector<Move>& opening, GameRecord& rec,
                       std::string* err) {
    Board b;
    if (!b.setFen(startFen)) { if (err) *err = "bad FEN"; return false; }
    for (Move m : opening) {
        Move mv[256];
        int n = b.genLegal(mv);
        bool ok = false;
        for (int i = 0; i < n; i++) if (mv[i] == m) { ok = true; break; }
        if (!ok) { if (err) *err = "illegal opening move"; return false; }
        b.makeMove(m);
    }
    rec = GameRecord();
    rec.startFen = b.fen();
    rec.rootFen = startFen;
    rec.opening = opening;
    if (beforeGame) rec.opponent = beforeGame(gameIdx);   // may switch the opponent (setOpponent) for this game
    rec.joroSide = opp ? joroSide_ : -1;
    const bool alt = cfg.depthStrong > 0 || cfg.moveTimeStrong > 0;
    rec.strongSide = !alt ? -1 : opp ? (joroSide_ ^ 1) : ((gameIdx & 1) ? BLACK : WHITE);   // vs an engine: the engine is the strong one
    gameIdx++;
    { std::lock_guard<std::mutex> g(liveMu); live = opening; }
    sw.clear();
    sb.clear();  // fresh tables => a replayed game is identical until the first experience change
    Searcher* ss[2] = {&sw, &sb};
    std::vector<Move> played = opening;   // opening + every move so far (the external opponent needs the whole game)
    int streak = 0, streakSign = 0;
    bool firstDone[2] = {false, false};   // has this side already made its first searched move?
    for (int ply = 0;; ply++) {
        Move mv[256];
        int nl = b.genLegal(mv);
        if (nl == 0) {
            if (b.inCheck()) { rec.result = b.side == WHITE ? -1 : 1; rec.reason = "checkmate"; }
            else { rec.result = 0; rec.reason = "stalemate"; }
            break;
        }
        if (b.halfmove >= 100) { rec.result = 0; rec.reason = "50-move"; break; }
        int reps = 1;
        for (auto& u : b.hist) if (u.hash == b.hash) reps++;
        if (reps >= 3) { rec.result = 0; rec.reason = "repetition"; break; }
        if (insufficientMaterial(b)) { rec.result = 0; rec.reason = "insufficient material"; break; }
        if (ply >= cfg.maxPlies) { rec.result = 0; rec.reason = "max plies"; break; }
        if (stopped) return false;
        if (paused) {                                   // sleep until resumed or stopped
            waiting = true;
            while (paused && !stopped) std::this_thread::sleep_for(std::chrono::milliseconds(150));
            waiting = false;
            if (stopped) return false;
        }

        if (opp && b.side != joroSide_) {              // the external engine (Stockfish) moves
            Move om = opp(startFen, played);
            if (stopped) return false;
            bool ok = false;
            for (int i = 0; i < nl; i++) if (mv[i] == om) { ok = true; break; }
            if (!ok) { if (err) *err = "opponent engine gave no legal move"; return false; }
            rec.keys.push_back(b.hash);
            rec.moves.push_back(om);
            rec.movers.push_back(b.side);
            rec.scores.push_back(NO_SCORE);
            b.makeMove(om);
            played.push_back(om);
            { std::lock_guard<std::mutex> g(liveMu); live.push_back(om); }
            continue;
        }

        Searcher& s = *ss[b.side];
        s.stopFlag = false;
        Limits lim;
        const bool strong = alt && (opp ? b.side == joroSide_ : b.side == rec.strongSide);   // JORO itself uses its full strength vs an engine
        lim.depth = (strong && cfg.depthStrong > 0) ? cfg.depthStrong : cfg.depth;
        const int mt = strong ? cfg.moveTimeStrong : cfg.moveTimeWeak;
        if (mt > 0) { lim.movetime = mt; lim.depth = 0; }
        SearchResult r = s.go(b, lim);
        if (stopped) return false;
        if (!firstDone[b.side]) {                       // variety: sometimes the 2nd best first move
            firstDone[b.side] = true;
            std::uniform_real_distribution<double> u(0.0, 100.0);
            if (cfg.varyFirstPct > 0 && nl > 1 && !r.fromExperience && u(rng) < cfg.varyFirstPct) {
                s.excluded = r.best;
                s.stopFlag = false;
                s.clear();
                SearchResult r2 = s.go(b, lim);
                s.excluded = MOVE_NONE;
                if (stopped) return false;
                if (r2.best != MOVE_NONE && !r2.fromExperience && r2.score >= r.score - cfg.varyMaxLoss) {
                    r = r2;
                    rec.variedPly = (int)rec.moves.size();
                }
            }
        }
        for (auto& mt : r.mateTraps) exp.add(mt.first, mt.second, EXP_BAD, 0, 1);   // proven forced mate against us: remembered
        rec.keys.push_back(b.hash);
        rec.moves.push_back(r.best);
        rec.movers.push_back(b.side);
        rec.scores.push_back(r.fromExperience ? NO_SCORE : r.score);
        if (cfg.adjudicate && !r.fromExperience) {
            int w = b.side == WHITE ? r.score : -r.score;  // white point of view
            if (std::abs(w) >= 900) {
                int sg = w > 0 ? 1 : -1;
                streak = (sg == streakSign) ? streak + 1 : 1;
                streakSign = sg;
            } else { streak = 0; streakSign = 0; }
            if (streak >= 6) { rec.result = streakSign; rec.reason = "adjudicated"; break; }
        }
        b.makeMove(r.best);
        played.push_back(r.best);
        { std::lock_guard<std::mutex> g(liveMu); live.push_back(r.best); }
    }
    rec.marks.assign(rec.moves.size(), MK_NONE);
    return true;
}

std::vector<Move> Trainer::liveMoves() const {
    std::lock_guard<std::mutex> g(liveMu);
    return live;
}

static int clampScore(int s) { return std::max(-1000, std::min(1000, s)); }

// Backtracking : walk back over the decisions of the failing side, find the critical move.
void Trainer::blame(GameRecord& rec, int side, int resultForSide, int& newBad, int& exhausted) {
    const size_t n = rec.moves.size();
    std::vector<int> untried(n, 0);
    std::vector<size_t> dec;  // decision indices of this side
    Board b;
    b.setFen(rec.startFen);
    for (size_t i = 0; i < n; i++) {
        if (rec.movers[i] == side) {
            Move mv[256];
            int nl = b.genLegal(mv), u = 0;
            for (int k = 0; k < nl; k++)
                if (mv[k] != rec.moves[i] && !exp.isBad(rec.keys[i], mv[k])) u++;
            untried[i] = u;
            dec.push_back(i);
        }
        b.makeMove(rec.moves[i]);
    }
    int terminal = resultForSide < 0 ? -1000 : 0;
    int bestJ = -1, bestDrop = -100000, lastJ = -1;
    std::vector<int> drop(dec.size(), 0);
    for (size_t j = 0; j < dec.size(); j++) {
        int e0 = rec.scores[dec[j]];
        int e1 = (j + 1 < dec.size()) ? rec.scores[dec[j + 1]] : terminal;
        drop[j] = (e0 == NO_SCORE || e1 == NO_SCORE) ? 0 : clampScore(e0) - clampScore(e1);
        if (untried[dec[j]] > 0) {
            lastJ = (int)j;
            if (drop[j] > bestDrop) { bestDrop = drop[j]; bestJ = (int)j; }
        }
    }
    int pick = (bestJ >= 0 && bestDrop >= cfg.blameThreshold) ? bestJ : lastJ;  // else: plain backtrack
    if (pick < 0) { exhausted++; return; }  // nothing left to vary for this side
    size_t i = dec[pick];
    int inc = exp.goodCount(rec.keys[i], rec.moves[i]) + 1;  // must outweigh an old "good" mark
    bool had = exp.badCount(rec.keys[i], rec.moves[i]) > 0;
    exp.add(rec.keys[i], rec.moves[i], EXP_BAD, -std::max(0, drop[pick]), inc);
    if (!had) newBad++;
    if (i < rec.marks.size()) rec.marks[i] = drop[pick] >= 300 ? MK_BLUNDER : MK_BAD;
}

static int materialOf(const Board& b, int c) {
    int m = 0;
    for (int s = 0; s < 64; s++) {
        int p = b.sq[s];
        if (p && colorOf(p) == c && typeOf(p) != KING) m += PIECE_VAL[typeOf(p)];
    }
    return m;
}

// ------------------------------------------------------------------------------------------------ Situation analysis
// After a decided game JORO looks back at it and names what happened, so that the experience can tell GOOD situations from BAD ones:
//   loser : bad opening (big early drop) | weak king (castling thrown away / shield torn) | queen trade or exchange that ended in a
//           losing endgame | the losing endgame itself | sacrifice that brought nothing (lost, perhaps mated)
//   winner: mating attack (every position of the line, stronger near the mate) | fast mate | pressure (the opponent only defends while
//           we check / capture; a torn king shield makes it stronger) | winning sacrifice | winning endgame | SHORT win (never reached
//           an endgame: the best kind)
// Each situation is stored on the position where it appeared (the position AFTER the move that created it), with a value signed for the
// side to move there. A draw teaches no situation (the move-level blame still runs for it).
namespace {
struct PosInfo {
    U64 key = 0;
    int stm = 0;
    int matW = 0;          // white material minus black (cp, no kings)
    bool endgame = false;
    int shieldMiss[2] = {0, 0};
    U64 sig = 0;           // situationSignature (features of the position)
    int castle[2] = {0, 0};   // 1 = still has castling rights
    bool kingHome[2] = {true, true};   // king still on its start square
};
struct MoveInfo { int capType = 0; int movedType = 0; int to = 0; bool check = false; };

bool endgameBoard(const Board& b) {
    int np = 0, q = 0;
    for (int s = 0; s < 64; s++) {
        const int t = typeOf(b.sq[s]);
        if (t > PAWN && t < KING) { np += PIECE_VAL[t]; if (t == QUEEN) q++; }
    }
    return np <= 2600 || (q == 0 && np <= 3400);
}
PosInfo infoOf(const Board& b) {
    PosInfo p;
    p.key = b.hash;
    p.sig = situationSignature(b);
    p.stm = b.side;
    for (int s = 0; s < 64; s++) {
        const int pc = b.sq[s];
        if (!pc || typeOf(pc) == KING) continue;
        p.matW += (colorOf(pc) == WHITE ? 1 : -1) * PIECE_VAL[typeOf(pc)];
    }
    p.endgame = endgameBoard(b);
    for (int c = 0; c < 2; c++) {
        p.shieldMiss[c] = b.kingSq[c] >= 0 ? classifyKing(b, c).shieldMissing : 0;
        p.castle[c] = (b.castling & (c == WHITE ? (CR_WK | CR_WQ) : (CR_BK | CR_BQ))) ? 1 : 0;
        p.kingHome[c] = b.kingSq[c] == (c == WHITE ? 4 : 60);
    }
    return p;
}
} // namespace

void Trainer::analyseSituations(GameRecord& rec, int side, bool won) {
    const int n = (int)rec.moves.size();
    if (n < 2) return;
    // ---- replay the game once and collect what the rules below need
    std::vector<PosInfo> pos;
    std::vector<MoveInfo> mi(n);
    Board b;
    if (!b.setFen(rec.startFen)) return;
    pos.push_back(infoOf(b));
    for (int i = 0; i < n; i++) {
        const Move m = rec.moves[i];
        mi[i].to = mTo(m);
        mi[i].capType = b.sq[mTo(m)] ? typeOf(b.sq[mTo(m)]) : (mFlag(m) == F_EP ? (int)PAWN : 0);
        mi[i].movedType = typeOf(b.sq[mFrom(m)]);
        b.makeMove(m);
        mi[i].check = b.inCheck();
        pos.push_back(infoOf(b));
    }
    const int openLen = (int)rec.opening.size();
    const bool mate = rec.reason == "checkmate";
    const int sgn = side == WHITE ? 1 : -1;
    auto mat = [&](int i) { return sgn * pos[std::min(i, n)].matW; };              // material of `side` minus the other one
    auto evalOf = [&](int i) {                                                      // search score of `side` around ply i, NO_SCORE if unknown
        for (int k = i; k <= i + 1 && k < n; k++)
            if (rec.movers[k] == side && rec.scores[k] != NO_SCORE) return clampScore(rec.scores[k]);
        return (int)NO_SCORE;
    };
    int firstEnd = -1;
    for (int i = 0; i <= n; i++) if (pos[i].endgame) { firstEnd = i; break; }
    const size_t before = exp.sitCount();
    // value = +mag for the side favoured, seen from the side to move on the position
    auto put = [&](int idx, uint32_t code, int favoured, int mag) {
        idx = std::max(0, std::min(idx, n));
        exp.addSituation(pos[idx].key, code, pos[idx].stm == favoured ? mag : -mag, 1);
    };
    const int other = side ^ 1;

    if (won) {
        std::vector<int> dec;
        for (int i = 0; i < n; i++) if (rec.movers[i] == side) dec.push_back(i);
        const int total = openLen + n;
        // ---- mating attack / fast mate: every position of the line, the nearer to the mate the stronger
        if (mate) {
            for (int i : dec) {
                const int plies = n - i;
                if (plies > 60) continue;
                put(i + 1, SIT_MATE_ATTACK, side, 40 + std::max(0, (24 - plies) * 7));
                if (total <= 40) put(i + 1, SIT_FAST_MATE, side, 80 + (40 - total) * 3);
            }
        }
        // ---- the best win: short, never reaching the endgame
        if (firstEnd < 0) {
            int k = 0;
            for (int j = (int)dec.size() - 1; j >= 0 && k < 8; j--, k++) put(dec[j] + 1, SIT_SHORT_WIN, side, 60 + (mate ? 30 : 0));
        }
        // ---- pressure: 3 of our decisions in a row with a clear edge, the opponent never checks or captures (it only defends)
        //      while we check or capture at least twice. A torn king shield of the opponent makes the pressure stronger.
        for (size_t j = 0; j + 2 < dec.size(); j++) {
            const int i0 = dec[j], i2 = dec[j + 2];
            bool ok = true;
            int active = 0;
            for (int i = i0; i <= i2 + 1 && i < n && ok; i++) {
                if (rec.movers[i] == side) {
                    const int e = evalOf(i);
                    if (e == NO_SCORE || e < 100) ok = false;
                    if (mi[i].check || mi[i].capType) active++;
                } else if (mi[i].check || mi[i].capType) ok = false;
            }
            if (ok && active >= 2) {
                put(i0 + 1, SIT_PRESSURE, side, 50 + (pos[std::min(n, i2 + 1)].shieldMiss[other] >= 2 ? 30 : 0));
                j += 2;                                                             // one record per window
            }
        }
        // ---- winning sacrifice: material given away and not recouped, the game is won
        for (int i : dec) {
            if (i + 4 > n) break;
            if (mat(i) - mat(i + 2) >= 200 && mat(i + 4) - mat(i) <= -150) put(i + 1, SIT_SAC_WIN, side, mate ? 105 : 70);
        }
        // ---- winning endgame
        if (firstEnd >= 0 && firstEnd <= n && mat(firstEnd) >= 150) {
            const int e = evalOf(firstEnd);
            put(firstEnd, SIT_WIN_ENDGAME, side, 60 + (e != NO_SCORE && e >= 300 ? 40 : 0));
        }
    } else {
        // ---- the critical decision: the biggest fall of our own evaluation
        int crit = -1, critDrop = 0;
        for (int i = 0; i < n; i++) {
            if (rec.movers[i] != side || rec.scores[i] == NO_SCORE) continue;
            int nxt = NO_SCORE;
            for (int k = i + 1; k < n; k++) if (rec.movers[k] == side) { nxt = rec.scores[k]; break; }
            const int drop = clampScore(rec.scores[i]) - (nxt == NO_SCORE ? -1000 : clampScore(nxt));
            if (drop > critDrop) { critDrop = drop; crit = i; }
        }
        // ---- bad opening: the fall came early
        if (crit >= 0 && critDrop >= cfg.blameThreshold && openLen + crit <= 24)
            put(crit + 1, SIT_BAD_OPENING, other, std::min(300, 80 + critDrop / 2));
        // ---- weak king: castling rights thrown away without castling, or the shield torn open, before the game turned
        for (int i = 1; i <= n; i++) {
            const bool rights = pos[i - 1].castle[side] && !pos[i].castle[side] && pos[i].kingHome[side];   // rights lost, king did not castle
            const bool torn = pos[i].shieldMiss[side] >= 2 && pos[i - 1].shieldMiss[side] < 2;
            if ((rights || torn) && (crit < 0 || i <= crit + 3)) { put(i, SIT_WEAK_KING, other, 120); break; }
        }
        // ---- exchanges that led to a lost endgame
        if (firstEnd >= 0 && firstEnd <= n) {
            const int e = evalOf(firstEnd);
            const bool losing = mat(firstEnd) <= -150 || (e != NO_SCORE && e <= -150);
            if (losing) {
                put(firstEnd, SIT_LOSING_ENDGAME, other, 100);
                for (int i = std::min(n - 2, firstEnd) ; i >= 0 && i >= firstEnd - 10; i--) {      // the last exchange before the endgame
                    if (rec.movers[i] != side || !mi[i].capType || mi[i].capType < KNIGHT) continue;
                    if (!mi[i + 1].capType || mi[i + 1].to != mi[i].to) continue;                     // not recaptured: not an exchange
                    const bool queen = mi[i].capType == QUEEN || mi[i + 1].capType == QUEEN;
                    put(i + 2, queen ? SIT_QUEEN_TRADE : SIT_EXCHANGE, other, queen ? 110 : 90);
                    break;
                }
            }
        }
        // ---- a sacrifice that brought nothing
        for (int i = 0; i + 4 <= n; i++) {
            if (rec.movers[i] != side) continue;
            if (mat(i) - mat(i + 2) >= 200 && mat(i + 4) - mat(i) <= -150) { put(i + 1, SIT_BAD_SACRIFICE, other, mate ? 160 : 120); break; }
        }
    }
    // ---- PATTERNS: every other kind of situation. Each position of the game teaches how games that went through a position with
    // these features ended (for the side to move there). Seen in wins AND losses the pattern ends up balanced near zero; only a
    // pattern that really leads to one result keeps a value. A draw teaches nothing. A short win weighs more.
    {
        const int mag = won ? (firstEnd < 0 ? 45 : 30) : 30;
        for (int i = 2; i <= n; i++) {
            const int v = (pos[i].stm == side ? 1 : -1) * (won ? mag : -mag);
            exp.addSituation(pos[i].sig, SIT_PATTERN, v, 1);
        }
    }
    rec.sitNew += (int)(exp.sitCount() - before);
}

// A winner's move is kept only if it is VERIFIED by a deeper search (depth+1, the move excluded):
//  * BRILLIANT: gives up material (>= 2 pawns over the exchange) without the evaluation falling, or starts a
//    forced mate, and beats every alternative by cfg.brilliantMargin cp;
//  * GREAT: no sacrifice needed, the position is not already decided, and the move beats every alternative by
//    cfg.greatMargin cp (a clearly best move, not just one of several good ones).
// Ordinary winning moves are not stored - the search finds them again anyway.
void Trainer::findBrilliant(GameRecord& rec, int side, int& newGood) {
    const size_t n = rec.moves.size();
    std::vector<size_t> dec;
    std::vector<int> mat;
    std::vector<std::string> fens;
    Board b;
    b.setFen(rec.startFen);
    for (size_t i = 0; i < n; i++) {
        if (rec.movers[i] == side) {
            dec.push_back(i);
            mat.push_back(materialOf(b, side) - materialOf(b, side ^ 1));
            fens.push_back(b.fen());
        }
        b.makeMove(rec.moves[i]);
    }
    struct Cand { size_t j; bool brilliant; int gain; };
    std::vector<Cand> cands;
    for (size_t j = 0; j + 1 < dec.size(); j++) {
        const size_t i = dec[j];
        const int sc0 = rec.scores[i], sc1 = rec.scores[dec[j + 1]];
        if (sc0 == NO_SCORE || sc1 == NO_SCORE) continue;                // played from experience: no evidence
        const int lost = mat[j] - mat[j + 1];                              // material given up over the exchange
        const bool sacrifice = lost >= 200 && sc1 >= sc0 - 60 && sc0 >= -50;
        const bool mateStart = sc0 >= MATE_BOUND && (j == 0 || rec.scores[dec[j - 1]] < MATE_BOUND);
        if (sacrifice || mateStart) cands.push_back({j, true, 0});
        else if (cfg.great && sc0 >= -50 && sc0 < 600 && sc1 >= sc0 - 30) cands.push_back({j, false, sc1 - sc0});
    }
    // great candidates: only the most promising ones are verified (each costs a depth+1 search)
    std::vector<Cand> chosen, great;
    for (auto& c : cands) (c.brilliant ? chosen : great).push_back(c);
    std::sort(great.begin(), great.end(), [](const Cand& a, const Cand& b) { return a.gain > b.gain; });
    if ((int)great.size() > cfg.greatMaxPerGame) great.resize(cfg.greatMaxPerGame);
    chosen.insert(chosen.end(), great.begin(), great.end());
    for (auto& c : chosen) {
        if (stopped) break;
        const size_t j = c.j, i = dec[j];
        Board vb;
        if (!vb.setFen(fens[j])) continue;
        sv.clear();
        sv.excluded = rec.moves[i];
        sv.stopFlag = false;
        Limits lim;
        lim.depth = std::max(cfg.depth, cfg.depthStrong) + 1;
        SearchResult alt = sv.go(vb, lim);
        sv.excluded = MOVE_NONE;
        if (alt.best == MOVE_NONE) continue;                               // it was the only legal move: not exceptional
        int played = clampScore(rec.scores[i]), other = clampScore(alt.score);
        const int need = c.brilliant ? cfg.brilliantMargin : cfg.greatMargin;
        if (played - other < need) continue;                               // an alternative is nearly as good
        bool had = exp.goodCount(rec.keys[i], rec.moves[i]) > 0;
        exp.add(rec.keys[i], rec.moves[i], EXP_GOOD, played, 1);
        if (i < rec.marks.size()) rec.marks[i] = c.brilliant ? MK_BRILLIANT : MK_GREAT;
        if (!had) newGood++;
    }
}

void Trainer::learn(GameRecord& rec, int& newBad, int& newGood, int& exhausted) {
    rec.sitNew = 0;
    for (int side = 0; side < 2; side++) {
        if (opp && side != joroSide_) continue;          // never learn from the external engine's moves
        int rs = rec.result == 0 ? 0 : (((rec.result == 1) == (side == WHITE)) ? 1 : -1);
        if (rs != 0 && cfg.situations) analyseSituations(rec, side, rs == 1);   // what kind of situation was it? (good for the winner, bad for the loser)
        if (rs == 1) {
            if (cfg.brilliantOnly) {
                findBrilliant(rec, side, newGood);   // only exceptional moves are kept
            } else {
                for (size_t i = 0; i < rec.moves.size(); i++) {
                    if (rec.movers[i] != side) continue;
                    bool had = exp.goodCount(rec.keys[i], rec.moves[i]) > 0;
                    int v = rec.scores[i] == NO_SCORE ? 0 : clampScore(rec.scores[i]);
                    exp.add(rec.keys[i], rec.moves[i], EXP_GOOD, v, 1);
                    if (!had) newGood++;
                }
            }
        } else if (rs == -1 || cfg.drawIsFail) {
            blame(rec, side, rs, newBad, exhausted);
        }
    }
}

bool Trainer::step(const std::string& startFen, const std::vector<Move>& opening, TrainSession& s, GameRecord& rec,
                   int& newBad, int& newGood, std::string* err) {
    if (stopped) return false;
    if (!playGame(startFen, opening, rec, err)) return false;
    size_t before = exp.size();
    int nb = 0, ng = 0, ex = 0;
    learn(rec, nb, ng, ex);
    newBad = nb;
    newGood = ng;
    s.stats.games++;
    s.stats.newBad += nb;
    s.stats.newGood += ng;
    s.stats.exhausted += ex;
    if (rec.result == 1) s.stats.whiteWins++; else if (rec.result == -1) s.stats.blackWins++; else s.stats.draws++;
    s.stable = (exp.size() == before) ? s.stable + 1 : 0;
    if (rec.result != 0 && rec.result == s.streakSide) s.streakLen++;
    else { s.streakSide = rec.result; s.streakLen = rec.result != 0 ? 1 : 0; }
    s.finished = s.stats.games >= cfg.maxGames || s.stable >= cfg.stableLimit ||
                 (cfg.confirmWins > 0 && s.streakLen >= cfg.confirmWins);
    return true;
}

TrainStats Trainer::trainOpening(const std::string& startFen, const std::vector<std::string>& opening,
                                 std::string* err) {
    TrainSession s;
    Board b;
    std::vector<Move> mv;
    b.setFen(startFen);
    for (auto& t : opening) {
        Move m = b.parseMove(t);
        if (m == MOVE_NONE) { if (err) *err = "illegal opening move " + t; return s.stats; }
        b.makeMove(m);
        mv.push_back(m);
    }
    while (!s.finished && !stopped) {
        GameRecord rec;
        int nb = 0, ng = 0;
        if (!step(startFen, mv, s, rec, nb, ng, err)) break;
        if (onGame) onGame(s.stats.games, rec, nb, ng);
    }
    return s.stats;
}

} // namespace joro
