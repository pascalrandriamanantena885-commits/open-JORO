// JORO - tuner.h : SPSA tuning of the style weights and of the search constants, by self-play (no UCI, in-process).
//
// One iteration (step):
//   1. every parameter theta_i gets a random direction D_i = +-1 and a perturbation delta_i (c_i * c_k, at least 0.5)
//   2. A plays with theta + delta*D, B with theta - delta*D: `pairs` openings x 2 colours, equal time per move
//   3. d = (wins - losses) / games, in [-1, 1].  theta_i += a_k * c_i * D_i * d   (a_k decays slowly)
//   4. an exponential moving average of theta is kept: it is the value that is exported (less noisy than theta)
// The state is written after every iteration (resume after a pause, a stop or a killed process). Pause / stop act at the
// next move, so a phone can be paused at any time without losing anything but the games of the current iteration.
#pragma once
#include "search.h"
#include "tunables.h"
#include <atomic>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace joro {

struct TuneStart { std::string fen; std::vector<std::string> moves; };   // moves: UCI text, played from fen

// One start per line: a FEN (the line contains '/', 4 or 6 fields) or UCI moves from the standard start. '#' = comment.
std::vector<TuneStart> parseTuneStarts(const std::string& text);

struct TuneConfig {
    int pairs = 8;             // openings per iteration; each is played twice (A white, A black) -> 2*pairs games
    int movetimeMs = 40;       // per move
    int64_t nodes = 0;         // > 0 replaces movetimeMs (reproducible, independent of the CPU speed)
    int threads = 2;           // games played at the same time
    int hashMB = 8;            // per searcher
    unsigned seed = 1;
    double eta = 1.0;          // step size (1 = a unanimous win moves each theta by about c_i)
    double decay = 50;         // the step shrinks as (1 + iter / decay)^-0.602
    int emaWindow = 20;        // iterations averaged in the exported value
    int maxPlies = 300;
    bool tuneStyle = true;     // the 14 style weights (contempt is never tuned)
    bool tuneSearch = true;    // the search constants (tunables.h)
    bool tunePlans = true;     // the 18 JORO plan parameters (plan A / B / C, selection thresholds, LMR relief)
};

struct TuneStep { int iter = 0; long long games = 0; int w = 0, d = 0, l = 0; };   // result of ONE iteration (A = theta+)

class Tuner {
public:
    // base: values of the parameters that are not tuned, and the starting point of the tuned ones.
    Tuner(const TuneConfig& cfg, std::vector<TuneStart> starts, const Style& base, const SearchParams& baseSp);

    bool loadState(const std::string& path, std::string* err = nullptr);   // resumes theta / average / counters
    bool saveState(const std::string& path) const;                          // atomic (tmp + rename)
    bool appendCsv(const std::string& path, const TuneStep& s) const;       // one line per iteration

    // 0 = ok, 2 = stopped (nothing was changed), -1 = error (no start positions / nothing to tune)
    int step(TuneStep& out);
    // One batch of verification games: the exported (averaged) values against the starting values. Adds to the totals.
    int verifyStep(int& w, int& d, int& l);

    void stop();                                   // thread-safe, final
    void setPaused(bool p);                        // thread-safe; workers sleep at the next move (no CPU)
    bool isPaused() const { return paused_; }
    bool isWaiting() const;                        // true when every worker really sleeps
    bool wasStopped() const { return stopped_; }

    int iteration() const { return iter_; }
    long long games() const { return games_; }
    void verifyTotals(int& w, int& d, int& l) const { w = vW_; d = vD_; l = vL_; }
    Style tunedStyle() const;                      // base + the averaged values, rounded
    SearchParams tunedSearch() const;
    bool exportTuned(const std::string& path) const;   // tuning file (style + search)
    std::string table() const;                     // "name  start -> averaged (current)" one per line
    std::string verifyText() const;                // "+W =D -L ... Elo ..." of the verification totals
    int paramCount() const { return (int)defs_.size(); }

private:
    struct Def { const char* name; bool style; int idx; int lo, hi; double c; };
    struct Game { int start; bool aWhite; };
    TuneConfig cfg_;
    std::vector<TuneStart> starts_;
    Style baseStyle_;
    SearchParams baseSp_;
    std::vector<Def> defs_;
    std::vector<double> theta_, avg_;
    std::vector<int> init_;
    int iter_ = 0;
    long long games_ = 0;
    int vW_ = 0, vD_ = 0, vL_ = 0;
    std::vector<std::unique_ptr<Searcher>> poolA_, poolB_;

    std::atomic<bool> stopped_{false}, paused_{false};
    std::atomic<int> active_{0}, sleeping_{0};
    mutable std::mutex mu_;
    std::condition_variable cv_;

    void apply(const std::vector<int>& vals, Style& st, SearchParams& sp) const;
    int clampi(int i, int v) const;
    bool runGames(const std::vector<Game>& games, const std::vector<int>& valsA, const std::vector<int>& valsB, std::vector<int>& res);
    int playGame(Searcher& A, Searcher& B, const TuneStart& st, bool aWhite);
    void gate();
};

} // namespace joro
