// JORO - search.h : alpha-beta search + experience-aware root
#pragma once
#include "board.h"
#include "eval.h"
#include "experience.h"
#include "tunables.h"
#include <atomic>
#include <chrono>
#include <utility>
#include <vector>

namespace joro {

const int MAXPLY = 128, INF_SCORE = 32000, MATE = 31000, MATE_BOUND = MATE - MAXPLY;

struct Limits {
    int depth = 0;           // 0 = no depth limit
    int64_t movetime = 0;    // ms
    int64_t time[2] = {0, 0};
    int64_t inc[2] = {0, 0};
    int movestogo = 0;
    int64_t nodes = 0;
    bool infinite = false;
};

struct SearchResult {
    Move best = MOVE_NONE;
    Move ponder = MOVE_NONE;
    int score = 0;
    int depth = 0;
    int64_t nodes = 0;
    bool fromExperience = false;
    // Plan D report (see Searcher::planD)
    bool planD = false;                                        // Plan D was active for this move (A / B / C stalled, experience loaded)
    int dPly = 0;                                              // the principal line reaches a position known by the experience after this many plies (0 = none)
    int dKind = 0;                                             // what is known there: 1 good move, 2 good situation, 3 bad situation (to avoid)
    int dSit = 0;                                              // situation score (cp, side to move there) of that position, 0 if none
    bool dNear = false;                                        // Plan D steered toward the nearest GOOD situation of the experience (the root situation is new to it)
    int dDist = -1;                                            // distance (events: trades, captures, castling...) from the root to the nearest good situation, -1 = none known
    bool dGuard = false;                                       // Plan D ran in guard mode (plan A/B/C progressing: only bad situations are avoided)
    // Variation Brain report
    int brainRejected = 0;                                     // candidate moves refused because of a dangerous variation
    std::vector<std::pair<U64, Move>> mateTraps;               // (position key, move) refused because it allows a forced mate
};

struct TTEntry { U64 key; Move move; int16_t score; int8_t depth; uint8_t bound; };

class Searcher {
public:
    Style style;
    SearchParams sp = defaultSearchParams();   // search constants (tunable by SPSA; defaults = the old hard-coded values)
    bool useExperience = true;
    bool strictStyle = true;   // experience made with another style is ignored
    Move excluded = MOVE_NONE; // root move left out of the search (verification of brilliant moves)
    bool quiet = false;        // true = no "info" output (trainer / JNI)
    int moveOverhead = 30;     // ms
    // ---- Variation Brain: after the search, the chosen move is checked by a forcing-line analysis (opponent plays only
    // checks / captures / promotions, we answer with everything). A move that allows a forced mate, a lost piece, a
    // promotion, or a stalemate / draw while we are clearly better is refused and the search is redone without it.
    bool brain = true;
    int brainNodes = 30000;    // node budget of one analysis
    int brainTries = 3;        // candidates examined at most
    int brainLoss = 300;       // cp: material the opponent must win by force for the move to be refused
    int brainSacrificeOK = 150; // cp: a material "loss" is accepted when the search itself says we are this much better
    // ---- Plan D (experience steering). Plans A / B / C hunt the enemy king. When the plan of the side to move makes no progress (its
    // bonus is below dStall cp, or there is no plan) and the experience is loaded, JORO looks for the positions it already KNOWS
    // (joro.exp keeps the position key of every good move and of every learned situation) and tries to lead the game there: a move that
    // enters such a position is worth a bonus for the side that knows a good move there (a mating attack counts most), so the search
    // finds the forcing way (checks, captures, sacrifices) to it. Once in a known position, the root experience plays on by itself.
    // A position where the OPPONENT knows a good move is avoided in the same way; a position where the opponent to move has a known
    // losing move (a trap) is slightly attractive. Off by default (trainer / tuner / gate keep their behaviour); live games and UCI turn it on.
    // SITUATION MEMORY (experience kind 2, see experience.h): the experience also knows GOOD situations (a line that ended in mate, a
    // pressure that keeps the opponent defending, a winning sacrifice / endgame, a short win) and BAD ones (a bad opening, a weak king,
    // a queen trade or exchange that led to a lost endgame, a useless sacrifice). Plan D reads them for every position the search
    // enters (Experience::sitScore) and turns them into a bonus / a penalty (sitPct % of the stored value, capped by dCap).
    // It is only used once the experience holds enough situations (30% weight from dSitMin, 100% from dSitFull), and in two modes:
    //   * plan A / B / C stalled      -> FULL: good situations attract, bad ones repel (together with the known good moves);
    //   * plan A / B / C progressing  -> GUARD: only bad situations repel, the attack is never disturbed by a bonus.
    bool planD = false;
    int dSitMin = 30;          // situations in the experience below which they are not used at all
    int dSitFull = 300;        // situations in the experience from which they have their full weight (30% at dSitMin, linear in between)
    int dSitPct = 60;          // % of the stored situation value that becomes search bonus / penalty
    int dBadPct = 130;         // bad situations weigh this % more than good ones: a known trap is avoided more strongly than a goal is chased
    int dStall = 20;           // cp: plan bonus below which A / B / C count as stalled
    int dGood = 35;            // cp: entering a position with a known good move
    int dTrap = 12;            // cp: the opponent to move there has a known bad move
    int dCap = 200;            // cp: largest bonus
    // NEW situation (never met: the experience holds no pattern like it). Plan D compares it with the good situations JORO has already been
    // through (pattern features, sitDistance) and, when the nearest one is at most dNearMax events away, steers toward it by any means
    // (forcing moves, trades, a sacrifice: each goal is worth its gain * (progress made from the root) / (distance at the root), so reaching
    // it is worth the whole gain; only progress counts, so the bonus does not depend on the path). When the nearest good situation is farther than that, Plan D does not steer and plans A / B / C go on alone.
    // 0 turns it off.
    int dNearMax = 5;
    int dNearAttack = 2;       // while plan A / B / C is PROGRESSING (guard mode) the steering only takes over when the good situation is this close
    std::atomic<bool> stopFlag;

    Searcher();
    void setHash(int mb);
    void clear();
    void setExperience(const Experience* e) { exp = e; }

    // Caller must set stopFlag=false before calling.
    SearchResult go(Board& board, const Limits& lim);

private:
    Board* b = nullptr;
    const Experience* exp = nullptr;
    std::vector<TTEntry> tt;
    size_t ttMask = 0;
    Move killers[MAXPLY][2];
    int history[2][64][64];
    Move pv[MAXPLY][MAXPLY];
    int pvLen[MAXPLY];
    std::vector<Move> rootMoves;
    Limits lim;
    int64_t nodes = 0, softMs = 0, hardMs = 0;
    std::chrono::steady_clock::time_point t0;
    bool halt = false, canStop = false, warnedStyle = false;
    bool dOn = false;          // Plan D active in the search in progress
    bool dGuard = false;       // ... in guard mode (only bad situations count)
    int sitMul = 0;            // % weight of the situation memory for the search in progress (0 = not used)
    int dRoot = 0;             // colour to move at the root
    int dState = -1;           // (dOn, dRoot) of the last search: the table is cleared when it changes
    bool dNear = false;        // ... steering toward the nearest good situation (new root situation)
    struct NearT { SitFeat f; int gain; int d0; };   // goal, cp when reached, distance from the root
    std::vector<NearT> nearT;  // goals of this search (gain = cp at distance 0)
    struct NearC { U64 key; int val; };
    mutable NearC nearCache[8192];
    int nearBonus() const;     // cp for the ROOT side: how close the current position's situation is to the goals (0 = not near)
    int expEdge(int parentNear) const;   // Plan D bonus (cp, for the side to move in the CURRENT position) of a position known by the experience

    int64_t elapsedMs() const;
    void checkTime();
    int search(int depth, int alpha, int beta, int ply, bool nullOk);
    int qsearch(int alpha, int beta, int ply);
    int drawScore(int ply) const { return (ply & 1) ? style.contempt() : -style.contempt(); }
    int scoreMove(Move m, Move ttMove, int ply) const;
    bool hasNonPawn(int c) const;
    SearchResult iterate(int maxDepth, SearchResult res);
    // Variation Brain internals (masks: 1 mate, 2 draw/stalemate, 4 material, 8 promotion)
    std::vector<Move> banned;
    int64_t brainUsed = 0;
    int brainUs = 0, brainT = 0, brainDrawVal = 0;
    int matDiff() const;
    int brainOppWins(int d);
    int brainUsLoses(int d);
    int dangerOf(Move cand, int candScore, int m0);
};

} // namespace joro
