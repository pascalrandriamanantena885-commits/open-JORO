// joro_pack : put the tuning (+ experience + version label) INTO a JORO engine file, or read / extract / export it.
//   joro_pack pack --engine joro --tuning tuned.style [--exp joro.exp] --label v5 --out joro-v5
//   joro_pack info joro-v5
//   joro_pack extract joro-v5 [--tuning out.style] [--exp out.exp]
//   joro_pack header --tuning tuned.style --label v5 > joro_tuned.h      (the tuned values as C++ constants)
#include "embed.h"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iterator>
#include <string>

using namespace joro;

static std::string slurp(const std::string& p, bool* ok = nullptr) {
    std::ifstream f(p, std::ios::binary);
    if (ok) *ok = (bool)f;
    return std::string(std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>());
}

int main(int argc, char** argv) {
    if (argc < 2) {
        printf("joro_pack pack --engine F --tuning F [--exp F] --label L --out F | info F | extract F [--tuning F] [--exp F] | header --tuning F --label L\n");
        return 1;
    }
    std::string cmd = argv[1], engine, tuning, exp, label, out, pos;
    for (int i = 2; i < argc; i++) {
        std::string a = argv[i];
        auto next = [&]() { return i + 1 < argc ? std::string(argv[++i]) : std::string(); };
        if (a == "--engine") engine = next();
        else if (a == "--tuning") tuning = next();
        else if (a == "--exp") exp = next();
        else if (a == "--label") label = next();
        else if (a == "--out") out = next();
        else pos = a;
    }
    std::string err;
    if (cmd == "pack") {
        bool ok = true;
        std::string text = tuning.empty() ? "" : slurp(tuning, &ok);
        if (!ok || engine.empty() || out.empty()) { printf("pack: --engine, --out and a readable --tuning are needed\n"); return 1; }
        if (!packEngine(engine, out, text, exp, label, &err)) { printf("pack failed: %s\n", err.c_str()); return 1; }
        printf("written %s (label '%s', tuning %zu bytes%s)\n", out.c_str(), label.c_str(), text.size(), exp.empty() ? "" : ", with experience");
        return 0;
    }
    if (cmd == "info" || cmd == "extract") {
        EmbeddedPayload ep;
        if (pos.empty() || !readEmbedded(pos, ep, &err)) { printf("%s\n", err.c_str()); return 1; }
        printf("label '%s' | executable %zu bytes | tuning %zu bytes | experience %zu bytes\n", ep.label.c_str(), ep.exeSize, ep.tuning.size(), ep.exp.size());
        if (cmd == "extract") {
            if (!tuning.empty()) std::ofstream(tuning) << ep.tuning;
            if (!exp.empty()) std::ofstream(exp, std::ios::binary).write(ep.exp.data(), (std::streamsize)ep.exp.size());
        }
        return 0;
    }
    if (cmd == "header") {
        bool ok = true;
        std::string text = slurp(tuning, &ok);
        if (!ok) { printf("cannot read the tuning file\n"); return 1; }
        fputs(tuningAsHeader(text, label).c_str(), stdout);
        return 0;
    }
    printf("unknown command %s\n", cmd.c_str());
    return 1;
}
