#include "tunables.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>

namespace joro {

static const char* SNAMES[SPR_PLAN_FIRST] = {"rfp_margin", "rfp_depth", "null_base", "null_div", "delta_margin", "lmr_start", "lmr_more"};
static const int SDEFAULT[SPR_PLAN_FIRST] = {120, 3, 2, 6, 200, 3, 8};

SearchParams::SearchParams() {
    for (int i = 0; i < SPR_COUNT; i++) v[i] = i < SPR_PLAN_FIRST ? SDEFAULT[i] : planParamDef(i - SPR_PLAN_FIRST).def;
}
const char* SearchParams::paramName(int i) { return (i >= 0 && i < SPR_PLAN_FIRST) ? SNAMES[i] : (i >= SPR_PLAN_FIRST && i < SPR_COUNT) ? planParamDef(i - SPR_PLAN_FIRST).name : ""; }
bool SearchParams::set(const std::string& name, int value) {
    for (int i = 0; i < SPR_COUNT; i++)
        if (name == paramName(i)) { v[i] = value; return true; }
    return false;
}

SearchParams& defaultSearchParams() {
    static SearchParams sp;
    return sp;
}

bool loadTuning(const std::string& path, Style& st, SearchParams& sp, std::string* err) {
    std::ifstream f(path);
    if (!f) { if (err) *err = "cannot open " + path; return false; }
    std::stringstream ss;
    ss << f.rdbuf();
    return loadTuningText(ss.str(), st, sp);
}

bool loadTuningText(const std::string& json, Style& st, SearchParams& sp) {
    if (!st.loadText(json)) return false;
    std::string t = json;
    size_t sec = t.find("\"search\"");
    if (sec == std::string::npos) return true;          // a plain style file
    t = t.substr(sec);
    for (int i = 0; i < SPR_COUNT; i++) {
        size_t k = t.find(std::string("\"") + SearchParams::paramName(i) + "\"");
        if (k == std::string::npos) continue;
        size_t c = t.find(':', k);
        if (c != std::string::npos) sp.v[i] = atoi(t.c_str() + c + 1);
    }
    return true;
}

bool saveTuning(const std::string& path, const Style& st, const SearchParams& sp) {
    std::ofstream f(path);
    if (!f) return false;
    f << "{\n  \"name\": \"" << st.name << "\",\n  \"weights\": {\n";
    for (int i = 0; i < SP_COUNT; i++) f << "    \"" << Style::paramName(i) << "\": " << st.w[i] << (i + 1 < SP_COUNT ? ",\n" : "\n");
    f << "  },\n  \"search\": {\n";
    for (int i = 0; i < SPR_COUNT; i++) f << "    \"" << SearchParams::paramName(i) << "\": " << sp.v[i] << (i + 1 < SPR_COUNT ? ",\n" : "\n");
    f << "  }\n}\n";
    return (bool)f;
}

} // namespace joro
