# JORO v0.4

UCI chess engine (C++17) with a patchable **experience file** (`joro.exp`).

## Build
    cmake -S . -B build && cmake --build build -j      # or: g++ -O3 -std=c++17 -pthread src/*.cpp -o joro
    ./build/joro        # speaks UCI

## UCI options
| option | meaning |
|---|---|
| ExperienceFile | path to `joro.exp` (the patch produced by the trainer app) |
| UseExperience | on/off |
| ExperienceStyle | apply the style stored in the file |
| StyleFile | path to a style file |
| Style_<param> | one weight (own_king, enemy_king, ... contempt) |
| StrictStyle | ignore experience made with another style |
| Hash, MoveOverhead | usual |

Debug commands: `d` (FEN + key), `eval`, `perft N`.

## JORO style (`styles/joro.style`, from "JORO PLAYING STYLE v1.0")
One identity for all of JORO. Each module of the style document is an evaluation module with a weight (% , 100 = nominal):
| module | param(s) | implemented as |
|---|---|---|
| DKD dual king dominance | own_king, enemy_king | pawn shield, open files on own king; king-zone attack units on the enemy king |
| TBDA target behind defense | pins, loose | pins/x-rays on king & queen, hanging pieces, overloaded defenders |
| SI sacrifice intelligence | compensation | bonus offsetting a material deficit when attack/activity/development justify it |
| DSI deep square intelligence | outposts, potential | outposts, squares a knight can reach next, rooks on files toward the king |
| PASI phase-aware | opening, endgame | development/centre/castling early; mop-up, king vs passers, opposite bishops late |
| DPSI pawn structure | structure, passers | isolated/doubled/backward, chains, connected & free passers |
| IPC initiative | initiative | threats by lesser pieces, space, tempo |
| KHTI king hunting & trap | king_hunt | enemy king escape squares (free / controlled / blocked), isolation from its defenders, open lines & batteries aimed at it, mating-net bonus; in the search, a check that leaves the king at most one flight square is extended |
Search-level parts (tactics: deflection, decoy, clearance, interference, sacrifices) come from the search itself.
`styles/neutral.style` = ablation baseline. The experience file stores the style id: an experience made with another
style is ignored (`StrictStyle`), and `joro_train` refuses to continue a file of another style.
A/B test: `joro_match --a styles/joro.style --b styles/neutral.style --movetime 50`.
Measured here (48 games, 40 ms/move): JORO style 59% vs neutral - positive but small sample.
KHTI A/B (same style, only `king_hunt` changes, 48 games each, 40 ms/move): weight 100 -> 42% ; weight 100 without the search
extension -> 44% ; weight 50 -> 59%. The samples are small (+-70 Elo) but the default is now temporarily 100 (`styles/joro.style`) pending SPSA. The
weight can be changed (`--set king_hunt=N`, UCI `Style_king_hunt`). Pieces of KHTI that are only approximated by the static
evaluation: "king attraction" (sacrifices/forcing sequences are found by the search, not planned) and "unsafe square
prediction" (only squares already controlled are counted). An experience made before KHTI stays valid (its style id is the
KHTI-off id): the engine uses it with the current style; the trainer upgrades it to the current style on the next training.

## JORO character & plans (identity)
JORO is an attacking, king-hunting engine. Its search, eval and parameters are organised around three plans:

* **Plan A - prevent castling (always the priority).** Stop the enemy king from castling through attack and pressure
  (control of f1/g1/c1-d1 style squares, pins, initiative). The sacrifice-intelligence eval (`compensation`) and its
  teammates are used here to justify giving material for tempo.
* **Plan B - drive the king out of its castle.** If the enemy king has castled anyway, make it unsafe: rook squares,
  square intelligence (`outposts`, `potential`), sacrifices, pawn storm (3 pawns), open lines toward the shield.
* **Plan C - queen hunt.** When the king is too well defended, switch the attack to the queen, played like a king hunt
  (trapping it, removing its escape squares).

Plan A has priority at all times; plans B and C alternate with each other depending on the position.

**Implemented in the engine** (`selectPlan(board, attacker)` in `src/eval.cpp`, shown by the UCI `eval` command):
* Choice: no plan in the endgame (phase < 8). Enemy king uncastled with castling rights -> **A**. Otherwise **C** if the
  enemy king is castled, has a full shield, no open shield file, >= 3 defenders within 3 squares and the enemy still has a
  queen; else **B**. B and C therefore alternate as the king gets harder or softer.
* Eval: each plan adds a bonus to the `hunt` term (so it is scaled by `king_hunt`, currently 100, and also feeds the
  sacrifice-compensation `comp`, whose threshold is lowered from 40 to 30 when a plan is active).
  A: controlled castling transit squares (+10 each), enemy king in check (+14), all castling sides denied (+12), cap 60.
  B: weak king-zone squares no pawn can cover (+4 each, max 6), rook lifts on the shield files (+6, max 2), 3-pawn storm
  (+14), >= 2 missing shield pawns (+8), cap 70. C: few safe squares for the enemy queen (+4 per missing square), queen
  attacked (+20, +16 if by a lesser piece), queen trapped (+50), cap 100.
* Search: a quiet move that serves the active plan gets one ply less late-move reduction (A: controls a castling transit
  square; B: lands within 2 squares of the enemy king; C: attacks the enemy queen). The KHTI check extension is unchanged.
* **Plan D - steer toward known experience (search level, `src/search.cpp`).** When the plan of the side to move makes no progress
  (its bonus is below `dStall` = 20 cp, or there is no plan) and `joro.exp` is loaded, JORO does not search blindly: the experience
  stores the position key of every good move and every learned SITUATION (see "Situation memory" below), so the search gives a
  bonus to a move that ENTERS a known good position (`dGood` 35 cp, a good situation `dSitPct` 60% of its stored value, capped by
  `dCap` 200) and a penalty for one that enters a known bad situation (130% of the same weight: what is bad weighs more).
  **Two modes:** FULL when plan A/B/C is stalled (good situations attract, bad ones repel); GUARD when plan A/B/C is progressing
  (only bad situations repel: the attack is never disturbed by a bonus). The situations are used only when the experience holds
  enough of them: nothing below `dSitMin` = 30, 30% weight there, 100% from `dSitFull` = 300. The forcing way (checks,
  captures, sacrifices) to a known position is therefore found by the normal search; once there, the root experience plays the stored
  moves by itself. A position where the OPPONENT knows a good move is avoided the same way; one where the opponent to move has a known
  losing move (a trap) is slightly attractive (`dTrap` 12 cp). Moves into a known position get no late-move reduction. The bonus is
  applied at the edge of the tree (the child is searched in a shifted window), so transposition-table entries stay valid inside one
  Plan D state (the table is cleared when the state changes). `SearchResult.planD / dPly / dKind (1 good move, 2 good situation, 3 bad situation) / dSit / dGuard` report it (the Live tab shows a
  "plan D" chip and how many plies away the known position is). **Default:** on in live games and in UCI (option `PlanD`), off in the
  trainer / tuner / gate (`Searcher::planD = false`) so that training keeps exploring. Test: `tests/plan_d_test.cpp`.
  **NEW situation -> steer toward the nearest good one (`dNearMax`, default 5; 0 = off).** When the root situation has never been met
  (`Experience::patCount(signature) == 0`) the exact-position / exact-pattern probes know nothing, so Plan D compares it with the GOOD
  situations JORO has already lived through: `Experience::goodTargets()` decodes the good learned patterns (balanced score >= 20) back to
  their 12 features (`SitFeat`), and `sitDistance(current, target)` counts the events needed to get there (captures, trades, a sacrifice
  = balance step, castling; things that cannot come back, like a lost queen or lost castling rights, cost 8 per step; the enemy king costs
  double). If the nearest target is <= `dNearMax` events away the search steers toward it **by any means**: each target is worth
  `gain * progress / distance-at-root` (gain = stored value x `dSitPct` x situation weight, capped by `dCap`), so a forcing line, a trade or
  a small sacrifice is accepted when it gets there. Only progress counts (telescoping along the line), so the bonus does not depend on the
  path and the transposition table stays valid. While plan A / B / C is progressing the steering only takes over when the target is <= `dNearAttack` (2) events away, so a running attack is not disturbed by a far goal. If the nearest target is farther than `dNearMax`, Plan D does not steer and plans
  A / B / C go on alone (`SearchResult.dDist` reports the distance, `dNear` / `dKind = 4` the steering). Limits: only learned PATTERNS have
  features (named situations are exact positions); the pattern signature is coarse (it does not tell O-O from O-O-O).
* **SPSA-tunable:** 18 plan parameters (`PlanParam` in `src/eval.h`) live in `SearchParams`, so they are in the tuning file's
  `"search"` object, in the UCI options `Search_plan_*` and in the tuner (the style id / experience format is unchanged):
  bonuses `plan_a_transit, plan_a_check, plan_a_stuck, plan_b_weak, plan_b_lift, plan_b_storm3, plan_b_shield, plan_c_safe,
  plan_c_att, plan_c_lesser, plan_c_trap`; weight of each plan in % `plan_w_a, plan_w_b, plan_w_c`; when each plan applies
  `plan_hard_def` (defenders that make the king "hard" -> C), `plan_phase_min`, `plan_comp_thresh`; search `plan_lmr_relief`.
  The caps (60 / 70 / 100) stay fixed; `plan_w_*` scale the capped value.
      ./build/joro_tune --plans-only --state plans.state --out plans.style --pairs 8 --movetime 40 --iters 400
  `--no-plans` leaves them out of a full run; `king_hunt` is not touched by `--plans-only` (it stays at 100).
  Not A/B-tested yet: after the run, check with `--verify N` (tuned values against the start values).

**Note (current setting):** `king_hunt` is fixed at **100** (`styles/joro.style`, `Style::Style()` default) until the SPSA
tuning is finished. The older A/B figure below (100 -> 42%, 50 -> 59%) was measured on a small sample before this decision.

## JORO release: a tuned engine file (v*)
Flow: **Tune** (SPSA) -> **Fakafakao** (verify) -> **Ampiharo** (apply) -> **Calibrate** -> **Ampiharo update** -> `JORO v<n>`.
The release is one engine file that carries its own tuning, so another chess app / program / script can load it as it is:

* `src/embed.h` : the tuning JSON (style + search + plan parameters), optionally `joro.exp` and a label are appended to the
  executable (footer `JOROEMB1`, the executable still runs: loaders ignore trailing bytes). At start the engine reads its own
  file (`/proc/self/exe`); the UCI name becomes `JORO 0.4 v5`, the `Style_*` / `Search_*` option defaults show the tuned values,
  and `info string embedded: ...` tells what was found. UCI options (`StyleFile`, `ExperienceFile`, `Style_*`, `Search_*`) set later still win.
* `joro_pack` (CLI, same code as the app):
      joro_pack pack --engine joro --tuning tuned.style [--exp joro.exp] --label v5 --out joro-v5
      joro_pack info joro-v5                       # label, sizes
      joro_pack extract joro-v5 --tuning a.style --exp a.exp
      joro_pack header --tuning tuned.style --label v5 > joro_tuned.h    # the tuned values as C++ constants (for the code)
  Packing a packed engine replaces its payload.
* In the code: `joro_tuned.h` gives `joro_tuned::style[]` / `search[]` ({name, value}); apply with `Style::set` / `SearchParams::set`,
  or paste the numbers into `Style::Style()`, `SDEFAULT` (tunables.cpp) and `PPDEF` (eval.cpp, plan parameters).

## King Position Classifier (v0.5)
`classifyKing(board, color)` -> short-castled / long-castled / uncastled-center / exposed / edge / other, plus shield pawns,
missing shield pawns and open shield files (`eval` debug command prints it). KHTI uses it (middlegame only, scaled by
`king_hunt`): missing shield, rooks/queen/double rooks on the shield files, pawn storm, uncastled king facing open lines,
enemy rook shut in by its own king (Rh8+Kg8). Not A/B-tested yet: run `joro_match` before changing the default weight.

## A/B gate (v0.5)
* After a training the new experience plays the previous one (`joro_train --gate 2 --gate-ms 60`, on by default: 2 games per
  trained opening, both colours, at most 8 openings). Under 45% -> the previous file is restored and the new one is kept as
  `OUT.rejected`; the previous file is always kept as `OUT.bak`. It only catches big regressions (a few games are noisy).
  The app does the same with its switch in the Train tab (only when an experience file existed before the training).
  (The old etudes - training by enemy-king type and the endgame etudes - were removed: the Situation memory replaces them.)

## Self-play strength (v0.5)
`--depth-weak 5 --depth-strong 8` (defaults) or `--ms-weak 150 --ms-strong 400`; `--equal` = both sides alike. The strong
side alternates White/Black every game, so a rematch swaps roles. In the app (Train tab) the same values are the prefilled
inputs; a switch chooses depth or milliseconds.

## Situation memory (replaces the etudes and the mating-variation memory)
JORO learns to tell GOOD from BAD **situations** by looking back at every decided game (`Trainer::analyseSituations`,
`src/trainer.cpp`). A situation is stored on the POSITION where it appeared (the position after the move that created it), as an
experience entry of kind 2 (`SitCode` in `src/experience.h`), with a value signed for the side to move there:
* **BAD** (learned from a lost game): `SIT_BAD_OPENING` (big early drop), `SIT_WEAK_KING` (castling thrown away / shield torn open
  before the game turned), `SIT_QUEEN_TRADE` and `SIT_EXCHANGE` (the last exchange before an endgame that was lost),
  `SIT_LOSING_ENDGAME` (entering the endgame already worse), `SIT_BAD_SACRIFICE` (material given for nothing; heavier when it ends in mate).
* **GOOD** (learned from a won game): `SIT_MATE_ATTACK` (every position of a line that ended in checkmate, stronger the nearer the
  mate), `SIT_FAST_MATE` (mate within 20 moves), `SIT_PRESSURE` (3 decisions in a row with an edge while the opponent never checks or
  captures and we do it twice; stronger when its king shield is torn), `SIT_SAC_WIN` (material given and not recouped, game won),
  `SIT_WIN_ENDGAME`, and `SIT_SHORT_WIN` (won without ever reaching an endgame: the best kind, so it is learned on the last 8 decisions).
* **These named codes are only examples.** Everything else is learned as a **PATTERN** (`SIT_PATTERN`, `situationSignature`): the key is a
  signature of the position's features (phase, queens, material balance, rooks / minors / pawns, castling state of both kings), not
  the exact position. Every position of every decided game teaches how such positions ended for the side to move; seen in wins and
  losses the pattern balances near zero, seen mostly in one result it keeps a value (full weight after 20 sightings). So JORO knows
  many more situations after training, and they apply to positions it has never met. To add a new feature, extend the signature
  (or add a named code in `analyseSituations`).
* **Balance:** the same situation seen again grows in confidence (count) and its value is averaged; `Experience::sitScore` adds all the
  records of a position (good and bad cancel when they weigh the same) and clamps it to +-400. A draw teaches no situation.
* **Use:** Plan D (see above) reads `sitScore` of every position the search enters, only once the experience holds enough situations.
  Live games and UCI have Plan D on; the trainer keeps it off so that training keeps exploring (`--no-situations` stops learning them).
* **Format:** unchanged (version 2, same 16-byte entries). An engine that predates the situations ignores them in the move logic; only
  its Plan D probe could take them for a known good position. Old files load as they are; the old mating-line moves (value >= 20000)
  stay as ordinary GOOD moves. Test: `tests/situation_test.cpp`.
* The classification uses simple rules (material, castling rights, shield pawns, checks / captures), not a verdict of a deeper search:
  tune the thresholds in `analyseSituations` after looking at what a real training run stores.
* **Variation Brain** (`VariationBrain` UCI option, `--no-brain`): before a move is played, a forcing-line analysis (the
  opponent plays only checks / captures / promotions, we answer with anything, 30000 nodes) refuses a move that allows a
  forced mate, a lost piece (unless the search itself says it is a sound sacrifice), a promotion, or a stalemate / draw
  while we stand clearly better. A forced mate found this way is stored as BAD. Not yet A/B-tested with `joro_match`.
  (It is a search-level safety net and is kept; it is not part of the experience memory.)

## Experience file (`src/experience.h`)
Entries `(position key, move, kind GOOD/BAD/SITUATION, value, count)` (for kind SITUATION `move` is the situation code).
* At the root JORO **removes every move marked BAD** (net count: bad > good) -> it never repeats the same error.
* If a **GOOD** move is known it is played directly (learned win).
* Header also stores the **style** (5 weights) so a patch can change how JORO plays.
Position keys use a fixed Zobrist seed, so the same file works on PC, CI and Android.

## Verified
perft: startpos d5, Kiwipete d4, pos3 d5, pos4 d4, pos5 d3, pos6 d3 : all exact. Incremental hash == full hash.
~1.2M nps, depth 14 in 2 s from startpos (single thread).

## CI
`.github/workflows/calibrate.yml` : JORO vs Stockfish (`UCI_LimitStrength`, `UCI_Elo` levels) via fastchess,
runs on every push touching `src/**` or `experience/**`; Elo estimate appended to `calibration/history.csv`.
Put the trained file at `experience/joro.exp`. Stockfish's minimum UCI_Elo is 1320.
`openings/openings.epd` is generated with `tools/make_openings.sh`.

## Trainer (`joro_train`)
    ./build/joro_train --opening "e2e4 e7e5 g1f3 b8c6" --depth 8 --out experience/joro.exp
    ./build/joro_train --openings tools/lines.txt --in experience/joro.exp --out experience/joro.exp
Self-play JORO vs JORO from the opening. After each game, for each side:
* **won** -> NO move is stored, except the **brilliant** ones (see below). (`--all-good` restores the old behaviour: every move GOOD.)
* **lost / drew** -> backtracking over its decisions: the move with the biggest eval drop (>= 100 cp) that still has
  untried alternatives is stored BAD (else the last decision with alternatives). Next game takes another variation.
Stops when: `--games` budget, `--stable` games without anything new, or `--confirm` consecutive wins by one side.
Games are deterministic (fixed depth, tables cleared) so a replay is identical until the first changed move.

## Opponents, PGN and per-opening table (v0.6)
**Mixed opponents** (`--vs ENGINE --mix self=20,ladder=60,max=20`): every game JORO plays JORO, Stockfish on the *ladder*, or
Stockfish at full strength, chosen by those proportions; JORO's colour alternates each game. The ladder uses `UCI_LimitStrength` +
`UCI_Elo` (levels `--ladder-levels`, default 1320..3190, clamped to the engine's range) and goes up one level when JORO won
`--ladder-need` of the last `--ladder-window` games at that level (default 3 of 3). The level is kept in `OUT.ladder` between
runs (`--ladder-reset` to restart). Without `--mix`, `--vs` behaves as before (full strength, fixed colour).
**First-move variety**: with probability `--vary-first` (default 5 %) JORO's first searched move after the opening is its 2nd best
(only if within `--vary-loss` cp, default 60) so the same opening does not replay the same game; `--seed` makes a run repeatable.
**PGN**: every game is written to `PREFIX_0001.pgn, _0002 ...` (`--pgn`, default `OUT_games`; `--pgn-split N` games per file,
default 100; `--no-pgn`). Moves carry `!!` brilliant, `!` great, `?` bad, `??` blunder (the BAD stored by the backtracking, drop >= 300 cp)
with `[%eval]` comments (white point of view). Brilliant / great marks come from the verified-move search (`findBrilliant`).
**Table per opening** (`--stats`, default `OUT.stats.csv`, one row per opening and run, printed at the end of the run): games, result
vs Stockfish, mates won by JORO, shortest mate, mating variations stored (run / all runs), new bad / brilliant / great, and a progress mark
against the previous run of the same opening: +1 for a shorter mate (or the first one), +1 for at least one new mating variation, +-1 when the
share of games ending in mate moves by 10 points or more -> UP / DOWN / = / NEW. Mate length depends on the opponent met, so compare runs
that used the same `--mix`. The Android app is not wired to these yet (the code is in `trainer`, `opponent.h`, `pgn`, `opstats`).

## SPSA tuning of the style and of the search (v0.7)
`joro_tune` (and the **Tune** tab of the Android app, same C++ `Tuner`) tunes by self-play, with no data set:
* 14 style weights (`own_king` ... `king_hunt`; `contempt` is never tuned) and 7 search constants (`src/tunables.h`: reverse-futility
  margin/depth, null-move `R = base + depth/div`, delta pruning, LMR start/extra). Their defaults reproduce exactly the old hard-coded
  values (same node counts as before on the same positions).
* One iteration = `--pairs` openings x 2 colours. A plays theta+delta*D, B plays theta-delta*D (D = random +-1 per parameter); then
  theta += a_k * c_i * D_i * (W-L)/games. The exported value is an exponential moving average of theta (less noisy).
* State written after **every** iteration (`--state`, resumed automatically): stop / kill / reboot lose at most one iteration.
  In the app, pause makes the games sleep at the next move (0 % CPU measured).
* `--verify N` plays N batches of *tuned vs starting values*: SPSA alone proves nothing, read the Elo interval before using the result.
        ./build/joro_tune --openings tools/lines.txt --iters 300 --pairs 8 --movetime 40 --threads 2 \
                          --state tuning/tune.state --out tuning/tuned.style --verify 20
* Tuning file = a style JSON plus a `"search"` object. UCI: `setoption name StyleFile value tuned.style` (loads both), or
  `Style_<name>` / `Search_<name>` one by one. `joro_train --style-file` reads the style part only.
* An experience is bound to its style id: applying a tuning re-stamps the header of `joro.exp` (entries untouched, old file kept as
  `joro.exp.prestyle`). The app does it with **Ampiharo**; **Averina ny tany am-boalohany** goes back to the built-in values.
* Typical cost: ~16 games per iteration at 40 ms/move; a few hundred iterations are needed. Measured here: 3 s per game and thread.

## Adding an eval term without breaking joro.exp (v0.8)
1. `src/eval.h`: add the new `StyleParam` **just before `SP_COUNT`** (values are append-only: they are the indices stored in old files),
   its name in `PNAMES` (`src/eval.cpp`), and its default in `Style`. Default **0 = module off** is the safe choice while you experiment:
   `Style::id()` ignores a zero extra parameter, so every existing experience stays compatible and `joro.exp` stays byte-identical.
2. Nothing else for the tuner: `joro_tune` and the Tune tab take every style parameter (range 0..300, step 15; special ranges in
   `Tuner::Tuner`). `Style_<name>` UCI options and the style / tuning JSON files also work by name.
3. Experience file: parameters 0..15 stay in the 16 header slots by index; those from 16 on are written in an optional **footer by name**
   (`"JSTY"`, count, `{name[16], i32}`), non-zero only. A parameter missing from a file = off. Names the program does not know are kept when
   it saves the file again. A damaged footer makes the load fail (no silently wrong style). Older C++ readers ignore the footer; the Android
   `Storage.readExpInfo` accepts it.
4. When the default of the new term is non-zero (or the tuning turns it on), the style id changes: old experiences are then
   "another style". Apply the tuning (**Ampiharo**) or `Experience::setStyle`: the header is re-stamped and the entries are kept.
5. Test: `sh tests/run_exp_tests.sh` (with `OLD=/path/to/older/repo` it also checks old-reader / new-reader compatibility). The test hook
   `-DEXP_HEADER_PARAMS=13` puts real parameters in the footer without needing a 17th parameter.

## Next
Kotlin Android app: JNI around `joro_trainer` (start / stop / progress / export `joro.exp`).

## What the experience keeps
* **GREAT** moves of the winner (v0.5): no sacrifice needed, but a depth+1 search without that move is >= 60 cp worse
  (`--great-margin N`, `--no-great`). At most 8 verifications per side and game.
* **BAD** moves: the critical move of a lost/drawn game (backtracking). They are removed at the root, so the same mistake is never repeated.
* **Brilliant** moves of the winner, stored as GOOD and played directly: a move that gives up material (>= 2 pawns over the
  exchange) without the evaluation falling, or that starts a forced mate, AND that a deeper search (depth+1, the move excluded)
  confirms to beat every alternative by >= 120 cp. Ordinary winning moves are not stored: the search finds them again anyway,
  and a won game says little about each individual move. The experience file is therefore small and made of reliable facts.
