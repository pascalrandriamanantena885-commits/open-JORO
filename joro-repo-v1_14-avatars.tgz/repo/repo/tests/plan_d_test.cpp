// Plan D test (experience steering).  g++ -O2 -std=c++17 -Isrc tests/plan_d_test.cpp src/board.cpp src/eval.cpp src/experience.cpp src/search.cpp \
//                                         src/tunables.cpp src/embed.cpp -pthread -o plan_d_test
//  1. without experience / with planD off, nothing changes (no Plan D report)
//  2. a position known as a GOOD SITUATION (mating attack) two plies ahead (a check with a single reply) attracts the search: Ra8+ is chosen,
//     dPly = 2, dKind = 2; with too little situation experience (< dSitMin) it is ignored
//  3. a position where the OPPONENT knows a good move is avoided: the move the engine would play is dropped when it leads there
//  4. a position where the opponent to move has a known bad move (trap) is preferred
//  6. NEW situation (no pattern like it in the experience): Plan D finds the nearest GOOD pattern (features, sitDistance) and steers
//     toward it; farther than dNearMax -> no steering, plans A / B / C go on
//  5. Plan D is not active when the root position itself is known (the root experience plays it) and when plan A / B / C makes progress
#include "search.h"
#include <cstdio>
#include <string>

using namespace joro;
static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { printf("FAIL: %s\n", msg); fails++; } else printf("ok:   %s\n", msg); } while (0)

static Move mv(Board& b, const char* uci) { Move m = b.parseMove(uci); return m; }
static U64 keyAfter(const char* fen, std::initializer_list<const char*> moves) {
    Board b; b.setFen(fen);
    for (auto u : moves) { Move m = b.parseMove(u); if (m == MOVE_NONE || !b.makeLegal(m)) { printf("bad test move %s\n", u); return 0; } }
    return b.hash;
}
static SearchResult run(Searcher& s, const char* fen, int depth) {
    Board b; b.setFen(fen);
    s.stopFlag = false;
    Limits l; l.depth = depth;
    return s.go(b, l);
}

int main() {
    initTables();
    const char* FEN = "6k1/5p1p/6p1/8/8/8/5PPP/R5K1 w - - 0 1";    // Ra8+ Kg7 is forced
    // ---- 1 / 2
    {
        Experience exp;
        U64 z = keyAfter(FEN, {"a1a8", "g8g7"});
        Board b; b.setFen(FEN); b.makeLegal(b.parseMove("a1a8")); b.makeLegal(b.parseMove("g8g7"));
        exp.addSituation(z, SIT_MATE_ATTACK, 200, 3);                           // white (to move there) has a mating attack
        Experience few = exp; for (int i = 0; i < 10; i++) few.addSituation(0x8000 + i, SIT_PRESSURE, 50, 1);                                                  // too little situation experience: must be ignored
        for (int i = 0; i < 300; i++) exp.addSituation(0x9000 + i, SIT_PRESSURE, 50, 1);  // plenty of situations (>= dSitFull): full weight
        Searcher off; off.setExperience(&exp); off.quiet = true; off.brain = false;
        auto r0 = run(off, FEN, 6);
        CHECK(!r0.planD, "planD off: no Plan D report");
        Searcher on; on.setExperience(&exp); on.quiet = true; on.brain = false; on.planD = true;
        auto r1 = run(on, FEN, 6);
        printf("      planD off: %s   planD on: %s  (dPly %d kind %d)\n", Board::moveToStr(r0.best).c_str(), Board::moveToStr(r1.best).c_str(), r1.dPly, r1.dKind);
        CHECK(r1.planD, "planD on: active (plan A/B/C stalled)");
        CHECK(Board::moveToStr(r1.best) == "a1a8", "the checking move into the known mating line is chosen");
        CHECK(r1.dPly == 2 && r1.dKind == 2, "report: known position reached after 2 plies, good situation");
        Searcher fw; fw.setExperience(&few); fw.quiet = true; fw.brain = false; fw.planD = true;
        auto rf = run(fw, FEN, 6);
        CHECK(rf.dKind != 2, "too few situations in the experience: the situation memory is not used");
        Experience empty;
        Searcher none; none.setExperience(&empty); none.quiet = true; none.planD = true;
        CHECK(!run(none, FEN, 4).planD, "empty experience: Plan D off");
    }
    // ---- 3 : avoid a position where the opponent knows a good move
    {
        const char* S = START_FEN;
        Searcher base; Experience e0; base.setExperience(&e0); base.quiet = true; base.brain = false;
        Experience dummy; dummy.add(1, 1, EXP_GOOD, 10, 1);                    // non-empty experience, unrelated
        Searcher s0; s0.setExperience(&dummy); s0.quiet = true; s0.brain = false; s0.planD = true;
        auto r0 = run(s0, S, 5);
        std::string played = Board::moveToStr(r0.best);
        Board b; b.setFen(S);
        Experience exp = dummy;
        U64 k = keyAfter(S, {played.c_str()});
        Board c; c.setFen(S); c.makeLegal(c.parseMove(played)); Move reply; { Move ms[256]; int n = c.genLegal(ms); reply = ms[0]; (void)n; }
        exp.add(k, reply, EXP_GOOD, 50, 3);                                      // black knows a good move after our usual move
        Searcher s1; s1.setExperience(&exp); s1.quiet = true; s1.brain = false; s1.planD = true; s1.dGood = 120;
        auto r1 = run(s1, S, 5);
        printf("      usual move %s -> with the opponent's known position: %s\n", played.c_str(), Board::moveToStr(r1.best).c_str());
        CHECK(Board::moveToStr(r1.best) != played, "move leading to a position the opponent knows is avoided");
        // ---- 4 : trap attraction
        Experience exp2 = dummy;
        exp2.add(keyAfter(S, {"a2a3"}), 5, EXP_BAD, -300, 2);                    // black to move after a3 has a known bad move
        Searcher s2; s2.setExperience(&exp2); s2.quiet = true; s2.brain = false; s2.planD = true; s2.dTrap = 200;
        auto r2 = run(s2, S, 3);
        CHECK(Board::moveToStr(r2.best) == "a2a3", "move into a position where the opponent has a known bad move is preferred");
        // ---- 5 : the root known by the experience is played by the experience, no search
        Experience exp3 = dummy;
        Board rb; rb.setFen(S);
        Move m0 = rb.parseMove("g1f3");
        exp3.add(rb.hash, m0, EXP_GOOD, 40, 2);
        Searcher s3; s3.setExperience(&exp3); s3.quiet = true; s3.planD = true;
        auto r3 = run(s3, S, 4);
        CHECK(r3.fromExperience && r3.best == m0 && !r3.planD, "known root position: the experience move is played, Plan D not needed");
    }
    // ---- 6 : NEW situation -> steer toward the nearest GOOD situation already lived through; too far -> no steering
    {
        const char* R = "r1bq1rk1/ppp2ppp/2np1n2/2b1p3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQ - 0 6";   // white can castle now (the usual move there is another one)
        Board rb; rb.setFen(R);
        SitFeat f0 = situationFeatures(rb, WHITE);
        CHECK(signatureOf(f0) == situationSignature(rb), "signatureOf(features) is the situation signature");
        SitFeat castled = f0; castled.v[10] = 0;                                  // white king castled
        CHECK(sitDistance(f0, castled) == 1, "castling = 1 event away");
        SitFeat noQ = f0; noQ.v[2] = 0;
        CHECK(sitDistance(noQ, f0) >= SIT_IMPOSSIBLE, "a queen that is gone does not come back (impossible)");
        Experience exp;
        for (int i = 0; i < 300; i++) exp.addSituation(0xA000 + i, SIT_PRESSURE, 50, 1);       // enough situations: full weight
        for (int i = 0; i < 20; i++) exp.addSituation(signatureOf(castled), SIT_PATTERN, 200, 1);   // castled pattern: good, well seen
        const auto& tg = exp.goodTargets();
        CHECK(tg.size() == 1 && sitDistance(f0, tg[0].f) == 1 && tg[0].f.v[10] == 0, "the good pattern is decoded back to its features");
        CHECK(exp.patCount(signatureOf(f0)) == 0, "the root situation is new to the experience");
        Searcher off; off.setExperience(&exp); off.quiet = true; off.brain = false; off.planD = true; off.dNearMax = 0;
        auto ro = run(off, R, 4);
        Searcher on; on.setExperience(&exp); on.quiet = true; on.brain = false; on.planD = true;
        auto rn = run(on, R, 4);
        printf("      near off: %s   near on: %s  (dist %d, dPly %d, kind %d)\n", Board::moveToStr(ro.best).c_str(), Board::moveToStr(rn.best).c_str(), rn.dDist, rn.dPly, rn.dKind);
        CHECK(rn.dNear && rn.dDist == 1, "new situation, good situation 1 event away: Plan D steers toward it");
        CHECK(Board::moveToStr(ro.best) != "e1g1", "without steering JORO does not castle here");
        CHECK(Board::moveToStr(rn.best) == "e1g1", "with steering the move that reaches the good situation (castling) is chosen");
        CHECK(rn.dKind == 4 && rn.dPly >= 1, "report: kind 4 (near good situation), plies until it is reached");
        // too far: the only good situation needs a queen trade + a castled enemy king + fewer pawns... farther than dNearMax
    }
    {
        const char* R = "r1bq1rk1/ppp2ppp/2np1n2/2b1p3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQ - 0 6";
        Board rb; rb.setFen(R);
        SitFeat far = situationFeatures(rb, WHITE);
        far.v[2] = 0; far.v[3] = 0; far.v[4] = 1; far.v[5] = 1; far.v[8] = 0; far.v[9] = 0; far.v[10] = 0; far.v[11] = 0;   // queens off, a rook each, few pawns...
        Experience exp;
        for (int i = 0; i < 300; i++) exp.addSituation(0xA000 + i, SIT_PRESSURE, 50, 1);
        for (int i = 0; i < 20; i++) exp.addSituation(signatureOf(far), SIT_PATTERN, 200, 1);
        Searcher on; on.setExperience(&exp); on.quiet = true; on.brain = false; on.planD = true;
        auto rn = run(on, R, 4);
        CHECK(!rn.dNear && rn.dDist > on.dNearMax, "good situation too far: no steering (plans A / B / C go on), distance reported");
        Searcher pd; pd.setExperience(&exp); pd.quiet = true; pd.brain = false; pd.planD = false;
        CHECK(!run(pd, R, 4).dNear, "Plan D off: no steering");
        Searcher nr; nr.setExperience(&exp); nr.quiet = true; nr.brain = false; nr.planD = true; nr.dNearMax = 0;
        CHECK(!run(nr, R, 4).dNear, "dNearMax = 0: steering off");
    }
    printf(fails ? "\n%d FAILED\n" : "\nALL OK\n", fails);
    return fails ? 1 : 0;
}
