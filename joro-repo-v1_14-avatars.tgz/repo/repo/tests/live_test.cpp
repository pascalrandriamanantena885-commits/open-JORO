// Live-game API test: games are played through app::live* and the experience file must stay byte for byte identical.
//   g++ -O2 -std=c++17 -pthread -Isrc tests/live_test.cpp src/appapi.cpp src/board.cpp src/eval.cpp src/experience.cpp src/search.cpp \
//       src/tunables.cpp src/embed.cpp src/trainer.cpp src/gate.cpp src/san.cpp src/pgn.cpp src/opstats.cpp src/tuner.cpp -o live_test
#include "appapi.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <sys/stat.h>

using namespace joro;
static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { printf("FAIL: %s\n", msg); fails++; } else printf("ok:   %s\n", msg); } while (0)

static std::string slurp(const std::string& p) { std::ifstream f(p, std::ios::binary); std::stringstream ss; ss << f.rdbuf(); return ss.str(); }

int main() {
    initTables();
    std::vector<int> open;
    CHECK(app::parseSanLine("1.e4 e5 2.Nf3 Nc6", open) && open.size() == 4, "opening parsed");

    // outcome detection
    std::vector<int> fm;
    app::parseSanLine("1.f3 e5 2.g4 Qh4#", fm);
    auto o = app::liveOutcome(fm);
    CHECK(o.size() == 3 && o[0] == 1 && o[1] == -1 && o[2] == 0, "fool's mate = black wins by mate");
    o = app::liveOutcome(open);
    CHECK(o.size() == 3 && o[0] == 0, "opening is not over");
    std::vector<int> rep;
    app::parseSanLine("1.Nf3 Nf6 2.Ng1 Ng8 3.Nf3 Nf6 4.Ng1 Ng8", rep);
    o = app::liveOutcome(rep);
    CHECK(o.size() == 3 && o[0] == 1 && o[1] == 0 && o[2] == 3, "threefold repetition = draw");
    CHECK(app::liveOutcome({1, 2, 3}).empty(), "illegal moves -> empty");

    // an experience file made by the trainer
    std::string path = "/tmp/live_test.exp";
    remove(path.c_str());
    std::string err;
    app::TrainHandle* th = app::trainCreate(open, path, 4, 5, 0, 0, 2, 3, 5, true, 8, 0.0, "t", &err);
    CHECK(th != nullptr, "trainCreate");
    for (int i = 0; i < 2 && th; i++) { auto r = app::trainStep(th); if (r.empty() || r[0] != 0) break; }
    app::trainDestroy(th);
    std::string before = slurp(path);
    struct stat st0; stat(path.c_str(), &st0);
    CHECK(!before.empty(), "experience file written by training");

    for (int useExp = 1; useExp >= 0; useExp--) {
        app::LiveHandle* h = app::liveCreate(path, useExp != 0, 8, &err);
        CHECK(h != nullptr, useExp ? "liveCreate (experience on)" : "liveCreate (experience off)");
        if (!h) continue;
        printf("      %s\n", app::liveInfo(h).c_str());
        app::liveNewGame(h);
        std::vector<int> mv = open;
        int ply = 0;
        bool badMove = false;
        while (ply < 40) {
            auto oc = app::liveOutcome(mv);
            if (oc.empty() || oc[0]) break;
            auto r = app::liveJoroMove(h, mv, 0, 30);
            auto legal = app::legalMoves(mv);
            bool legalOk = false;
            for (int m : legal) if (m == r[0]) legalOk = true;
            if (!legalOk) { badMove = true; break; }
            mv.push_back(r[0]);
            ply++;
        }
        CHECK(!badMove && ply > 0, "JORO vs JORO: every move legal");
        auto pl = app::livePlans(h, mv);
        CHECK(pl.size() == 2 && pl[0] >= 0 && pl[0] <= 3 && pl[1] >= 0 && pl[1] <= 3, "plans returned");
        printf("      %s\n", app::sanLine(mv).c_str());
        // stop works: a search started after liveStop returns "no move"
        app::liveStop(h);
        auto r = app::liveJoroMove(h, mv, 0, 1000);
        CHECK(r[0] == 0, "after liveStop no move is returned");
        app::liveNewGame(h);
        r = app::liveJoroMove(h, open, 0, 30);
        CHECK(r[0] != 0, "liveNewGame re-arms");
        app::liveDestroy(h);
        std::string after = slurp(path);
        struct stat st1; stat(path.c_str(), &st1);
        CHECK(after == before && st1.st_mtime == st0.st_mtime, "joro.exp untouched (same bytes, same mtime)");
        CHECK(slurp(path + ".tmp").empty() && slurp(path + ".bak").empty(), "no .tmp / .bak created");
    }
    app::LiveHandle* h = app::liveCreate("/tmp/does_not_exist.exp", true, 8, &err);
    CHECK(h != nullptr, "missing experience file: JORO plays without memory");
    if (h) { app::liveNewGame(h); auto r = app::liveJoroMove(h, open, 0, 30); CHECK(r[0] != 0, "move without experience"); CHECK(!std::ifstream("/tmp/does_not_exist.exp"), "no file created"); app::liveDestroy(h); }
    printf(fails ? "\n%d FAILED\n" : "\nALL OK\n", fails);
    return fails ? 1 : 0;
}
