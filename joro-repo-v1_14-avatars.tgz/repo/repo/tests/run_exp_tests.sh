#!/bin/sh
# Tests of the joro.exp header / footer (experience.h). Run from the repo root after:  cmake -S . -B build && cmake --build build
#   A  production layout: the file stays the plain v2 file (no footer while all extra parameters are off)
#   B  test hook EXP_HEADER_PARAMS=13: contempt and king_hunt go to the footer BY NAME -> exercises the footer for real
#   C  an old reader (optional: OLD=/path/to/older/repo with its own build/) loads the new files and the other way round
set -e
B=${BUILD:-build}
T=$(mktemp -d)
echo "== A"; g++ -O1 -std=c++17 -Isrc tests/exp_header_test.cpp $B/libjoro_core.a -pthread -o $T/expA && $T/expA rt $T/a.exp | grep -E "FAIL|ALL OK|FAILED"
echo "== B"; g++ -O1 -std=c++17 -DEXP_HEADER_PARAMS=13 -Isrc tests/exp_header_test.cpp src/experience.cpp $B/libjoro_core.a -pthread -o $T/expB && $T/expB rt $T/b.exp | grep -E "FAIL|ALL OK|FAILED"
if [ -n "$OLD" ]; then
  echo "== C"
  g++ -O1 -std=c++17 -Isrc tests/exp_cross.cpp $B/libjoro_core.a -pthread -o $T/crossNEW
  g++ -O1 -std=c++17 -I$OLD/src tests/exp_cross.cpp $OLD/build/libjoro_core.a -pthread -o $T/crossOLD
  $T/crossOLD write $T/old.exp; $T/crossNEW write $T/new.exp
  echo -n "old file, new reader: "; $T/crossNEW read $T/old.exp
  echo -n "new file, old reader: "; $T/crossOLD read $T/new.exp
  cmp $T/old.exp $T/new.exp && echo "old and new files are byte-identical"
fi
rm -rf $T
