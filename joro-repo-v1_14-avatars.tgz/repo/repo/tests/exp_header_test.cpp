// modes: rt <file> (round trip, sizes, footer behaviours)   write <file> / read <file> (cross-version compatibility)
#include "experience.h"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>
using namespace joro;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } else printf("ok   %s\n", #c); } while (0)
static std::vector<char> slurp(const std::string& p) { std::ifstream f(p, std::ios::binary); return {std::istreambuf_iterator<char>(f), {}}; }
static void spit(const std::string& p, const std::vector<char>& v) { std::ofstream f(p, std::ios::binary); f.write(v.data(), (std::streamsize)v.size()); }
static Style mk(int own, int kh, int cont) { Style s; s.w[SP_OWN_KING] = own; s.w[SP_KING_HUNT] = kh; s.w[SP_CONTEMPT] = cont; return s; }
static Experience mkExp(const Style& st) {
    Experience e; e.add(0x1111, 0x0a, EXP_BAD, 0, 2); e.add(0x2222, 0x0b, EXP_GOOD, 10, 1); e.addSituation(0x3333, SIT_MATE_ATTACK, 120, 2); e.setStyle(st); return e;
}
static bool same(const Style& a, const Style& b) { for (int i = 0; i < SP_COUNT; i++) if (a.w[i] != b.w[i]) return false; return true; }

int main(int argc, char** argv) {
    std::string mode = argv[1], path = argv[2];
    if (mode == "write") { Experience e = mkExp(mk(123, 77, 9)); return e.save(path) ? 0 : 1; }
    if (mode == "read") {
        Experience e; std::string err;
        if (!e.load(path, &err)) { printf("LOAD FAILED: %s\n", err.c_str()); return 2; }
        Style s; e.getStyle(s);
        printf("entries=%zu own=%d hunt=%d contempt=%d bad=%d\n", e.size(), s.w[SP_OWN_KING], s.w[SP_KING_HUNT], s.w[SP_CONTEMPT], e.badCount(0x1111, 0x0a));
        return 0;
    }
    // ---- round trip
    printf("EXP_HEADER_PARAMS = %d, SP_COUNT = %d\n", EXP_HEADER_PARAMS, SP_COUNT);
    int k = 0;                                                       // non-zero parameters that live in the footer
    Style st = mk(123, 77, 9);
    for (int i = EXP_HEADER_PARAMS; i < SP_COUNT; i++) if (st.w[i] != 0) k++;
    { Experience e = mkExp(st); CHECK(e.save(path)); }
    auto raw = slurp(path);
    size_t n = 3, body = 104 + 16 * n;
    printf("     file %zu bytes, body %zu, footer params %d\n", raw.size(), body, k);
    CHECK(raw.size() == body + (k ? 8 + 20 * (size_t)k : 0));
    { Experience e; CHECK(e.load(path)); Style g; CHECK(e.getStyle(g)); CHECK(same(g, st)); CHECK(g.id() == st.id()); CHECK(e.compatibleWith(st));
      CHECK(!e.isLegacy()); CHECK(e.size() == 3); CHECK(e.badCount(0x1111, 0x0a) == 2); CHECK(e.goodCount(0x2222, 0x0b) == 1); CHECK(e.weight(SP_KING_HUNT) == 77); }
    // all the extra parameters off -> no footer, the file is byte-for-byte the plain v2 file
    { Style off = st; for (int i = EXP_HEADER_PARAMS; i < SP_COUNT; i++) off.w[i] = 0; Experience e = mkExp(off); CHECK(e.save(path + ".off")); CHECK(slurp(path + ".off").size() == body); }
    if (k) {
        // an unknown parameter written by a NEWER version: ignored by getStyle, kept when the file is saved again
        auto b2 = raw; uint32_t cnt = 0; std::memcpy(&cnt, &b2[body + 4], 4); cnt++; std::memcpy(&b2[body + 4], &cnt, 4);
        char nm[16] = {0}; std::strcpy(nm, "future_term"); int32_t v = 5;
        b2.insert(b2.end(), nm, nm + 16); b2.insert(b2.end(), (char*)&v, (char*)&v + 4);
        spit(path + ".new", b2);
        Experience e; CHECK(e.load(path + ".new")); Style g; e.getStyle(g); CHECK(same(g, st));
        CHECK(e.save(path + ".new2")); auto b3 = slurp(path + ".new2"); std::string t(b3.begin(), b3.end()); CHECK(t.find("future_term") != std::string::npos);
        Experience e2; CHECK(e2.load(path + ".new2")); Style g2; e2.getStyle(g2); CHECK(same(g2, st));
        // a damaged footer: the load fails with a clear message (never a silently wrong style)
        auto b4 = raw; b4.resize(b4.size() - 7); spit(path + ".cut", b4);
        Experience c; std::string err; CHECK(!c.load(path + ".cut", &err)); CHECK(err.find("footer") != std::string::npos);
        // garbage after the entries is ignored
        auto b5 = slurp(path + ".off"); const char junk[] = "XXXXXXXXXXXX"; b5.insert(b5.end(), junk, junk + 12); spit(path + ".junk", b5);
        Experience j; CHECK(j.load(path + ".junk")); CHECK(j.size() == 3);
    }
    // merge keeps the footer of the donor when it brings the style
    { Experience a; Experience b = mkExp(st); a.merge(b); Style g; CHECK(a.getStyle(g)); CHECK(same(g, st)); }
    printf(fails ? "FAILED %d\n" : "ALL OK\n", fails);
    return fails;
}
