// Situation memory test.  g++ -O2 -std=c++17 -Isrc tests/situation_test.cpp src/trainer.cpp src/board.cpp src/eval.cpp src/experience.cpp \
//                           src/search.cpp src/tunables.cpp src/embed.cpp -pthread -o situation_test
//  1. save / load keeps the situations (kind 2) and the move logic ignores them
//  2. balance: a good and a bad record on the same position cancel; confidence grows with the count
//  3. Plan D reads the situations: a move into a BAD situation is avoided, a move into a GOOD one is chosen (only with enough situations)
//  4. the trainer's analysis: a checkmate game stores mating-attack situations (good for the winner, bad for the mated side)
//  5. a real short self-play game runs and stores situations without crashing
#include "trainer.h"
#include <cstdio>
#include <string>

using namespace joro;
static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { printf("FAIL: %s\n", msg); fails++; } else printf("ok:   %s\n", msg); } while (0)

static U64 keyAfter(const char* fen, std::initializer_list<const char*> moves) {
    Board b; b.setFen(fen);
    for (auto u : moves) { Move m = b.parseMove(u); if (m == MOVE_NONE || !b.makeLegal(m)) return 0; }
    return b.hash;
}
static SearchResult run(Searcher& s, const char* fen, int depth) {
    Board b; b.setFen(fen);
    s.stopFlag = false;
    Limits l; l.depth = depth;
    return s.go(b, l);
}
static void filler(Experience& e, int n) { for (int i = 0; i < n; i++) e.addSituation(0x7000 + i, SIT_PRESSURE, 40, 1); }

int main() {
    initTables();
    // ---- 1
    {
        Experience e;
        e.add(0x11, 0x0a, EXP_GOOD, 30, 2);
        e.addSituation(0x22, SIT_WEAK_KING, -150, 2);
        e.addSituation(0x33, SIT_SHORT_WIN, 90, 1);
        e.save("/tmp/sit.exp");
        Experience f; std::string err;
        CHECK(f.load("/tmp/sit.exp", &err), "file with situations loads");
        CHECK(f.size() == 3 && f.sitCount() == 2, "3 entries, 2 of them situations");
        CHECK(f.goodCount(0x11, 0x0a) == 2 && f.goodCount(0x22, SIT_WEAK_KING) == 0 && f.badCount(0x22, SIT_WEAK_KING) == 0, "move logic ignores situations");
        CHECK(f.sitScore(0x22) < 0 && f.sitScore(0x33) > 0, "stored sign kept");
        Move c[1] = {0x0a};
        CHECK(f.bestGood(0x11, c, 1) == 0x0a && f.bestGood(0x22, c, 1) == MOVE_NONE, "bestGood unaffected");
    }
    // ---- 2
    {
        Experience e;
        e.addSituation(0x44, SIT_MATE_ATTACK, 120, 3);
        e.addSituation(0x44, SIT_QUEEN_TRADE, -120, 3);
        CHECK(e.sitScore(0x44) == 0, "good and bad of the same weight cancel (balance)");
        Experience g; g.addSituation(0x55, SIT_PRESSURE, 90, 1);
        const int one = g.sitScore(0x55);
        g.addSituation(0x55, SIT_PRESSURE, 90, 2);
        CHECK(g.sitScore(0x55) > one && g.sitScore(0x55) == 90, "confidence grows with the number of times seen");
    }
    // ---- 2b : patterns generalise
    {
        Board a, b2, c; a.setFen(START_FEN); b2.setFen(START_FEN); c.setFen("rnb1kbnr/pppppppp/8/8/8/8/PPPPPPPP/RNB1KBNR w KQkq - 0 1");
        b2.makeLegal(b2.parseMove("g1f3")); b2.makeLegal(b2.parseMove("g8f6")); b2.makeLegal(b2.parseMove("f3g1")); b2.makeLegal(b2.parseMove("f6g8"));
        CHECK(situationSignature(a) == situationSignature(b2), "same features -> same signature (other piece placement is not a different pattern)");
        CHECK(situationSignature(a) != situationSignature(c), "different features (queen missing) -> different signature");
        Experience e;
        for (int i = 0; i < 20; i++) e.addSituation(situationSignature(c), SIT_PATTERN, -30, 1);
        CHECK(e.sitScore(situationSignature(c)) == -30, "a pattern seen often has full weight");
        Experience f; f.addSituation(situationSignature(c), SIT_PATTERN, -30, 1);
        CHECK(f.sitScore(situationSignature(c)) > -5, "a pattern seen once has little weight");
    }
    // ---- 3
    {
        const char* S = START_FEN;
        Experience base; filler(base, 300);
        Searcher s0; s0.setExperience(&base); s0.quiet = true; s0.brain = false; s0.planD = true;
        const std::string usual = Board::moveToStr(run(s0, S, 5).best);
        Experience bad = base;
        bad.addSituation(keyAfter(S, {usual.c_str()}), SIT_QUEEN_TRADE, 300, 3);   // black to move there stands well: bad for us
        Searcher s1; s1.setExperience(&bad); s1.quiet = true; s1.brain = false; s1.planD = true;
        auto r1 = run(s1, S, 5);
        CHECK(Board::moveToStr(r1.best) != usual, "a move into a known BAD situation is avoided");
        Experience good = base;
        good.addSituation(keyAfter(S, {"a2a3"}), SIT_PRESSURE, -300, 3);          // black to move there is in trouble
        Searcher s2; s2.setExperience(&good); s2.quiet = true; s2.brain = false; s2.planD = true; s2.dCap = 400;
        auto r2 = run(s2, S, 3);
        CHECK(Board::moveToStr(r2.best) == "a2a3", "a move into a known GOOD situation is chosen");
        Experience few; filler(few, 10); few.addSituation(keyAfter(S, {usual.c_str()}), SIT_QUEEN_TRADE, 300, 3);
        Searcher s3; s3.setExperience(&few); s3.quiet = true; s3.brain = false; s3.planD = true;
        CHECK(Board::moveToStr(run(s3, S, 5).best) == usual, "too little experience: the situation is not used");
        Searcher s4; s4.setExperience(&bad); s4.quiet = true; s4.brain = false; s4.planD = false;
        CHECK(Board::moveToStr(run(s4, S, 5).best) == usual, "Plan D off: situations are not used");
    }
    // ---- 4 : fool's mate, scripted
    {
        Experience e; TrainConfig cfg; cfg.brain = false;
        Trainer tr(e, cfg);
        GameRecord rec;
        Board b; b.setFen(START_FEN);
        rec.startFen = rec.rootFen = b.fen();
        for (const char* u : {"f2f3", "e7e5", "g2g4", "d8h4"}) {
            Move m = b.parseMove(u);
            rec.keys.push_back(b.hash); rec.moves.push_back(m); rec.movers.push_back(b.side); rec.scores.push_back(NO_SCORE);
            b.makeMove(m);
        }
        const U64 fin = b.hash;
        rec.result = -1; rec.reason = "checkmate";
        int nb = 0, ng = 0, ex = 0;
        tr.learn(rec, nb, ng, ex);
        CHECK(rec.sitNew > 0, "checkmate game: new situations learned");
        CHECK(e.sitScore(fin) < 0, "the mated side to move stands in a bad situation");
        CHECK(e.sitScore(keyAfter(START_FEN, {"f2f3", "e7e5"})) < 0, "the mating attack is stored on the line (earlier position: white to move stands badly)");
    }
    // ---- 5 : real self-play
    {
        Experience e; TrainConfig cfg; cfg.depth = 3; cfg.depthStrong = 3; cfg.maxGames = 4; cfg.maxPlies = 120; cfg.seed = 7; cfg.brain = false;
        Trainer tr(e, cfg);
        std::string err;
        TrainStats st = tr.trainOpening(START_FEN, {"e2e4", "e7e5"}, &err);
        printf("      games %d, entries %zu, situations %zu\n", st.games, e.size(), e.sitCount());
        CHECK(err.empty() && st.games > 0, "self-play runs");
    }
    printf(fails ? "\n%d FAILED\n" : "\nALL OK\n", fails);
    return fails ? 1 : 0;
}
