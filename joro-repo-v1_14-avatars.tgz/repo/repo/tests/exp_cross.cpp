#include "experience.h"
#include <cstdio>
using namespace joro;
int main(int argc, char** argv) {
    std::string mode = argv[1], path = argv[2];
    if (mode == "write") {
        Style s; s.w[SP_OWN_KING] = 123; s.w[SP_KING_HUNT] = 77; s.w[SP_CONTEMPT] = 9;
        Experience e; e.add(0x1111, 0x0a, EXP_BAD, 0, 2); e.add(0x2222, 0x0b, EXP_GOOD, 10, 1); e.addSituation(0x3333, SIT_MATE_ATTACK, 120, 2); e.setStyle(s);
        return e.save(path) ? 0 : 1;
    }
    Experience e; std::string err;
    if (!e.load(path, &err)) { printf("LOAD FAILED: %s\n", err.c_str()); return 2; }
    Style s; e.getStyle(s);
    printf("entries=%zu own=%d hunt=%d contempt=%d bad=%d\n", e.size(), s.w[SP_OWN_KING], s.w[SP_KING_HUNT], s.w[SP_CONTEMPT], e.badCount(0x1111, 0x0a));
    return 0;
}
