cmake_minimum_required(VERSION 3.18)
project(joro_ref CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# JORO sources live in <repo>/src (android/app/src/main/cpp -> 5 levels up)
set(JORO_SRC ${CMAKE_CURRENT_SOURCE_DIR}/../../../../../src)

# The referee: tells the Kotlin match runner whether a game is over (mate, draw, illegal move).
add_library(joro_ref SHARED referee_jni.cpp ${JORO_SRC}/board.cpp)
target_include_directories(joro_ref PRIVATE ${JORO_SRC})
