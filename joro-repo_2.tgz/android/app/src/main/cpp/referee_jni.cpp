#include <jni.h>
#include "referee.h"

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM*, void*) {
    joro::initTables();  // once, before any worker thread builds a Board
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_joro_calibrator_Referee_nativeStatus(JNIEnv* env, jclass, jstring jfen, jstring jmoves) {
    const char* f = env->GetStringUTFChars(jfen, nullptr);
    const char* m = env->GetStringUTFChars(jmoves, nullptr);
    int r = joro::refereeStatus(f ? f : "", m ? m : "");
    env->ReleaseStringUTFChars(jfen, f);
    env->ReleaseStringUTFChars(jmoves, m);
    return r;
}
