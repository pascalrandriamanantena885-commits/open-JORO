package com.joro.calibrator

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale

data class ExpInfo(val version: Int, val entries: Long, val hasStyle: Boolean, val styleId: String, val styleName: String) {
    fun describe(): String =
        "$entries entries" + if (hasStyle) " | style $styleName ($styleId)" else " | no style"
}

/** Files of the app: engines, experience, history. Everything stays on the phone. */
class Storage(private val ctx: Context) {
    private val nativeDir: String get() = ctx.applicationInfo.nativeLibraryDir
    val bundledJoro: File get() = File(nativeDir, "libjoro.so")
    val stockfish: File get() = File(nativeDir, "libstockfish.so")
    val importedJoro: File get() = File(ctx.filesDir, "engines/joro_imported")
    val expFile: File get() = File(ctx.filesDir, "experience/joro.exp")
    private val historyFile: File get() = File(ctx.filesDir, "history.json")

    /** The imported (updated) engine wins over the one bundled in the APK. */
    fun joroFile(): File = if (importedJoro.exists()) importedJoro else bundledJoro
    fun joroSource(): String = if (importedJoro.exists()) "imported" else "bundled"

    // ------------------------------------------------------------------ experience
    fun readExpInfo(f: File): ExpInfo? {
        if (!f.exists() || f.length() < 104) return null
        return try {
            val raw = ByteArray(104)
            DataInputStream(f.inputStream()).use { it.readFully(raw) }
            val b = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
            if (raw[0] != 'J'.code.toByte() || raw[1] != 'E'.code.toByte() || raw[2] != 'X'.code.toByte() || raw[3] != 'P'.code.toByte()) return null
            val version = b.getInt(4)
            val n = b.getInt(8).toLong() and 0xFFFFFFFFL
            val flags = b.getInt(12)
            val sid = b.getLong(16)
            var end = 24
            while (end < 40 && raw[end].toInt() != 0) end++
            val name = String(raw, 24, end - 24, Charsets.US_ASCII)
            if (version != 2 || f.length() != 104 + n * 16) return null
            ExpInfo(version, n, (flags and 1) != 0, String.format(Locale.US, "%016x", sid), name)
        } catch (e: Exception) {
            null
        }
    }

    fun currentExpInfo(): ExpInfo? = readExpInfo(expFile)

    fun importExperience(uri: Uri): Result<ExpInfo> = runCatching {
        val tmp = File(ctx.cacheDir, "import.exp")
        ctx.contentResolver.openInputStream(uri)!!.use { input -> tmp.outputStream().use { input.copyTo(it) } }
        val info = readExpInfo(tmp) ?: run {
            tmp.delete()
            error("Tsy experience JORO mety ity fichier ity (header JEXP v2 / habe tsy mety)")
        }
        expFile.parentFile!!.mkdirs()
        tmp.copyTo(expFile, overwrite = true)
        tmp.delete()
        info
    }

    fun deleteExperience() { expFile.delete() }

    // ------------------------------------------------------------------ engine
    /** Imports a new JORO executable (arm64, built by build_engines_android.sh / the GitHub workflow). */
    fun importEngine(uri: Uri): Result<String> = runCatching {
        val tmp = File(ctx.filesDir, "engines/joro_new")
        tmp.parentFile!!.mkdirs()
        ctx.contentResolver.openInputStream(uri)!!.use { input -> tmp.outputStream().use { input.copyTo(it) } }
        tmp.setExecutable(true, false)
        tmp.setReadable(true, false)
        val e = UciEngine(tmp.absolutePath, "probe")
        if (!e.start()) {
            tmp.delete()
            error("Tsy mety hampandeha ny fichier (tsy executable arm64, na voasakana ny Android ny fampiasana azy avy ao anaty tahiry app).")
        }
        val ok = e.handshake()
        val name = e.idName
        e.quit()
        if (!ok || !name.startsWith("JORO")) {
            tmp.delete()
            error("Tsy mamaly UCI toa JORO ilay fichier.")
        }
        importedJoro.delete()
        if (!tmp.renameTo(importedJoro)) { tmp.copyTo(importedJoro, overwrite = true); tmp.delete() }
        importedJoro.setExecutable(true, false)
        name
    }

    fun removeImportedEngine() { importedJoro.delete() }

    // ------------------------------------------------------------------ history
    fun loadHistory(): List<Summary> {
        return try {
            if (!historyFile.exists()) return emptyList()
            val arr = JSONArray(historyFile.readText())
            (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addHistory(sm: Summary) {
        val all = loadHistory() + sm
        val arr = JSONArray()
        all.takeLast(200).forEach { arr.put(toJson(it)) }
        historyFile.writeText(arr.toString())
    }

    fun clearHistory() { historyFile.delete() }

    private fun toJson(s: Summary): JSONObject {
        val o = JSONObject()
        o.put("t", s.timestamp); o.put("engine", s.engineName); o.put("exp", s.experience); o.put("tc", s.tcText)
        o.put("overall", s.overall ?: JSONObject.NULL); o.put("ob", s.overallBound.name); o.put("partial", s.partial)
        val a = JSONArray()
        for (r in s.levels) {
            val j = JSONObject()
            j.put("elo", r.elo); j.put("w", r.w); j.put("d", r.d); j.put("l", r.l)
            j.put("score", r.score); j.put("est", r.estimate); j.put("hw", r.halfWidth); j.put("b", r.bound.name)
            a.put(j)
        }
        o.put("levels", a)
        return o
    }

    private fun fromJson(o: JSONObject): Summary {
        val a = o.getJSONArray("levels")
        val levels = (0 until a.length()).map {
            val j = a.getJSONObject(it)
            LevelResult(j.getInt("elo"), j.getInt("w"), j.getInt("d"), j.getInt("l"), j.getDouble("score"),
                j.getDouble("est"), j.getDouble("hw"), Bound.valueOf(j.getString("b")))
        }
        return Summary(o.getLong("t"), o.getString("engine"), o.getString("exp"), o.getString("tc"), levels,
            if (o.isNull("overall")) null else o.getDouble("overall"), Bound.valueOf(o.getString("ob")), o.getBoolean("partial"))
    }
}
