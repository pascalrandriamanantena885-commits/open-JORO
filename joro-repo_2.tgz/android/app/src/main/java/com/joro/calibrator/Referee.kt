package com.joro.calibrator

/** Native judge (same board code as the engine). */
object Referee {
    const val ONGOING = 0
    const val WHITE_MATES = 1
    const val BLACK_MATES = 2
    const val ILLEGAL = 9

    init { System.loadLibrary("joro_ref") }

    @JvmStatic
    external fun nativeStatus(fen: String, moves: String): Int
}
