package com.joro.calibrator

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp

// Explicit high-contrast palettes (text/background >= 12:1). We do not rely on the device's automatic
// "force dark", which could turn dark text into dark-on-dark and make it vanish.
private val Dark = darkColorScheme(
    primary = Color(0xFF8AB4FF), onPrimary = Color(0xFF00132E),
    background = Color(0xFF0F1115), onBackground = Color(0xFFF2F4F8),
    surface = Color(0xFF0F1115), onSurface = Color(0xFFF2F4F8),
    surfaceVariant = Color(0xFF1E2330), onSurfaceVariant = Color(0xFFE3E7EF),
    surfaceContainerHighest = Color(0xFF1E2330),
    outline = Color(0xFF9AA3B8), outlineVariant = Color(0xFF3A4156),
    error = Color(0xFFFF8A80), onError = Color(0xFF330000),
    secondaryContainer = Color(0xFF2A3A5C), onSecondaryContainer = Color(0xFFF2F4F8)
)

private val Light = lightColorScheme(
    primary = Color(0xFF0B57D0), onPrimary = Color(0xFFFFFFFF),
    background = Color(0xFFFFFFFF), onBackground = Color(0xFF111318),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF111318),
    surfaceVariant = Color(0xFFEEF1F6), onSurfaceVariant = Color(0xFF1B1F27),
    surfaceContainerHighest = Color(0xFFEEF1F6),
    outline = Color(0xFF5B6270), outlineVariant = Color(0xFFC4CAD6),
    error = Color(0xFFB3261E), onError = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD9E5FF), onSecondaryContainer = Color(0xFF111318)
)

// slightly larger and heavier base text for readability
private val Type = Typography(
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 21.sp),
    labelLarge = TextStyle(fontSize = 15.sp, lineHeight = 20.sp)
)

@Composable
fun JoroTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        typography = Type,
        content = content
    )
}
