package com.joro.calibrator

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Matrix calibration: JORO vs Stockfish (UCI_LimitStrength + UCI_Elo) for several levels at once.
 * Games of all levels are interleaved in one queue and played by [CalibConfig.concurrency] workers,
 * so every level progresses evenly and the total time stays short.
 */
class MatchRunner(
    private val joroPath: String,
    private val sfPath: String,
    private val expPath: String?,
    private val cfg: CalibConfig,
    private val openings: List<String>,
    private val onStats: (Map<Int, LevelStats>) -> Unit,
    private val onLog: (String) -> Unit
) {
    private class Task(val level: Int, val game: Int)

    private val lock = Any()
    private val stats = LinkedHashMap<Int, LevelStats>()
    @Volatile var joroName: String = ""
        private set
    @Volatile var sfName: String = ""
        private set

    init {
        for (lv in cfg.levels) stats[lv] = LevelStats(lv, cfg.gamesPerLevel)
    }

    suspend fun run() = coroutineScope {
        val queue = ConcurrentLinkedQueue<Task>()
        for (g in 0 until cfg.gamesPerLevel) for (lv in cfg.levels) queue.add(Task(lv, g))   // interleaved levels
        val jobs = List(cfg.concurrency) { idx -> launch(Dispatchers.IO) { worker(idx, queue) } }
        jobs.joinAll()
    }

    private suspend fun worker(idx: Int, queue: ConcurrentLinkedQueue<Task>) {
        val job = currentCoroutineContext()[Job]
        val cancelled: () -> Boolean = { job?.isActive == false }
        val joro = UciEngine(joroPath, "joro$idx")
        val sf = UciEngine(sfPath, "sf$idx")
        try {
            if (!joro.start()) { onLog("JORO tsy afaka nandeha: $joroPath"); return }
            if (!sf.start()) { onLog("Stockfish tsy afaka nandeha: $sfPath"); return }
            if (!joro.handshake()) { onLog("JORO tsy mamaly UCI"); return }
            if (!sf.handshake()) { onLog("Stockfish tsy mamaly UCI"); return }
            joroName = joro.idName
            sfName = sf.idName
            joro.setOption("Hash", cfg.hashMb.toString())
            joro.setOption("MoveOverhead", "50")
            if (expPath != null && cfg.useExperience) {
                joro.setOption("ExperienceFile", expPath)
                joro.setOption("UseExperience", "true")
            } else {
                joro.setOption("UseExperience", "false")
            }
            sf.setOption("Threads", "1")
            sf.setOption("Hash", cfg.hashMb.toString())
            sf.setOption("UCI_LimitStrength", "true")
            while (true) {
                currentCoroutineContext().ensureActive()
                val t = queue.poll() ?: break
                val r = playGame(joro, sf, t, cancelled) ?: continue
                record(t.level, r)
            }
        } finally {
            joro.quit()
            sf.quit()
        }
    }

    private fun record(level: Int, r: Int) {
        val snapshot: Map<Int, LevelStats>
        synchronized(lock) {
            val s = stats[level]!!
            stats[level] = when {
                r > 0 -> s.copy(w = s.w + 1)
                r < 0 -> s.copy(l = s.l + 1)
                else -> s.copy(d = s.d + 1)
            }
            snapshot = LinkedHashMap(stats)
        }
        onStats(snapshot)
    }

    /** Result from JORO's point of view: +1 win, 0 draw, -1 loss; null = cancelled. */
    private fun playGame(joro: UciEngine, sf: UciEngine, t: Task, cancelled: () -> Boolean): Int? {
        sf.setOption("UCI_Elo", t.level.toString())
        joro.send("ucinewgame")
        sf.send("ucinewgame")
        if (!joro.isReady(8000, cancelled) || !sf.isReady(8000, cancelled)) return if (cancelled()) null else {
            onLog("Engine tsy mamaly isready"); 0
        }
        val fen = openings[(t.game / 2) % openings.size] + " 0 1"   // both colours play the same opening
        val joroWhite = t.game % 2 == 0
        val startSide = if (fen.split(" ")[1] == "w") 0 else 1
        val moves = ArrayList<String>()
        val remaining = longArrayOf(cfg.baseMs, cfg.baseMs)
        var streak = 0
        var streakSign = 0

        while (true) {
            if (cancelled()) return null
            val status = Referee.nativeStatus(fen, moves.joinToString(" "))
            if (status != Referee.ONGOING) {
                val whiteWon: Boolean? = when (status) {
                    Referee.WHITE_MATES -> true
                    Referee.BLACK_MATES -> false
                    Referee.ILLEGAL -> ((startSide + moves.size - 1) % 2 == 1)   // last mover made an illegal move
                    else -> null                                                  // draw
                }
                if (status == Referee.ILLEGAL) onLog("Move tsy ara-dalàna: ${moves.lastOrNull()}")
                return outcome(whiteWon, joroWhite)
            }
            if (moves.size >= 300) return 0

            val stm = (startSide + moves.size) % 2                 // 0 = white to move
            val jMoves = (stm == 0) == joroWhite
            val engine = if (jMoves) joro else sf
            val posCmd = if (moves.isEmpty()) "position fen $fen" else "position fen $fen moves ${moves.joinToString(" ")}"
            engine.send(posCmd)
            val t0 = System.nanoTime()
            engine.send("go wtime ${remaining[0]} btime ${remaining[1]} winc ${cfg.incMs} binc ${cfg.incMs}")
            var lastScore: Int? = null
            val bm = engine.readUntil("bestmove", remaining[stm] + 2000, cancelled) { l ->
                val sc = parseScore(l)
                if (sc != null) lastScore = sc
            }
            val spent = (System.nanoTime() - t0) / 1_000_000L
            if (cancelled()) return null
            if (bm == null) {                       // crash or hard timeout => that side loses
                engine.send("stop")
                engine.isReady(3000, cancelled)     // swallows a late "bestmove" before the next game
                onLog((if (jMoves) "JORO" else "Stockfish") + " tsy namaly (crash/timeout)")
                return if (jMoves) -1 else 1
            }
            if (spent > remaining[stm] + 150) {     // flag fell
                return if (jMoves) -1 else 1
            }
            remaining[stm] = remaining[stm] - spent + cfg.incMs
            val parts = bm.split(" ")
            val mv = if (parts.size > 1) parts[1] else "0000"
            if (mv == "0000" || mv == "(none)") return if (jMoves) -1 else 1
            moves.add(mv)

            // adjudication: both engines see >= 9 pawns for the same side during 8 consecutive plies
            val sc = lastScore
            if (sc != null) {
                val w = if (stm == 0) sc else -sc
                if (Math.abs(w) >= 900) {
                    val sg = if (w > 0) 1 else -1
                    streak = if (sg == streakSign) streak + 1 else 1
                    streakSign = sg
                } else { streak = 0; streakSign = 0 }
                if (streak >= 8) return outcome(streakSign > 0, joroWhite)
            }
        }
    }

    private fun outcome(whiteWon: Boolean?, joroWhite: Boolean): Int = when (whiteWon) {
        null -> 0
        else -> if (whiteWon == joroWhite) 1 else -1
    }

    private fun parseScore(line: String): Int? {
        if (!line.startsWith("info") || line.contains("bound")) return null
        val p = line.split(" ")
        val i = p.indexOf("score")
        if (i < 0 || i + 2 >= p.size) return null
        val v = p[i + 2].toIntOrNull() ?: return null
        return when (p[i + 1]) {
            "cp" -> v
            "mate" -> if (v > 0) 30000 else -30000
            else -> null
        }
    }
}
