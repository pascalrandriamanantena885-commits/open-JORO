package com.joro.calibrator

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val running: Boolean = false,
    val stats: Map<Int, LevelStats> = emptyMap(),
    val summary: Summary? = null,
    val log: List<String> = emptyList(),
    val joroInfo: String = "",
    val expInfo: String = "",
    val importMessage: String = "",
    val history: List<Summary> = emptyList(),
    val message: String = ""
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val storage = Storage(app)

    // ---- inputs (kept here so they survive tab switches and rotation)
    var levelsText by mutableStateOf("2500, 2600, 2700, 3000")
    var gamesText by mutableStateOf("20")
    var baseSecText by mutableStateOf("10")
    var incMsText by mutableStateOf("100")
    var concurrencyText by mutableStateOf(defaultConcurrency().toString())
    var hashText by mutableStateOf("16")
    var useExperience by mutableStateOf(true)

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui

    init {
        CalibrationController.recoverIfNeeded(app)   // a run cut short by Android is kept as a partial result
        _ui.update { it.copy(history = storage.loadHistory().reversed()) }
        refreshInfo()
        // The run lives in CalibrationController (process + foreground service), not here: the UI only observes it.
        viewModelScope.launch {
            CalibrationController.state.collect { rs ->
                _ui.update { it.copy(running = rs.running, stats = rs.stats, summary = rs.summary, log = rs.log, message = rs.message) }
                if (!rs.running) _ui.update { it.copy(history = storage.loadHistory().reversed()) }
            }
        }
    }

    private fun defaultConcurrency(): Int = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(1, 4)

    // ------------------------------------------------------------------ info
    fun refreshInfo() {
        viewModelScope.launch {
            val joroText = withContext(Dispatchers.IO) {
                val f = storage.joroFile()
                if (!f.exists()) return@withContext "JORO: tsy hita (${f.name})"
                val e = UciEngine(f.absolutePath, "info")
                val name = if (e.start() && e.handshake()) e.idName else "tsy mandeha"
                e.quit()
                "JORO (${storage.joroSource()}): $name"
            }
            val exp = storage.currentExpInfo()
            _ui.update { it.copy(joroInfo = joroText, expInfo = exp?.describe() ?: "tsy misy experience") }
        }
    }

    // ------------------------------------------------------------------ calibration
    fun parseLevels(text: String): List<Int> =
        text.split(',', ' ', ';', '/').mapNotNull { it.trim().toIntOrNull() }
            .map { it.coerceIn(1320, 3190) }   // range accepted by Stockfish UCI_Elo
            .distinct().sorted()

    fun start() {
        if (_ui.value.running) return
        val levels = parseLevels(levelsText)
        if (levels.isEmpty()) { msg("Ampidiro level iray farafahakeliny (ohatra 2500, 2600)"); return }
        var games = (gamesText.toIntOrNull() ?: 20).coerceIn(2, 400)
        if (games % 2 == 1) games++
        val cfg = CalibConfig(
            levels = levels,
            gamesPerLevel = games,
            baseMs = ((baseSecText.toDoubleOrNull() ?: 10.0) * 1000).toLong().coerceIn(500, 3_600_000),
            incMs = (incMsText.toLongOrNull() ?: 100L).coerceIn(0, 60_000),
            concurrency = (concurrencyText.toIntOrNull() ?: 1).coerceIn(1, 8),
            hashMb = (hashText.toIntOrNull() ?: 16).coerceIn(1, 256),
            useExperience = useExperience
        )
        val err = CalibrationController.start(getApplication(), cfg)
        if (err != null) msg(err)
    }

    fun stop() { CalibrationController.stop() }

    private fun msg(m: String) { _ui.update { it.copy(message = m) } }

    // ------------------------------------------------------------------ import / update
    fun importExperience(uri: Uri) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { storage.importExperience(uri) }
            val text = r.fold({ "Experience vaovao nampidirina: ${it.describe()}" }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(importMessage = text) }
            refreshInfo()
        }
    }

    fun deleteExperience() {
        storage.deleteExperience()
        _ui.update { it.copy(importMessage = "Experience nofafana.") }
        refreshInfo()
    }

    fun importEngine(uri: Uri) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { storage.importEngine(uri) }
            val text = r.fold({ "Moteur vaovao nampidirina: $it" }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(importMessage = text) }
            refreshInfo()
        }
    }

    fun removeImportedEngine() {
        storage.removeImportedEngine()
        _ui.update { it.copy(importMessage = "Miverina amin'ny moteur ao anaty APK.") }
        refreshInfo()
    }

    fun clearHistory() {
        storage.clearHistory()
        _ui.update { it.copy(history = emptyList()) }
    }
}
