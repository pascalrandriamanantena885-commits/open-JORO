# JORO Calibrator (Android, offline)

Kotlin + Jetpack Compose app. Runs **JORO vs Stockfish (UCI_LimitStrength + UCI_Elo)** on the phone, for several
levels at once ("matrix"), and shows a summary with the estimated Elo of JORO. No INTERNET permission.

## How it works
* JORO and Stockfish are UCI **executables** (`libjoro.so`, `libstockfish.so` in `jniLibs/arm64-v8a`), started as child processes.
* `MatchRunner` plays games between them (clocks, adjudication, 24 openings from `assets/openings.epd`, both colours).
* `Referee` (JNI, same board code as the engine) decides mate / stalemate / draw / illegal move.
* Matrix mode: games of all levels (e.g. 2500, 2600, 2700, 3000) are interleaved in one queue and played by N workers at once.
* `Elo.kt`: score -> Elo difference, 95% interval, inverse-variance weighted overall estimate. A level where JORO scores
  0% or 100% only gives a bound (shown as <= or >=): use levels close to JORO's strength to get a real number.
* Tab **Import**: new `joro.exp` (validated: header, version, size, style id) and new JORO engine binary (arm64, UCI
  handshake tested before it is accepted). Each calibration is saved in **Tantara** with the engine name/experience.

## Build
GitHub: run workflow `build_apk` -> artifacts `joro-calibrator-apk` (install it), `joro-engine-arm64` (file for "Import moteur").
Local: `ANDROID_NDK_HOME=... android/tools/build_engines_android.sh` then open `android/` in Android Studio.
Only arm64-v8a phones are supported (emulators x86 are not).

## Notes / limits
* `targetSdk = 28` on purpose: Android 10+ blocks executing binaries from an app's own data folder for apps
  targeting 29+, and that is what "Import moteur" needs. Fine for a side-loaded tool, not for Google Play.
* Stockfish is GPLv3: if you share the APK, share the sources too (the JORO sources are in this repo).
* Stockfish's UCI_Elo scale is calibrated for another time control/hardware: compare JORO versions with each other.
* The phone throttles when hot: keep concurrency <= cores/2, same settings between runs.

## Runs in the background
The run is owned by `CalibrationController` (process level), not by the screen. Starting a calibration also starts
`CalibrationService` (foreground service + partial wake lock + notification with progress and an "Atsaha" button).
So the calibration keeps going when the screen is off, when you leave the app, and when you swipe it away from the
recents. The result is saved in "Tantara" and announced by a notification when it ends. Reopen the app at any time: it
shows the live progress.
* Stops only if you press "Atsaha", use "Force stop" in Android settings, or the system kills the process. In that case
  the games already played are kept as a partial result at the next launch (marked `[tapaka]`).
* Some brands (Xiaomi, Huawei, Samsung "sleeping apps", ...) kill background apps aggressively: use the
  "Battery: avelao hiasa foana ny app" button and allow auto-start / no restrictions for the app.
* It does not restart by itself after a reboot.
