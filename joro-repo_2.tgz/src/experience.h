// JORO - experience.h : the patchable "experience" file (joro.exp)
//
// File layout (little endian), version 2:
//   header 104 bytes : magic "JEXP" | u32 version(=2) | u32 nEntries | u32 flags (bit0 = has style)
//                      | u64 styleId | char styleName[16] | i32 style[16] (weights, see StyleParam)
//   entries (16 bytes each) : u64 key | u32 move | i16 value | u8 kind (0 good, 1 bad) | u8 count
// The experience belongs to the style that produced it (styleId = hash of the weights).
#pragma once
#include "eval.h"
#include <string>
#include <unordered_map>
#include <vector>

namespace joro {

enum ExpKind : uint8_t { EXP_GOOD = 0, EXP_BAD = 1 };

struct ExpEntry {
    U64 key;
    uint32_t move;
    int16_t value;
    uint8_t kind;
    uint8_t count;
};
static_assert(sizeof(ExpEntry) == 16, "ExpEntry must be 16 bytes");

class Experience {
public:
    bool load(const std::string& path, std::string* err = nullptr);
    bool save(const std::string& path) const;

    // record a move for a position key. inc = how many times it was seen
    void add(U64 key, Move m, int kind, int value = 0, int inc = 1);
    int goodCount(U64 key, Move m) const;
    int badCount(U64 key, Move m) const;
    bool isBad(U64 key, Move m) const { return badCount(key, m) > goodCount(key, m); }
    // best "good" move among candidates (net count > 0); returns MOVE_NONE if none
    Move bestGood(U64 key, const Move* cands, int n, int* value = nullptr) const;

    void merge(const Experience& o);
    void clear();
    size_t size() const { return total; }

    void setStyle(const Style& s);
    bool getStyle(Style& s) const;
    bool hasStyle() const { return styleSet; }
    uint64_t styleId() const { return styleIdv; }

private:
    std::unordered_map<U64, std::vector<ExpEntry>> map;
    size_t total = 0;
    bool styleSet = false;
    int32_t st[16] = {0};
    uint64_t styleIdv = 0;
    char styleName[16] = {0};
};

} // namespace joro
