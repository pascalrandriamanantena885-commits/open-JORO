// JORO - search.cpp
#include "search.h"
#include <algorithm>
#include <cstdio>
#include <cstring>

namespace joro {

enum { B_UPPER = 1, B_LOWER = 2, B_EXACT = 3 };

static inline int toTT(int s, int ply) { return s >= MATE_BOUND ? s + ply : (s <= -MATE_BOUND ? s - ply : s); }
static inline int fromTT(int s, int ply) { return s >= MATE_BOUND ? s - ply : (s <= -MATE_BOUND ? s + ply : s); }

Searcher::Searcher() : stopFlag(false) {
    initTables();
    setHash(16);
    clear();
}

void Searcher::setHash(int mb) {
    size_t n = 1;
    size_t want = (size_t)std::max(1, mb) * 1024 * 1024 / sizeof(TTEntry);
    while (n * 2 <= want) n *= 2;
    tt.assign(n, TTEntry{0, 0, 0, 0, 0});
    ttMask = n - 1;
}

void Searcher::clear() {
    std::fill(tt.begin(), tt.end(), TTEntry{0, 0, 0, 0, 0});
    std::memset(killers, 0, sizeof killers);
    std::memset(history, 0, sizeof history);
}

int64_t Searcher::elapsedMs() const {
    return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count();
}

void Searcher::checkTime() {
    if (!canStop) return;
    if (stopFlag.load() || (hardMs && elapsedMs() >= hardMs) || (lim.nodes && nodes >= lim.nodes)) halt = true;
}

bool Searcher::hasNonPawn(int c) const {
    for (int s = 0; s < 64; s++) {
        int p = b->sq[s];
        if (p && colorOf(p) == c && typeOf(p) > PAWN && typeOf(p) < KING) return true;
    }
    return false;
}

int Searcher::scoreMove(Move m, Move ttMove, int ply) const {
    if (m == ttMove) return 1000000;
    int victim = b->sq[mTo(m)];
    int att = typeOf(b->sq[mFrom(m)]);
    if (victim || mFlag(m) == F_EP) {
        int v = victim ? typeOf(victim) : PAWN;
        return 100000 + v * 100 - att + (mPromo(m) ? 50 : 0);
    }
    if (mPromo(m)) return 95000 + mPromo(m);
    if (m == killers[ply][0]) return 90000;
    if (m == killers[ply][1]) return 89000;
    return history[b->side][mFrom(m)][mTo(m)];
}

int Searcher::qsearch(int alpha, int beta, int ply) {
    pvLen[ply] = ply;
    if ((++nodes & 1023) == 0) checkTime();
    if (halt) return 0;
    if (ply >= MAXPLY - 1) return evaluate(*b, style);
    int stand = evaluate(*b, style);
    if (stand >= beta) return stand;
    if (stand > alpha) alpha = stand;
    Move mv[256];
    int sc[256];
    int n = b->genMoves(mv, true);
    for (int i = 0; i < n; i++) sc[i] = scoreMove(mv[i], MOVE_NONE, ply);
    for (int i = 0; i < n; i++) {
        int bi = i;
        for (int j = i + 1; j < n; j++) if (sc[j] > sc[bi]) bi = j;
        std::swap(sc[i], sc[bi]);
        std::swap(mv[i], mv[bi]);
        Move m = mv[i];
        int victim = b->sq[mTo(m)];
        int gain = victim ? PIECE_VAL[typeOf(victim)] : 100;
        if (!mPromo(m) && stand + gain + 200 < alpha) continue;  // delta pruning
        if (!b->makeLegal(m)) continue;
        int score = -qsearch(-beta, -alpha, ply + 1);
        b->unmakeMove();
        if (halt) return 0;
        if (score > alpha) {
            alpha = score;
            if (score >= beta) return score;
        }
    }
    return alpha;
}

int Searcher::search(int depth, int alpha, int beta, int ply, bool nullOk) {
    pvLen[ply] = ply;
    if ((++nodes & 1023) == 0) checkTime();
    if (halt) return 0;
    const bool root = ply == 0, pvNode = beta - alpha > 1;
    if (!root) {
        if (b->isDraw()) return drawScore(ply);
        if (ply >= MAXPLY - 1) return evaluate(*b, style);
        alpha = std::max(alpha, -MATE + ply);
        beta = std::min(beta, MATE - ply - 1);
        if (alpha >= beta) return alpha;
    }
    const bool inChk = b->inCheck();
    if (inChk) depth++;
    if (depth <= 0) return qsearch(alpha, beta, ply);

    TTEntry* e = &tt[b->hash & ttMask];
    Move ttMove = MOVE_NONE;
    if (e->key == b->hash) {
        ttMove = e->move;
        if (!pvNode && e->depth >= depth) {
            int s = fromTT(e->score, ply);
            if (e->bound == B_EXACT || (e->bound == B_LOWER && s >= beta) || (e->bound == B_UPPER && s <= alpha))
                return s;
        }
    }
    int staticEval = inChk ? -INF_SCORE : evaluate(*b, style);
    if (!pvNode && !inChk && std::abs(beta) < MATE_BOUND) {
        if (depth <= 3 && staticEval - 120 * depth >= beta) return staticEval;  // reverse futility
        if (nullOk && depth >= 3 && staticEval >= beta && hasNonPawn(b->side)) {
            int R = 2 + depth / 6;
            b->makeNull();
            int s = -search(depth - 1 - R, -beta, -beta + 1, ply + 1, false);
            b->unmakeNull();
            if (halt) return 0;
            if (s >= beta) return s >= MATE_BOUND ? beta : s;
        }
    }

    Move mv[256];
    int sc[256];
    int n = b->genMoves(mv, false);
    if (root) {  // keep only allowed root moves (experience may have removed known-bad ones)
        int k = 0;
        for (int i = 0; i < n; i++)
            if (std::find(rootMoves.begin(), rootMoves.end(), mv[i]) != rootMoves.end()) mv[k++] = mv[i];
        n = k;
    }
    for (int i = 0; i < n; i++) sc[i] = scoreMove(mv[i], ttMove, ply);

    int legal = 0, bestScore = -INF_SCORE;
    Move best = MOVE_NONE;
    const int alpha0 = alpha;
    for (int i = 0; i < n; i++) {
        int bi = i;
        for (int j = i + 1; j < n; j++) if (sc[j] > sc[bi]) bi = j;
        std::swap(sc[i], sc[bi]);
        std::swap(mv[i], mv[bi]);
        Move m = mv[i];
        bool isCap = b->sq[mTo(m)] || mFlag(m) == F_EP;
        bool quietMove = !isCap && !mPromo(m);
        int mover = b->side;
        if (!b->makeLegal(m)) continue;
        legal++;
        bool givesCheck = b->inCheck();
        int newDepth = depth - 1, red = 0;
        if (depth >= 3 && legal > 3 && quietMove && !inChk && !givesCheck) {
            red = 1 + (legal > 8) + (depth > 6);
            if (pvNode) red--;
            if (red < 0) red = 0;
        }
        int score;
        if (legal == 1) {
            score = -search(newDepth, -beta, -alpha, ply + 1, true);
        } else {
            score = -search(newDepth - red, -alpha - 1, -alpha, ply + 1, true);
            if (score > alpha && red > 0) score = -search(newDepth, -alpha - 1, -alpha, ply + 1, true);
            if (score > alpha && score < beta) score = -search(newDepth, -beta, -alpha, ply + 1, true);
        }
        b->unmakeMove();
        if (halt) return 0;
        if (score > bestScore) {
            bestScore = score;
            best = m;
            if (score > alpha) {
                alpha = score;
                pv[ply][ply] = m;
                for (int k = ply + 1; k < pvLen[ply + 1]; k++) pv[ply][k] = pv[ply + 1][k];
                pvLen[ply] = pvLen[ply + 1];
                if (score >= beta) {
                    if (quietMove) {
                        if (killers[ply][0] != m) { killers[ply][1] = killers[ply][0]; killers[ply][0] = m; }
                        int& h = history[mover][mFrom(m)][mTo(m)];
                        h = std::min(h + depth * depth, 80000);
                    }
                    break;
                }
            }
        }
    }
    if (legal == 0) return inChk ? -MATE + ply : drawScore(ply);
    uint8_t bound = bestScore >= beta ? B_LOWER : (bestScore > alpha0 ? B_EXACT : B_UPPER);
    if (e->key != b->hash || e->depth <= depth || bound == B_EXACT) {
        e->key = b->hash;
        e->move = best;
        e->score = (int16_t)toTT(bestScore, ply);
        e->depth = (int8_t)std::min(depth, 127);
        e->bound = bound;
    }
    return bestScore;
}

SearchResult Searcher::go(Board& board, const Limits& limits) {
    b = &board;
    lim = limits;
    nodes = 0;
    halt = false;
    canStop = false;
    t0 = std::chrono::steady_clock::now();
    SearchResult res;

    Move legalMoves[256];
    int nl = b->genLegal(legalMoves);
    if (nl == 0) return res;
    const U64 key = b->hash;
    rootMoves.assign(legalMoves, legalMoves + nl);

    // ---- experience at the root: drop known-bad moves, play known-good ones
    bool expOK = exp && useExperience;
    if (expOK && strictStyle && exp->hasStyle() && exp->styleId() != style.id()) {
        if (!quiet && !warnedStyle) {
            printf("info string experience IGNORED: made with another style (%016llx != %016llx)\n",
                   (unsigned long long)exp->styleId(), (unsigned long long)style.id());
            warnedStyle = true;
        }
        expOK = false;
    }
    if (expOK) {
        std::vector<Move> filtered;
        for (int i = 0; i < nl; i++)
            if (!exp->isBad(key, legalMoves[i])) filtered.push_back(legalMoves[i]);
        if (!filtered.empty() && filtered.size() < rootMoves.size()) {
            if (!quiet) printf("info string experience: %d bad move(s) excluded\n", (int)(rootMoves.size() - filtered.size()));
            rootMoves = filtered;
        }
        int val = 0;
        Move g = exp->bestGood(key, rootMoves.data(), (int)rootMoves.size(), &val);
        if (g != MOVE_NONE) {
            res.best = g;
            res.score = val;
            res.fromExperience = true;
            if (!quiet) {
                printf("info string experience move %s\n", Board::moveToStr(g).c_str());
                fflush(stdout);
            }
            return res;
        }
    }
    if (rootMoves.size() == 1) {
        res.best = rootMoves[0];
        return res;
    }

    // ---- time management
    int maxDepth = MAXPLY - 2;
    softMs = hardMs = 0;
    if (lim.depth > 0) maxDepth = std::min(lim.depth, MAXPLY - 2);
    if (lim.movetime > 0) {
        hardMs = softMs = std::max<int64_t>(1, lim.movetime - moveOverhead);
    } else if (lim.time[b->side] > 0 && !lim.infinite) {
        int64_t t = lim.time[b->side], inc = lim.inc[b->side];
        int mtg = lim.movestogo > 0 ? std::min(lim.movestogo, 50) : 30;
        int64_t alloc = t / mtg + inc * 3 / 4;
        softMs = std::max<int64_t>(1, std::min(alloc, t * 4 / 10) - moveOverhead);
        hardMs = std::max<int64_t>(1, std::min(alloc * 3, t * 6 / 10) - moveOverhead);
    }

    std::memset(killers, 0, sizeof killers);
    for (int d = 1; d <= maxDepth; d++) {
        canStop = d > 1;
        int score = search(d, -INF_SCORE, INF_SCORE, 0, true);
        if (halt && d > 1) break;
        if (pvLen[0] > 0 && pv[0][0] != MOVE_NONE) {
            res.best = pv[0][0];
            res.ponder = pvLen[0] > 1 ? pv[0][1] : MOVE_NONE;
            res.score = score;
            res.depth = d;
        }
        if (!quiet) {
            int64_t ms = elapsedMs();
            printf("info depth %d score ", d);
            if (std::abs(score) >= MATE_BOUND) printf("mate %d", score > 0 ? (MATE - score + 1) / 2 : -((MATE + score) / 2));
            else printf("cp %d", score);
            printf(" nodes %lld nps %lld time %lld pv", (long long)nodes, (long long)(ms ? nodes * 1000 / ms : nodes), (long long)ms);
            for (int k = 0; k < pvLen[0]; k++) printf(" %s", Board::moveToStr(pv[0][k]).c_str());
            printf("\n");
            fflush(stdout);
        }
        if (softMs && elapsedMs() > softMs * 6 / 10) break;
        if (std::abs(score) >= MATE_BOUND && d >= 4) break;
    }
    if (res.best == MOVE_NONE) res.best = rootMoves[0];
    res.nodes = nodes;
    return res;
}

} // namespace joro
