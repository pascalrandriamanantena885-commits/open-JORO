// JORO - eval.cpp : the JORO style as evaluation modules
#include "eval.h"
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>

namespace joro {

const int PIECE_VAL[7] = {0, 100, 320, 330, 500, 900, 0};
static const int V[7] = {0, 1, 3, 3, 5, 9, 100};  // relative values for "attacked by a lesser piece"

// ---------------------------------------------------------------- Style
static const char* PNAMES[SP_COUNT] = {"own_king", "enemy_king", "pins",     "loose",   "compensation",
                                       "outposts", "potential", "opening",   "endgame", "structure",
                                       "passers",  "initiative", "activity", "contempt"};
Style::Style() {
    for (int i = 0; i < SP_COUNT; i++) w[i] = 100;
    w[SP_CONTEMPT] = 0;
}
const char* Style::paramName(int i) { return (i >= 0 && i < SP_COUNT) ? PNAMES[i] : ""; }
uint64_t Style::id() const {
    uint64_t h = 1469598103934665603ULL;  // FNV-1a over the weights
    for (int i = 0; i < SP_COUNT; i++) {
        h ^= (uint64_t)(uint32_t)w[i];
        h *= 1099511628211ULL;
    }
    return h;
}
bool Style::set(const std::string& p, int v) {
    for (int i = 0; i < SP_COUNT; i++)
        if (p == PNAMES[i]) { w[i] = v; return true; }
    return false;
}
bool Style::save(const std::string& path) const {
    std::ofstream f(path);
    if (!f) return false;
    f << "{\n  \"name\": \"" << name << "\",\n  \"weights\": {\n";
    for (int i = 0; i < SP_COUNT; i++) f << "    \"" << PNAMES[i] << "\": " << w[i] << (i + 1 < SP_COUNT ? ",\n" : "\n");
    f << "  }\n}\n";
    return true;
}
bool Style::load(const std::string& path, std::string* err) {
    std::ifstream f(path);
    if (!f) { if (err) *err = "cannot open " + path; return false; }
    std::stringstream ss;
    ss << f.rdbuf();
    std::string t = ss.str();
    size_t p = t.find("\"name\"");
    if (p != std::string::npos) {
        size_t a = t.find('"', t.find(':', p) + 1), b = t.find('"', a + 1);
        if (a != std::string::npos && b != std::string::npos) name = t.substr(a + 1, b - a - 1);
    }
    for (int i = 0; i < SP_COUNT; i++) {
        std::string key = std::string("\"") + PNAMES[i] + "\"";
        size_t k = t.find(key);
        if (k == std::string::npos) continue;  // missing key => keeps the default
        size_t c = t.find(':', k);
        if (c != std::string::npos) w[i] = atoi(t.c_str() + c + 1);
    }
    return true;
}

// ---------------------------------------------------------------- tables
static U64 kingZone[2][64];
static const int DIRS[8][2] = {{1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}};
static inline int popc(U64 x) { return __builtin_popcountll(x); }
static inline int ctz(U64 x) { return __builtin_ctzll(x); }

static bool initEvalTables() {
    initTables();
    for (int c = 0; c < 2; c++)
        for (int s = 0; s < 64; s++) {
            U64 z = 1ULL << s;
            for (int i = 0; i < kingN[s]; i++) z |= 1ULL << kingTo[s][i];
            int dir = c == WHITE ? 1 : -1, r2 = (s >> 3) + 2 * dir;
            if (r2 >= 0 && r2 < 8)
                for (int df = -1; df <= 1; df++) {
                    int nf = (s & 7) + df;
                    if (nf >= 0 && nf < 8) z |= 1ULL << (r2 * 8 + nf);
                }
            kingZone[c][s] = z;
        }
    return true;
}

static inline int centrality(int f, int r) { return 7 - (std::abs(2 * f - 7) + std::abs(2 * r - 7)) / 2; }  // 0..6
static inline int kdist(int a, int b) { return std::max(std::abs((a & 7) - (b & 7)), std::abs((a >> 3) - (b >> 3))); }

static const int pawnMg[8] = {0, 0, 2, 6, 14, 28, 50, 0};
static const int pawnEg[8] = {0, 0, 5, 12, 25, 45, 80, 0};
static const int passedMg[8] = {0, 0, 5, 10, 20, 35, 60, 0};
static const int passedEg[8] = {0, 0, 10, 20, 40, 70, 120, 0};

int evaluate(const Board& b, const Style& st) {
    static const bool inited = initEvalTables();
    (void)inited;
    const int* W = st.w;

    // per-color module accumulators
    int mg[2] = {0, 0}, eg[2] = {0, 0};
    int ownK[2] = {0, 0}, enemyK[2] = {0, 0}, pins[2] = {0, 0}, loose[2] = {0, 0}, outp[2] = {0, 0}, pot[2] = {0, 0},
        dev[2] = {0, 0}, endg[2] = {0, 0}, strM[2] = {0, 0}, strE[2] = {0, 0}, pasM[2] = {0, 0}, pasE[2] = {0, 0},
        init[2] = {0, 0}, act[2] = {0, 0};

    int cnt[2][8], hi[2][8], lo[2][8], npc[2][7], mat[2] = {0, 0};
    for (int c = 0; c < 2; c++) {
        for (int f = 0; f < 8; f++) { cnt[c][f] = 0; hi[c][f] = -1; lo[c][f] = 8; }
        for (int t = 0; t < 7; t++) npc[c][t] = 0;
    }
    // ---- A: pawn files, counts, material
    for (int s = 0; s < 64; s++) {
        int p = b.sq[s];
        if (!p) continue;
        int c = colorOf(p), t = typeOf(p);
        npc[c][t]++;
        mat[c] += PIECE_VAL[t];
        if (t == PAWN) {
            int f = s & 7, r = s >> 3;
            cnt[c][f]++;
            hi[c][f] = std::max(hi[c][f], r);
            lo[c][f] = std::min(lo[c][f], r);
        }
    }
    {   // insufficient material
        int pawns = npc[0][PAWN] + npc[1][PAWN];
        int majors = npc[0][ROOK] + npc[0][QUEEN] + npc[1][ROOK] + npc[1][QUEEN];
        int minors = npc[0][KNIGHT] + npc[0][BISHOP] + npc[1][KNIGHT] + npc[1][BISHOP];
        if (!pawns && !majors && minors <= 1) return 0;
    }
    int phase = std::min(24, npc[0][KNIGHT] + npc[1][KNIGHT] + npc[0][BISHOP] + npc[1][BISHOP] +
                                 2 * (npc[0][ROOK] + npc[1][ROOK]) + 4 * (npc[0][QUEEN] + npc[1][QUEEN]));

    // ---- B: attack maps
    U64 pmask[64];
    int attN[2][64], low[2][64];
    U64 attAll[2] = {0, 0};
    std::memset(attN, 0, sizeof attN);
    for (int c = 0; c < 2; c++) for (int s = 0; s < 64; s++) low[c][s] = 99;
    int attackers[2] = {0, 0}, units[2] = {0, 0};
    static const int unitW[7] = {0, 0, 2, 2, 3, 5, 0};
    auto mark = [&](int c, U64 m, int v) {
        attAll[c] |= m;
        while (m) { int s = ctz(m); m &= m - 1; attN[c][s]++; if (v < low[c][s]) low[c][s] = v; }
    };
    for (int s = 0; s < 64; s++) {
        int p = b.sq[s];
        pmask[s] = 0;
        if (!p) continue;
        int c = colorOf(p), t = typeOf(p), f = s & 7, r = s >> 3;
        U64 m = 0;
        if (t == PAWN) {
            int r1 = c == WHITE ? r + 1 : r - 1;
            if (r1 >= 0 && r1 < 8) {
                if (f > 0) m |= 1ULL << (r1 * 8 + f - 1);
                if (f < 7) m |= 1ULL << (r1 * 8 + f + 1);
            }
        } else if (t == KNIGHT) {
            for (int i = 0; i < knightN[s]; i++) m |= 1ULL << knightTo[s][i];
        } else if (t == KING) {
            for (int i = 0; i < kingN[s]; i++) m |= 1ULL << kingTo[s][i];
        } else {
            int d0 = (t == BISHOP) ? 1 : 0, dstep = (t == QUEEN) ? 1 : 2;
            for (int d = d0; d < 8; d += dstep) {
                int nf = f + DIRS[d][0], nr = r + DIRS[d][1];
                while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                    int to = nr * 8 + nf;
                    m |= 1ULL << to;
                    if (b.sq[to]) break;
                    nf += DIRS[d][0];
                    nr += DIRS[d][1];
                }
            }
        }
        pmask[s] = m;
        mark(c, m, V[t]);
        if (t >= KNIGHT && t <= QUEEN) {
            int hits = popc(m & kingZone[c ^ 1][b.kingSq[c ^ 1]]);
            if (hits) { attackers[c]++; units[c] += hits * unitW[t]; }
        }
    }

    // ---- DKD enemy king pressure
    for (int c = 0; c < 2; c++) {
        if (!attackers[c]) continue;
        int u = std::min(units[c], 30), bonus = u * u / 3;
        if (attackers[c] == 1) bonus /= 3;
        if (!npc[c][QUEEN]) bonus /= 2;
        bonus -= popc(attAll[c ^ 1] & kingZone[c ^ 1][b.kingSq[c ^ 1]]) * 4;
        enemyK[c] = std::max(0, std::min(bonus, 350));
    }

    // weak = pieces attacked by the enemy and defended once only (for overload detection)
    U64 weak[2] = {0, 0};
    for (int s = 0; s < 64; s++) {
        int p = b.sq[s];
        if (!p || typeOf(p) == KING) continue;
        int c = colorOf(p);
        if (attN[c ^ 1][s] > 0 && attN[c][s] == 1) weak[c] |= 1ULL << s;
    }

    int threatsOn[2] = {0, 0};   // pieces of color c attacked by a lesser piece
    static const int tropOpenHome[2][4] = {{1, 2, 5, 6}, {57, 58, 61, 62}};
    int undeveloped[2] = {0, 0};

    // ---- C: piece by piece
    for (int s = 0; s < 64; s++) {
        int p = b.sq[s];
        if (!p) continue;
        const int c = colorOf(p), o = c ^ 1, t = typeOf(p), f = s & 7, r = s >> 3;
        const int rr = c == WHITE ? r : 7 - r, dir = c == WHITE ? 1 : -1;
        const int cen = centrality(f, r);
        int m = PIECE_VAL[t], e = PIECE_VAL[t];
        const U64 pm = pmask[s];
        const int ek = b.kingSq[o], ok = b.kingSq[c];

        // TBDA : hanging pieces / overloaded defenders
        if (t != KING) {
            if (attN[o][s] > 0 && attN[c][s] == 0) loose[c] -= (t == PAWN ? 6 : PIECE_VAL[t] / 14);
            else if (t != PAWN && attN[o][s] > 0 && low[o][s] < V[t]) threatsOn[c]++;
            if (t != PAWN && popc(pm & weak[c]) >= 2) loose[c] -= 12 * (popc(pm & weak[c]) - 1);
        }

        switch (t) {
            case PAWN: {
                m += pawnMg[rr];
                e += pawnEg[rr];
                if ((f == 3 || f == 4) && rr >= 2 && rr <= 4) m += 8;
                if (cnt[c][f] > 1) { strM[c] -= 6; strE[c] -= 10; }
                bool isolated = (f == 0 || cnt[c][f - 1] == 0) && (f == 7 || cnt[c][f + 1] == 0);
                if (isolated) { strM[c] -= 10; strE[c] -= 14; }
                // chain / phalanx
                int rb = r - dir;
                bool chain = rb >= 0 && rb < 8 && ((f > 0 && b.sq[rb * 8 + f - 1] == mkPiece(c, PAWN)) ||
                                                   (f < 7 && b.sq[rb * 8 + f + 1] == mkPiece(c, PAWN)));
                bool phalanx = (f > 0 && b.sq[s - 1] == mkPiece(c, PAWN)) || (f < 7 && b.sq[s + 1] == mkPiece(c, PAWN));
                if (chain) { strM[c] += 5; strE[c] += 4; }
                else if (phalanx) { strM[c] += 3; strE[c] += 3; }
                // backward
                if (!isolated && rr >= 1 && rr <= 5) {
                    bool behindSupport = false;
                    for (int fx = std::max(0, f - 1); fx <= std::min(7, f + 1); fx += 2) {
                        if (fx == f) continue;
                        if (c == WHITE ? lo[WHITE][fx] <= r : hi[BLACK][fx] >= r) behindSupport = true;
                    }
                    int r1 = r + dir, r2 = r + 2 * dir;
                    bool stopAttacked = r2 >= 0 && r2 < 8 &&
                        ((f > 0 && b.sq[r2 * 8 + f - 1] == mkPiece(o, PAWN)) || (f < 7 && b.sq[r2 * 8 + f + 1] == mkPiece(o, PAWN)));
                    if (!behindSupport && stopAttacked && b.sq[r1 * 8 + f] == 0) { strM[c] -= 10; strE[c] -= 8; }
                }
                bool passed = true;
                for (int fx = std::max(0, f - 1); fx <= std::min(7, f + 1) && passed; fx++) {
                    if (c == WHITE) { if (hi[BLACK][fx] > r) passed = false; }
                    else { if (lo[WHITE][fx] < r) passed = false; }
                }
                if (cnt[c][f] > 1 && (c == WHITE ? hi[WHITE][f] > r : lo[BLACK][f] < r)) passed = false;  // only the front pawn
                if (passed) {
                    pasM[c] += passedMg[rr];
                    pasE[c] += passedEg[rr];
                    int stop = s + 8 * dir;
                    if (stop >= 0 && stop < 64) {
                        if (!b.sq[stop] && attN[o][stop] == 0) pasE[c] += rr * 4;     // free to advance
                        pasE[c] += rr * 2 * (kdist(ek, stop) - kdist(ok, stop));        // kings vs the passer
                    }
                    // connected passers
                    for (int fx = f - 1; fx <= f + 1; fx += 2) {
                        if (fx < 0 || fx > 7) continue;
                        for (int rx = r - 1; rx <= r + 1; rx++) {
                            if (rx < 0 || rx > 7) continue;
                            if (b.sq[rx * 8 + fx] == mkPiece(c, PAWN)) {
                                bool ps2 = true;
                                for (int gx = std::max(0, fx - 1); gx <= std::min(7, fx + 1) && ps2; gx++)
                                    if (c == WHITE ? hi[BLACK][gx] > rx : lo[WHITE][gx] < rx) ps2 = false;
                                if (ps2) { pasM[c] += passedMg[rr] / 4; pasE[c] += passedEg[rr] / 3; }
                            }
                        }
                    }
                }
                break;
            }
            case KNIGHT:
            case BISHOP: {
                if (t == KNIGHT) { m += 6 * cen - 18; e += 4 * cen - 12; }
                else { m += 3 * cen - 6; e += 2 * cen - 4; }
                int mob = 0;
                {   // mobility = attacked squares not occupied by own pieces
                    U64 mm = pm;
                    while (mm) { int q = ctz(mm); mm &= mm - 1; int tp = b.sq[q]; if (!tp || colorOf(tp) != c) mob++; }
                }
                act[c] += (mob - (t == KNIGHT ? 4 : 6)) * 4;
                // DSI outposts
                if (rr >= 3 && rr <= 5) {
                    bool ok2 = true;
                    for (int fx = f - 1; fx <= f + 1; fx += 2) {
                        if (fx < 0 || fx > 7) continue;
                        if (c == WHITE ? hi[BLACK][fx] > r : lo[WHITE][fx] < r) ok2 = false;
                    }
                    int rb = r - dir;
                    bool sup = (f > 0 && b.sq[rb * 8 + f - 1] == mkPiece(c, PAWN)) || (f < 7 && b.sq[rb * 8 + f + 1] == mkPiece(c, PAWN));
                    if (ok2 && sup) outp[c] += (t == KNIGHT ? 22 : 10) + (rr - 3) * 6 + (std::abs(f - (ek & 7)) <= 2 ? 8 : 0);
                }
                // DSI potential: knight one jump from a supported outpost
                if (t == KNIGHT) {
                    U64 mm = pm;
                    while (mm) {
                        int q = ctz(mm); mm &= mm - 1;
                        int qf = q & 7, qr = q >> 3, qrr = c == WHITE ? qr : 7 - qr;
                        if (qrr < 4 || qrr > 5 || b.sq[q] != 0) continue;
                        bool ok2 = true;
                        for (int fx = qf - 1; fx <= qf + 1; fx += 2) {
                            if (fx < 0 || fx > 7) continue;
                            if (c == WHITE ? hi[BLACK][fx] > qr : lo[WHITE][fx] < qr) ok2 = false;
                        }
                        int qb = qr - dir;
                        bool sup = (qf > 0 && b.sq[qb * 8 + qf - 1] == mkPiece(c, PAWN)) || (qf < 7 && b.sq[qb * 8 + qf + 1] == mkPiece(c, PAWN));
                        if (ok2 && sup && attN[o][q] == 0) pot[c] += 8;
                    }
                }
                if (b.kingSq[c] >= 0) for (int i = 0; i < 4; i++) if (s == tropOpenHome[c][i]) undeveloped[c]++;
                if (t == BISHOP) {   // TBDA pins / x-ray
                    for (int d = 1; d < 8; d += 2) {
                        int nf = f + DIRS[d][0], nr = r + DIRS[d][1], p1 = 0;
                        while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                            int q = b.sq[nr * 8 + nf];
                            if (q) {
                                if (!p1) { if (colorOf(q) == c) break; p1 = q; }
                                else {
                                    if (colorOf(q) != c) {
                                        if (typeOf(q) == KING) pins[c] += 18;
                                        else if (V[typeOf(q)] > V[typeOf(p1)]) pins[c] += 10;
                                    }
                                    break;
                                }
                            }
                            nf += DIRS[d][0]; nr += DIRS[d][1];
                        }
                    }
                }
                break;
            }
            case ROOK:
            case QUEEN: {
                if (t == QUEEN) { m += cen; e += 2 * cen; }
                int k = 0;
                { U64 mm = pm; while (mm) { int q = ctz(mm); mm &= mm - 1; int tp = b.sq[q]; if (!tp || colorOf(tp) != c) k++; } }
                if (t == ROOK) {
                    act[c] += (k - 6) * 2;
                    if (rr == 6) { m += 15; e += 25; }
                    if (cnt[c][f] == 0) {
                        act[c] += (cnt[o][f] == 0) ? 15 : 8;
                        if (std::abs(f - (ek & 7)) <= 1) pot[c] += 10;   // DSI : file toward the king
                    }
                } else {
                    act[c] += (k - 10);
                }
                for (int d = 0; d < 8; d += (t == ROOK ? 2 : 1)) {   // pins
                    int nf = f + DIRS[d][0], nr = r + DIRS[d][1], p1 = 0;
                    while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                        int q = b.sq[nr * 8 + nf];
                        if (q) {
                            if (!p1) { if (colorOf(q) == c) break; p1 = q; }
                            else {
                                if (colorOf(q) != c) {
                                    if (typeOf(q) == KING) pins[c] += 18;
                                    else if (V[typeOf(q)] > V[typeOf(p1)]) pins[c] += 10;
                                }
                                break;
                            }
                        }
                        nf += DIRS[d][0]; nr += DIRS[d][1];
                    }
                }
                break;
            }
            case KING: {
                m += -8 * cen - 12 * rr;
                e += 8 * cen;
                if (rr <= 1) {
                    for (int fx = std::max(0, f - 1); fx <= std::min(7, f + 1); fx++) {
                        int r1 = r + dir, r2 = r + 2 * dir;
                        bool p1 = r1 >= 0 && r1 < 8 && b.sq[r1 * 8 + fx] == mkPiece(c, PAWN);
                        bool p2 = r2 >= 0 && r2 < 8 && b.sq[r2 * 8 + fx] == mkPiece(c, PAWN);
                        if (p1) ownK[c] += 10;
                        else if (p2) ownK[c] += 5;
                        else ownK[c] -= 15;
                        if (cnt[c][fx] == 0) ownK[c] -= (cnt[o][fx] == 0 ? 14 : 8);   // open / semi-open file on the king
                    }
                }
                break;
            }
        }
        mg[c] += m;
        eg[c] += e;
    }

    // ---- PASI opening: development, centre, castling
    {
        int openF = std::max(0, 16 - b.fullmove) * 100 / 16;
        for (int c = 0; c < 2; c++) {
            int d = -12 * undeveloped[c];
            int homeQ = c == WHITE ? 3 : 59;
            if (b.sq[homeQ] != mkPiece(c, QUEEN) && undeveloped[c] >= 2) d -= 10;
            int kg = b.kingSq[c];
            bool castled = (c == WHITE ? (kg == 6 || kg == 2) : (kg == 62 || kg == 58));
            if (castled) d += 12;
            else if (!((c == WHITE) ? (b.castling & 3) : (b.castling & 12))) d -= 15;
            int cp = c == WHITE ? 3 : 4;
            if (b.sq[cp * 8 + 3] == mkPiece(c, PAWN)) d += 8;
            if (b.sq[cp * 8 + 4] == mkPiece(c, PAWN)) d += 8;
            dev[c] = d * openF / 100;
        }
    }

    // ---- IPC : threats, space, tempo
    for (int c = 0; c < 2; c++) {
        U64 enemyHalf = c == WHITE ? 0xFFFFFFFF00000000ULL : 0x00000000FFFFFFFFULL;
        init[c] = 8 * threatsOn[c ^ 1] + popc(attAll[c] & enemyHalf) / 2;
    }
    init[b.side] += 6 + 4 * threatsOn[b.side ^ 1];

    // ---- PASI endgame : conversion (mop-up), drawish scaling
    for (int c = 0; c < 2; c++) {
        int o = c ^ 1;
        if (mat[c] - mat[o] >= 300 && npc[o][PAWN] == 0 && phase <= 12) {
            int ek = b.kingSq[o];
            endg[c] += (6 - centrality(ek & 7, ek >> 3)) * 10 + (14 - kdist(b.kingSq[c], ek) * 2) * 4;
        }
    }

    // ---- SI : compensation for material deficit (initiative / king attack / development)
    int comp[2] = {0, 0};
    for (int c = 0; c < 2; c++) {
        int deficit = mat[c ^ 1] - mat[c];
        if (deficit >= 60 && deficit <= 500) {
            int base = enemyK[c] / 2 + std::max(0, act[c] - act[c ^ 1]) + 5 * std::max(0, undeveloped[c ^ 1] - undeveloped[c]) +
                       std::max(0, pasM[c] - pasM[c ^ 1]) / 2 + init[c] / 2;
            if (base > 40) comp[c] = std::min(deficit * 50 / 100, base);
        }
    }

    // ---- combine modules with the style weights
    for (int c = 0; c < 2; c++) {
        mg[c] += (ownK[c] * W[SP_OWN_KING] + enemyK[c] * W[SP_ENEMY_KING] + pins[c] * W[SP_PINS] + loose[c] * W[SP_LOOSE] +
                  comp[c] * W[SP_COMP] + outp[c] * W[SP_OUTPOST] + pot[c] * W[SP_POTENTIAL] + dev[c] * W[SP_OPENING] +
                  strM[c] * W[SP_STRUCT] + pasM[c] * W[SP_PASSERS] + init[c] * W[SP_INITIATIVE] + act[c] * W[SP_ACTIVITY]) / 100;
        eg[c] += (pins[c] * W[SP_PINS] / 2 + loose[c] * W[SP_LOOSE] + outp[c] * W[SP_OUTPOST] * 6 / 10 +
                  endg[c] * W[SP_ENDGAME] + strE[c] * W[SP_STRUCT] + pasE[c] * W[SP_PASSERS] + act[c] * W[SP_ACTIVITY]) / 100;
        if (npc[c][BISHOP] >= 2) { mg[c] += 30; eg[c] += 40; }
    }
    int score = ((mg[0] - mg[1]) * phase + (eg[0] - eg[1]) * (24 - phase)) / 24;
    // opposite-coloured bishops: drawish (PASI endgame, draw recognition)
    if (npc[0][BISHOP] == 1 && npc[1][BISHOP] == 1 && npc[0][KNIGHT] + npc[1][KNIGHT] + npc[0][ROOK] + npc[1][ROOK] +
            npc[0][QUEEN] + npc[1][QUEEN] == 0) {
        int wb = -1, bb = -1;
        for (int s = 0; s < 64; s++) {
            if (b.sq[s] == mkPiece(WHITE, BISHOP)) wb = ((s & 7) + (s >> 3)) & 1;
            if (b.sq[s] == mkPiece(BLACK, BISHOP)) bb = ((s & 7) + (s >> 3)) & 1;
        }
        if (wb != bb) score = score * (100 - 40 * std::max(0, W[SP_ENDGAME]) / 100) / 100;
    }
    return (b.side == WHITE ? score : -score) + 10;
}

} // namespace joro
