// JORO - trainer.h : self-play learning loop (JORO vs JORO) that writes the experience file.
//
// For one opening, games are replayed until the variations are exhausted (or a budget is hit):
//   * a side that WON  -> every move it played is stored as GOOD  (kept in "memory")
//   * a side that LOST -> backtracking finds the critical move; it is stored as BAD, so the
//                         next game tries another variation and never repeats the same error.
#pragma once
#include "search.h"
#include <functional>
#include <string>
#include <vector>

namespace joro {

const int NO_SCORE = -32768;

struct TrainConfig {
    int depth = 8;             // search depth per move in self-play
    int maxPlies = 300;        // game is a draw after this
    int maxGames = 200;        // budget per opening
    int stableLimit = 3;       // stop after N games that taught nothing new
    int confirmWins = 5;       // stop when the same side wins N games in a row (the other side found no refutation)
    bool drawIsFail = true;    // a draw is not a win -> the side tries another variation
    int blameThreshold = 100;  // cp: eval drop that marks a move as the "critical" one
    bool adjudicate = true;    // |eval| >= 900cp for 6 consecutive moves => game decided
    int hashMB = 16;
    Style style;               // style used by both sides (stored in the exported file)
};

struct GameRecord {
    std::string startFen;           // position after the opening
    std::vector<Move> moves;        // moves played after the opening
    std::vector<U64> keys;          // position key before each move
    std::vector<int> scores;        // search score (mover point of view) or NO_SCORE if played from experience
    std::vector<int> movers;        // side that played each move
    int result = 0;                 // +1 white won, -1 black won, 0 draw
    std::string reason;
};

struct TrainStats {
    int games = 0, whiteWins = 0, blackWins = 0, draws = 0;
    int newBad = 0, newGood = 0, exhausted = 0;
};

class Trainer {
public:
    Trainer(Experience& exp, const TrainConfig& cfg);

    // called after every game (progress for the CLI / the Android UI)
    std::function<void(int gameNo, const GameRecord&, int newBad, int newGood)> onGame;

    void stop();  // thread-safe, can be called from the UI

    TrainStats trainOpening(const std::string& startFen, const std::vector<std::string>& openingMoves,
                            std::string* err = nullptr);
    bool playGame(const std::string& startFen, const std::vector<std::string>& openingMoves, GameRecord& rec,
                  std::string* err = nullptr);
    void learn(const GameRecord& rec, int& newBad, int& newGood, int& exhausted);

private:
    Experience& exp;
    TrainConfig cfg;
    Searcher sw, sb;
    std::atomic<bool> stopped;
    void blame(const GameRecord& rec, int side, int resultForSide, int& newBad, int& exhausted);
};

} // namespace joro
