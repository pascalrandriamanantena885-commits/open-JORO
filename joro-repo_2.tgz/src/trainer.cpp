// JORO - trainer.cpp
#include "trainer.h"
#include <algorithm>
#include <cstdlib>

namespace joro {

static bool insufficientMaterial(const Board& b) {
    int minors = 0;
    for (int s = 0; s < 64; s++) {
        int t = typeOf(b.sq[s]);
        if (t == PAWN || t == ROOK || t == QUEEN) return false;
        if (t == KNIGHT || t == BISHOP) minors++;
    }
    return minors <= 1;
}

Trainer::Trainer(Experience& e, const TrainConfig& c) : exp(e), cfg(c), stopped(false) {
    for (Searcher* s : {&sw, &sb}) {
        s->quiet = true;
        s->style = cfg.style;
        s->setHash(cfg.hashMB);
        s->setExperience(&exp);
        s->useExperience = true;
    }
}

void Trainer::stop() {
    stopped = true;
    sw.stopFlag = true;
    sb.stopFlag = true;
}

bool Trainer::playGame(const std::string& startFen, const std::vector<std::string>& opening, GameRecord& rec,
                       std::string* err) {
    Board b;
    if (!b.setFen(startFen)) { if (err) *err = "bad FEN"; return false; }
    for (auto& s : opening) {
        Move m = b.parseMove(s);
        if (m == MOVE_NONE) { if (err) *err = "illegal opening move " + s; return false; }
        b.makeMove(m);
    }
    rec = GameRecord();
    rec.startFen = b.fen();
    sw.clear();
    sb.clear();  // fresh tables => a replayed game is identical until the first experience change
    Searcher* ss[2] = {&sw, &sb};
    int streak = 0, streakSign = 0;
    for (int ply = 0;; ply++) {
        Move mv[256];
        int nl = b.genLegal(mv);
        if (nl == 0) {
            if (b.inCheck()) { rec.result = b.side == WHITE ? -1 : 1; rec.reason = "checkmate"; }
            else { rec.result = 0; rec.reason = "stalemate"; }
            break;
        }
        if (b.halfmove >= 100) { rec.result = 0; rec.reason = "50-move"; break; }
        int reps = 1;
        for (auto& u : b.hist) if (u.hash == b.hash) reps++;
        if (reps >= 3) { rec.result = 0; rec.reason = "repetition"; break; }
        if (insufficientMaterial(b)) { rec.result = 0; rec.reason = "insufficient material"; break; }
        if (ply >= cfg.maxPlies) { rec.result = 0; rec.reason = "max plies"; break; }
        if (stopped) return false;

        Searcher& s = *ss[b.side];
        s.stopFlag = false;
        Limits lim;
        lim.depth = cfg.depth;
        SearchResult r = s.go(b, lim);
        if (stopped) return false;
        rec.keys.push_back(b.hash);
        rec.moves.push_back(r.best);
        rec.movers.push_back(b.side);
        rec.scores.push_back(r.fromExperience ? NO_SCORE : r.score);
        if (cfg.adjudicate && !r.fromExperience) {
            int w = b.side == WHITE ? r.score : -r.score;  // white point of view
            if (std::abs(w) >= 900) {
                int sg = w > 0 ? 1 : -1;
                streak = (sg == streakSign) ? streak + 1 : 1;
                streakSign = sg;
            } else { streak = 0; streakSign = 0; }
            if (streak >= 6) { rec.result = streakSign; rec.reason = "adjudicated"; break; }
        }
        b.makeMove(r.best);
    }
    return true;
}

static int clampScore(int s) { return std::max(-1000, std::min(1000, s)); }

// Backtracking : walk back over the decisions of the failing side, find the critical move.
void Trainer::blame(const GameRecord& rec, int side, int resultForSide, int& newBad, int& exhausted) {
    const size_t n = rec.moves.size();
    std::vector<int> untried(n, 0);
    std::vector<size_t> dec;  // decision indices of this side
    Board b;
    b.setFen(rec.startFen);
    for (size_t i = 0; i < n; i++) {
        if (rec.movers[i] == side) {
            Move mv[256];
            int nl = b.genLegal(mv), u = 0;
            for (int k = 0; k < nl; k++)
                if (mv[k] != rec.moves[i] && !exp.isBad(rec.keys[i], mv[k])) u++;
            untried[i] = u;
            dec.push_back(i);
        }
        b.makeMove(rec.moves[i]);
    }
    int terminal = resultForSide < 0 ? -1000 : 0;
    int bestJ = -1, bestDrop = -100000, lastJ = -1;
    std::vector<int> drop(dec.size(), 0);
    for (size_t j = 0; j < dec.size(); j++) {
        int e0 = rec.scores[dec[j]];
        int e1 = (j + 1 < dec.size()) ? rec.scores[dec[j + 1]] : terminal;
        drop[j] = (e0 == NO_SCORE || e1 == NO_SCORE) ? 0 : clampScore(e0) - clampScore(e1);
        if (untried[dec[j]] > 0) {
            lastJ = (int)j;
            if (drop[j] > bestDrop) { bestDrop = drop[j]; bestJ = (int)j; }
        }
    }
    int pick = (bestJ >= 0 && bestDrop >= cfg.blameThreshold) ? bestJ : lastJ;  // else: plain backtrack
    if (pick < 0) { exhausted++; return; }  // nothing left to vary for this side
    size_t i = dec[pick];
    int inc = exp.goodCount(rec.keys[i], rec.moves[i]) + 1;  // must outweigh an old "good" mark
    bool had = exp.badCount(rec.keys[i], rec.moves[i]) > 0;
    exp.add(rec.keys[i], rec.moves[i], EXP_BAD, -std::max(0, drop[pick]), inc);
    if (!had) newBad++;
}

void Trainer::learn(const GameRecord& rec, int& newBad, int& newGood, int& exhausted) {
    for (int side = 0; side < 2; side++) {
        int rs = rec.result == 0 ? 0 : (((rec.result == 1) == (side == WHITE)) ? 1 : -1);
        if (rs == 1) {
            for (size_t i = 0; i < rec.moves.size(); i++) {
                if (rec.movers[i] != side) continue;
                bool had = exp.goodCount(rec.keys[i], rec.moves[i]) > 0;
                int v = rec.scores[i] == NO_SCORE ? 0 : clampScore(rec.scores[i]);
                exp.add(rec.keys[i], rec.moves[i], EXP_GOOD, v, 1);
                if (!had) newGood++;
            }
        } else if (rs == -1 || cfg.drawIsFail) {
            blame(rec, side, rs, newBad, exhausted);
        }
    }
}

TrainStats Trainer::trainOpening(const std::string& startFen, const std::vector<std::string>& opening,
                                 std::string* err) {
    TrainStats st;
    int stable = 0, streakSide = 0, streakLen = 0;
    for (int g = 1; g <= cfg.maxGames && !stopped; g++) {
        GameRecord rec;
        if (!playGame(startFen, opening, rec, err)) break;
        size_t before = exp.size();
        int nb = 0, ng = 0, ex = 0;
        learn(rec, nb, ng, ex);
        st.games++;
        st.newBad += nb;
        st.newGood += ng;
        st.exhausted += ex;
        if (rec.result == 1) st.whiteWins++; else if (rec.result == -1) st.blackWins++; else st.draws++;
        if (onGame) onGame(g, rec, nb, ng);
        stable = (exp.size() == before) ? stable + 1 : 0;
        if (rec.result != 0 && rec.result == streakSide) streakLen++;
        else { streakSide = rec.result; streakLen = rec.result != 0 ? 1 : 0; }
        if (cfg.confirmWins > 0 && streakLen >= cfg.confirmWins) break;
        if (stable >= cfg.stableLimit) break;
    }
    return st;
}

} // namespace joro
