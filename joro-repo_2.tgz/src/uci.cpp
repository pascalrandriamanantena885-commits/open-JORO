// JORO - uci.cpp : UCI protocol front-end
#include "uci.h"
#include "search.h"
#include <algorithm>
#include <cstdio>
#include <iostream>
#include <sstream>
#include <thread>

namespace joro {

static const char* ENGINE_NAME = "JORO 0.3";

static std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)tolower(c); });
    return s;
}

void uciLoop() {
    initTables();
    Board board;
    Searcher searcher;
    Experience exp;
    searcher.setExperience(&exp);
    std::thread th;
    bool useExpStyle = true;

    auto stopSearch = [&]() {
        searcher.stopFlag = true;
        if (th.joinable()) th.join();
    };

    std::string line;
    while (std::getline(std::cin, line)) {
        std::istringstream is(line);
        std::string cmd;
        is >> cmd;
        if (cmd.empty()) continue;

        if (cmd == "uci") {
            printf("id name %s\nid author JORO project\n", ENGINE_NAME);
            printf("option name Hash type spin default 16 min 1 max 2048\n");
            printf("option name Threads type spin default 1 min 1 max 1\n");
            printf("option name MoveOverhead type spin default 30 min 0 max 5000\n");
            printf("option name ExperienceFile type string default <empty>\n");
            printf("option name UseExperience type check default true\n");
            printf("option name ExperienceStyle type check default true\n");
            printf("option name StyleFile type string default <empty>\n");
            printf("option name StrictStyle type check default true\n");
            for (int i = 0; i < SP_COUNT; i++)
                printf("option name Style_%s type spin default %d min -300 max 400\n", Style::paramName(i), i == SP_CONTEMPT ? 0 : 100);
            printf("uciok\n");
            fflush(stdout);
        } else if (cmd == "isready") {
            printf("readyok\n");
            fflush(stdout);
        } else if (cmd == "setoption") {
            std::string tok, name, value;
            bool inValue = false;
            while (is >> tok) {
                if (!inValue && lower(tok) == "value") { inValue = true; continue; }
                if (tok == "name" && name.empty() && !inValue) continue;
                std::string& dst = inValue ? value : name;
                if (!dst.empty()) dst += ' ';
                dst += tok;
            }
            std::string n = lower(name);
            int v = atoi(value.c_str());
            if (n == "hash") searcher.setHash(v);
            else if (n == "moveoverhead") searcher.moveOverhead = v;
            else if (n == "useexperience") searcher.useExperience = lower(value) == "true";
            else if (n == "experiencestyle") useExpStyle = lower(value) == "true";
            else if (n == "strictstyle") searcher.strictStyle = lower(value) == "true";
            else if (n == "stylefile") {
                std::string err;
                if (searcher.style.load(value, &err))
                    printf("info string style loaded: %s id %016llx\n", searcher.style.name.c_str(), (unsigned long long)searcher.style.id());
                else printf("info string style NOT loaded (%s)\n", err.c_str());
                fflush(stdout);
            }
            else if (n.compare(0, 6, "style_") == 0) searcher.style.set(n.substr(6), v);
            else if (n == "experiencefile") {
                if (value.empty() || value == "<empty>") { exp.clear(); }
                else {
                    std::string err;
                    if (exp.load(value, &err)) {
                        printf("info string experience loaded: %zu entries from %s\n", exp.size(), value.c_str());
                        Style st;
                        if (useExpStyle && exp.getStyle(st)) {
                            searcher.style = st;
                            printf("info string style from experience: %s id %016llx\n", st.name.c_str(), (unsigned long long)st.id());
                        }
                    } else {
                        printf("info string experience NOT loaded (%s)\n", err.c_str());
                    }
                }
                fflush(stdout);
            }
        } else if (cmd == "ucinewgame") {
            stopSearch();
            searcher.clear();
            board.setFen(START_FEN);
        } else if (cmd == "position") {
            stopSearch();
            std::string tok;
            is >> tok;
            if (tok == "startpos") {
                board.setFen(START_FEN);
                is >> tok;
            } else if (tok == "fen") {
                std::string fen;
                while (is >> tok && tok != "moves") fen += (fen.empty() ? "" : " ") + tok;
                board.setFen(fen);
            }
            if (tok == "moves") {
                while (is >> tok) {
                    Move m = board.parseMove(tok);
                    if (m == MOVE_NONE) { printf("info string illegal move %s\n", tok.c_str()); break; }
                    board.makeMove(m);
                }
            }
        } else if (cmd == "go") {
            stopSearch();
            Limits lim;
            std::string tok;
            while (is >> tok) {
                long long v = 0;
                if (tok == "infinite") lim.infinite = true;
                else if (tok == "wtime") { is >> v; lim.time[WHITE] = v; }
                else if (tok == "btime") { is >> v; lim.time[BLACK] = v; }
                else if (tok == "winc") { is >> v; lim.inc[WHITE] = v; }
                else if (tok == "binc") { is >> v; lim.inc[BLACK] = v; }
                else if (tok == "movestogo") { is >> v; lim.movestogo = (int)v; }
                else if (tok == "movetime") { is >> v; lim.movetime = v; }
                else if (tok == "depth") { is >> v; lim.depth = (int)v; }
                else if (tok == "nodes") { is >> v; lim.nodes = v; }
            }
            searcher.stopFlag = false;
            th = std::thread([&, lim]() {
                Board copy = board;
                SearchResult r = searcher.go(copy, lim);
                if (r.best == MOVE_NONE) printf("bestmove 0000\n");
                else if (r.ponder != MOVE_NONE) printf("bestmove %s ponder %s\n", Board::moveToStr(r.best).c_str(), Board::moveToStr(r.ponder).c_str());
                else printf("bestmove %s\n", Board::moveToStr(r.best).c_str());
                fflush(stdout);
            });
        } else if (cmd == "stop") {
            stopSearch();
        } else if (cmd == "quit") {
            stopSearch();
            return;
        } else if (cmd == "d") {
            printf("Fen: %s\nKey: %016llx\n", board.fen().c_str(), (unsigned long long)board.hash);
            fflush(stdout);
        } else if (cmd == "eval") {
            printf("eval (side to move): %d cp | style %s id %016llx\n", evaluate(board, searcher.style), searcher.style.name.c_str(), (unsigned long long)searcher.style.id());
            fflush(stdout);
        } else if (cmd == "perft") {
            int d = 1;
            is >> d;
            printf("nodes %llu\n", (unsigned long long)board.perft(d));
            fflush(stdout);
        }
    }
    stopSearch();
}

} // namespace joro
