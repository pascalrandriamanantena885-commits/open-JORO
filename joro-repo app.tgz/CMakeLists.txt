cmake_minimum_required(VERSION 3.10)
project(JORO CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()
set(CMAKE_CXX_FLAGS_RELEASE "-O3")

# core library : reused as-is by the Android app (JNI) later
add_library(joro_core STATIC
  src/board.cpp src/eval.cpp src/experience.cpp src/search.cpp)
target_include_directories(joro_core PUBLIC src)

find_package(Threads REQUIRED)
add_executable(joro src/main.cpp src/uci.cpp)
target_link_libraries(joro joro_core Threads::Threads)

# trainer: self-play learning loop (also compiled into the Android app via JNI)
add_library(joro_trainer STATIC src/trainer.cpp)
target_link_libraries(joro_trainer joro_core)
add_executable(joro_train src/train_main.cpp)
target_link_libraries(joro_train joro_trainer Threads::Threads)

# A/B test of two styles at equal time per move
add_executable(joro_match src/match_main.cpp)
target_link_libraries(joro_match joro_core Threads::Threads)
