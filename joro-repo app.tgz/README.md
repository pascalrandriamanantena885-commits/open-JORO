# JORO v0.4

UCI chess engine (C++17) with a patchable **experience file** (`joro.exp`).

## Build
    cmake -S . -B build && cmake --build build -j      # or: g++ -O3 -std=c++17 -pthread src/*.cpp -o joro
    ./build/joro        # speaks UCI

## UCI options
| option | meaning |
|---|---|
| ExperienceFile | path to `joro.exp` (the patch produced by the trainer app) |
| UseExperience | on/off |
| ExperienceStyle | apply the style stored in the file |
| StyleFile | path to a style file |
| Style_<param> | one weight (own_king, enemy_king, ... contempt) |
| StrictStyle | ignore experience made with another style |
| Hash, MoveOverhead | usual |

Debug commands: `d` (FEN + key), `eval`, `perft N`.

## JORO style (`styles/joro.style`, from "JORO PLAYING STYLE v1.0")
One identity for all of JORO. Each module of the style document is an evaluation module with a weight (% , 100 = nominal):
| module | param(s) | implemented as |
|---|---|---|
| DKD dual king dominance | own_king, enemy_king | pawn shield, open files on own king; king-zone attack units on the enemy king |
| TBDA target behind defense | pins, loose | pins/x-rays on king & queen, hanging pieces, overloaded defenders |
| SI sacrifice intelligence | compensation | bonus offsetting a material deficit when attack/activity/development justify it |
| DSI deep square intelligence | outposts, potential | outposts, squares a knight can reach next, rooks on files toward the king |
| PASI phase-aware | opening, endgame | development/centre/castling early; mop-up, king vs passers, opposite bishops late |
| DPSI pawn structure | structure, passers | isolated/doubled/backward, chains, connected & free passers |
| IPC initiative | initiative | threats by lesser pieces, space, tempo |
| KHTI king hunting & trap | king_hunt | enemy king escape squares (free / controlled / blocked), isolation from its defenders, open lines & batteries aimed at it, mating-net bonus; in the search, a check that leaves the king at most one flight square is extended |
Search-level parts (tactics: deflection, decoy, clearance, interference, sacrifices) come from the search itself.
`styles/neutral.style` = ablation baseline. The experience file stores the style id: an experience made with another
style is ignored (`StrictStyle`), and `joro_train` refuses to continue a file of another style.
A/B test: `joro_match --a styles/joro.style --b styles/neutral.style --movetime 50`.
Measured here (48 games, 40 ms/move): JORO style 59% vs neutral - positive but small sample.
KHTI A/B (same style, only `king_hunt` changes, 48 games each, 40 ms/move): weight 100 -> 42% ; weight 100 without the search
extension -> 44% ; weight 50 -> 59%. The samples are small (+-70 Elo) but 50 is the default (`styles/joro.style`). The
weight can be changed (`--set king_hunt=N`, UCI `Style_king_hunt`). Pieces of KHTI that are only approximated by the static
evaluation: "king attraction" (sacrifices/forcing sequences are found by the search, not planned) and "unsafe square
prediction" (only squares already controlled are counted). An experience made before KHTI stays valid (its style id is the
KHTI-off id): the engine uses it with the current style; the trainer upgrades it to the current style on the next training.

## Experience file (`src/experience.h`)
Entries `(position key, move, kind GOOD/BAD, value, count)`.
* At the root JORO **removes every move marked BAD** (net count: bad > good) -> it never repeats the same error.
* If a **GOOD** move is known it is played directly (learned win).
* Header also stores the **style** (5 weights) so a patch can change how JORO plays.
Position keys use a fixed Zobrist seed, so the same file works on PC, CI and Android.

## Verified
perft: startpos d5, Kiwipete d4, pos3 d5, pos4 d4, pos5 d3, pos6 d3 : all exact. Incremental hash == full hash.
~1.2M nps, depth 14 in 2 s from startpos (single thread).

## CI
`.github/workflows/calibrate.yml` : JORO vs Stockfish (`UCI_LimitStrength`, `UCI_Elo` levels) via fastchess,
runs on every push touching `src/**` or `experience/**`; Elo estimate appended to `calibration/history.csv`.
Put the trained file at `experience/joro.exp`. Stockfish's minimum UCI_Elo is 1320.
`openings/openings.epd` is generated with `tools/make_openings.sh`.

## Trainer (`joro_train`)
    ./build/joro_train --opening "e2e4 e7e5 g1f3 b8c6" --depth 8 --out experience/joro.exp
    ./build/joro_train --openings tools/lines.txt --in experience/joro.exp --out experience/joro.exp
Self-play JORO vs JORO from the opening. After each game, for each side:
* **won** -> all its moves stored GOOD.
* **lost / drew** -> backtracking over its decisions: the move with the biggest eval drop (>= 100 cp) that still has
  untried alternatives is stored BAD (else the last decision with alternatives). Next game takes another variation.
Stops when: `--games` budget, `--stable` games without anything new, or `--confirm` consecutive wins by one side.
Games are deterministic (fixed depth, tables cleared) so a replay is identical until the first changed move.

## Next
Kotlin Android app: JNI around `joro_trainer` (start / stop / progress / export `joro.exp`).
