// JNI glue. Everything real lives in src/ (referee.h, appapi.h); no UCI is involved in the training path.
#include <jni.h>
#include <string>
#include <vector>
#include "appapi.h"
#include "referee.h"

using namespace joro;

static std::vector<int> toVec(JNIEnv* env, jintArray a) {
    std::vector<int> v;
    if (!a) return v;
    jsize n = env->GetArrayLength(a);
    v.resize((size_t)n);
    if (n > 0) env->GetIntArrayRegion(a, 0, n, v.data());
    return v;
}

static jintArray toArr(JNIEnv* env, const std::vector<int>& v) {
    jintArray r = env->NewIntArray((jsize)v.size());
    if (!v.empty()) env->SetIntArrayRegion(r, 0, (jsize)v.size(), v.data());
    return r;
}

static std::string toStr(JNIEnv* env, jstring s) {
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r = c ? c : "";
    env->ReleaseStringUTFChars(s, c);
    return r;
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM*, void*) {
    initTables();  // once, before any worker thread builds a Board
    return JNI_VERSION_1_6;
}

extern "C" {

// ---- Referee (calibration games)
JNIEXPORT jint JNICALL Java_com_joro_calibrator_Referee_nativeStatus(JNIEnv* env, jclass, jstring fen, jstring moves) {
    return refereeStatus(toStr(env, fen), toStr(env, moves));
}

// ---- board / opening
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_boardInfo(JNIEnv* env, jclass, jintArray moves) {
    return env->NewStringUTF(app::boardInfo(toVec(env, moves)).c_str());
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_legalMoves(JNIEnv* env, jclass, jintArray moves) {
    return toArr(env, app::legalMoves(toVec(env, moves)));
}
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_movesToSan(JNIEnv* env, jclass, jintArray moves) {
    return env->NewStringUTF(app::sanLine(toVec(env, moves)).c_str());
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_parseSanLine(JNIEnv* env, jclass, jstring text) {
    std::vector<int> out;
    if (!app::parseSanLine(toStr(env, text), out)) return nullptr;
    return toArr(env, out);
}

JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_sanFromUci(JNIEnv* env, jclass, jstring fen, jstring moves) {
    return env->NewStringUTF(app::sanFromUci(toStr(env, fen), toStr(env, moves)).c_str());
}

// ---- training
JNIEXPORT jlong JNICALL Java_com_joro_calibrator_Native_trainCreate(
    JNIEnv* env, jclass, jintArray moves, jstring expPath, jint depth, jint maxGames, jint stable, jint confirm,
    jboolean drawFail, jint hashMb) {
    std::string err;
    app::TrainHandle* h = app::trainCreate(toVec(env, moves), toStr(env, expPath), depth, maxGames, stable, confirm,
                                           drawFail != 0, hashMb, &err);
    return (jlong)(intptr_t)h;
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_trainStep(JNIEnv* env, jclass, jlong handle) {
    return toArr(env, app::trainStep((app::TrainHandle*)(intptr_t)handle));
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_trainStop(JNIEnv*, jclass, jlong handle) {
    app::trainStop((app::TrainHandle*)(intptr_t)handle);
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_trainDestroy(JNIEnv*, jclass, jlong handle) {
    app::trainDestroy((app::TrainHandle*)(intptr_t)handle);
}

}  // extern "C"
