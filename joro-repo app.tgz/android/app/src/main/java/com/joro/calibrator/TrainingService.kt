package com.joro.calibrator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Keeps the training alive when the app is closed (foreground service + wake lock + notification). */
class TrainingService : Service() {
    companion object {
        const val ACTION_STOP = "com.joro.calibrator.TRAIN_STOP"
        private const val CHANNEL = "training"
        private const val ID_RUN = 3
        private const val ID_DONE = 4
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wake: PowerManager.WakeLock? = null
    private var lastUpdate = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "JORO training", NotificationManager.IMPORTANCE_LOW))
        startForeground(ID_RUN, build("JORO training", "Manomboka...", 0, 0, true))

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "joro:training").apply {
            setReferenceCounted(false)
            acquire(12L * 60 * 60 * 1000)
        }

        scope.launch {
            TrainingController.state.collect { st ->
                if (st.running) {
                    val now = System.currentTimeMillis()
                    if (now - lastUpdate >= 1500) {
                        lastUpdate = now
                        val total = st.openingTotal * st.maxGames
                        val done = (st.openingIndex - 1).coerceAtLeast(0) * st.maxGames + st.game
                        nm.notify(ID_RUN, build(
                            "JORO training: ${st.openingIndex}/${st.openingTotal} ${st.openingName}",
                            "lalao ${st.game}/${st.maxGames}  W${st.white} B${st.black} D${st.draws}  +bad ${st.newBad} +good ${st.newGood}",
                            done, total, true))
                    }
                } else {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    nm.notify(ID_DONE, build("Training vita", "+bad ${st.newBad}  +good ${st.newGood}  entries ${st.entries}", 0, 0, false))
                    stopSelf()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) TrainingController.stop()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    private fun build(title: String, text: String, done: Int, total: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(title).setContentText(text)
            .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(ongoing)
        if (ongoing) {
            b.setProgress(total, done.coerceAtMost(total), total == 0)
            val stop = PendingIntent.getService(
                this, 2, Intent(this, TrainingService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(0, "Atsaha", stop)
        } else b.setAutoCancel(true)
        return b.build()
    }
}
