package com.joro.calibrator

import java.util.Locale
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object Elo {
    private fun eloFromScore(s: Double): Double = -400.0 * log10(1.0 / s - 1.0)

    fun summarize(
        stats: Collection<LevelStats>, engineName: String, experience: String, tcText: String, partial: Boolean,
        pgn: String = "", expSha: String = "none"
    ): Summary {
        val results = ArrayList<LevelResult>()
        var num = 0.0
        var den = 0.0
        for (st in stats.sortedBy { it.elo }) {
            val n = st.played
            if (n == 0) continue
            val raw = (st.w + 0.5 * st.d) / n
            val bound = when {
                st.w == 0 && st.d == 0 -> Bound.UPPER
                st.l == 0 && st.d == 0 -> Bound.LOWER
                else -> Bound.NONE
            }
            val s = raw.coerceIn(0.5 / n, 1.0 - 0.5 / n)   // avoid infinite Elo on 0% / 100%
            val variance = (st.w * (1 - s) * (1 - s) + st.d * (0.5 - s) * (0.5 - s) + st.l * s * s) / n
            val err = 1.96 * sqrt(variance / n)
            val lo = max(s - err, 0.5 / n)
            val hi = min(s + err, 1.0 - 0.5 / n)
            val est = st.elo + eloFromScore(s)
            val half = if (bound == Bound.NONE) (eloFromScore(hi) - eloFromScore(lo)) / 2 else 0.0
            results.add(LevelResult(st.elo, st.w, st.d, st.l, raw, est, half, bound))
            if (bound == Bound.NONE) {            // inverse-variance weight: levels near 50% say the most
                val wt = n * s * (1 - s)
                num += wt * est
                den += wt
            }
        }
        var overall: Double? = null
        var ob = Bound.NONE
        if (den > 0) {
            overall = num / den
        } else {
            val uppers = results.filter { it.bound == Bound.UPPER }
            val lowers = results.filter { it.bound == Bound.LOWER }
            if (uppers.isNotEmpty()) { overall = uppers.minOf { it.estimate }; ob = Bound.UPPER }
            else if (lowers.isNotEmpty()) { overall = lowers.maxOf { it.estimate }; ob = Bound.LOWER }
        }
        return Summary(System.currentTimeMillis(), engineName, experience, tcText, results, overall, ob, partial, pgn, expSha)
    }

    fun fmt(x: Double): String = String.format(Locale.US, "%.0f", x)

    fun overallText(sm: Summary): String {
        val o = sm.overall ?: return "-"
        return when (sm.overallBound) {
            Bound.UPPER -> "\u2264 ${fmt(o)}"
            Bound.LOWER -> "\u2265 ${fmt(o)}"
            Bound.NONE -> "\u2248 ${fmt(o)}"
        }
    }

    fun levelText(r: LevelResult): String = when (r.bound) {
        Bound.UPPER -> "\u2264 ${fmt(r.estimate)}"
        Bound.LOWER -> "\u2265 ${fmt(r.estimate)}"
        Bound.NONE -> "${fmt(r.estimate)} \u00b1${fmt(r.halfWidth)}"
    }

    /** Plain-text summary used for sharing and for the history list. */
    fun toText(sm: Summary): String {
        val sb = StringBuilder()
        sb.append("JORO calibration").append(if (sm.partial) " (partiel)" else "").append('\n')
        sb.append("Engine: ").append(sm.engineName).append('\n')
        sb.append("Experience: ").append(sm.experience).append('\n')
        sb.append("TC: ").append(sm.tcText).append('\n')
        for (r in sm.levels) {
            sb.append(String.format(Locale.US, "SF %d : +%d =%d -%d  (%.1f%%)  JORO %s\n",
                r.elo, r.w, r.d, r.l, r.score * 100, levelText(r)))
        }
        sb.append("=> JORO ").append(overallText(sm)).append(" Elo\n")
        sb.append("(UCI_Elo of Stockfish is calibrated at its own time control: use it to compare JORO versions.)")
        return sb.toString()
    }
}
