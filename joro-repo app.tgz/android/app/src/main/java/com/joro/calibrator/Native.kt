package com.joro.calibrator

/** Engine code running inside the app (same C++ as the UCI engine, but called directly: no UCI, no process). */
object Native {
    init { System.loadLibrary("joro_native") }

    // ---- board / opening (moves are ints: from | to<<6 | promo<<12 | flag<<15)
    @JvmStatic external fun boardInfo(moves: IntArray): String          // "64 cells|w|status"
    @JvmStatic external fun legalMoves(moves: IntArray): IntArray
    @JvmStatic external fun movesToSan(moves: IntArray): String         // "1. e4 e5 2. Nf3"
    @JvmStatic external fun parseSanLine(text: String): IntArray?       // null if the text is not a legal line

    // ---- calibration only: the engines speak UCI, the PGN needs SAN
    @JvmStatic external fun sanFromUci(fen: String, uciMoves: String): String

    // ---- training (one handle = one opening)
    @JvmStatic external fun trainCreate(
        moves: IntArray, expPath: String, depth: Int, maxGames: Int, stable: Int, confirm: Int,
        drawFail: Boolean, hashMb: Int
    ): Long
    @JvmStatic external fun trainStep(handle: Long): IntArray           // see appapi.h for the layout
    @JvmStatic external fun trainStop(handle: Long)
    @JvmStatic external fun trainDestroy(handle: Long)
}

fun moveFrom(m: Int): Int = m and 63
fun moveTo(m: Int): Int = (m shr 6) and 63
fun movePromo(m: Int): Int = (m shr 12) and 7   // 2 N, 3 B, 4 R, 5 Q

class BoardView(val cells: CharArray, val whiteToMove: Boolean, val status: Int)

fun parseBoard(s: String): BoardView? {
    if (s.length < 68 || s.startsWith("ERR")) return null
    return BoardView(s.substring(0, 64).toCharArray(), s[65] == 'w', s[67] - '0')
}
