package com.joro.calibrator

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TrainOpening(val name: String, val moves: List<Int>)

data class TrainParams(
    val depth: Int, val maxGames: Int, val stable: Int, val confirm: Int, val drawFail: Boolean, val hashMb: Int
)

data class OpeningResult(
    val name: String, val games: Int, val white: Int, val black: Int, val draws: Int,
    val newBad: Int, val newGood: Int, val verdict: String
)

data class TrainState(
    val running: Boolean = false,
    val openingName: String = "",
    val openingIndex: Int = 0,
    val openingTotal: Int = 0,
    val game: Int = 0,
    val maxGames: Int = 0,
    val white: Int = 0, val black: Int = 0, val draws: Int = 0,
    val newBad: Int = 0, val newGood: Int = 0,     // since the start of the run, all openings
    val entries: Int = 0,
    val log: List<String> = emptyList(),
    val results: List<OpeningResult> = emptyList(),
    val message: String = ""
)

/**
 * The training runs inside the app process: the C++ engine/trainer is called directly through JNI (no UCI).
 * Like the calibration it is owned by the process and kept alive by [TrainingService].
 * Every finished game is written to joro.exp, so a killed process loses at most one game.
 */
object TrainingController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow(TrainState())
    val state: StateFlow<TrainState> = _state
    private var job: Job? = null
    private val lock = Any()
    private var handle = 0L
    @Volatile private var stopRequested = false

    private val reasons = listOf("mat", "pat", "50 move", "repetition", "material tsy ampy", "max plies", "adjudicated", "?")

    @Synchronized
    fun start(ctx: Context, queue: List<TrainOpening>, p: TrainParams): String? {
        if (_state.value.running) return "Efa mandeha ny training."
        if (CalibrationController.state.value.running) return "Mandeha ny calibrate: andraso ny faran'izany."
        if (queue.isEmpty()) return "Tsy misy opening hanaovana training."
        val app = ctx.applicationContext
        val storage = Storage(app)
        storage.expFile.parentFile?.mkdirs()
        val expPath = storage.expFile.absolutePath
        stopRequested = false
        _state.value = TrainState(running = true, openingTotal = queue.size, maxGames = p.maxGames,
            entries = storage.currentExpInfo()?.entries?.toInt() ?: 0)

        job = scope.launch(Dispatchers.IO) {
            val results = ArrayList<OpeningResult>()
            var totalBad = 0
            var totalGood = 0
            for ((idx, op) in queue.withIndex()) {
                if (stopRequested) break
                val h = Native.trainCreate(op.moves.toIntArray(), expPath, p.depth, p.maxGames, p.stable, p.confirm, p.drawFail, p.hashMb)
                if (h == 0L) {
                    log("Tsy afaka nanomboka ny training (experience simba na opening tsy mety).")
                    break
                }
                synchronized(lock) { handle = h }
                _state.update { it.copy(openingName = op.name, openingIndex = idx + 1, game = 0, white = 0, black = 0, draws = 0) }
                var last: IntArray? = null
                var opBad = 0
                var opGood = 0
                while (true) {
                    val r = Native.trainStep(h)
                    if (r.isEmpty() || r[0] < 0 || r[0] == 2) break          // error or stopped
                    last = r
                    opBad += r[3]; opGood += r[4]; totalBad += r[3]; totalGood += r[4]
                    val res = when (r[1]) { 1 -> "1-0"; -1 -> "0-1"; else -> "1/2" }
                    val line = "${op.name} #${r[9]}: $res ${r[2]} plies (${reasons[r[10].coerceIn(0, 7)]})  +bad ${r[3]} +good ${r[4]}"
                    _state.update {
                        it.copy(game = r[9], white = r[6], black = r[7], draws = r[8], entries = r[5],
                            newBad = totalBad, newGood = totalGood, log = (it.log + line).takeLast(40))
                    }
                    if (r[0] == 1 || stopRequested) break
                }
                synchronized(lock) { handle = 0 }
                Native.trainDestroy(h)
                val l = last
                if (l != null) {
                    val verdict = when {
                        p.confirm > 0 && l[13] >= p.confirm && l[12] == 1 -> "White nandresy ${l[13]} lalao misesy"
                        p.confirm > 0 && l[13] >= p.confirm && l[12] == -1 -> "Black nandresy ${l[13]} lalao misesy"
                        l[14] >= p.stable -> "tsy nisy zava-baovao intsony"
                        l[9] >= p.maxGames -> "tapitra ny budget lalao"
                        else -> "natsahana"
                    }
                    results.add(OpeningResult(op.name, l[9], l[6], l[7], l[8], opBad, opGood, verdict))
                } else {
                    results.add(OpeningResult(op.name, 0, 0, 0, 0, 0, 0, "tsy nisy lalao vita"))
                }
                _state.update { it.copy(results = results.toList()) }
            }
            _state.update {
                it.copy(running = false, results = results.toList(),
                    message = if (stopRequested) "Natsahana. Voatahiry ao amin'ny joro.exp ny efa nianarana." else "Training vita.")
            }
        }
        ContextCompat.startForegroundService(app, Intent(app, TrainingService::class.java))
        return null
    }

    fun stop() {
        stopRequested = true
        synchronized(lock) { if (handle != 0L) Native.trainStop(handle) }   // interrupts the game being played
    }

    private fun log(line: String) { _state.update { it.copy(log = (it.log + line).takeLast(40)) } }
}
