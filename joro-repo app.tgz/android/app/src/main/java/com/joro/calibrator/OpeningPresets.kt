package com.joro.calibrator

/** Named opening lines in standard algebraic notation (parsed by the engine, no UCI). */
data class Preset(val name: String, val san: String)

object OpeningPresets {
    val all: List<Preset> = listOf(
        Preset("Ruy Lopez", "1.e4 e5 2.Nf3 Nc6 3.Bb5"),
        Preset("Italian Game", "1.e4 e5 2.Nf3 Nc6 3.Bc4 Nf6"),
        Preset("Scotch Game", "1.e4 e5 2.Nf3 Nc6 3.d4 exd4 4.Nxd4 Nf6"),
        Preset("Four Knights", "1.e4 e5 2.Nf3 Nc6 3.Nc3 Nf6 4.Bb5 Bb4"),
        Preset("Petrov Defence", "1.e4 e5 2.Nf3 Nf6 3.Nxe5 d6 4.Nf3 Nxe4"),
        Preset("Sicilian Najdorf-type", "1.e4 c5 2.Nf3 d6 3.d4 cxd4 4.Nxd4 Nf6 5.Nc3"),
        Preset("Sicilian (Nc6)", "1.e4 c5 2.Nf3 Nc6 3.d4 cxd4 4.Nxd4 Nf6"),
        Preset("Sicilian Closed", "1.e4 c5 2.Nc3 Nc6 3.g3 g6"),
        Preset("French Defence", "1.e4 e6 2.d4 d5 3.Nc3 Nf6"),
        Preset("French Winawer", "1.d4 e6 2.e4 d5 3.Nc3 Bb4"),
        Preset("Caro-Kann", "1.e4 c6 2.d4 d5 3.Nc3 dxe4 4.Nxe4 Bf5"),
        Preset("Pirc Defence", "1.e4 d6 2.d4 Nf6 3.Nc3 g6"),
        Preset("Modern Defence", "1.e4 g6 2.d4 Bg7 3.Nc3 d6"),
        Preset("Queen's Gambit Declined", "1.d4 d5 2.c4 e6 3.Nc3 Nf6"),
        Preset("Slav Defence", "1.d4 d5 2.c4 c6 3.Nf3 Nf6 4.Nc3"),
        Preset("Nimzo-Indian", "1.d4 Nf6 2.c4 e6 3.Nc3 Bb4"),
        Preset("King's Indian", "1.d4 Nf6 2.c4 g6 3.Nc3 Bg7 4.e4 d6"),
        Preset("Dutch Defence", "1.d4 f5 2.g3 Nf6 3.Bg2 e6"),
        Preset("London System", "1.d4 d5 2.Nf3 Nf6 3.Bf4 e6"),
        Preset("English (Nc6)", "1.c4 e5 2.Nc3 Nf6 3.Nf3 Nc6"),
        Preset("English Symmetrical", "1.c4 Nf6 2.Nc3 e6 3.Nf3 d5"),
        Preset("Reti / Catalan setup", "1.Nf3 d5 2.g3 Nf6 3.Bg2 e6"),
        Preset("Queen's Indian setup", "1.Nf3 Nf6 2.c4 b6 3.g3 Bb7")
    )
}
