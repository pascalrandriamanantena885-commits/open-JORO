// JORO - search.h : alpha-beta search + experience-aware root
#pragma once
#include "board.h"
#include "eval.h"
#include "experience.h"
#include <atomic>
#include <chrono>
#include <vector>

namespace joro {

const int MAXPLY = 128, INF_SCORE = 32000, MATE = 31000, MATE_BOUND = MATE - MAXPLY;

struct Limits {
    int depth = 0;           // 0 = no depth limit
    int64_t movetime = 0;    // ms
    int64_t time[2] = {0, 0};
    int64_t inc[2] = {0, 0};
    int movestogo = 0;
    int64_t nodes = 0;
    bool infinite = false;
};

struct SearchResult {
    Move best = MOVE_NONE;
    Move ponder = MOVE_NONE;
    int score = 0;
    int depth = 0;
    int64_t nodes = 0;
    bool fromExperience = false;
};

struct TTEntry { U64 key; Move move; int16_t score; int8_t depth; uint8_t bound; };

class Searcher {
public:
    Style style;
    bool useExperience = true;
    bool strictStyle = true;   // experience made with another style is ignored
    bool quiet = false;        // true = no "info" output (trainer / JNI)
    int moveOverhead = 30;     // ms
    std::atomic<bool> stopFlag;

    Searcher();
    void setHash(int mb);
    void clear();
    void setExperience(const Experience* e) { exp = e; }

    // Caller must set stopFlag=false before calling.
    SearchResult go(Board& board, const Limits& lim);

private:
    Board* b = nullptr;
    const Experience* exp = nullptr;
    std::vector<TTEntry> tt;
    size_t ttMask = 0;
    Move killers[MAXPLY][2];
    int history[2][64][64];
    Move pv[MAXPLY][MAXPLY];
    int pvLen[MAXPLY];
    std::vector<Move> rootMoves;
    Limits lim;
    int64_t nodes = 0, softMs = 0, hardMs = 0;
    std::chrono::steady_clock::time_point t0;
    bool halt = false, canStop = false, warnedStyle = false;

    int64_t elapsedMs() const;
    void checkTime();
    int search(int depth, int alpha, int beta, int ply, bool nullOk);
    int qsearch(int alpha, int beta, int ply);
    int drawScore(int ply) const { return (ply & 1) ? style.contempt() : -style.contempt(); }
    int scoreMove(Move m, Move ttMove, int ply) const;
    bool hasNonPawn(int c) const;
};

} // namespace joro
