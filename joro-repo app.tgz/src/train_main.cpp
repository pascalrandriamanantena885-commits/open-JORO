// JORO - train_main.cpp : command line trainer (same code is used by the Android app through JNI)
#include "trainer.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <cstring>

using namespace joro;

static void usage() {
    printf("joro_train --opening \"e2e4 e7e5 ...\" | --openings FILE   [options]\n"
           "  --fen FEN         start position (default: startpos)\n"
           "  --in FILE         continue from an existing experience file\n"
           "  --out FILE        experience file to write (default joro.exp)\n"
           "  --depth N         search depth in self-play (8)\n"
           "  --games N         max games per opening (200)\n"
           "  --stable N        stop after N games that taught nothing (3)\n"
           "  --confirm N       stop when the same side wins N games in a row (5)\n"
           "  --draw-ok         a draw is accepted (default: a draw is a failure)\n"
           "  --hash MB         hash per side (16)\n"
           "  --style-file F    JORO style file (styles/joro.style). The experience is bound to this style\n"
           "  --set name=value  override one style weight (e.g. --set enemy_king=120)\n");
}

int main(int argc, char** argv) {
    initTables();
    TrainConfig cfg;
    std::string fen = START_FEN, in, out = "joro.exp", openingStr, openingsFile;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        auto next = [&]() -> std::string { return i + 1 < argc ? argv[++i] : ""; };
        if (a == "--opening") openingStr = next();
        else if (a == "--openings") openingsFile = next();
        else if (a == "--fen") fen = next();
        else if (a == "--in") in = next();
        else if (a == "--out") out = next();
        else if (a == "--depth") cfg.depth = atoi(next().c_str());
        else if (a == "--games") cfg.maxGames = atoi(next().c_str());
        else if (a == "--stable") cfg.stableLimit = atoi(next().c_str());
        else if (a == "--confirm") cfg.confirmWins = atoi(next().c_str());
        else if (a == "--hash") cfg.hashMB = atoi(next().c_str());
        else if (a == "--draw-ok") cfg.drawIsFail = false;
        else if (a == "--style-file") {
            std::string err;
            if (!cfg.style.load(next(), &err)) { printf("cannot load style: %s\n", err.c_str()); return 1; }
        } else if (a == "--set") {
            std::string kv = next();
            size_t eq = kv.find('=');
            if (eq == std::string::npos || !cfg.style.set(kv.substr(0, eq), atoi(kv.c_str() + eq + 1))) { usage(); return 1; }
        } else { usage(); return 1; }
    }
    std::vector<std::string> lines;
    if (!openingStr.empty()) lines.push_back(openingStr);
    if (!openingsFile.empty()) {
        std::ifstream f(openingsFile);
        std::string l;
        while (std::getline(f, l)) if (!l.empty() && l[0] != '#') lines.push_back(l);
    }
    if (lines.empty()) { usage(); return 1; }

    printf("style: %s id %016llx\n", cfg.style.name.c_str(), (unsigned long long)cfg.style.id());
    Experience exp;
    if (!in.empty()) {
        std::string err;
        if (!exp.load(in, &err)) { printf("cannot load %s (%s)\n", in.c_str(), err.c_str()); return 1; }
        printf("loaded %zu entries from %s\n", exp.size(), in.c_str());
        if (!exp.compatibleWith(cfg.style)) {
            printf("ERROR: %s was made with another style (%016llx). Use the same --style-file, or start a new file.\n", in.c_str(), (unsigned long long)exp.styleId());
            return 1;
        }
    }
    exp.setStyle(cfg.style);

    Trainer tr(exp, cfg);
    tr.onGame = [](int g, const GameRecord& r, int nb, int ng) {
        printf("  game %3d: %-7s %3zu plies (%s)  +bad %d +good %d\n", g,
               r.result == 1 ? "1-0" : (r.result == -1 ? "0-1" : "1/2-1/2"), r.moves.size(), r.reason.c_str(), nb, ng);
        fflush(stdout);
    };
    for (size_t k = 0; k < lines.size(); k++) {
        std::istringstream is(lines[k]);
        std::vector<std::string> mv;
        std::string t;
        while (is >> t) mv.push_back(t);
        printf("opening %zu/%zu: %s\n", k + 1, lines.size(), lines[k].c_str());
        std::string err;
        TrainStats st = tr.trainOpening(fen, mv, &err);
        if (!err.empty()) { printf("  error: %s\n", err.c_str()); continue; }
        printf("  => games %d  W %d  B %d  D %d | new bad %d, new good %d, exhausted %d | entries %zu\n", st.games,
               st.whiteWins, st.blackWins, st.draws, st.newBad, st.newGood, st.exhausted, exp.size());
        if (!exp.save(out)) { printf("cannot write %s\n", out.c_str()); return 1; }
    }
    printf("saved %s (%zu entries)\n", out.c_str(), exp.size());
    return 0;
}
