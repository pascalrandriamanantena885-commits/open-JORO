#include "appapi.h"
#include "san.h"
#include <cctype>
#include <cstdio>
#include <cstdlib>

namespace joro { namespace app {

static bool replay(Board& b, const std::vector<int>& moves) {
    if (!b.setFen(START_FEN)) return false;
    for (int mi : moves) {
        Move m = (Move)mi, mv[256];
        int n = b.genLegal(mv);
        bool ok = false;
        for (int k = 0; k < n; k++) if (mv[k] == m) { ok = true; break; }
        if (!ok) return false;
        b.makeMove(m);
    }
    return true;
}

std::string boardInfo(const std::vector<int>& moves) {
    Board b;
    if (!replay(b, moves)) return "ERR";
    std::string out(64, '.');
    const char* pc = " pnbrqk";
    for (int s = 0; s < 64; s++) {
        int p = b.sq[s];
        if (!p) continue;
        char c = pc[typeOf(p)];
        out[s] = colorOf(p) == WHITE ? (char)toupper(c) : c;
    }
    Move mv[256];
    int n = b.genLegal(mv);
    int status = n == 0 ? (b.inCheck() ? 2 : 3) : (b.inCheck() ? 1 : 0);
    out += '|';
    out += b.side == WHITE ? 'w' : 'b';
    out += '|';
    out += char('0' + status);
    return out;
}

std::vector<int> legalMoves(const std::vector<int>& moves) {
    Board b;
    std::vector<int> r;
    if (!replay(b, moves)) return r;
    Move mv[256];
    int n = b.genLegal(mv);
    for (int i = 0; i < n; i++) r.push_back((int)mv[i]);
    return r;
}

std::string sanLine(const std::vector<int>& moves) {
    Board b;
    b.setFen(START_FEN);
    std::string out;
    for (size_t i = 0; i < moves.size(); i++) {
        Move m = (Move)moves[i];
        if (b.side == WHITE) out += std::to_string(b.fullmove) + ". ";
        else if (i == 0) out += std::to_string(b.fullmove) + "... ";
        out += moveToSan(b, m);
        out += ' ';
        b.makeMove(m);
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    return out;
}

bool parseSanLine(const std::string& text, std::vector<int>& out) {
    out.clear();
    Board b;
    b.setFen(START_FEN);
    std::string tok;
    auto flush = [&]() -> bool {
        if (tok.empty()) return true;
        std::string t = tok;
        tok.clear();
        size_t dot = t.rfind('.');          // "1.e4" or "12..." : drop the move number
        if (dot != std::string::npos) t = t.substr(dot + 1);
        if (t.empty()) return true;
        if (t == "1-0" || t == "0-1" || t == "1/2-1/2" || t == "*") return true;
        Move m = parseSan(b, t);
        if (m == MOVE_NONE) return false;
        out.push_back((int)m);
        b.makeMove(m);
        return true;
    };
    for (char c : text) {
        if (isspace((unsigned char)c)) { if (!flush()) return false; }
        else tok += c;
    }
    return flush();
}

std::string sanFromUci(const std::string& fen, const std::string& uciMoves) {
    Board b;
    if (!b.setFen(fen)) return "";
    std::string out, tok;
    size_t i = 0;
    int shown = 0;
    while (i <= uciMoves.size()) {
        if (i == uciMoves.size() || uciMoves[i] == ' ') {
            if (!tok.empty()) {
                Move m = b.parseMove(tok);
                if (m == MOVE_NONE) break;                  // an illegal move is not part of the record
                if (b.side == WHITE) out += std::to_string(b.fullmove) + ". ";
                else if (shown == 0) out += std::to_string(b.fullmove) + "... ";
                out += moveToSan(b, m) + " ";
                b.makeMove(m);
                shown++;
                tok.clear();
            }
        } else tok += uciMoves[i];
        i++;
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    return out;
}

// ------------------------------------------------------------------ training
static int reasonCode(const std::string& r) {
    if (r == "checkmate") return 0;
    if (r == "stalemate") return 1;
    if (r == "50-move") return 2;
    if (r == "repetition") return 3;
    if (r == "insufficient material") return 4;
    if (r == "max plies") return 5;
    if (r == "adjudicated") return 6;
    return 7;
}

static bool fileExists(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb");
    if (!f) return false;
    fclose(f);
    return true;
}

TrainHandle* trainCreate(const std::vector<int>& moves, const std::string& expPath, int depth, int maxGames,
                         int stable, int confirm, bool drawFail, int hashMb, std::string* err) {
    initTables();
    Board b;
    if (!replay(b, moves)) { if (err) *err = "opening not legal"; return nullptr; }
    TrainHandle* h = new TrainHandle();
    for (int m : moves) h->opening.push_back((Move)m);
    h->path = expPath;
    if (fileExists(expPath)) {
        std::string e;
        if (!h->exp.load(expPath, &e)) { if (err) *err = e; delete h; return nullptr; }
    }
    Style st;                                  // an existing experience keeps its style: same JORO everywhere
    if (h->exp.hasStyle() && !h->exp.isLegacy()) h->exp.getStyle(st);   // (a pre-KHTI experience is upgraded)
    h->exp.setStyle(st);
    h->cfg.style = st;
    h->cfg.depth = depth;
    h->cfg.maxGames = maxGames;
    h->cfg.stableLimit = stable;
    h->cfg.confirmWins = confirm;
    h->cfg.drawIsFail = drawFail;
    h->cfg.hashMB = hashMb;
    h->trainer = new Trainer(h->exp, h->cfg);
    return h;
}

static bool saveAtomic(const Experience& e, const std::string& path) {
    std::string tmp = path + ".tmp";
    if (!e.save(tmp)) return false;
    return std::rename(tmp.c_str(), path.c_str()) == 0;
}

std::vector<int> trainStep(TrainHandle* h) {
    GameRecord rec;
    int nb = 0, ng = 0;
    std::string err;
    bool ok = h->trainer->step(START_FEN, h->opening, h->sess, rec, nb, ng, &err);
    if (!ok) return {h->trainer->wasStopped() ? 2 : -1};
    saveAtomic(h->exp, h->path);                // after every game: nothing is lost if Android kills the process
    const TrainStats& s = h->sess.stats;
    return {h->sess.finished ? 1 : 0, rec.result, (int)rec.moves.size(), nb, ng, (int)h->exp.size(),
            s.whiteWins, s.blackWins, s.draws, s.games, reasonCode(rec.reason), s.exhausted,
            h->sess.streakSide, h->sess.streakLen, h->sess.stable};
}

void trainStop(TrainHandle* h) { if (h && h->trainer) h->trainer->stop(); }
void trainDestroy(TrainHandle* h) { delete h; }

}} // namespace joro::app
