// JORO - appapi.h : everything the Android app needs for the board and the TRAINING, as plain C++ (no JNI, no UCI).
// native_jni.cpp only wraps these functions. Moves travel as ints (the engine's own move encoding).
#pragma once
#include "trainer.h"
#include <string>
#include <vector>

namespace joro { namespace app {

// "64 chars (a1..h8, FEN letters, '.' = empty)|w or b|status" status: 0 ok, 1 check, 2 checkmate, 3 stalemate; "ERR" if invalid
std::string boardInfo(const std::vector<int>& moves);
std::vector<int> legalMoves(const std::vector<int>& moves);
std::string sanLine(const std::vector<int>& moves);                 // "1. e4 e5 2. Nf3 Nc6"
bool parseSanLine(const std::string& text, std::vector<int>& out);  // "1.e4 e5 2.Nf3" -> moves

// Calibration games only: the engines speak UCI, so the game record arrives as UCI text; the PGN needs SAN.
std::string sanFromUci(const std::string& fen, const std::string& uciMoves);

struct TrainHandle {
    Experience exp;
    TrainConfig cfg;
    Trainer* trainer = nullptr;
    TrainSession sess;
    std::vector<Move> opening;
    std::string path;
    ~TrainHandle() { delete trainer; }
};

// Loads (or creates) the experience file and prepares the training of one opening. nullptr on error.
TrainHandle* trainCreate(const std::vector<int>& moves, const std::string& expPath, int depth, int maxGames,
                         int stable, int confirm, bool drawFail, int hashMb, std::string* err);
// One game. Returns {status, result, plies, newBad, newGood, entries, W, B, D, games, reasonCode, exhausted,
//                    streakSide, streakLen, stable}; status: 0 go on, 1 finished, 2 stopped, -1 error.
std::vector<int> trainStep(TrainHandle* h);
void trainStop(TrainHandle* h);
void trainDestroy(TrainHandle* h);

}} // namespace joro::app
