// JNI glue. Everything real lives in src/ (referee.h, appapi.h); no UCI is involved in the training path.
#include <jni.h>
#include <string>
#include <vector>
#include "appapi.h"
#include "referee.h"

using namespace joro;

static std::vector<int> toVec(JNIEnv* env, jintArray a) {
    std::vector<int> v;
    if (!a) return v;
    jsize n = env->GetArrayLength(a);
    v.resize((size_t)n);
    if (n > 0) env->GetIntArrayRegion(a, 0, n, v.data());
    return v;
}

static jintArray toArr(JNIEnv* env, const std::vector<int>& v) {
    jintArray r = env->NewIntArray((jsize)v.size());
    if (!v.empty()) env->SetIntArrayRegion(r, 0, (jsize)v.size(), v.data());
    return r;
}

static std::string toStr(JNIEnv* env, jstring s) {
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r = c ? c : "";
    env->ReleaseStringUTFChars(s, c);
    return r;
}

static JavaVM* g_vm = nullptr;

extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    initTables();  // once, before any worker thread builds a Board
    return JNI_VERSION_1_6;
}

// ---- Referee (calibration games)
JNIEXPORT jint JNICALL Java_com_joro_calibrator_Referee_nativeStatus(JNIEnv* env, jclass, jstring fen, jstring moves) {
    return refereeStatus(toStr(env, fen), toStr(env, moves));
}

// ---- board / opening
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_boardInfo(JNIEnv* env, jclass, jintArray moves) {
    return env->NewStringUTF(app::boardInfo(toVec(env, moves)).c_str());
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_legalMoves(JNIEnv* env, jclass, jintArray moves) {
    return toArr(env, app::legalMoves(toVec(env, moves)));
}
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_movesToSan(JNIEnv* env, jclass, jintArray moves) {
    return env->NewStringUTF(app::sanLine(toVec(env, moves)).c_str());
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_parseSanLine(JNIEnv* env, jclass, jstring text) {
    std::vector<int> out;
    if (!app::parseSanLine(toStr(env, text), out)) return nullptr;
    return toArr(env, out);
}

JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_sanFromUci(JNIEnv* env, jclass, jstring fen, jstring moves) {
    return env->NewStringUTF(app::sanFromUci(toStr(env, fen), toStr(env, moves)).c_str());
}

// ---- JORO vs external engine (Stockfish): the callback is a Kotlin object with  fun bestMove(fen: String, moves: IntArray): Int

// ---- training
JNIEXPORT jlong JNICALL Java_com_joro_calibrator_Native_trainCreate(
    JNIEnv* env, jclass, jintArray moves, jstring expPath, jint depth, jint depthStrong, jint msWeak, jint msStrong, jint maxGames, jint stable, jint confirm,
    jboolean drawFail, jint hashMb, jdouble varyFirstPct, jstring label) {
    std::string err;
    app::TrainHandle* h = app::trainCreate(toVec(env, moves), toStr(env, expPath), depth, depthStrong, msWeak, msStrong, maxGames, stable, confirm,
                                           drawFail != 0, hashMb, varyFirstPct, toStr(env, label), &err);
    return (jlong)(intptr_t)h;
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_trainStep(JNIEnv* env, jclass, jlong handle) {
    return toArr(env, app::trainStep((app::TrainHandle*)(intptr_t)handle));
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_trainStop(JNIEnv*, jclass, jlong handle) {
    app::trainStop((app::TrainHandle*)(intptr_t)handle);
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_trainSetOpponent(JNIEnv* env, jclass, jlong handle, jint joroSide, jobject cb) {
    jobject ref = cb ? env->NewGlobalRef(cb) : nullptr;       // lives as long as the process (one per training run)
    if (!ref) { app::trainSetOpponent((app::TrainHandle*)(intptr_t)handle, joroSide, nullptr); return; }
    jclass cls = env->GetObjectClass(ref);
    jmethodID mid = env->GetMethodID(cls, "bestMove", "(Ljava/lang/String;[I)I");
    app::trainSetOpponent((app::TrainHandle*)(intptr_t)handle, joroSide,
        [ref, mid](const std::string& fen, const std::vector<int>& moves) -> int {
            JNIEnv* e = nullptr;
            bool attached = false;
            if (g_vm->GetEnv((void**)&e, JNI_VERSION_1_6) != JNI_OK) {
                if (g_vm->AttachCurrentThread(&e, nullptr) != JNI_OK) return 0;
                attached = true;
            }
            jstring jf = e->NewStringUTF(fen.c_str());
            jintArray ja = toArr(e, moves);
            jint r = e->CallIntMethod(ref, mid, jf, ja);
            if (e->ExceptionCheck()) { e->ExceptionClear(); r = 0; }
            e->DeleteLocalRef(jf);
            e->DeleteLocalRef(ja);
            if (attached) g_vm->DetachCurrentThread();
            return (int)r;
        });
}
// Mixed opponents: cb is a Kotlin object with  fun bestMove(fen: String, moves: IntArray): Int  and  fun prepare(elo: Int): Boolean
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_trainSetMix(JNIEnv* env, jclass, jlong handle, jobject cb) {
    app::TrainHandle* h = (app::TrainHandle*)(intptr_t)handle;
    if (!cb) return;
    jobject ref = env->NewGlobalRef(cb);
    jclass cls = env->GetObjectClass(ref);
    jmethodID best = env->GetMethodID(cls, "bestMove", "(Ljava/lang/String;[I)I");
    jmethodID prep = env->GetMethodID(cls, "prepare", "(I)Z");
    auto withEnv = [](auto&& fn) {
        JNIEnv* e = nullptr;
        bool attached = false;
        if (g_vm->GetEnv((void**)&e, JNI_VERSION_1_6) != JNI_OK) {
            if (g_vm->AttachCurrentThread(&e, nullptr) != JNI_OK) return;
            attached = true;
        }
        fn(e);
        if (attached) g_vm->DetachCurrentThread();
    };
    app::trainSetMix(h,
        [ref, best, withEnv](const std::string& fen, const std::vector<int>& moves) -> int {
            int r = 0;
            withEnv([&](JNIEnv* e) {
                jstring jf = e->NewStringUTF(fen.c_str());
                jintArray ja = toArr(e, moves);
                r = (int)e->CallIntMethod(ref, best, jf, ja);
                if (e->ExceptionCheck()) { e->ExceptionClear(); r = 0; }
                e->DeleteLocalRef(jf);
                e->DeleteLocalRef(ja);
            });
            return r;
        },
        [ref, prep, withEnv](int elo) -> bool {
            bool r = false;
            withEnv([&](JNIEnv* e) {
                r = e->CallBooleanMethod(ref, prep, (jint)elo) != JNI_FALSE;
                if (e->ExceptionCheck()) { e->ExceptionClear(); r = false; }
            });
            return r;
        });
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_runBegin(JNIEnv* env, jclass, jstring statsPath, jstring pgnPrefix, jint pgnSplit, jint wSelf,
                                                                jint wLadder, jint wMax, jint need, jint window, jstring ladderFile, jboolean reset) {
    app::runBegin(toStr(env, statsPath), toStr(env, pgnPrefix), pgnSplit, wSelf, wLadder, wMax, need, window, toStr(env, ladderFile), reset != 0);
}
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_runEnd(JNIEnv* env, jclass) {
    return env->NewStringUTF(app::runEnd().c_str());
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_trainFinish(JNIEnv*, jclass, jlong handle) {
    app::trainFinish((app::TrainHandle*)(intptr_t)handle);
}
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_trainLastOpponent(JNIEnv* env, jclass, jlong handle) {
    return env->NewStringUTF(app::trainLastOpponent((app::TrainHandle*)(intptr_t)handle).c_str());
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_setStartFen(JNIEnv* env, jclass, jstring fen) {
    app::setStartFen(toStr(env, fen));
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_gateRun(
    JNIEnv* env, jclass, jstring basePath, jstring candPath, jintArray openingsFlat, jint gamesPerStart, jint movetimeMs) {
    return toArr(env, app::gateRun(toStr(env, basePath), toStr(env, candPath), toVec(env, openingsFlat), gamesPerStart, movetimeMs));
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_gateRunSprt(
    JNIEnv* env, jclass, jstring basePath, jstring candPath, jintArray openingsFlat, jint movetimeMs, jint maxGames) {
    return toArr(env, app::gateRunSprt(toStr(env, basePath), toStr(env, candPath), toVec(env, openingsFlat), movetimeMs, maxGames));
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_gateStop(JNIEnv*, jclass, jboolean s) { app::gateStop(s != 0); }
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_trainPause(JNIEnv*, jclass, jlong handle, jboolean p) {
    app::trainPause((app::TrainHandle*)(intptr_t)handle, p != 0);
}
JNIEXPORT jboolean JNICALL Java_com_joro_calibrator_Native_trainWaiting(JNIEnv*, jclass, jlong handle) {
    return app::trainWaiting((app::TrainHandle*)(intptr_t)handle) ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_trainLive(JNIEnv* env, jclass, jlong handle) {
    return toArr(env, app::trainLive((app::TrainHandle*)(intptr_t)handle));
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_trainDestroy(JNIEnv*, jclass, jlong handle) {
    app::trainDestroy((app::TrainHandle*)(intptr_t)handle);
}

// ---- live games (read-only, see appapi.h): never touches joro.exp
JNIEXPORT jlong JNICALL Java_com_joro_calibrator_Native_liveCreate(JNIEnv* env, jclass, jstring expPath, jboolean useExperience, jint hashMb) {
    std::string err;
    app::LiveHandle* h = app::liveCreate(toStr(env, expPath), useExperience != 0, hashMb, &err);
    return (jlong)(intptr_t)h;
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_liveNewGame(JNIEnv*, jclass, jlong handle) { app::liveNewGame((app::LiveHandle*)(intptr_t)handle); }
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_liveJoroMove(JNIEnv* env, jclass, jlong handle, jintArray moves, jint depth, jint movetimeMs) {
    return toArr(env, app::liveJoroMove((app::LiveHandle*)(intptr_t)handle, toVec(env, moves), depth, movetimeMs));
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_liveStop(JNIEnv*, jclass, jlong handle) { app::liveStop((app::LiveHandle*)(intptr_t)handle); }
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_liveInfo(JNIEnv* env, jclass, jlong handle) {
    return env->NewStringUTF(app::liveInfo((app::LiveHandle*)(intptr_t)handle).c_str());
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_liveDestroy(JNIEnv*, jclass, jlong handle) { app::liveDestroy((app::LiveHandle*)(intptr_t)handle); }
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_liveOutcome(JNIEnv* env, jclass, jintArray moves) {
    return toArr(env, app::liveOutcome(toVec(env, moves)));
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_livePlans(JNIEnv* env, jclass, jlong handle, jintArray moves) {
    return toArr(env, app::livePlans((app::LiveHandle*)(intptr_t)handle, toVec(env, moves)));
}

// ---- SPSA tuning (style weights + search constants)
JNIEXPORT jlong JNICALL Java_com_joro_calibrator_Native_tuneCreate(
    JNIEnv* env, jclass, jstring openings, jstring statePath, jstring startPath, jint pairs, jint movetimeMs, jint threads, jint hashMb,
    jdouble eta, jint seed, jboolean tuneStyle, jboolean tuneSearch, jboolean tunePlans, jboolean resume) {
    std::string err;
    app::TuneHandle* h = app::tuneCreate(toStr(env, openings), toStr(env, statePath), toStr(env, startPath), pairs, movetimeMs, threads, hashMb, eta, seed,
                                         tuneStyle != 0, tuneSearch != 0, tunePlans != 0, resume != 0, &err);
    return (jlong)(intptr_t)h;
}
// ---- new JORO version: engine file with the tuning / experience inside, and the tuned values as a C++ header
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_packEngine(JNIEnv* env, jclass, jstring inEngine, jstring outEngine, jstring tuningPath,
                                                                    jstring expPath, jstring label) {
    std::string err;
    bool ok = app::packEngineFile(toStr(env, inEngine), toStr(env, outEngine), toStr(env, tuningPath), toStr(env, expPath), toStr(env, label), &err);
    return env->NewStringUTF(ok ? "" : (err.empty() ? "error" : err.c_str()));
}
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_tuningHeader(JNIEnv* env, jclass, jstring tuningPath, jstring label) {
    return env->NewStringUTF(app::tuningHeaderText(toStr(env, tuningPath), toStr(env, label)).c_str());
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_tuneStep(JNIEnv* env, jclass, jlong handle) {
    return toArr(env, app::tuneStep((app::TuneHandle*)(intptr_t)handle));
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_tuneVerifyStep(JNIEnv* env, jclass, jlong handle) {
    return toArr(env, app::tuneVerifyStep((app::TuneHandle*)(intptr_t)handle));
}
JNIEXPORT jboolean JNICALL Java_com_joro_calibrator_Native_tuneSetSprt(JNIEnv*, jclass, jlong handle, jboolean enabled, jdouble elo0, jdouble elo1,
                                                                        jdouble alpha, jdouble beta) {
    return app::tuneSetSprt((app::TuneHandle*)(intptr_t)handle, enabled != 0, elo0, elo1, alpha, beta) ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_tuneSprtInfo(JNIEnv* env, jclass, jlong handle) {
    return toArr(env, app::tuneSprtInfo((app::TuneHandle*)(intptr_t)handle));
}
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_tuneSprtText(JNIEnv* env, jclass, jlong handle) {
    return env->NewStringUTF(app::tuneSprtText((app::TuneHandle*)(intptr_t)handle).c_str());
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_tuneStop(JNIEnv*, jclass, jlong handle) { app::tuneStop((app::TuneHandle*)(intptr_t)handle); }
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_tunePause(JNIEnv*, jclass, jlong handle, jboolean p) {
    app::tunePause((app::TuneHandle*)(intptr_t)handle, p != 0);
}
JNIEXPORT jboolean JNICALL Java_com_joro_calibrator_Native_tuneWaiting(JNIEnv*, jclass, jlong handle) {
    return app::tuneWaiting((app::TuneHandle*)(intptr_t)handle) ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jintArray JNICALL Java_com_joro_calibrator_Native_tuneInfo(JNIEnv* env, jclass, jlong handle) {
    return toArr(env, app::tuneInfo((app::TuneHandle*)(intptr_t)handle));
}
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_tuneTable(JNIEnv* env, jclass, jlong handle) {
    return env->NewStringUTF(app::tuneTable((app::TuneHandle*)(intptr_t)handle).c_str());
}
JNIEXPORT jstring JNICALL Java_com_joro_calibrator_Native_tuneVerifyText(JNIEnv* env, jclass, jlong handle) {
    return env->NewStringUTF(app::tuneVerifyText((app::TuneHandle*)(intptr_t)handle).c_str());
}
JNIEXPORT jboolean JNICALL Java_com_joro_calibrator_Native_tuneExport(JNIEnv* env, jclass, jlong handle, jstring path) {
    return app::tuneExport((app::TuneHandle*)(intptr_t)handle, toStr(env, path)) ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT void JNICALL Java_com_joro_calibrator_Native_tuneDestroy(JNIEnv*, jclass, jlong handle) { app::tuneDestroy((app::TuneHandle*)(intptr_t)handle); }
JNIEXPORT jboolean JNICALL Java_com_joro_calibrator_Native_applyTuning(JNIEnv* env, jclass, jstring tuningPath, jstring expPath) {
    std::string err;
    return app::applyTuning(toStr(env, tuningPath), toStr(env, expPath), &err) ? JNI_TRUE : JNI_FALSE;
}

}  // extern "C"
