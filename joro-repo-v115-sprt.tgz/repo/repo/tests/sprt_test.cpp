// JORO - sprt_test.cpp : checks the SPRT module (formulas, bounds, and the error rates by simulation).
//   g++ -O2 -std=c++17 -Isrc tests/sprt_test.cpp -o sprt_test && ./sprt_test
#include "sprt.h"
#include <cstdio>
#include <random>

using namespace joro;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

// One game of a "true Elo" engine against another, with a draw ratio: P(W), P(D), P(L) giving the logistic expected score.
static int game(std::mt19937& rng, double elo, double drawRatio) {
    const double s = sprtScore(elo);
    double pw = s - drawRatio / 2, pl = 1 - s - drawRatio / 2;
    if (pw < 0) pw = 0;
    if (pl < 0) pl = 0;
    double u = std::uniform_real_distribution<double>(0, 1)(rng);
    if (u < pw) return 1;
    if (u < pw + drawRatio) return 0;
    return -1;
}

// Runs the test until it decides (max `cap` games). Returns the decision; games = number used.
static int runTest(std::mt19937& rng, double trueElo, const SprtConfig& c, int cap, int& games) {
    int w = 0, d = 0, l = 0;
    for (int i = 1; i <= cap; i++) {
        int r = game(rng, trueElo, 0.4);
        if (r > 0) w++; else if (r < 0) l++; else d++;
        SprtResult res = sprtEvaluate(w, d, l, c);
        if (res.decision != SPRT_CONTINUE) { games = i; return res.decision; }
    }
    games = cap;
    return SPRT_CONTINUE;
}

int main() {
    SprtConfig c;
    c.enabled = true; c.elo0 = 0; c.elo1 = 10; c.alpha = 0.05; c.beta = 0.05; c.minGames = 20;

    // bounds
    CHECK(std::fabs(sprtUpperBound(c) - 2.9444) < 1e-3);
    CHECK(std::fabs(sprtLowerBound(c) + 2.9444) < 1e-3);
    // no game: no decision, LLR 0
    SprtResult r0 = sprtEvaluate(0, 0, 0, c);
    CHECK(r0.llr == 0 && r0.decision == SPRT_CONTINUE);
    // sign of the LLR follows the score
    CHECK(sprtEvaluate(60, 40, 30, c).llr > 0);
    CHECK(sprtEvaluate(30, 40, 60, c).llr < 0);
    // exactly between s0 and s1: LLR ~ 0
    CHECK(std::fabs(sprtEvaluate(300, 400, 300, c).llr) < 1.0);   // 50% score is nearer to s0 (0 Elo): small negative
    // perfect start does not blow up, and min games is respected
    SprtResult p = sprtEvaluate(10, 0, 0, c);
    CHECK(std::isfinite(p.llr) && p.decision == SPRT_CONTINUE);   // 10 games < minGames
    SprtResult p2 = sprtEvaluate(40, 0, 0, c);
    CHECK(std::isfinite(p2.llr) && p2.decision == SPRT_H1);
    SprtResult p3 = sprtEvaluate(0, 0, 40, c);
    CHECK(std::isfinite(p3.llr) && p3.decision == SPRT_H0);
    // invalid config is harmless
    SprtConfig bad = c; bad.elo0 = 20;
    CHECK(sprtEvaluate(50, 0, 0, bad).decision == SPRT_CONTINUE);
    // parsing
    SprtConfig pc;
    CHECK(sprtParse("0,5", pc) && pc.elo0 == 0 && pc.elo1 == 5 && pc.enabled);
    CHECK(sprtParse("-2.5,3,0.1,0.1", pc) && pc.alpha == 0.1 && pc.beta == 0.1 && pc.elo0 == -2.5);
    CHECK(!sprtParse("5,0", pc));
    CHECK(!sprtParse("abc", pc));
    CHECK(!sprtParse("1", pc));

    // simulated error rates: with alpha = beta = 0.05 the observed rates must stay in the same range
    std::mt19937 rng(12345);
    const int runs = 1500;
    struct Case { double elo; const char* name; } cases[] = {{0, "true 0 Elo (H0)"}, {10, "true +10 Elo (H1)"}, {-30, "true -30 Elo"}, {40, "true +40 Elo"}};
    double h1rate[4];
    for (int k = 0; k < 4; k++) {
        int h1 = 0, h0 = 0, none = 0;
        long long total = 0;
        for (int i = 0; i < runs; i++) {
            int g;
            int dcs = runTest(rng, cases[k].elo, c, 60000, g);
            total += g;
            if (dcs == SPRT_H1) h1++; else if (dcs == SPRT_H0) h0++; else none++;
        }
        h1rate[k] = (double)h1 / runs;
        printf("%-20s  H1 %5.1f%%  H0 %5.1f%%  undecided %d  mean games %lld\n", cases[k].name, 100.0 * h1 / runs, 100.0 * h0 / runs, none,
               total / runs);
    }
    CHECK(h1rate[0] < 0.09);        // alpha 5% (+ margin: the normal approximation is not exact)
    CHECK(h1rate[1] > 0.88);        // 1 - beta
    CHECK(h1rate[2] < 0.005);       // a clearly worse engine almost never passes
    CHECK(h1rate[3] > 0.99);        // a clearly better one almost always does

    // gate configuration (H0: -40 Elo, H1: 0, 10% risks, at most 120 games; undecided -> reject under 45%)
    SprtConfig g;
    g.enabled = true; g.elo0 = -40; g.elo1 = 0; g.alpha = 0.1; g.beta = 0.1; g.minGames = 20;
    struct GCase { double elo; const char* name; } gc[] = {{0, "gate: equal (should pass)"}, {-20, "gate: -20 Elo"}, {-40, "gate: -40 Elo (should reject)"}, {-80, "gate: -80 Elo"}};
    double reject[4];
    for (int k = 0; k < 4; k++) {
        int rej = 0, und = 0;
        long long total = 0;
        for (int i = 0; i < runs; i++) {
            int w = 0, d = 0, l = 0, n = 0, dcs = SPRT_CONTINUE;
            for (; n < 120 && dcs == SPRT_CONTINUE; n++) {
                int r = game(rng, gc[k].elo, 0.4);
                if (r > 0) w++; else if (r < 0) l++; else d++;
                dcs = sprtEvaluate(w, d, l, g).decision;
            }
            total += n;
            if (dcs == SPRT_CONTINUE) { und++; if ((w + 0.5 * d) / n < 0.45) rej++; }
            else if (dcs == SPRT_H0) rej++;
        }
        reject[k] = (double)rej / runs;
        printf("%-30s  rejected %5.1f%%  undecided at 120: %5.1f%%  mean games %lld\n", gc[k].name, 100.0 * reject[k], 100.0 * und / runs, total / runs);
    }
    CHECK(reject[0] < 0.20);        // an equal experience is rarely thrown away
    CHECK(reject[2] > 0.50);        // a -40 Elo regression is caught about 6 times out of 10 within 120 games (honest limit of a small gate)
    CHECK(reject[3] > 0.95);        // a big regression always

    // the old gate for comparison: 16 games, reject under 45%
    for (int k = 0; k < 4; k++) {
        int rej = 0;
        for (int i = 0; i < runs; i++) {
            int w = 0, d = 0;
            for (int n = 0; n < 16; n++) { int r = game(rng, gc[k].elo, 0.4); if (r > 0) w++; else if (r == 0) d++; }
            if ((w + 0.5 * d) / 16 < 0.45) rej++;
        }
        printf("old gate (16 games, <45%%) %-8s rejected %5.1f%%\n", k == 0 ? "equal" : k == 1 ? "-20" : k == 2 ? "-40" : "-80", 100.0 * rej / runs);
    }

    printf(fails ? "SPRT TEST FAILED (%d)\n" : "sprt_test OK\n", fails);
    return fails ? 1 : 0;
}
