// JORO - gate.h : A/B gate for a freshly trained experience (new vs the previous one)
#pragma once
#include "search.h"
#include "sprt.h"
#include <atomic>
#include <string>
#include <vector>

namespace joro {

struct GateStart { std::string fen; std::vector<Move> moves; };   // start position + opening moves

struct GateResult {
    int wins = 0, draws = 0, losses = 0;          // from the candidate's point of view
    int decision = SPRT_CONTINUE;                  // SPRT gate only: SPRT_H1 = not worse (accept), SPRT_H0 = regression (reject)
    double llr = 0;
    int games() const { return wins + draws + losses; }
    double score() const { return games() ? (wins + 0.5 * draws) / games() : 0.5; }
};

// Verdict: SPRT_H0 -> reject, SPRT_H1 -> accept, undecided (or no SPRT) -> the old rule, reject under 45 %.
inline bool gateRejects(const GateResult& r) {
    if (r.decision == SPRT_H0) return true;
    if (r.decision == SPRT_H1) return false;
    return r.score() < 0.45;
}
// Default gate test: H0 = worse by 40 Elo or more, H1 = not worse; 10 % risks (a phone cannot afford more games).
inline SprtConfig gateSprtDefault() { SprtConfig c; c.enabled = true; c.elo0 = -40; c.elo1 = 0; c.alpha = 0.1; c.beta = 0.1; c.minGames = 20; return c; }

// Plays candidate-vs-base games from every start (the candidate has each colour in turn), equal time per move.
// Both sides use the base's style. Stops early when *stop becomes true.
// SPRT gate: pass `sprt` (H0 = the candidate is worse by elo0 or more, H1 = not worse than elo1, e.g. -40 / 0) and `maxGames` (> 0):
// the starts are played again and again (two games each, both colours) until the test decides or maxGames is reached. result.decision
// tells which; SPRT_CONTINUE = not decided at maxGames (the caller falls back on score()).
GateResult gateExperience(const Experience& cand, const Experience& base, const std::vector<GateStart>& starts,
                          int gamesPerStart, int movetimeMs, std::atomic<bool>* stop = nullptr, const SprtConfig* sprt = nullptr,
                          int maxGames = 0);

} // namespace joro
