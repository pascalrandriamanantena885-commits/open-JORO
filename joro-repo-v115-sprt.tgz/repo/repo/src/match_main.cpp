// JORO - match_main.cpp : A/B test of two styles (or two experience files) at equal time per move.
//   joro_match --a styles/joro.style --b styles/neutral.style --openings tools/lines.txt --movetime 50
//   add --sprt 0,10 to stop as soon as the SPRT decides (H1: A is better than B by >= 10 Elo, H0: A is not better than 0 Elo)
#include "search.h"
#include "sprt.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>

using namespace joro;

static int playOne(Searcher& white, Searcher& black, const std::string& fen, const std::vector<std::string>& opening, int movetime) {
    Board b;
    b.setFen(fen);
    for (auto& s : opening) { Move m = b.parseMove(s); if (!m) return 0; b.makeMove(m); }
    white.clear(); black.clear();
    int streak = 0, sign = 0;
    for (int ply = 0; ply < 400; ply++) {
        Move mv[256];
        if (b.genLegal(mv) == 0) return b.inCheck() ? (b.side == WHITE ? -1 : 1) : 0;
        if (b.halfmove >= 100) return 0;
        int reps = 1;
        for (auto& u : b.hist) if (u.hash == b.hash) reps++;
        if (reps >= 3) return 0;
        Searcher& s = b.side == WHITE ? white : black;
        s.stopFlag = false;
        Limits lim;
        lim.movetime = movetime;
        SearchResult r = s.go(b, lim);
        int w = b.side == WHITE ? r.score : -r.score;
        if (std::abs(w) >= 900) { int sg = w > 0 ? 1 : -1; streak = sg == sign ? streak + 1 : 1; sign = sg; }
        else { streak = 0; sign = 0; }
        if (streak >= 6) return sign;
        b.makeMove(r.best);
    }
    return 0;
}

int main(int argc, char** argv) {
    initTables();
    Searcher A, B;
    A.quiet = B.quiet = true;
    std::string openings = "tools/lines.txt";
    int movetime = 50, from = 0, to = 1000000;
    SprtConfig sprt;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        auto next = [&]() -> std::string { return i + 1 < argc ? argv[++i] : ""; };
        if (a == "--a") A.style.load(next());
        else if (a == "--b") B.style.load(next());
        else if (a == "--set-a" || a == "--set-b") {
            std::string kv = next();
            size_t eq = kv.find('=');
            (a == "--set-a" ? A : B).style.set(kv.substr(0, eq), atoi(kv.c_str() + eq + 1));
        }
        else if (a == "--openings") openings = next();
        else if (a == "--movetime") movetime = atoi(next().c_str());
        else if (a == "--from") from = atoi(next().c_str());
        else if (a == "--to") to = atoi(next().c_str());
        else if (a == "--sprt") {
            if (!sprtParse(next(), sprt)) { printf("bad --sprt (use E0,E1[,ALPHA,BETA] with E0 < E1, 0 < ALPHA,BETA < 0.5)\n"); return 1; }
        }
    }
    std::vector<std::vector<std::string>> ops;
    std::ifstream f(openings);
    std::string l;
    while (std::getline(f, l)) {
        if (l.empty() || l[0] == '#') continue;
        std::istringstream is(l);
        std::vector<std::string> v; std::string t;
        while (is >> t) v.push_back(t);
        ops.push_back(v);
    }
    int w = 0, d = 0, lo = 0;
    for (int i = from; i < (int)ops.size() && i < to; i++) {
        int r1 = playOne(A, B, START_FEN, ops[i], movetime);    // A white
        int r2 = -playOne(B, A, START_FEN, ops[i], movetime);   // A black (sign flipped to A's view)
        for (int r : {r1, r2}) { if (r > 0) w++; else if (r < 0) lo++; else d++; }
        if (sprt.enabled) {
            SprtResult sr = sprtEvaluate(w, d, lo, sprt);
            printf("opening %4d  +%d =%d -%d  LLR %.2f (%.2f ; %.2f)\n", i + 1, w, d, lo, sr.llr, sr.lower, sr.upper);
            fflush(stdout);
            if (sr.decision != SPRT_CONTINUE) break;
        }
    }
    printf("A vs B : +%d =%d -%d  (A score %.1f%%)\n", w, d, lo, 100.0 * (w + 0.5 * d) / std::max(1, w + d + lo));
    if (sprt.enabled) {
        SprtResult sr = sprtEvaluate(w, d, lo, sprt);
        printf("%s\n", sprtText(sr, sprt).c_str());
        if (sr.decision == SPRT_CONTINUE) printf("not decided: the openings ran out (more openings / a larger --sprt interval are needed)\n");
    }
    return 0;
}
