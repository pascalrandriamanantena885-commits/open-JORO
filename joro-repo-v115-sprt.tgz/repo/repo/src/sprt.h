// JORO - sprt.h : Sequential Probability Ratio Test on a W/D/L result (header only, no dependency).
//
// Question answered: "is version B really better than version A?" without fixing the number of games in advance.
//   H0 : Elo(B - A) <= elo0          H1 : Elo(B - A) >= elo1          (elo0 < elo1)
// After every game (or batch) the log-likelihood ratio LLR is updated; the test stops as soon as
//   LLR >= upper = ln((1 - beta) / alpha)   -> H1 accepted  (B is better by about elo1 or more)
//   LLR <= lower = ln(beta / (1 - alpha))   -> H0 accepted  (B is not better than elo0; reject the change)
// alpha = risk of accepting H1 when H0 is true (a useless change gets through), beta = risk of accepting H0 when H1 is true.
//
// Model: GSPRT with the normal approximation of the mean score per game (as in fishtest / fastchess, trinomial version):
//   LLR = N * (s1 - s0) * (2 * mean - s0 - s1) / (2 * var)
// s = 1 / (1 + 10^(-elo / 400)) is the expected score at that Elo (logistic scale), mean / var are the sample mean and
// variance of the score per game. A bucket (W, D or L) that is still empty counts as 0.5 game, so a perfect start (10-0)
// does not give an infinite LLR. Games played in pairs (same opening, both colours) are treated as independent games: that is
// slightly optimistic when the two games of a pair are correlated; use alpha = beta = 0.05 (or less) and do not stop on a
// handful of games (minGames).
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>

namespace joro {

struct SprtConfig {
    bool enabled = false;
    double elo0 = 0.0;       // H0: improvement <= elo0
    double elo1 = 10.0;      // H1: improvement >= elo1
    double alpha = 0.05;     // false-accept risk
    double beta = 0.05;      // false-reject risk
    int minGames = 20;       // never decide before this many games (the normal approximation is poor on a few games)
};

enum SprtDecision { SPRT_CONTINUE = 0, SPRT_H1 = 1, SPRT_H0 = -1 };

struct SprtResult {
    int w = 0, d = 0, l = 0;
    double llr = 0.0, lower = 0.0, upper = 0.0;
    int decision = SPRT_CONTINUE;
    int games() const { return w + d + l; }
    // 0 at the lower bound, 1 at the upper bound (for a progress bar)
    double progress() const {
        double r = upper > lower ? (llr - lower) / (upper - lower) : 0.5;
        return std::max(0.0, std::min(1.0, r));
    }
};

inline double sprtScore(double elo) { return 1.0 / (1.0 + std::pow(10.0, -elo / 400.0)); }

// Elo difference of a score in (0, 1); clamped so that 0% / 100% stay finite.
inline double sprtElo(double s) {
    s = std::max(0.001, std::min(0.999, s));
    return -400.0 * std::log10(1.0 / s - 1.0);
}

inline double sprtLowerBound(const SprtConfig& c) { return std::log(c.beta / (1.0 - c.alpha)); }
inline double sprtUpperBound(const SprtConfig& c) { return std::log((1.0 - c.beta) / c.alpha); }

// Valid configuration: 0 < alpha, beta < 0.5 and elo0 < elo1.
inline bool sprtValid(const SprtConfig& c) {
    return c.alpha > 0 && c.alpha < 0.5 && c.beta > 0 && c.beta < 0.5 && c.elo0 < c.elo1;
}

inline SprtResult sprtEvaluate(int w, int d, int l, const SprtConfig& c) {
    SprtResult r;
    r.w = w; r.d = d; r.l = l;
    r.lower = sprtLowerBound(c);
    r.upper = sprtUpperBound(c);
    if (w < 0 || d < 0 || l < 0 || w + d + l == 0 || !sprtValid(c)) return r;
    const double W = w > 0 ? w : 0.5, D = d > 0 ? d : 0.5, L = l > 0 ? l : 0.5;
    const double n = W + D + L;
    const double mean = (W + 0.5 * D) / n;
    const double var = (W * (1 - mean) * (1 - mean) + D * (0.5 - mean) * (0.5 - mean) + L * mean * mean) / n;
    if (var <= 1e-12) return r;
    const double s0 = sprtScore(c.elo0), s1 = sprtScore(c.elo1);
    r.llr = n * (s1 - s0) * (2.0 * mean - s0 - s1) / (2.0 * var);
    if (w + d + l >= c.minGames) {
        if (r.llr >= r.upper) r.decision = SPRT_H1;
        else if (r.llr <= r.lower) r.decision = SPRT_H0;
    }
    return r;
}

// One line, e.g. "SPRT [0, 10] a=0.05 b=0.05: LLR 1.82 (-2.94 ; 2.94) -> not decided yet"
inline std::string sprtText(const SprtResult& r, const SprtConfig& c) {
    char buf[220];
    const char* verdict = r.decision == SPRT_H1 ? "H1 accepted: really better"
                          : r.decision == SPRT_H0 ? "H0 accepted: not better (do not apply)"
                                                  : "not decided yet";
    snprintf(buf, sizeof buf, "SPRT [%g, %g] a=%g b=%g: LLR %.2f (%.2f ; %.2f) -> %s", c.elo0, c.elo1, c.alpha, c.beta, r.llr, r.lower,
             r.upper, verdict);
    return buf;
}

// "elo0,elo1[,alpha,beta]" (command line). Returns false on a bad text; fields not given keep their value.
inline bool sprtParse(const std::string& text, SprtConfig& c) {
    double v[4];
    int n = 0;
    size_t pos = 0;
    while (pos <= text.size() && n < 4) {
        size_t e = text.find(',', pos);
        std::string tok = text.substr(pos, e == std::string::npos ? std::string::npos : e - pos);
        char* end = nullptr;
        double x = strtod(tok.c_str(), &end);
        if (tok.empty() || end == tok.c_str() || *end != 0) return false;
        v[n++] = x;
        if (e == std::string::npos) break;
        pos = e + 1;
    }
    if (n < 2) return false;
    c.elo0 = v[0];
    c.elo1 = v[1];
    if (n > 2) c.alpha = v[2];
    if (n > 3) c.beta = v[3];
    c.enabled = true;
    return sprtValid(c);
}

} // namespace joro
