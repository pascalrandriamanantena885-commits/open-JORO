#include "appapi.h"
#include <sstream>
#include "embed.h"
#include "gate.h"
#include "pgn.h"
#include "san.h"
#include <atomic>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <map>

namespace joro { namespace app {

static std::string g_startFen;                 // empty = START_FEN
static std::atomic<bool> g_gateStop{false};
static const char* startFenC() { return g_startFen.empty() ? START_FEN : g_startFen.c_str(); }
void setStartFen(const std::string& fen) { g_startFen = fen; }
void gateStop(bool s) { g_gateStop = s; }

static bool replay(Board& b, const std::vector<int>& moves) {
    if (!b.setFen(startFenC())) return false;
    for (int mi : moves) {
        Move m = (Move)mi, mv[256];
        int n = b.genLegal(mv);
        bool ok = false;
        for (int k = 0; k < n; k++) if (mv[k] == m) { ok = true; break; }
        if (!ok) return false;
        b.makeMove(m);
    }
    return true;
}

std::string boardInfo(const std::vector<int>& moves) {
    Board b;
    if (!replay(b, moves)) return "ERR";
    std::string out(64, '.');
    const char* pc = " pnbrqk";
    for (int s = 0; s < 64; s++) {
        int p = b.sq[s];
        if (!p) continue;
        char c = pc[typeOf(p)];
        out[s] = colorOf(p) == WHITE ? (char)toupper(c) : c;
    }
    Move mv[256];
    int n = b.genLegal(mv);
    int status = n == 0 ? (b.inCheck() ? 2 : 3) : (b.inCheck() ? 1 : 0);
    out += '|';
    out += b.side == WHITE ? 'w' : 'b';
    out += '|';
    out += char('0' + status);
    return out;
}

std::vector<int> legalMoves(const std::vector<int>& moves) {
    Board b;
    std::vector<int> r;
    if (!replay(b, moves)) return r;
    Move mv[256];
    int n = b.genLegal(mv);
    for (int i = 0; i < n; i++) r.push_back((int)mv[i]);
    return r;
}

std::string sanLine(const std::vector<int>& moves) {
    Board b;
    b.setFen(startFenC());
    std::string out;
    for (size_t i = 0; i < moves.size(); i++) {
        Move m = (Move)moves[i];
        if (b.side == WHITE) out += std::to_string(b.fullmove) + ". ";
        else if (i == 0) out += std::to_string(b.fullmove) + "... ";
        out += moveToSan(b, m);
        out += ' ';
        b.makeMove(m);
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    return out;
}

bool parseSanLine(const std::string& text, std::vector<int>& out) {
    out.clear();
    Board b;
    b.setFen(START_FEN);
    std::string tok;
    auto flush = [&]() -> bool {
        if (tok.empty()) return true;
        std::string t = tok;
        tok.clear();
        size_t dot = t.rfind('.');          // "1.e4" or "12..." : drop the move number
        if (dot != std::string::npos) t = t.substr(dot + 1);
        if (t.empty()) return true;
        if (t == "1-0" || t == "0-1" || t == "1/2-1/2" || t == "*") return true;
        Move m = parseSan(b, t);
        if (m == MOVE_NONE) return false;
        out.push_back((int)m);
        b.makeMove(m);
        return true;
    };
    for (char c : text) {
        if (isspace((unsigned char)c)) { if (!flush()) return false; }
        else tok += c;
    }
    return flush();
}

std::string sanFromUci(const std::string& fen, const std::string& uciMoves) {
    Board b;
    if (!b.setFen(fen)) return "";
    std::string out, tok;
    size_t i = 0;
    int shown = 0;
    while (i <= uciMoves.size()) {
        if (i == uciMoves.size() || uciMoves[i] == ' ') {
            if (!tok.empty()) {
                Move m = b.parseMove(tok);
                if (m == MOVE_NONE) break;                  // an illegal move is not part of the record
                if (b.side == WHITE) out += std::to_string(b.fullmove) + ". ";
                else if (shown == 0) out += std::to_string(b.fullmove) + "... ";
                out += moveToSan(b, m) + " ";
                b.makeMove(m);
                shown++;
                tok.clear();
            }
        } else tok += uciMoves[i];
        i++;
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    return out;
}

// ------------------------------------------------------------------ training
static int reasonCode(const std::string& r) {
    if (r == "checkmate") return 0;
    if (r == "stalemate") return 1;
    if (r == "50-move") return 2;
    if (r == "repetition") return 3;
    if (r == "insufficient material") return 4;
    if (r == "max plies") return 5;
    if (r == "adjudicated") return 6;
    return 7;
}

static bool fileExists(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb");
    if (!f) return false;
    fclose(f);
    return true;
}

// ---- state of the current run (one training thread: no lock needed)
namespace {
struct OppSum { int games = 0, w = 0, d = 0, l = 0; };
struct RunState {
    bool on = false;
    OpponentPlan* plan = nullptr;
    PgnWriter* pgn = nullptr;
    OpeningStats* stats = nullptr;
    std::vector<OpeningRow> rows;
    std::map<std::string, OppSum> perOpp;
    int runNo = 0, games = 0;
    std::string date, ladderFile;
    void clear() { delete plan; delete pgn; delete stats; plan = nullptr; pgn = nullptr; stats = nullptr; rows.clear(); perOpp.clear(); on = false; games = 0; }
} g_run;
}

void runBegin(const std::string& statsPath, const std::string& pgnPrefix, int pgnSplit, int wSelf, int wLadder, int wMax,
              int ladderNeed, int ladderWindow, const std::string& ladderFile, bool ladderReset) {
    g_run.clear();
    g_run.plan = new OpponentPlan();
    g_run.plan->wSelf = wSelf; g_run.plan->wLadder = wLadder; g_run.plan->wMax = wMax;
    if (wSelf + wLadder + wMax <= 0) g_run.plan->wSelf = 100;
    g_run.plan->need = ladderNeed > 0 ? ladderNeed : 3;
    g_run.plan->window = ladderWindow > 0 ? ladderWindow : 3;
    g_run.plan->clampLevels(1320, 3190);
    g_run.ladderFile = ladderFile;
    if (!ladderReset && !ladderFile.empty()) g_run.plan->loadLevel(ladderFile);
    if (!pgnPrefix.empty()) g_run.pgn = new PgnWriter(pgnPrefix, pgnSplit);
    if (!statsPath.empty()) { g_run.stats = new OpeningStats(statsPath); g_run.stats->load(); g_run.runNo = g_run.stats->nextRun(); }
    char buf[16];
    time_t now = time(nullptr);
    strftime(buf, sizeof buf, "%Y-%m-%d", localtime(&now));
    g_run.date = buf;
    g_run.on = true;
}

std::string runEnd() {
    std::string out;
    if (g_run.on && g_run.stats && !g_run.rows.empty()) {
        out = "Run " + std::to_string(g_run.runNo) + "  (mat: halavany amin'ny hetsika, taloha > ankehitriny)\n" + g_run.stats->table(g_run.rows);
        g_run.stats->append(g_run.rows);
    }
    if (g_run.on && !g_run.perOpp.empty()) {
        out += "\nIsaky ny opponent:\n";
        char buf[160];
        for (auto& kv : g_run.perOpp) {
            const OppSum& o = kv.second;
            if (kv.first == "JORO") snprintf(buf, sizeof buf, "  %-16s %4d lalao  fotsy %d, mainty %d, draw %d\n", kv.first.c_str(), o.games, o.w, o.l, o.d);
            else snprintf(buf, sizeof buf, "  %-16s %4d lalao  JORO +%d =%d -%d (%.0f%%)\n", kv.first.c_str(), o.games, o.w, o.d, o.l,
                          o.games ? 100.0 * (o.w + 0.5 * o.d) / o.games : 0.0);
            out += buf;
        }
        if (g_run.plan && g_run.plan->wLadder > 0) out += "  Ambaratonga ankehitriny: UCI_Elo " + std::to_string(g_run.plan->levels[g_run.plan->level]) + "\n";
    }
    g_run.clear();
    return out;
}

static std::string openingIdOf(const std::string& fen, const std::vector<int>& moves) {
    Board b;
    std::vector<std::string> mv;
    if (b.setFen(fen)) for (int m : moves) { mv.push_back(Board::moveToStr((Move)m)); b.makeMove((Move)m); }
    return openingId(fen, mv);
}

TrainHandle* trainCreate(const std::vector<int>& moves, const std::string& expPath, int depth, int depthStrong, int msWeak, int msStrong, int maxGames,
                         int stable, int confirm, bool drawFail, int hashMb, double varyFirstPct, const std::string& label, std::string* err) {
    initTables();
    Board b;
    if (!replay(b, moves)) { if (err) *err = "opening not legal"; return nullptr; }
    TrainHandle* h = new TrainHandle();
    for (int m : moves) h->opening.push_back((Move)m);
    h->path = expPath;
    h->startFen = startFenC();
    if (fileExists(expPath)) {
        std::string e;
        if (!h->exp.load(expPath, &e)) { if (err) *err = e; delete h; return nullptr; }
    }
    Style st;                                  // an existing experience keeps its style: same JORO everywhere
    if (h->exp.hasStyle() && !h->exp.isLegacy()) h->exp.getStyle(st);   // (a pre-KHTI experience is upgraded)
    h->exp.setStyle(st);
    h->cfg.style = st;
    h->cfg.depth = depth;
    h->cfg.depthStrong = depthStrong;
    h->cfg.moveTimeWeak = msWeak;
    h->cfg.moveTimeStrong = msStrong;
    h->cfg.maxGames = maxGames;
    h->cfg.stableLimit = stable;
    h->cfg.confirmWins = confirm;
    h->cfg.drawIsFail = drawFail;
    h->cfg.hashMB = hashMb;
    h->cfg.varyFirstPct = varyFirstPct;
    h->label = label;
    h->acc = new OpeningAcc(openingIdOf(h->startFen, moves), label);
    h->trainer = new Trainer(h->exp, h->cfg);
    return h;
}

static bool saveAtomic(const Experience& e, const std::string& path) {
    std::string tmp = path + ".tmp";
    if (!e.save(tmp)) return false;
    return std::rename(tmp.c_str(), path.c_str()) == 0;
}

std::vector<int> trainStep(TrainHandle* h) {
    GameRecord rec;
    int nb = 0, ng = 0;
    std::string err;
    bool ok = h->trainer->step(h->startFen, h->opening, h->sess, rec, nb, ng, &err);
    if (!ok) return {h->trainer->wasStopped() ? 2 : -1};
    saveAtomic(h->exp, h->path);                // after every game: nothing is lost if Android kills the process
    h->lastOpponent = rec.opponent;
    int elo = h->curSpec.kind == OpponentSpec::LADDER ? h->curSpec.elo : 0;
    int promoted = 0, brill = 0, great = 0;
    for (uint8_t m : rec.marks) { if (m == MK_BRILLIANT) brill++; else if (m == MK_GREAT) great++; }
    if (h->acc) h->acc->add(rec, nb, elo);
    if (g_run.on) {
        OppSum& os = g_run.perOpp[rec.opponent];
        os.games++;
        g_run.games++;
        int sc = rec.result;                    // white point of view
        if (rec.joroSide >= 0) sc = rec.result == 0 ? 0 : (((rec.result == 1) == (rec.joroSide == WHITE)) ? 1 : -1);
        if (rec.joroSide < 0) { if (sc > 0) os.w++; else if (sc < 0) os.l++; else os.d++; }   // self-play: w = white wins, l = black wins
        else { if (sc > 0) os.w++; else if (sc < 0) os.l++; else os.d++; }
        if (rec.joroSide >= 0 && g_run.plan && g_run.plan->report(h->curSpec, sc > 0 ? 1.0 : (sc == 0 ? 0.5 : 0.0))) {
            promoted = 1;
            if (!g_run.ladderFile.empty()) g_run.plan->saveLevel(g_run.ladderFile);
        }
        if (g_run.pgn) g_run.pgn->add(rec, "JORO training: " + h->label);
    }
    const TrainStats& s = h->sess.stats;
    return {h->sess.finished ? 1 : 0, rec.result, (int)rec.moves.size(), nb, ng, (int)h->exp.size(),
            s.whiteWins, s.blackWins, s.draws, s.games, reasonCode(rec.reason), s.exhausted,
            h->sess.streakSide, h->sess.streakLen, h->sess.stable, ng,
            rec.joroSide, rec.sitNew, brill, great, rec.variedPly, elo, promoted};
}

void trainFinish(TrainHandle* h) {
    if (!h || !h->acc || !g_run.on || !g_run.stats || h->acc->row.games == 0) return;
    OpeningRow r = h->acc->row;
    r.run = g_run.runNo;
    r.date = g_run.date;
    g_run.stats->compare(r);
    g_run.rows.push_back(r);
}

std::string trainLastOpponent(TrainHandle* h) { return h ? h->lastOpponent : std::string(); }

void trainSetMix(TrainHandle* h, std::function<int(const std::string&, const std::vector<int>&)> engineFn, std::function<bool(int)> prepareFn) {
    if (!h || !h->trainer) return;
    Trainer* tr = h->trainer;
    Trainer::OpponentFn ef = [engineFn](const std::string& fen, const std::vector<Move>& mv) -> Move {
        std::vector<int> v(mv.begin(), mv.end());
        return (Move)engineFn(fen, v);
    };
    tr->beforeGame = [h, tr, ef, prepareFn](int) -> std::string {
        static int counter = 0;                 // colour alternates over the whole run, not per opening
        h->curSpec = (g_run.on && g_run.plan) ? g_run.plan->next() : OpponentSpec();
        if (h->curSpec.kind != OpponentSpec::SELF && !prepareFn(h->curSpec.kind == OpponentSpec::LADDER ? h->curSpec.elo : 0))
            h->curSpec = OpponentSpec();        // the engine is dead: JORO plays itself
        if (h->curSpec.kind == OpponentSpec::SELF) { tr->setOpponent(WHITE, Trainer::OpponentFn()); return h->curSpec.label; }
        tr->setOpponent((counter++ & 1) ? BLACK : WHITE, ef);
        return h->curSpec.label;
    };
}

void trainSetOpponent(TrainHandle* h, int joroSide, std::function<int(const std::string&, const std::vector<int>&)> fn) {
    if (!h || !h->trainer) return;
    h->trainer->setOpponent(joroSide, [fn](const std::string& fen, const std::vector<Move>& mv) -> Move {
        std::vector<int> v(mv.begin(), mv.end());
        return (Move)fn(fen, v);
    });
}

void trainStop(TrainHandle* h) { if (h && h->trainer) h->trainer->stop(); }
void trainPause(TrainHandle* h, bool p) { if (h && h->trainer) h->trainer->setPaused(p); }
bool trainWaiting(TrainHandle* h) { return h && h->trainer && h->trainer->isWaiting(); }
std::vector<int> trainLive(TrainHandle* h) {
    std::vector<int> out;
    if (h && h->trainer) for (Move m : h->trainer->liveMoves()) out.push_back((int)m);
    return out;
}
void trainDestroy(TrainHandle* h) { delete h; }

static bool gateLoad(const std::string& basePath, const std::string& candPath, const std::vector<int>& openingsFlat, Experience& base,
                     Experience& cand, std::vector<GateStart>& starts) {
    initTables();
    std::string err;
    if (fileExists(basePath) && !base.load(basePath, &err)) return false;
    if (!cand.load(candPath, &err)) return false;
    GateStart cur; cur.fen = START_FEN;
    bool any = false;
    for (int m : openingsFlat) {
        if (m == -1) { starts.push_back(cur); cur.moves.clear(); any = false; }
        else { cur.moves.push_back((Move)m); any = true; }
    }
    if (any) starts.push_back(cur);
    return !starts.empty();
}

std::vector<int> gateRunSprt(const std::string& basePath, const std::string& candPath, const std::vector<int>& openingsFlat,
                             int movetimeMs, int maxGames) {
    Experience base, cand;
    std::vector<GateStart> starts;
    if (!gateLoad(basePath, candPath, openingsFlat, base, cand, starts)) return {};
    g_gateStop = false;
    SprtConfig c = gateSprtDefault();
    GateResult r = gateExperience(cand, base, starts, 2, movetimeMs, &g_gateStop, &c, std::max(2, maxGames));
    return {r.wins, r.draws, r.losses, r.decision, (int)std::lround(r.llr * 1000)};
}

std::vector<int> gateRun(const std::string& basePath, const std::string& candPath, const std::vector<int>& openingsFlat,
                         int gamesPerStart, int movetimeMs) {
    initTables();
    Experience base, cand;
    std::string err;
    if (fileExists(basePath) && !base.load(basePath, &err)) return {};
    if (!cand.load(candPath, &err)) return {};
    std::vector<GateStart> starts;
    GateStart cur; cur.fen = START_FEN;
    bool any = false;
    for (int m : openingsFlat) {
        if (m == -1) { starts.push_back(cur); cur.moves.clear(); any = false; }
        else { cur.moves.push_back((Move)m); any = true; }
    }
    if (any) starts.push_back(cur);
    if (starts.empty()) return {};
    g_gateStop = false;
    GateResult r = gateExperience(cand, base, starts, gamesPerStart, movetimeMs, &g_gateStop);
    return {r.wins, r.draws, r.losses};
}

// ------------------------------------------------------------------------------------------------ live games (read-only)
LiveHandle* liveCreate(const std::string& expPath, bool useExperience, int hashMb, std::string* err) {
    initTables();
    LiveHandle* h = new LiveHandle();
    Style st;
    if (useExperience && !expPath.empty() && fileExists(expPath)) {
        std::string e;
        if (!h->exp.load(expPath, &e)) { if (err) *err = e; delete h; return nullptr; }
        h->hasExp = true;
        if (h->exp.hasStyle() && !h->exp.isLegacy()) h->exp.getStyle(st);   // same style as the trainer would use with this file
        h->expInfo = "joro.exp: " + std::to_string((long long)h->exp.size()) + " entries (read only)";
    } else {
        h->expInfo = useExperience ? "no experience file: JORO plays without memory" : "experience off: JORO plays without memory";
    }
    for (int i = 0; i < 2; i++) {
        Searcher& s = h->s[i];
        s.quiet = true;
        s.style = st;
        s.setHash(hashMb > 0 ? hashMb : 16);
        s.setExperience(h->hasExp ? &h->exp : nullptr);
        s.useExperience = h->hasExp;
        s.brain = true;
        s.planD = true;            // Plan D: steer toward positions the experience knows when plans A / B / C are stalled
    }
    return h;
}

void liveNewGame(LiveHandle* h) {
    if (!h) return;
    h->stopped = false;
    for (int i = 0; i < 2; i++) { h->s[i].stopFlag = false; h->s[i].clear(); }
}

std::vector<int> liveJoroMove(LiveHandle* h, const std::vector<int>& moves, int depth, int movetimeMs) {
    if (!h || h->stopped) return {0, 0, 0, 0, 0, 0};
    Board b;
    if (!replay(b, moves)) return {0, 0, 0, 0, 0, 0};
    Move mv[256];
    if (b.genLegal(mv) == 0) return {0, 0, 0, 0, 0, 0};
    Searcher& s = h->s[b.side];
    s.stopFlag = false;
    if (h->stopped) return {0, 0, 0, 0, 0, 0};                // liveStop arrived between the two tests
    Limits lim;
    if (movetimeMs > 0) lim.movetime = movetimeMs;
    else lim.depth = depth > 0 ? depth : 6;
    SearchResult r = s.go(b, lim);                              // mateTraps of r are deliberately NOT recorded anywhere
    if (h->stopped || r.best == MOVE_NONE) return {0, r.score, r.depth, 0, 0, 0};
    int64_t nodes = r.nodes > 2000000000LL ? 2000000000LL : r.nodes;
    return {(int)r.best, r.score, r.depth, r.fromExperience ? 1 : 0, r.brainRejected, (int)nodes, r.planD ? 1 : 0, r.dPly, r.dKind, r.dSit, r.dGuard ? 1 : 0};
}

void liveStop(LiveHandle* h) {
    if (!h) return;
    h->stopped = true;
    h->s[0].stopFlag = true;
    h->s[1].stopFlag = true;
}
std::string liveInfo(LiveHandle* h) { return h ? h->expInfo : std::string(); }
void liveDestroy(LiveHandle* h) { delete h; }

static bool noMatingMaterial(const Board& b) {
    int minors = 0;
    for (int s = 0; s < 64; s++) {
        int t = typeOf(b.sq[s]);
        if (t == PAWN || t == ROOK || t == QUEEN) return false;
        if (t == KNIGHT || t == BISHOP) minors++;
    }
    return minors <= 1;
}

std::vector<int> liveOutcome(const std::vector<int>& moves) {
    Board b;
    if (!replay(b, moves)) return {};
    Move mv[256];
    if (b.genLegal(mv) == 0) {
        if (b.inCheck()) return {1, b.side == WHITE ? -1 : 1, 0};
        return {1, 0, 1};
    }
    if (b.halfmove >= 100) return {1, 0, 2};
    int reps = 1;
    for (auto& u : b.hist) if (u.hash == b.hash) reps++;
    if (reps >= 3) return {1, 0, 3};
    if (noMatingMaterial(b)) return {1, 0, 4};
    return {0, 0, 0};
}

std::vector<int> livePlans(LiveHandle* h, const std::vector<int>& moves) {
    Board b;
    if (!h || !replay(b, moves)) return {0, 0};
    const int* pp = h->s[0].sp.v + SPR_PLAN_FIRST;
    return {selectPlan(b, WHITE, pp), selectPlan(b, BLACK, pp)};
}

// ------------------------------------------------------------------------------------------------ SPSA tuning
TuneHandle* tuneCreate(const std::string& openingsText, const std::string& statePath, const std::string& startPath, int pairs, int movetimeMs,
                       int threads, int hashMb, double eta, int seed, bool tuneStyle, bool tuneSearch, bool tunePlans, bool resume, std::string* err) {
    initTables();
    std::vector<TuneStart> starts = parseTuneStarts(openingsText);
    if (starts.empty()) { if (err) *err = "no usable start position"; return nullptr; }
    Style st;
    SearchParams sp;
    if (!startPath.empty() && fileExists(startPath)) {
        std::string e;
        if (!loadTuning(startPath, st, sp, &e)) { if (err) *err = e; return nullptr; }
    }
    TuneConfig cfg;
    cfg.pairs = pairs > 0 ? pairs : 8;
    cfg.movetimeMs = movetimeMs > 0 ? movetimeMs : 40;
    cfg.threads = threads > 0 ? threads : 2;
    cfg.hashMB = hashMb > 0 ? hashMb : 8;
    if (eta > 0) cfg.eta = eta;
    cfg.seed = (unsigned)(seed > 0 ? seed : 1);
    cfg.tuneStyle = tuneStyle;
    cfg.tuneSearch = tuneSearch;
    cfg.tunePlans = tunePlans;
    TuneHandle* h = new TuneHandle();
    h->tuner = new Tuner(cfg, std::move(starts), st, sp);
    h->statePath = statePath;
    if (h->tuner->paramCount() == 0) { if (err) *err = "nothing to tune"; delete h; return nullptr; }
    if (resume && fileExists(statePath)) {
        std::string e;
        if (!h->tuner->loadState(statePath, &e)) { if (err) *err = e; delete h; return nullptr; }
    }
    return h;
}

std::vector<int> tuneStep(TuneHandle* h) {
    TuneStep s;
    int rc = h->tuner->step(s);
    if (rc != 0) return {rc, h->tuner->iteration(), (int)h->tuner->games(), 0, 0, 0};
    h->tuner->saveState(h->statePath);
    h->tuner->appendCsv(h->statePath + ".csv", s);
    return {0, s.iter, (int)s.games, s.w, s.d, s.l};
}

std::vector<int> tuneVerifyStep(TuneHandle* h) {
    int w = 0, d = 0, l = 0;
    int rc = h->tuner->verifyStep(w, d, l);
    int tw, td, tl;
    h->tuner->verifyTotals(tw, td, tl);
    if (rc == 0) h->tuner->saveState(h->statePath);
    std::vector<int> out = {rc, w, d, l, tw, td, tl};
    if (h->tuner->sprtConfig().enabled) {
        SprtResult r = h->tuner->sprtResult();
        out.push_back(r.decision);
        out.push_back((int)std::lround(r.llr * 1000));
        out.push_back((int)std::lround(r.lower * 1000));
        out.push_back((int)std::lround(r.upper * 1000));
    }
    return out;
}

bool tuneSetSprt(TuneHandle* h, bool enabled, double elo0, double elo1, double alpha, double beta) {
    if (!h) return false;
    SprtConfig c;
    c.enabled = enabled;
    c.elo0 = elo0; c.elo1 = elo1; c.alpha = alpha; c.beta = beta;
    if (enabled && !sprtValid(c)) return false;
    h->tuner->setSprt(c);
    return true;
}

std::vector<int> tuneSprtInfo(TuneHandle* h) {
    if (!h) return {0, 0, 0, 0, 0, 0};
    const SprtConfig& c = h->tuner->sprtConfig();
    SprtResult r = h->tuner->sprtResult();
    return {r.decision, (int)std::lround(r.llr * 1000), (int)std::lround(r.lower * 1000), (int)std::lround(r.upper * 1000), r.games(),
            c.enabled ? 1 : 0};
}

std::string tuneSprtText(TuneHandle* h) {
    if (!h || !h->tuner->sprtConfig().enabled) return "";
    return sprtText(h->tuner->sprtResult(), h->tuner->sprtConfig());
}

void tuneStop(TuneHandle* h) { if (h) h->tuner->stop(); }
void tunePause(TuneHandle* h, bool paused) { if (h) h->tuner->setPaused(paused); }
bool tuneWaiting(TuneHandle* h) { return h && h->tuner->isWaiting(); }
std::vector<int> tuneInfo(TuneHandle* h) {
    if (!h) return {0, 0, 0, 0, 0};
    int w, d, l;
    h->tuner->verifyTotals(w, d, l);
    return {h->tuner->iteration(), (int)h->tuner->games(), w, d, l};
}
std::string tuneTable(TuneHandle* h) { return h ? h->tuner->table() : ""; }
std::string tuneVerifyText(TuneHandle* h) { return h ? h->tuner->verifyText() : ""; }
bool tuneExport(TuneHandle* h, const std::string& path) { return h && h->tuner->exportTuned(path); }
void tuneDestroy(TuneHandle* h) { delete h; }

static bool copyFile(const std::string& from, const std::string& to) {
    std::ifstream in(from, std::ios::binary);
    std::ofstream out(to, std::ios::binary);
    if (!in || !out) return false;
    out << in.rdbuf();
    return (bool)out;
}

bool applyTuning(const std::string& tuningPath, const std::string& expPath, std::string* err) {
    initTables();
    Style st;
    SearchParams sp;
    if (!tuningPath.empty()) {
        std::string e;
        if (!loadTuning(tuningPath, st, sp, &e)) { if (err) *err = e; return false; }
    }
    if (!expPath.empty() && fileExists(expPath)) {
        Experience exp;
        std::string e;
        if (!exp.load(expPath, &e)) { if (err) *err = e; return false; }
        copyFile(expPath, expPath + ".prestyle");
        exp.setStyle(st);
        std::string tmp = expPath + ".tmp";
        if (!exp.save(tmp) || std::rename(tmp.c_str(), expPath.c_str()) != 0) { if (err) *err = "cannot write " + expPath; return false; }
    }
    defaultSearchParams() = sp;
    return true;
}

bool packEngineFile(const std::string& inEngine, const std::string& outEngine, const std::string& tuningPath, const std::string& expPath,
                    const std::string& label, std::string* err) {
    std::string text;
    if (!tuningPath.empty() && fileExists(tuningPath)) {
        std::ifstream f(tuningPath);
        std::stringstream ss;
        ss << f.rdbuf();
        text = ss.str();
    }
    return packEngine(inEngine, outEngine, text, fileExists(expPath) ? expPath : "", label, err);
}

std::string tuningHeaderText(const std::string& tuningPath, const std::string& label) {
    std::ifstream f(tuningPath);
    if (!f) return "";
    std::stringstream ss;
    ss << f.rdbuf();
    return tuningAsHeader(ss.str(), label);
}

}} // namespace joro::app
