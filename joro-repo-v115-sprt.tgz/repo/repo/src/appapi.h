// JORO - appapi.h : everything the Android app needs for the board and the TRAINING, as plain C++ (no JNI, no UCI).
// native_jni.cpp only wraps these functions. Moves travel as ints (the engine's own move encoding).
#pragma once
#include "trainer.h"
#include "opponent.h"
#include "opstats.h"
#include "tuner.h"
#include <functional>
#include <string>
#include <vector>

namespace joro { namespace app {

// "64 chars (a1..h8, FEN letters, '.' = empty)|w or b|status" status: 0 ok, 1 check, 2 checkmate, 3 stalemate; "ERR" if invalid
std::string boardInfo(const std::vector<int>& moves);
std::vector<int> legalMoves(const std::vector<int>& moves);
std::string sanLine(const std::vector<int>& moves);                 // "1. e4 e5 2. Nf3 Nc6"
bool parseSanLine(const std::string& text, std::vector<int>& out);  // "1.e4 e5 2.Nf3" -> moves

// Calibration games only: the engines speak UCI, so the game record arrives as UCI text; the PGN needs SAN.
std::string sanFromUci(const std::string& fen, const std::string& uciMoves);

struct TrainHandle {
    Experience exp;
    TrainConfig cfg;
    Trainer* trainer = nullptr;
    TrainSession sess;
    std::vector<Move> opening;
    std::string path;
    std::string startFen;      // start position of this training (set by setStartFen before trainCreate)
    std::string label;         // name of the opening (PGN event, per-opening table)
    OpeningAcc* acc = nullptr; // per-opening statistics of this run
    OpponentSpec curSpec;      // opponent of the game being played (mixed mode)
    std::string lastOpponent;  // label of the opponent of the last finished game
    ~TrainHandle() { delete trainer; delete acc; }
};

// Loads (or creates) the experience file and prepares the training of one opening. nullptr on error.
// varyFirstPct: chance (percent) that JORO's first move after the opening is its 2nd best. label: name of the opening.
TrainHandle* trainCreate(const std::vector<int>& moves, const std::string& expPath, int depth, int depthStrong, int msWeak, int msStrong, int maxGames,
                         int stable, int confirm, bool drawFail, int hashMb, double varyFirstPct, const std::string& label, std::string* err);
// One game. Returns {status, result, plies, newBad, newGood, entries, W, B, D, games, reasonCode, exhausted,
//                    streakSide, streakLen, stable, brilliantThisGame,
//                    joroSide (-1 = JORO vs JORO, 0/1 = colour of JORO vs an engine), sitNew (new situations), brilliantMarks, greatMarks,
//                    variedPly (-1 = none), opponentElo (0 = none / full strength), ladderMoved (1 = the ladder went up)}; status: 0 go on, 1 finished, 2 stopped, -1 error.
std::vector<int> trainStep(TrainHandle* h);
void trainStop(TrainHandle* h);
// Start position used by the board helpers and by the NEXT trainCreate (empty = the standard start). Used by the board editor (custom start position).
void setStartFen(const std::string& fen);
// A/B gate: candidate experience file vs base file. openingsFlat = moves of each start separated by -1 (startpos only).
// Returns {wins, draws, losses} of the candidate, or {} on error. gateStop() aborts a running gate.
std::vector<int> gateRun(const std::string& basePath, const std::string& candPath, const std::vector<int>& openingsFlat,
                         int gamesPerStart, int movetimeMs);
// Same with the SPRT gate (see gate.h): {wins, draws, losses, decision (1 accept, -1 reject, 0 undecided -> use the 45% rule), LLR*1000}.
std::vector<int> gateRunSprt(const std::string& basePath, const std::string& candPath, const std::vector<int>& openingsFlat,
                             int movetimeMs, int maxGames);
void gateStop(bool stop);
// JORO vs an external engine: joroSide 0 = white, 1 = black; fn(startFen, moves so far) returns the engine's move.
void trainSetOpponent(TrainHandle* h, int joroSide, std::function<int(const std::string&, const std::vector<int>&)> fn);
// ---- a RUN = all the openings of one press on "Hanomboka": opponents, PGN and the per-opening table are shared by them.
// Mixed opponents (needs trainSetMix on every handle): weights of JORO itself / Stockfish ladder / Stockfish full strength.
void runBegin(const std::string& statsPath, const std::string& pgnPrefix, int pgnSplit, int wSelf, int wLadder, int wMax,
              int ladderNeed, int ladderWindow, const std::string& ladderFile, bool ladderReset);
// Writes the table to the CSV and returns it as text (with the per-opponent summary); "" if nothing was played.
std::string runEnd();
// engineFn(fen, moves) = the external engine's move; prepareFn(elo) puts the engine at that UCI_Elo (0 = full strength), false = engine dead.
void trainSetMix(TrainHandle* h, std::function<int(const std::string&, const std::vector<int>&)> engineFn, std::function<bool(int)> prepareFn);
std::string trainLastOpponent(TrainHandle* h);
void trainFinish(TrainHandle* h);                      // call after the last step of an opening (before trainDestroy)
void trainPause(TrainHandle* h, bool paused);          // thread-safe; the game sleeps at the next move
bool trainWaiting(TrainHandle* h);                     // true once it really sleeps
std::vector<int> trainLive(TrainHandle* h);            // moves of the game being played (opening + moves so far)
void trainDestroy(TrainHandle* h);


// ---- LIVE games (the "Live" tab): JORO vs JORO or JORO vs an external engine, played only to WATCH how the engine plays.
// Nothing here ever writes to the experience: the file is only READ (a private copy in the handle, may be switched off), no BAD /
// brilliant / mate-trap is recorded, nothing is saved. Training (trainCreate / trainStep) is the only path that changes joro.exp.
// The game itself is driven by the caller (Kotlin): it asks for JORO's move, or Stockfish's through UCI, and checks liveOutcome().
struct LiveHandle {
    Experience exp;
    bool hasExp = false;       // an experience was loaded (read-only) and is used by the searchers
    Searcher s[2];             // one per colour, each with its own tables (same as the trainer)
    std::atomic<bool> stopped{false};
    std::string expInfo;       // "joro.exp: 1234 entries" or why it is not used
};
// expPath may be missing / \"\" ; useExperience=false = JORO plays without its memory. nullptr on error (err filled).
LiveHandle* liveCreate(const std::string& expPath, bool useExperience, int hashMb, std::string* err);
void liveNewGame(LiveHandle* h);                       // clears the tables of both searchers, re-arms after liveStop
// JORO's move after `moves` (standard start position). depth / movetimeMs: movetimeMs > 0 wins over depth.
// Returns {move (0 = none / stopped), score cp (side to move), depth reached, fromExperience 0/1, brainRejected, nodes (clamped),
//          planD 0/1 (Plan D was steering toward known positions), dPly (plies until the planned line reaches a position the experience
//          knows, 0 = none), dKind (1 known good move, 2 good situation, 3 bad situation to avoid), dSit (situation score cp there), dGuard 0/1 (guard mode)}. An empty / stopped result has only the first 6 values.
std::vector<int> liveJoroMove(LiveHandle* h, const std::vector<int>& moves, int depth, int movetimeMs);
void liveStop(LiveHandle* h);                          // thread-safe: interrupts the search in progress
std::string liveInfo(LiveHandle* h);
void liveDestroy(LiveHandle* h);
// Is the game over after `moves`? {over 0/1, result (1 white wins, -1 black wins, 0 draw), reason (same codes as trainStep: 0 mate, 1 stalemate,
// 2 50 moves, 3 repetition, 4 insufficient material)}. {} if the moves are not legal.
std::vector<int> liveOutcome(const std::vector<int>& moves);
// The plan (selectPlan, see eval.h: 0 none, 1 A, 2 B, 3 C) each side follows in the position: {white, black}
std::vector<int> livePlans(LiveHandle* h, const std::vector<int>& moves);   // uses the tuned plan parameters of the handle's searchers

// ---- SPSA tuning (style weights + search constants), see tuner.h. One handle = one tuning run (it can be resumed from its state file).
struct TuneHandle {
    Tuner* tuner = nullptr;
    std::string statePath;
    ~TuneHandle() { delete tuner; }
};
// openingsText: one start per line (FEN or UCI moves, see parseTuneStarts). startPath: tuning/style file to start from ("" = defaults).
// resume: continue from statePath when it exists. nullptr on error (err filled).
TuneHandle* tuneCreate(const std::string& openingsText, const std::string& statePath, const std::string& startPath, int pairs, int movetimeMs,
                       int threads, int hashMb, double eta, int seed, bool tuneStyle, bool tuneSearch, bool tunePlans, bool resume, std::string* err);
// One SPSA iteration (blocks for its games). Returns {status, iter, games, W, D, L}; status 0 ok, 2 stopped, -1 error. The state is saved.
std::vector<int> tuneStep(TuneHandle* h);
// One batch of verification games (tuned vs starting values). Returns {status, W, D, L, totalW, totalD, totalL}. The state is saved.
// With tuneSetSprt the array has 4 more values: {..., decision (0 go on, 1 H1 tuned is better, -1 H0 not better), LLR*1000, lower*1000, upper*1000}.
std::vector<int> tuneVerifyStep(TuneHandle* h);
// Turns the SPRT on the verification totals on / off (call after tuneCreate). false if the values are invalid (0 < alpha, beta < 0.5, elo0 < elo1).
bool tuneSetSprt(TuneHandle* h, bool enabled, double elo0, double elo1, double alpha, double beta);
// {decision, LLR*1000, lower*1000, upper*1000, games, enabled 0/1} for the totals now (also right after a resume); text = one line.
std::vector<int> tuneSprtInfo(TuneHandle* h);
std::string tuneSprtText(TuneHandle* h);
void tuneStop(TuneHandle* h);                      // thread-safe, final for this handle
void tunePause(TuneHandle* h, bool paused);        // thread-safe; the games sleep at the next move
bool tuneWaiting(TuneHandle* h);                   // true once every worker really sleeps
// {iteration, games, verifyW, verifyD, verifyL}: where a resumed tuning stands
std::vector<int> tuneInfo(TuneHandle* h);
std::string tuneTable(TuneHandle* h);              // "name  start -> tuned  (delta)" per line
std::string tuneVerifyText(TuneHandle* h);
bool tuneExport(TuneHandle* h, const std::string& path);   // the tuned values as a tuning file
void tuneDestroy(TuneHandle* h);
// Makes a tuning file the process-wide default of every new searcher ("" = built-in defaults) and writes its style into the
// header of the experience file (entries untouched; the old file is kept as EXP.prestyle). false on error.
bool applyTuning(const std::string& tuningPath, const std::string& expPath, std::string* err);
// New JORO version: the engine file + the tuning (+ the experience) packed in one executable (see embed.h). tuningPath / expPath may be "".
bool packEngineFile(const std::string& inEngine, const std::string& outEngine, const std::string& tuningPath, const std::string& expPath,
                    const std::string& label, std::string* err);
// The tuned values as a C++ header text (for the code); "" when the tuning cannot be read.
std::string tuningHeaderText(const std::string& tuningPath, const std::string& label);

}} // namespace joro::app
