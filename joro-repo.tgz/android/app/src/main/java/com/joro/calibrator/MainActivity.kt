package com.joro.calibrator

import android.content.Intent
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) { App(vm) }
            }
        }
    }
}

@Composable
fun App(vm: MainViewModel) {
    val s by vm.ui.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().padding(top = 24.dp)) {
        Text("JORO Calibrator", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, bottom = 8.dp))
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Calibrate") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Tantara") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Import") })
        }
        when (tab) {
            0 -> CalibrateTab(vm, s)
            1 -> HistoryTab(vm, s)
            else -> ImportTab(vm, s)
        }
    }
}

private fun num(v: String) = v.filter { it.isDigit() || it == '.' }

@Composable
fun CalibrateTab(vm: MainViewModel, s: UiState) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(s.joroInfo, fontSize = 13.sp)
        Text("Experience: ${s.expInfo}", fontSize = 13.sp)

        OutlinedTextField(
            value = vm.levelsText, onValueChange = { vm.levelsText = it },
            label = { Text("Stockfish UCI_Elo (1320-3190), ohatra 2500, 2600, 2700, 3000") },
            enabled = !s.running, modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(vm.gamesText, { vm.gamesText = num(it) }, label = { Text("Lalao/level") },
                enabled = !s.running, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(vm.concurrencyText, { vm.concurrencyText = num(it) }, label = { Text("Miaraka (matrix)") },
                enabled = !s.running, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(vm.baseSecText, { vm.baseSecText = num(it) }, label = { Text("Fotoana (s)") },
                enabled = !s.running, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(vm.incMsText, { vm.incMsText = num(it) }, label = { Text("Inc (ms)") },
                enabled = !s.running, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(vm.hashText, { vm.hashText = num(it) }, label = { Text("Hash MB") },
                enabled = !s.running, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = vm.useExperience, onCheckedChange = { vm.useExperience = it }, enabled = !s.running)
            Text("Ampiasaina ny experience (joro.exp)")
        }
        if (!s.running) {
            Button(onClick = { vm.start() }, modifier = Modifier.fillMaxWidth()) { Text("Hanomboka calibrate") }
        } else {
            OutlinedButton(onClick = { vm.stop() }, modifier = Modifier.fillMaxWidth()) { Text("Atsaha (mitahiry valiny ampahany)") }
        }
        if (s.running) Text("Mitohy ao ambadika ny calibrate (notification), na dia akatona aza ny app.", fontSize = 12.sp)
        if (s.message.isNotEmpty()) Text(s.message, color = MaterialTheme.colorScheme.error)
        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) {
            Text("Battery: avelao hiasa foana ny app")
        }

        s.stats.values.sortedBy { it.elo }.forEach { st ->
            Column {
                Text("SF ${st.elo}:  ${st.played}/${st.planned}   +${st.w} =${st.d} \u2212${st.l}", fontFamily = FontFamily.Monospace)
                LinearProgressIndicator(progress = { if (st.planned == 0) 0f else st.played.toFloat() / st.planned }, modifier = Modifier.fillMaxWidth())
            }
        }
        s.summary?.let { SummaryCard(it) }
        if (s.log.isNotEmpty()) {
            Text("Log", fontWeight = FontWeight.Bold)
            s.log.takeLast(6).forEach { Text(it, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
        }
    }
}

@Composable
fun SummaryCard(sm: Summary) {
    val ctx = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Valiny" + if (sm.partial) " (ampahany)" else "", fontWeight = FontWeight.Bold)
            Text("JORO ${Elo.overallText(sm)} Elo", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("${sm.engineName}\nExperience: ${sm.experience}\nTC: ${sm.tcText}", fontSize = 12.sp)
            sm.levels.forEach { r ->
                Text("SF ${r.elo}  +${r.w} =${r.d} \u2212${r.l}  ${"%.1f".format(r.score * 100)}%  \u2192 ${Elo.levelText(r)}",
                    fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
            Text("Ny UCI_Elo an'i Stockfish dia nasiana calibration amin'ny time control hafa: ampiasao hampitahana ny version JORO.", fontSize = 11.sp)
            OutlinedButton(onClick = {
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, Elo.toText(sm)) }
                ctx.startActivity(Intent.createChooser(i, "Zarao ny valiny"))
            }) { Text("Zarao") }
        }
    }
}

@Composable
fun HistoryTab(vm: MainViewModel, s: UiState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (s.history.isEmpty()) Text("Mbola tsy misy calibrate natao.")
        s.history.forEach { sm ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(DateFormat.getDateTimeInstance().format(Date(sm.timestamp)), fontSize = 12.sp)
                    Text("JORO ${Elo.overallText(sm)} Elo" + if (sm.partial) " (ampahany)" else "", fontWeight = FontWeight.Bold)
                    Text("${sm.engineName}\nExp: ${sm.experience}\n${sm.tcText}", fontSize = 11.sp)
                    Text(sm.levels.joinToString("  ") { "${it.elo}:${"%.0f".format(it.score * 100)}%" }, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
        if (s.history.isNotEmpty()) OutlinedButton(onClick = { vm.clearHistory() }) { Text("Fafao ny tantara") }
    }
}

@Composable
fun ImportTab(vm: MainViewModel, s: UiState) {
    val expPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importExperience(uri) }
    val enginePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importEngine(uri) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Experience (joro.exp)", fontWeight = FontWeight.Bold)
                Text("Ankehitriny: ${s.expInfo}", fontSize = 12.sp)
                Text("Ny fichier avy amin'ny trainer. Ny style ao anatiny no ampiasain'ny moteur.", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { expPicker.launch(arrayOf("*/*")) }) { Text("Import .exp") }
                    OutlinedButton(onClick = { vm.deleteExperience() }) { Text("Fafao") }
                }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Moteur JORO", fontWeight = FontWeight.Bold)
                Text(s.joroInfo, fontSize = 12.sp)
                Text("Fichier executable arm64 vaovao (avy amin'ny build GitHub). Hosedraina avy hatrany ny UCI alohan'ny handraisana azy.", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { enginePicker.launch(arrayOf("*/*")) }) { Text("Import moteur") }
                    OutlinedButton(onClick = { vm.removeImportedEngine() }) { Text("Moteur an'ny APK") }
                }
            }
        }
        if (s.importMessage.isNotEmpty()) Text(s.importMessage)
    }
}
