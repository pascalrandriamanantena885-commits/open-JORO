package com.joro.calibrator

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class TuneParams(
    val pairs: Int = 8,                 // openings per iteration; each is played twice (both colours) -> 2*pairs games
    val movetimeMs: Int = 40,
    val threads: Int = 2,               // games at the same time (keep <= cores / 2: the phone throttles when hot)
    val hashMb: Int = 8,
    val eta: Double = 1.0,              // step size
    val tuneStyle: Boolean = true,      // the style weights of the engine (count read from it)
    val tuneSearch: Boolean = true,     // the search constants
    val tunePlans: Boolean = true,      // the plan parameters of the engine (plan A / B / C, when each plan applies)
    val resume: Boolean = true,         // continue the previous tuning (false = start again from the applied / default values)
    val maxIterations: Int = 0,         // 0 = until stopped
    val verifyBatches: Int = 0,         // > 0 = do not tune: play this many batches of tuned-vs-start games (the MAXIMUM when sprt is on)
    val sprt: Boolean = true,           // verification as a SPRT: stops by itself as soon as "better" / "not better" is established
    val sprtElo0: Double = 0.0,         // H0: the tuned values are not better than this many Elo
    val sprtElo1: Double = 20.0         // H1: the tuned values are better by at least this many Elo (alpha = beta = 5%)
)

data class TuneState(
    val running: Boolean = false,
    val verifying: Boolean = false,
    val iteration: Int = 0,
    val games: Int = 0,
    val maxIterations: Int = 0,
    val lastW: Int = 0, val lastD: Int = 0, val lastL: Int = 0,      // last iteration, from the point of view of the "+" side
    val recent: List<Int> = emptyList(),                             // (W - L) of the last iterations
    val table: String = "",                                          // "name  start -> tuned (delta)"
    val verifyW: Int = 0, val verifyD: Int = 0, val verifyL: Int = 0, // tuned vs starting values (all batches so far)
    val verifyBatchesDone: Int = 0, val verifyBatchesTotal: Int = 0,
    val sprtOn: Boolean = false,
    val sprtDecision: Int = 0,                                       // 0 go on, 1 H1 (better), -1 H0 (not better)
    val sprtLlr: Double = 0.0, val sprtLower: Double = 0.0, val sprtUpper: Double = 0.0,
    val paused: Boolean = false,
    val sleeping: Boolean = false,                                   // the games really sleep (no CPU)
    val message: String = "",
    val log: List<String> = emptyList()
)

/**
 * SPSA tuning inside the app process (JNI, no UCI). Like the training it is owned by the process and kept alive by [TuneService].
 * The state is written after EVERY iteration (tuning/tune.state): pause, stop, a killed process or a reboot lose at most the games of
 * the iteration in progress, and "resume" continues where it stopped.
 */
object TuneController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow(TuneState())
    val state: StateFlow<TuneState> = _state
    private var job: Job? = null
    private val lock = Any()
    private var handle = 0L
    @Volatile private var stopRequested = false
    @Volatile private var pausedFlag = false

    /** Loads the openings of the Calibrate tab (assets/openings.epd): FENs, 4 fields. */
    private fun openingsText(ctx: Context): String =
        runCatching { ctx.assets.open("openings.epd").bufferedReader().use { it.readText() } }.getOrDefault("")

    @Synchronized
    fun start(ctx: Context, p: TuneParams): String? {
        if (_state.value.running) return "Efa mandeha ny tuning."
        if (TrainingController.state.value.running) return "Mandeha ny training: andraso ny faran'izany."
        if (CalibrationController.state.value.running) return "Mandeha ny calibrate: andraso ny faran'izany."
        if (LiveController.state.value.running) return "Mandeha ny lalao Live: atsaharo aloha."
        val app = ctx.applicationContext
        val storage = Storage(app)
        storage.engineRequired()?.let { return it }          // no JORO in the APK: an imported engine is needed
        val openings = openingsText(app)
        if (openings.isBlank()) return "Tsy hita ny openings.epd ao amin'ny assets."
        val verifyMode = p.verifyBatches > 0
        if (verifyMode && !storage.tuneStateFile.exists()) return "Mbola tsy misy tuning natao: andramo aloha ny tuning."
        storage.tuningDir.mkdirs()
        if (!p.resume && !verifyMode) {                                       // start again: forget the previous state
            storage.tuneStateFile.delete()
            File(storage.tuneStateFile.absolutePath + ".csv").delete()
            storage.tunedStyleFile.delete()                                   // an old candidate must not be applied by mistake
        }
        stopRequested = false
        pausedFlag = false
        _state.value = TuneState(running = true, verifying = verifyMode, maxIterations = p.maxIterations, verifyBatchesTotal = p.verifyBatches,
            message = if (verifyMode) "Fakana-pahaizana: tuned vs fanombohana..." else "Manomboka...")

        job = scope.launch(Dispatchers.IO) {
            val start = if (storage.activeStyleFile.exists()) storage.activeStyleFile.absolutePath else ""
            // The imported JORO decides which style weights / search constants exist: tune ITS parameters, through UCI.
            val engine = storage.importedJoro.absolutePath       // always the imported engine: its own parameters are tuned
            val h = Native.tuneCreate(openings, storage.tuneStateFile.absolutePath, start, engine, p.pairs, p.movetimeMs, p.threads, p.hashMb, p.eta,
                1, p.tuneStyle, p.tuneSearch, p.tunePlans, p.resume || verifyMode)
            if (h == 0L) {
                _state.update { it.copy(running = false, verifying = false, message = "Tsy afaka nanomboka ny tuning (state simba, na tsy misy parametra hotononina).") }
                return@launch
            }
            synchronized(lock) { handle = h }
            val sprtOn = verifyMode && p.sprt
            if (sprtOn && !Native.tuneSetSprt(h, true, p.sprtElo0, p.sprtElo1, 0.05, 0.05)) {
                synchronized(lock) { handle = 0 }
                Native.tuneDestroy(h)
                _state.update { it.copy(running = false, verifying = false, message = "SPRT: tsy mety ny lanja (ny Elo ambany tsy maintsy ambany noho ny Elo avo).") }
                return@launch
            }
            if (pausedFlag) Native.tunePause(h, true)
            val info = Native.tuneInfo(h)
            if (sprtOn) {                                                // a resumed verification may already hold games (even a decision)
                val si = Native.tuneSprtInfo(h)
                if (si.size >= 6) _state.update {
                    it.copy(sprtOn = true, sprtDecision = si[0], sprtLlr = si[1] / 1000.0, sprtLower = si[2] / 1000.0, sprtUpper = si[3] / 1000.0)
                }
            }
            _state.update {
                it.copy(iteration = info[0], games = info[1], verifyW = info[2], verifyD = info[3], verifyL = info[4], table = Native.tuneTable(h),
                    message = if (info[0] > 0 && !verifyMode) "Tohizana avy amin'ny iteration ${info[0]}." else it.message)
            }
            // "really asleep" flag, polled cheaply
            val poll = launch {
                while (true) {
                    val sleeping = Native.tuneWaiting(h)
                    _state.update { if (it.sleeping == sleeping) it else it.copy(sleeping = sleeping) }
                    delay(400)
                }
            }
            try {
                if (verifyMode) {
                    var done = 0
                    while (!stopRequested && done < p.verifyBatches && _state.value.sprtDecision == 0) {
                        val r = Native.tuneVerifyStep(h)
                        if (r.size < 7 || r[0] != 0) break
                        done++
                        _state.update {
                            val u = it.copy(verifyW = r[4], verifyD = r[5], verifyL = r[6], verifyBatchesDone = done)
                            if (r.size >= 11) u.copy(sprtOn = true, sprtDecision = r[7], sprtLlr = r[8] / 1000.0, sprtLower = r[9] / 1000.0, sprtUpper = r[10] / 1000.0)
                            else u
                        }
                    }
                } else {
                    var iters = 0
                    while (!stopRequested) {
                        val r = Native.tuneStep(h)
                        if (r.size < 6 || r[0] != 0) break                    // 2 = stopped, -1 = error
                        iters++
                        Native.tuneExport(h, storage.tunedStyleFile.absolutePath)   // the candidate is always up to date
                        val diff = r[3] - r[5]
                        val line = "#${r[1]}: +${r[3]} =${r[4]} −${r[5]}"
                        _state.update {
                            it.copy(iteration = r[1], games = r[2], lastW = r[3], lastD = r[4], lastL = r[5],
                                recent = (it.recent + diff).takeLast(40), table = Native.tuneTable(h), log = (it.log + line).takeLast(20))
                        }
                        if (p.maxIterations > 0 && iters >= p.maxIterations) break
                    }
                }
            } finally {
                poll.cancelAndJoin()                                  // no JNI call may still use the handle when it is destroyed
                val table = Native.tuneTable(h)
                val vt = Native.tuneVerifyText(h)
                val vi = Native.tuneInfo(h)
                Native.tuneExport(h, storage.tunedStyleFile.absolutePath)
                synchronized(lock) { handle = 0 }
                Native.tuneDestroy(h)
                _state.update {
                    it.copy(running = false, verifying = false, paused = false, sleeping = false, table = table,
                        verifyW = vi[2], verifyD = vi[3], verifyL = vi[4],
                        message = (if (stopRequested) "Natsahana. " else if (it.sprtDecision != 0) "SPRT vita: voavaly. " else "Vita. ") +
                            "Voatahiry ny tuning: azo tohizana rehefa te-hanohy. " + vt)
                }
            }
        }
        ContextCompat.startForegroundService(app, Intent(app, TuneService::class.java))
        return null
    }

    /** Pause: every game sleeps at its next move (no CPU, the wake lock is released by the service). Resume continues the same games. */
    fun setPaused(p: Boolean) {
        pausedFlag = p
        synchronized(lock) { if (handle != 0L) Native.tunePause(handle, p) }
        _state.update { it.copy(paused = p, sleeping = if (p) it.sleeping else false) }
    }

    fun stop() {
        stopRequested = true
        synchronized(lock) { if (handle != 0L) Native.tuneStop(handle) }   // aborts the games of the current iteration (theta untouched)
    }

    /** Makes the tuned values the active ones: in-app engine, joro.exp header and the Calibrate tab (through the UCI option StyleFile). */
    fun apply(ctx: Context): String {
        if (_state.value.running) return "Mandeha ny tuning: atsaharo aloha."
        val st = Storage(ctx.applicationContext)
        if (!st.tunedStyleFile.exists()) return "Mbola tsy misy valiny tononina."
        return runCatching {
            st.tunedStyleFile.copyTo(st.activeStyleFile, overwrite = true)
            val ok = Native.applyTuning(st.activeStyleFile.absolutePath, st.expFile.absolutePath)
            if (ok) "Nampiharina ny tuning. Ny style ao amin'ny joro.exp dia nohavaozina (efa nentina ny entries; ny taloha: joro.exp.prestyle)."
            else "Tsy nahomby ny fampiharana (joro.exp simba?)."
        }.getOrElse { "Tsy nahomby: ${it.message}" }
    }

    /** Back to JORO's built-in style and search constants. */
    fun reset(ctx: Context): String {
        if (_state.value.running) return "Mandeha ny tuning: atsaharo aloha."
        val st = Storage(ctx.applicationContext)
        st.activeStyleFile.delete()
        val ok = Native.applyTuning("", st.expFile.absolutePath)
        return if (ok) "Niverina ny style sy ny search tany am-boalohany." else "Tsy nahomby ny famerenana (joro.exp simba?)."
    }

    fun hasActive(ctx: Context): Boolean = Storage(ctx.applicationContext).activeStyleFile.exists()
    /** {style, search, plan}: parameters the imported engine gives ({0,0,0} when there is none). */
    fun paramCounts(ctx: Context): IntArray {
        val st = Storage(ctx.applicationContext)
        if (!st.importedJoro.exists()) return intArrayOf(0, 0, 0)      // no engine, nothing to count
        val r = Native.tuneParamCounts(st.importedJoro.absolutePath)
        return if (r.size == 4 && r[0] == 1) intArrayOf(r[1], r[2], r[3]) else intArrayOf(0, 0, 0)
    }

    fun hasCandidate(ctx: Context): Boolean = Storage(ctx.applicationContext).tunedStyleFile.exists()

    /** At launch: the applied tuning is again the default of the in-app engine (the experience file is not touched). */
    fun restoreActive(ctx: Context) {
        val st = Storage(ctx.applicationContext)
        if (st.activeStyleFile.exists()) runCatching { Native.applyTuning(st.activeStyleFile.absolutePath, "") }
    }
}
