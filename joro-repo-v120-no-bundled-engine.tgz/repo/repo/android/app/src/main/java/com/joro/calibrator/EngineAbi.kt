package com.joro.calibrator

import android.os.Build
import java.io.File

/**
 * The CPU an engine executable was built for, read from its ELF header (an engine with a JORO payload appended keeps its header).
 * An engine of another ABI cannot be started on this phone, but it can still be kept and PACKED (tuning + experience inside) for export:
 * packing only appends data, so it works for any ABI.
 */
object EngineAbi {
    /** "arm64-v8a", "armeabi-v7a", "x86_64", "x86", "riscv64"; "?" = an ELF of another machine; null = not an ELF file (exe, dmg, text...). */
    fun ofFile(f: File): String? {
        val b = ByteArray(20)
        val n = runCatching { f.inputStream().use { it.read(b) } }.getOrDefault(-1)
        if (n < 20) return null
        if (b[0] != 0x7F.toByte() || b[1] != 'E'.code.toByte() || b[2] != 'L'.code.toByte() || b[3] != 'F'.code.toByte()) return null
        val little = b[5].toInt() == 1
        val m = if (little) (b[18].toInt() and 0xFF) or ((b[19].toInt() and 0xFF) shl 8) else ((b[18].toInt() and 0xFF) shl 8) or (b[19].toInt() and 0xFF)
        return when (m) {
            183 -> "arm64-v8a"
            40 -> "armeabi-v7a"
            62 -> "x86_64"
            3 -> "x86"
            243 -> "riscv64"
            else -> "?"
        }
    }

    fun deviceAbis(): List<String> = Build.SUPPORTED_ABIS.toList()

    /** Can this phone start an engine of that ABI? (arm64 phones usually also run armeabi-v7a; x86_64 devices also run x86.) */
    fun runnable(abi: String): Boolean = abi in deviceAbis()
}

/** An engine kept in the library: [abi] and whether this phone can run it (if not it is only kept for export). */
data class EngineEntry(val name: String, val abi: String, val runnable: Boolean)

/** Result of an engine import: [active] = it became the engine in use (false = kept in the library only). */
data class EngineImport(val text: String, val active: Boolean)
