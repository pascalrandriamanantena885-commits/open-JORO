package com.joro.calibrator

import android.app.Application
import android.net.Uri
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val running: Boolean = false,
    val stats: Map<Int, LevelStats> = emptyMap(),
    val summary: Summary? = null,
    val log: List<String> = emptyList(),
    val joroInfo: String = "",
    val expInfo: String = "",
    val importMessage: String = "",
    val history: List<Summary> = emptyList(),
    val message: String = "",
    val train: TrainState = TrainState(),
    val trainMessage: String = "",
    val exportMessage: String = "",
    val updates: List<String> = emptyList(),
    val release: String = "",
    val expSha: String = "none",
    val engines: List<EngineEntry> = emptyList(),          // engines kept besides the active one
    val hasImported: Boolean = false                   // an imported engine is active (a new import must ask: keep both / replace)
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val storage = Storage(app)

    // ---- inputs (kept here so they survive tab switches and rotation)
    var levelsText by mutableStateOf("2500, 2600, 2700, 3000")
    var gamesText by mutableStateOf("20")
    var baseSecText by mutableStateOf("10")
    var incMsText by mutableStateOf("100")
    var concurrencyText by mutableStateOf(defaultConcurrency().toString())
    var hashText by mutableStateOf("16")
    var useExperience by mutableStateOf(true)

    // ---- training inputs: the opening is built on the board (ints), not typed as UCI text
    var openingMoves by mutableStateOf<List<Int>>(emptyList())
    var openingName by mutableStateOf("Position de depart")
    var flipped by mutableStateOf(false)
    var sanInput by mutableStateOf("")

    // ---- custom start position (board editor of the Training tab). customFen "" = standard start; otherwise openingMoves are
    // played from this FEN and the training starts from it (JORO vs JORO or vs Stockfish, experience learned as usual).
    var customFen by mutableStateOf("")
    var editing by mutableStateOf(false)
    var editCells by mutableStateOf(BoardEditor.startCells())
    var editWhite by mutableStateOf(true)
    var editBrush by mutableStateOf('P')               // piece letter to put, '.' = eraser
    var editMessage by mutableStateOf("")
    // Self-play strength (defaults): the strong side alternates between White and Black every game.
    var trainDepthText by mutableStateOf("5")          // weak side, depth
    var trainDepthStrongText by mutableStateOf("8")    // strong side, depth
    var trainByTime by mutableStateOf(false)           // false = depth, true = milliseconds per move
    var trainMsWeakText by mutableStateOf("150")
    var trainMsStrongText by mutableStateOf("400")
    var trainGamesText by mutableStateOf("100")
    var trainStableText by mutableStateOf("3")
    var trainConfirmText by mutableStateOf("5")
    var trainHashText by mutableStateOf("16")
    var trainDrawFail by mutableStateOf(true)
    var trainBatch by mutableStateOf(false)
    var trainGate by mutableStateOf(true)           // A/B gate after the training
    var trainVsSf by mutableStateOf(false)          // JORO vs Stockfish
    var trainMixSelfText by mutableStateOf("20")    // opponent mix (proportions): JORO itself / Stockfish ladder / Stockfish full strength
    var trainMixLadderText by mutableStateOf("60")
    var trainMixMaxText by mutableStateOf("20")
    var trainLadderNeedText by mutableStateOf("3")  // ladder: level up after N wins in the last M ladder games
    var trainLadderWindowText by mutableStateOf("3")
    var trainVaryText by mutableStateOf("5")        // % chance that JORO's first move after the opening is its 2nd best
    var trainFilesRev by mutableStateOf(0)          // bumped when a training file is deleted (the list is re-read)
    var trainSfTimeText by mutableStateOf("1000")   // ms per Stockfish move

    // ---- Live games (Live tab): only to watch the engine; nothing is learned and joro.exp is never written
    var liveVsSf by mutableStateOf(false)           // false = JORO vs JORO, true = JORO vs Stockfish
    var liveJoroWhite by mutableStateOf(true)       // JORO's colour against Stockfish
    var liveSfMax by mutableStateOf(false)          // Stockfish at full strength (no UCI_Elo)
    var liveSfEloText by mutableStateOf("2000")     // Stockfish UCI_Elo 1320..3190
    var liveSfMsText by mutableStateOf("500")       // ms per Stockfish move
    var liveJoroMsText by mutableStateOf("500")     // ms per JORO move
    var liveDelayText by mutableStateOf("300")      // pause between moves (ms) to follow the game
    var liveUseExp by mutableStateOf(true)          // JORO reads joro.exp (read only)
    var liveOpeningMoves by mutableStateOf<List<Int>>(emptyList())
    var liveOpeningName by mutableStateOf("Position de depart")
    // custom start position of the Live tab (own editor state, separate from the Training tab): "" = standard start
    var liveCustomFen by mutableStateOf("")
    var liveEditing by mutableStateOf(false)
    var liveEditCells by mutableStateOf(BoardEditor.startCells())
    var liveEditWhite by mutableStateOf(true)
    var liveEditBrush by mutableStateOf('P')
    var liveEditMessage by mutableStateOf("")
    var liveSanInput by mutableStateOf("")
    var liveFlipped by mutableStateOf(false)
    var liveMessage by mutableStateOf("")

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui

    init {
        CalibrationController.recoverIfNeeded(app)   // a run cut short by Android is kept as a partial result
        TuneController.restoreActive(app)            // the applied tuning (search constants) is the default of the in-app engine
        _ui.update { it.copy(history = storage.loadHistory().reversed()) }
        refreshInfo()
        // The run lives in CalibrationController (process + foreground service), not here: the UI only observes it.
        viewModelScope.launch {
            TrainingController.state.collect { ts ->
                val was = _ui.value.train.running
                _ui.update { it.copy(train = ts) }
                if (was && !ts.running) refreshInfo()       // the experience file changed
            }
        }
        viewModelScope.launch {
            CalibrationController.state.collect { rs ->
                _ui.update { it.copy(running = rs.running, stats = rs.stats, summary = rs.summary, log = rs.log, message = rs.message) }
                if (!rs.running) _ui.update { it.copy(history = storage.loadHistory().reversed()) }
            }
        }
    }

    private fun defaultConcurrency(): Int = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(1, 4)

    // ------------------------------------------------------------------ info
    fun refreshInfo() {
        viewModelScope.launch {
            val joroText = withContext(Dispatchers.IO) {
                val f = storage.joroFile() ?: return@withContext "Tsy misy moteur JORO: import aloha (tab Import)."
                val e = UciEngine(f.absolutePath, "info")
                val name = if (e.start() && e.handshake()) e.idName else "tsy mandeha"
                e.quit()
                "JORO (${storage.joroSource()}): $name"
            }
            val exp = storage.currentExpInfo()
            _ui.update {
                it.copy(joroInfo = joroText, expInfo = exp?.describe() ?: "tsy misy experience",
                    updates = storage.listUpdates(), release = storage.releaseLabel(), expSha = storage.expSha(),
                    engines = storage.engineLibrary(), hasImported = storage.hasImportedEngine())
            }
        }
    }

    // ------------------------------------------------------------------ calibration
    fun parseLevels(text: String): List<Int> =
        text.split(',', ' ', ';', '/').mapNotNull { it.trim().toIntOrNull() }
            .map { it.coerceIn(1320, 3190) }   // range accepted by Stockfish UCI_Elo
            .distinct().sorted()

    fun start() {
        if (_ui.value.running) return
        val levels = parseLevels(levelsText)
        if (levels.isEmpty()) { msg("Ampidiro level iray farafahakeliny (ohatra 2500, 2600)"); return }
        var games = (gamesText.toIntOrNull() ?: 20).coerceIn(2, 400)
        if (games % 2 == 1) games++
        val cfg = CalibConfig(
            levels = levels,
            gamesPerLevel = games,
            baseMs = ((baseSecText.toDoubleOrNull() ?: 10.0) * 1000).toLong().coerceIn(500, 3_600_000),
            incMs = (incMsText.toLongOrNull() ?: 100L).coerceIn(0, 60_000),
            concurrency = (concurrencyText.toIntOrNull() ?: 1).coerceIn(1, 8),
            hashMb = (hashText.toIntOrNull() ?: 16).coerceIn(1, 256),
            useExperience = useExperience
        )
        val err = CalibrationController.start(getApplication(), cfg)
        if (err != null) msg(err)
    }

    fun stop() { CalibrationController.stop() }

    // ------------------------------------------------------------------ training
    private fun lineName() = if (customFen.isEmpty()) "Opening manokana" else BoardEditor.nameOf(customFen)

    fun playOpeningMove(m: Int) { openingMoves = openingMoves + m; openingName = lineName() }
    fun undoOpening() { if (openingMoves.isNotEmpty()) { openingMoves = openingMoves.dropLast(1); openingName = if (openingMoves.isEmpty() && customFen.isEmpty()) "Position de depart" else lineName() } }
    fun resetOpening() { customFen = ""; editing = false; openingMoves = emptyList(); openingName = "Position de depart"; _ui.update { it.copy(trainMessage = "") } }

    /**
     * Runs [block] with the custom start position loaded in the native board helpers (they read one global start FEN), then puts the
     * standard start back. null = refused: a training or a Live game is using that global right now.
     */
    fun <T> withStart(block: () -> T): T? {
        if (customFen.isEmpty()) return block()
        if (TrainingController.state.value.running || LiveController.state.value.running) return null
        return synchronized(startLock) {
            Native.setStartFen(customFen)
            try { block() } finally { Native.setStartFen("") }
        }
    }
    private val startLock = Any()

    /** Opens the editor on the position that is on the board now. */
    fun openEditor() {
        val b = withStart { parseBoard(Native.boardInfo(openingMoves.toIntArray())) }
        editCells = b?.cells?.toList() ?: BoardEditor.startCells()
        editWhite = b?.whiteToMove ?: true
        editMessage = ""
        editing = true
    }
    fun editTap(sq: Int) {
        val c = editCells.toMutableList()
        c[sq] = if (c[sq] == editBrush) '.' else editBrush          // tap the same piece again = remove it
        editCells = c
        editMessage = ""
    }
    fun editClear() { editCells = MutableList(64) { '.' }; editMessage = "Board foana: ampio Roi roa farafahakeliny." }
    fun editStandard() { editCells = BoardEditor.startCells(); editWhite = true; editMessage = "" }

    /** Checks the position, then makes it the start of the training (the moves already played are dropped). */
    fun editApply() {
        val err = BoardEditor.validate(editCells, editWhite)
        if (err != null) { editMessage = err; return }
        val fen = BoardEditor.toFen(editCells, editWhite)
        if (TrainingController.state.value.running || LiveController.state.value.running) {
            editMessage = "Mandeha ny training na ny lalao Live: andraso ny faran'izany."; return
        }
        val before = customFen
        customFen = if (fen == BoardEditor.STANDARD_FEN) "" else fen
        val b = withStart { parseBoard(Native.boardInfo(IntArray(0))) }
        when {
            b == null -> { customFen = before; editMessage = "Tsy nanaiky ny position ny moteur." }
            b.status == 2 || b.status == 3 -> { customFen = before; editMessage = "Mat na pat ny position: tsy misy lalao hilalaovana." }
            else -> {
                openingMoves = emptyList()
                openingName = if (customFen.isEmpty()) "Position de depart" else BoardEditor.nameOf(customFen)
                editing = false
                editMessage = ""
                _ui.update { it.copy(trainMessage = "") }
            }
        }
    }

    fun selectPreset(p: Preset) {
        val m = Native.parseSanLine(p.san)
        if (m == null) { _ui.update { it.copy(trainMessage = "Preset tsy mety: ${p.name}") }; return }
        customFen = ""
        editing = false
        openingMoves = m.toList()
        openingName = p.name
        _ui.update { it.copy(trainMessage = "") }
    }

    /** The user pastes a line in standard notation (1.e4 e5 2.Nf3 ...). */
    fun applySan() {
        val m = Native.parseSanLine(sanInput)
        if (m == null) { _ui.update { it.copy(trainMessage = "Tsy azoko io lalao io (SAN tsy mety na move tsy ara-dalana).") }; return }
        customFen = ""
        editing = false
        openingMoves = m.toList()
        openingName = "Opening manokana"
        _ui.update { it.copy(trainMessage = "") }
    }

    fun startTraining() {
        val queue = when {
            trainBatch -> OpeningPresets.all.mapNotNull { p -> Native.parseSanLine(p.san)?.let { TrainOpening(p.name, it.toList()) } }
            else -> listOf(TrainOpening(openingName, openingMoves, customFen))
        }
        val params = TrainParams(
            depth = (trainDepthText.toIntOrNull() ?: 5).coerceIn(1, 20),
            depthStrong = (trainDepthStrongText.toIntOrNull() ?: 8).coerceIn(1, 24),
            msWeak = if (trainByTime) (trainMsWeakText.toIntOrNull() ?: 150).coerceIn(10, 60000) else 0,
            msStrong = if (trainByTime) (trainMsStrongText.toIntOrNull() ?: 400).coerceIn(10, 60000) else 0,
            maxGames = (trainGamesText.toIntOrNull() ?: 100).coerceIn(1, 5000),
            stable = (trainStableText.toIntOrNull() ?: 3).coerceIn(1, 100),
            confirm = (trainConfirmText.toIntOrNull() ?: 5).coerceIn(0, 100),
            drawFail = trainDrawFail,
            hashMb = (trainHashText.toIntOrNull() ?: 16).coerceIn(1, 256),
            gate = trainGate,
            vsStockfish = trainVsSf,
            mixSelf = (trainMixSelfText.toIntOrNull() ?: 20).coerceIn(0, 1000),
            mixLadder = (trainMixLadderText.toIntOrNull() ?: 60).coerceIn(0, 1000),
            mixMax = (trainMixMaxText.toIntOrNull() ?: 20).coerceIn(0, 1000),
            ladderNeed = (trainLadderNeedText.toIntOrNull() ?: 3).coerceIn(1, 20),
            ladderWindow = (trainLadderWindowText.toIntOrNull() ?: 3).coerceIn(1, 20),
            varyFirstPct = (trainVaryText.toDoubleOrNull() ?: 5.0).coerceIn(0.0, 100.0),
            sfMoveTimeMs = (trainSfTimeText.toIntOrNull() ?: 1000).coerceIn(50, 60000)
        )
        val err = TrainingController.start(getApplication(), queue, params)
        _ui.update { it.copy(trainMessage = err ?: "") }
    }

    fun stopTraining() { TrainingController.stop() }

    // ------------------------------------------------------------------ live games (watch only)
    private fun liveLineName() = if (liveCustomFen.isEmpty()) "Opening manokana" else BoardEditor.nameOf(liveCustomFen)

    /** Board helpers of the Live setup screen, with the edited start position loaded (null = refused, see LiveController.withStart). */
    fun <T> liveWithStart(block: () -> T): T? = LiveController.withStart(liveCustomFen, block)

    fun livePlayOpeningMove(m: Int) { liveOpeningMoves = liveOpeningMoves + m; liveOpeningName = liveLineName() }
    fun liveUndoOpening() {
        if (liveOpeningMoves.isNotEmpty()) {
            liveOpeningMoves = liveOpeningMoves.dropLast(1)
            liveOpeningName = if (liveOpeningMoves.isEmpty() && liveCustomFen.isNotEmpty()) liveLineName() else "Opening manokana"
        }
    }
    fun liveResetOpening() {
        liveCustomFen = ""; liveEditing = false
        liveOpeningMoves = emptyList(); liveOpeningName = "Position de depart"; liveMessage = ""
    }

    /** Opens the editor on the position that is on the board now. */
    fun liveOpenEditor() {
        val b = liveWithStart { parseBoard(Native.boardInfo(liveOpeningMoves.toIntArray())) }
        liveEditCells = b?.cells?.toList() ?: BoardEditor.startCells()
        liveEditWhite = b?.whiteToMove ?: true
        liveEditMessage = ""
        liveEditing = true
    }
    fun liveEditTap(sq: Int) {
        val c = liveEditCells.toMutableList()
        c[sq] = if (c[sq] == liveEditBrush) '.' else liveEditBrush      // tap the same piece again = remove it
        liveEditCells = c
        liveEditMessage = ""
    }
    fun liveEditClear() { liveEditCells = MutableList(64) { '.' }; liveEditMessage = "Board foana: ampio Roi roa farafahakeliny." }
    fun liveEditStandard() { liveEditCells = BoardEditor.startCells(); liveEditWhite = true; liveEditMessage = "" }

    /** Checks the position, then makes it the start of the Live game (the moves already played are dropped). */
    fun liveEditApply() {
        val err = BoardEditor.validate(liveEditCells, liveEditWhite)
        if (err != null) { liveEditMessage = err; return }
        val fen = BoardEditor.toFen(liveEditCells, liveEditWhite)
        if (LiveController.state.value.running) { liveEditMessage = "Mandeha ny lalao Live: andraso ny faran'izany."; return }
        if (TrainingController.state.value.running) { liveEditMessage = "Mandeha ny training: andraso ny faran'izany."; return }
        val before = liveCustomFen
        liveCustomFen = if (fen == BoardEditor.STANDARD_FEN) "" else fen
        val b = liveWithStart { parseBoard(Native.boardInfo(IntArray(0))) }
        when {
            b == null -> { liveCustomFen = before; liveEditMessage = "Tsy nanaiky ny position ny moteur." }
            b.status == 2 || b.status == 3 -> { liveCustomFen = before; liveEditMessage = "Mat na pat ny position: tsy misy lalao hilalaovana." }
            else -> {
                liveOpeningMoves = emptyList()
                liveOpeningName = if (liveCustomFen.isEmpty()) "Position de depart" else BoardEditor.nameOf(liveCustomFen)
                liveEditing = false
                liveEditMessage = ""
                liveMessage = ""
            }
        }
    }

    fun liveSelectPreset(p: Preset) {
        val m = Native.parseSanLine(p.san)
        if (m == null) { liveMessage = "Preset tsy mety: ${p.name}"; return }
        liveCustomFen = ""; liveEditing = false          // presets are lines from the standard start
        liveOpeningMoves = m.toList()
        liveOpeningName = p.name
        liveMessage = ""
    }

    fun liveApplySan() {
        val m = Native.parseSanLine(liveSanInput)
        if (m == null) { liveMessage = "Tsy azoko io lalao io (SAN tsy mety na move tsy ara-dalana)."; return }
        liveCustomFen = ""; liveEditing = false          // a pasted game starts from the standard position
        liveOpeningMoves = m.toList()
        liveOpeningName = "Opening manokana"
        liveMessage = ""
    }

    fun startLive() {
        val params = LiveParams(
            vsStockfish = liveVsSf,
            joroWhite = liveJoroWhite,
            sfElo = if (liveSfMax) 0 else (liveSfEloText.toIntOrNull() ?: 2000).coerceIn(1320, 3190),
            sfMs = (liveSfMsText.toIntOrNull() ?: 500).coerceIn(20, 60000),
            joroMs = (liveJoroMsText.toIntOrNull() ?: 500).coerceIn(10, 60000),
            useExperience = liveUseExp,
            hashMb = 16,
            delayMs = (liveDelayText.toIntOrNull() ?: 300).coerceIn(0, 10000),
            opening = liveOpeningMoves,
            openingName = liveOpeningName,
            startFen = liveCustomFen
        )
        liveFlipped = liveVsSf && !liveJoroWhite          // JORO's side at the bottom of the board
        liveMessage = LiveController.start(getApplication(), params) ?: ""
    }

    private fun msg(m: String) { _ui.update { it.copy(message = m) } }

    // ------------------------------------------------------------------ import / update
    private fun busy(): Boolean {
        val b = _ui.value.running || _ui.value.train.running
        if (b) _ui.update { it.copy(importMessage = "Mandeha ny calibrate na training: andraso ny faran'izany.") }
        return b
    }

    fun importExperience(uri: Uri) {
        if (busy()) return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { storage.importExperience(uri) }
            val text = r.fold({ "Experience vaovao nampidirina: ${it.describe()}" }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(importMessage = text) }
            refreshInfo()
        }
    }

    fun deleteExperience() {
        if (busy()) return
        storage.deleteExperience()
        _ui.update { it.copy(importMessage = "Experience nofafana.") }
        refreshInfo()
    }

    fun importEngine(uri: Uri, keepPrevious: Boolean = false) {
        if (busy()) return
        viewModelScope.launch {
            val had = storage.hasImportedEngine()
            val r = withContext(Dispatchers.IO) { storage.importEngine(uri, keepPrevious) }
            val text = r.fold({ if (!it.active) it.text else "Moteur vaovao nampidirina: ${it.text}" + if (had) (if (keepPrevious) " (ny teo aloha voatahiry)" else " (nosoloina ny teo aloha)") else "" },
                { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(importMessage = text) }
            refreshInfo()
        }
    }

    fun activateEngine(name: String) {
        if (busy()) return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { storage.activateLibraryEngine(name) }
            _ui.update { it.copy(importMessage = r.fold({ "Moteur ampiasaina izao: $it (ny teo aloha voatahiry)" }, { "Hadisoana: ${it.message}" })) }
            refreshInfo()
        }
    }

    fun deleteKeptEngine(name: String) {
        storage.deleteLibraryEngine(name)
        _ui.update { it.copy(engines = storage.engineLibrary(), importMessage = "Nofafana ny moteur voatahiry.") }
    }

    fun removeImportedEngine() {
        storage.removeImportedEngine()
        _ui.update { it.copy(importMessage = "Nesorina ny moteur mavitrika: tsy misy moteur intsony (import na ampiasao ny voatahiry).") }
        refreshInfo()
    }

    // ------------------------------------------------------------------ files: PGN, JORO updates
    private var pendingExport: File? = null

    fun trainFiles(): List<String> = storage.trainFiles()
    fun deleteTrainFile(name: String) { storage.deletePgn(name); trainFilesRev++ }
    fun pgnSize(name: String): Long = storage.pgnFile(name)?.length() ?: 0L
    fun pgnFileOf(name: String): File? = storage.pgnFile(name)
    fun updateFileOf(name: String): File? = storage.updateFile(name)

    fun prepareExport(f: File?) { pendingExport = f }

    fun exportTo(uri: Uri) {
        val f = pendingExport
        pendingExport = null
        if (f == null) return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { storage.copyTo(uri, f) } }
            val text = r.fold({ "Naharitra tany amin'ny storage: ${f.name}" }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(exportMessage = text) }
        }
    }

    fun deletePgn(name: String) {
        storage.deletePgn(name)
        _ui.update { it.copy(history = storage.loadHistory().reversed(), exportMessage = "Nofafana ny PGN.") }
    }

    /** JORO update = the JORO engine in use + the current experience (accepted because it raised the strength). */
    fun createUpdate(sm: Summary?) {
        if (busy()) return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { storage.createUpdate(sm) }
            val text = r.fold({ "JORO v${it.release} vita: ${it.files.joinToString { f -> f.name }}. Alefaso (Export / Partager) ny moteur joro-v${it.release}-<abi> (${it.files.filter { f -> f.name.startsWith("joro-v${it.release}-") }.joinToString { f -> f.name.substringAfterLast("-") }}) mba ho ampiasaina amin'ny app hafa." }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(importMessage = text) }
            refreshInfo()
        }
    }

    fun importUpdate(uri: Uri) {
        if (busy()) return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { storage.importUpdate(uri) }
            val text = r.fold({ "JORO update nampidirina: $it (ny moteur teo aloha, raha nisy, voatahiry ao amin'ny Moteur voatahiry)" }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(importMessage = text) }
            refreshInfo()
        }
    }

    fun deleteUpdate(name: String) {
        storage.deleteUpdate(name)
        _ui.update { it.copy(updates = storage.listUpdates(), importMessage = "Nofafana ny update.") }
    }

    fun clearHistory() {
        storage.clearHistory()
        _ui.update { it.copy(history = emptyList()) }
    }
}
