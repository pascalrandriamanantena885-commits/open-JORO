package com.joro.calibrator

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs

/**
 * LIVE games: one game JORO vs JORO or JORO vs Stockfish (strength chosen), from a chosen opening, only to WATCH how the engine plays.
 *
 * It has NO effect on the experience: joro.exp is only READ (a private copy inside the native handle, can be switched off), nothing is
 * learned, no BAD / brilliant mark, no PGN / statistics file, no A/B gate. Only the Training tab changes joro.exp.
 * The game lives in the process (like the other runs), so it goes on when you change tab; it is not a foreground service.
 */
data class LiveParams(
    val vsStockfish: Boolean,
    val joroWhite: Boolean = true,          // only used against Stockfish
    val sfElo: Int = 0,                      // UCI_Elo 1320..3190, 0 = full strength
    val sfMs: Int = 500,                     // Stockfish ms per move
    val joroMs: Int = 500,                   // JORO ms per move
    val useExperience: Boolean = true,       // JORO reads joro.exp (read only)
    val hashMb: Int = 16,
    val delayMs: Int = 300,                  // pause after each move so the game can be followed
    val opening: List<Int> = emptyList(),
    val openingName: String = "",
    val startFen: String = ""               // "" = standard start; otherwise the edited position the opening moves are played from
)

/** One move of the game, for the list under the board. */
data class LiveMove(
    val label: String,        // "12. Nf3" or "Nf3" (SAN, move number only before White's move)
    val who: String,          // "JORO" / "Stockfish"
    val eval: String,         // JORO's evaluation, White's point of view ("+0.35", "-M3"); "" for Stockfish
    val depth: Int,
    val fromExp: Boolean,     // the move came from the experience (no search)
    val rejected: Int,        // moves refused by the Variation Brain before this one was chosen
    val plan: Int,            // 0 none, 1 A, 2 B, 3 C (the plan JORO follows for this side in the position)
    val planD: Boolean = false, // Plan D steered this move: A / B / C stalled, JORO led the game toward positions its experience knows
    val dPly: Int = 0,        // Plan D: plies until the planned line reaches a position the experience knows (0 = none found)
    val dKind: Int = 0        // ... 1 = a known good move there, 2 = a good situation, 3 = a bad situation (avoided), 4 = a NEW situation: steering toward the nearest good one
)

data class LiveState(
    val running: Boolean = false,
    val moves: List<Int> = emptyList(),
    val openingLen: Int = 0,
    val openingName: String = "",
    val startFen: String = "",              // start position of this game ("" = standard)
    val white: String = "",
    val black: String = "",
    val paused: Boolean = false,
    val thinking: String = "",
    val result: String = "",
    val message: String = "",
    val expInfo: String = "",
    val sanLine: String = "",
    val log: List<LiveMove> = emptyList()
)

object LiveController {
    private const val MAX_PLIES = 400
    private const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow(LiveState())
    val state: StateFlow<LiveState> = _state
    private var job: Job? = null
    private val lock = Any()
    private val startLock = Any()
    private var handle = 0L
    @Volatile private var stopRequested = false
    @Volatile private var pausedFlag = false

    private val reasons = listOf("mat", "pat", "50 hetsika tsy nisy fakana/baolina", "famerenana intelo", "material tsy ampy")

    /** Starts the game. Returns an error text, or null when it started. */
    @Synchronized
    fun start(ctx: Context, p: LiveParams): String? {
        if (_state.value.running) return "Efa mandeha ny lalao Live."
        if (TrainingController.state.value.running) return "Mandeha ny training: andraso ny faran'izany."
        if (CalibrationController.state.value.running) return "Mandeha ny calibrate: andraso ny faran'izany."
        if (TuneController.state.value.running) return "Mandeha ny tuning: andraso ny faran'izany."
        val app = ctx.applicationContext
        val storage = Storage(app)
        storage.engineRequired()?.let { return it }          // no JORO in the APK: an imported engine is needed
        stopRequested = false
        pausedFlag = false

        var sf: UciEngine? = null
        var opponent: StockfishOpponent? = null
        if (p.vsStockfish) {
            val f = storage.stockfish
            if (!f.exists()) return "Tsy hita ny Stockfish ao anaty APK (libstockfish.so). Jereo ny README."
            val e = UciEngine(f.absolutePath, "live-sf")
            if (!e.start() || !e.handshake() || !e.isReady()) { e.quit(); return "Tsy afaka nandeha ny Stockfish." }
            e.setOption("Hash", "64")
            e.setOption("Threads", "1")
            if (!e.isReady()) { e.quit(); return "Tsy afaka nandeha ny Stockfish." }
            val o = StockfishOpponent(e, p.sfMs) { stopRequested }
            if (!o.prepare(p.sfElo)) { e.quit(); return "Tsy afaka nandeha ny Stockfish." }
            sf = e
            opponent = o
        }
        // read-only copy of joro.exp inside the native handle; nothing is ever saved back
        val h = Native.liveCreate(storage.expFile.absolutePath, p.useExperience, p.hashMb)
        if (h == 0L) { sf?.quit(); return "Tsy afaka nanomboka (joro.exp simba?)." }
        Native.liveNewGame(h)
        synchronized(lock) { handle = h }

        val joroName = "JORO" + storage.releaseLabel().let { if (it.isEmpty()) "" else " $it" }
        val sfName = if (p.sfElo > 0) "Stockfish ${p.sfElo}" else "Stockfish (heriny rehetra)"
        val whiteName = if (!p.vsStockfish || p.joroWhite) joroName else sfName
        val blackName = if (!p.vsStockfish || !p.joroWhite) joroName else sfName
        val opp = opponent
        val engine = sf

        // The native helpers read ONE global start position: it stays set to this game's FEN until the game ends.
        var firstSan = ""
        var whiteFirst = true
        synchronized(startLock) {
            Native.setStartFen(p.startFen)
            firstSan = Native.movesToSan(p.opening.toIntArray())
            whiteFirst = parseBoard(Native.boardInfo(IntArray(0)))?.whiteToMove ?: true
            _state.value = LiveState(
                running = true, moves = p.opening, openingLen = p.opening.size, openingName = p.openingName, startFen = p.startFen,
                white = whiteName, black = blackName, expInfo = Native.liveInfo(h), sanLine = firstSan
            )
        }
        val sfFen = p.startFen.ifEmpty { START_FEN }

        job = scope.launch(Dispatchers.IO) {
            val moves = ArrayList<Int>(p.opening)
            val log = ArrayList<LiveMove>()
            var sanBefore = firstSan
            var result = ""
            var message = ""
            try {
                while (!stopRequested) {
                    while (pausedFlag && !stopRequested) delay(150)
                    if (stopRequested) break
                    val arr = moves.toIntArray()
                    val oc = Native.liveOutcome(arr)
                    if (oc.size < 3) { message = "Position tsy ara-dalana."; break }
                    if (oc[0] == 1) { result = describe(oc[1], oc[2], whiteName, blackName); break }
                    if (moves.size >= MAX_PLIES) { result = "1/2-1/2  draw (nahatratra ny $MAX_PLIES plies)"; break }

                    val whiteToMove = (moves.size % 2 == 0) == whiteFirst   // the side to move at the start of the position moves on even counts
                    val joroTurn = !p.vsStockfish || whiteToMove == p.joroWhite
                    var move = 0
                    var eval = ""
                    var depth = 0
                    var fromExp = false
                    var rejected = 0
                    var plan = 0
                    var planD = false
                    var dPly = 0
                    var dKind = 0
                    if (joroTurn) {
                        _state.update { it.copy(thinking = "JORO mieritreritra...") }
                        val plans = Native.livePlans(h, arr)
                        if (plans.size >= 2) plan = if (whiteToMove) plans[0] else plans[1]
                        val r = Native.liveJoroMove(h, arr, 0, p.joroMs)
                        if (r.size >= 6) {
                            move = r[0]
                            eval = fmtEval(if (whiteToMove) r[1] else -r[1])
                            depth = r[2]
                            fromExp = r[3] == 1
                            rejected = r[4]
                            if (r.size >= 9) { planD = r[6] == 1; dPly = r[7]; dKind = r[8] }
                        }
                    } else if (opp != null) {
                        _state.update { it.copy(thinking = "Stockfish mieritreritra...") }
                        move = opp.bestMove(sfFen, arr)
                    }
                    if (move == 0) {
                        if (!stopRequested) message = "Tsy nisy hetsika azo (nijanona ny engine?)."
                        break
                    }
                    moves.add(move)
                    val sanAfter = Native.movesToSan(moves.toIntArray())
                    val label = sanAfter.removePrefix(sanBefore).trim()
                    sanBefore = sanAfter
                    log.add(LiveMove(label, if (joroTurn) "JORO" else "Stockfish", eval, depth, fromExp, rejected, plan, planD, dPly, dKind))
                    val snapshotMoves = moves.toList()
                    val snapshotLog = log.toList()
                    _state.update { it.copy(moves = snapshotMoves, log = snapshotLog, sanLine = sanAfter, thinking = "") }
                    if (p.delayMs > 0) delay(p.delayMs.toLong())
                }
            } catch (e: Exception) {
                message = "Hadisoana: ${e.message}"
            }
            synchronized(lock) { handle = 0L }
            Native.liveDestroy(h)
            engine?.quit()
            // give the global start position back together with the state change (the UI reads both under the same lock)
            synchronized(startLock) {
                Native.setStartFen("")
                _state.update {
                    it.copy(
                        running = false, paused = false, thinking = "", result = result,
                        message = if (stopRequested && result.isEmpty()) "Natsahana." else message
                    )
                }
            }
        }
        return null
    }

    /**
     * Runs [block] with the start position [fen] ("" = standard) loaded in the native board helpers, for the board / moves / PNG shown
     * by the Live tab. While a game runs, the helpers already hold ITS position and are left alone. null = refused: another run (the
     * training) uses that global right now and the position is not the standard one.
     */
    fun <T> withStart(fen: String, block: () -> T): T? = synchronized(startLock) {
        when {
            _state.value.running -> block()
            fen.isEmpty() -> block()
            TrainingController.state.value.running -> null
            else -> {
                Native.setStartFen(fen)
                try { block() } finally { Native.setStartFen("") }
            }
        }
    }

    /** Pause: the game sleeps at the next move boundary (no CPU while it sleeps). */
    fun setPaused(p: Boolean) {
        pausedFlag = p
        _state.update { it.copy(paused = p) }
    }

    /** Stops the game now (interrupts the search in progress). */
    fun stop() {
        pausedFlag = false
        stopRequested = true
        synchronized(lock) { if (handle != 0L) Native.liveStop(handle) }
    }

    /** Back to the set-up screen once a game is over. */
    fun clear() {
        if (!_state.value.running) _state.value = LiveState()
    }

    private fun describe(result: Int, reason: Int, white: String, black: String): String {
        val why = reasons.getOrElse(reason) { "?" }
        return when (result) {
            1 -> "1-0  $white nandresy ($why)"
            -1 -> "0-1  $black nandresy ($why)"
            else -> "1/2-1/2  draw ($why)"
        }
    }

    /** Evaluation in pawns from White's point of view; engine mate scores (about 31000 - plies) are shown as M<moves>. */
    private fun fmtEval(cp: Int): String {
        val a = abs(cp)
        if (a >= 30872) {
            val n = (31000 - a + 1) / 2
            return (if (cp > 0) "+M" else "-M") + n
        }
        return String.format(Locale.US, "%+.2f", cp / 100.0)
    }
}
