package com.joro.calibrator

/** Engine code running inside the app (same C++ as the UCI engine, but called directly: no UCI, no process). */
object Native {
    init { System.loadLibrary("joro_native") }

    // ---- board / opening (moves are ints: from | to<<6 | promo<<12 | flag<<15)
    @JvmStatic external fun boardInfo(moves: IntArray): String          // "64 cells|w|status"
    @JvmStatic external fun legalMoves(moves: IntArray): IntArray
    @JvmStatic external fun movesToSan(moves: IntArray): String         // "1. e4 e5 2. Nf3"
    @JvmStatic external fun parseSanLine(text: String): IntArray?       // null if the text is not a legal line

    // ---- calibration only: the engines speak UCI, the PGN needs SAN
    @JvmStatic external fun sanFromUci(fen: String, uciMoves: String): String

    // ---- training (one handle = one opening)
    @JvmStatic external fun trainCreate(
        moves: IntArray, expPath: String, depth: Int, depthStrong: Int, msWeak: Int, msStrong: Int, maxGames: Int, stable: Int, confirm: Int,
        drawFail: Boolean, hashMb: Int, varyFirstPct: Double, label: String
    ): Long
    @JvmStatic external fun trainStep(handle: Long): IntArray           // see appapi.h for the layout
    @JvmStatic external fun trainStop(handle: Long)
    /** Start position for the board helpers and the NEXT trainCreate ("" = standard start). Used by the board editor. */
    @JvmStatic external fun setStartFen(fen: String)
    /** A/B gate: candidate vs base experience. openingsFlat = moves of each start, separated by -1. Returns [wins, draws, losses] (candidate) or empty. */
    @JvmStatic external fun gateRun(basePath: String, candPath: String, openingsFlat: IntArray, gamesPerStart: Int, movetimeMs: Int): IntArray
    /** SPRT gate (H0: new is worse by >= 40 Elo, H1: not worse): plays until decided or maxGames. [wins, draws, losses, decision (1 accept, -1 reject, 0 undecided), LLR*1000] or empty. */
    @JvmStatic external fun gateRunSprt(basePath: String, candPath: String, openingsFlat: IntArray, movetimeMs: Int, maxGames: Int): IntArray
    @JvmStatic external fun gateStop(stop: Boolean)
    /** JORO vs an external engine: [cb] must have  fun bestMove(fen: String, moves: IntArray): Int  (0 = no move). */
    @JvmStatic external fun trainSetOpponent(handle: Long, joroSide: Int, cb: Any?)
    /** Mixed opponents: [cb] must have  fun bestMove(fen: String, moves: IntArray): Int  and  fun prepare(elo: Int): Boolean (elo 0 = full strength). */
    @JvmStatic external fun trainSetMix(handle: Long, cb: Any)
    /** A run = all openings of one start: PGN files (prefix_0001.pgn ...), per-opening table (CSV) and opponent weights are shared. */
    @JvmStatic external fun runBegin(statsPath: String, pgnPrefix: String, pgnSplit: Int, wSelf: Int, wLadder: Int, wMax: Int,
                                     need: Int, window: Int, ladderFile: String, ladderReset: Boolean)
    @JvmStatic external fun runEnd(): String                            // saves the table, returns it as text
    @JvmStatic external fun trainFinish(handle: Long)                   // after the last step of an opening
    @JvmStatic external fun trainLastOpponent(handle: Long): String
    @JvmStatic external fun trainPause(handle: Long, paused: Boolean)   // sleeps at the next move (no CPU)
    @JvmStatic external fun trainWaiting(handle: Long): Boolean         // true once it really sleeps
    @JvmStatic external fun trainLive(handle: Long): IntArray           // moves of the game being played now
    @JvmStatic external fun trainDestroy(handle: Long)

    // ---- live games (the Live tab): JORO vs JORO / vs Stockfish just to WATCH. The experience is only read, never written.
    /** Loads joro.exp read-only (useExperience=false or no file = JORO without memory). Returns 0 on error. */
    @JvmStatic external fun liveCreate(expPath: String, useExperience: Boolean, hashMb: Int): Long
    @JvmStatic external fun liveNewGame(handle: Long)
    /** JORO's move after [moves] (standard start). movetimeMs > 0 wins over depth. {move (0 = none/stopped), score cp, depth, fromExperience 0/1, brainRejected, nodes, planD 0/1, dPly, dKind} (the last three only when 9 values come back). */
    @JvmStatic external fun liveJoroMove(handle: Long, moves: IntArray, depth: Int, movetimeMs: Int): IntArray
    @JvmStatic external fun liveStop(handle: Long)
    @JvmStatic external fun liveInfo(handle: Long): String
    @JvmStatic external fun liveDestroy(handle: Long)
    /** {over 0/1, result (1 white, -1 black, 0 draw), reason (0 mate, 1 stalemate, 2 50 moves, 3 repetition, 4 insufficient material)}; empty if illegal. */
    @JvmStatic external fun liveOutcome(moves: IntArray): IntArray
    /** The plan each side follows: {white, black}; 0 none, 1 A, 2 B, 3 C. */
    @JvmStatic external fun livePlans(handle: Long, moves: IntArray): IntArray

    // ---- SPSA tuning of the style weights + search constants (one handle = one tuning run, resumable from its state file)
    /** openings = text, one start per line (FEN or UCI moves). startPath "" = defaults. Returns 0 on error. */
    @JvmStatic external fun tuneCreate(openings: String, statePath: String, startPath: String, enginePath: String, pairs: Int, movetimeMs: Int, threads: Int, hashMb: Int,
                                       eta: Double, seed: Int, tuneStyle: Boolean, tuneSearch: Boolean, tunePlans: Boolean, resume: Boolean): Long
    /** "14 style + 7 search + 18 plan = 39 parameters (engine)": what this tuning really tunes (read from the engine, not fixed). */
    @JvmStatic external fun tuneSummary(handle: Long): String
    /** {ok 0/1, style, search, plan}: parameters the engine would give. enginePath "" = built-in. */
    @JvmStatic external fun tuneParamCounts(enginePath: String): IntArray
    /** One iteration (blocks for its games). {status, iteration, games, W, D, L}; status 0 ok, 2 stopped, -1 error. */
    @JvmStatic external fun tuneStep(handle: Long): IntArray
    /** One batch of verification games (tuned vs starting values). {status, W, D, L, totalW, totalD, totalL} (+ {decision, LLR*1000, lower*1000, upper*1000} when the SPRT is on). */
    @JvmStatic external fun tuneVerifyStep(handle: Long): IntArray
    /** SPRT on the verification totals (call after tuneCreate). false = invalid values (0 < alpha, beta < 0.5 and elo0 < elo1). */
    @JvmStatic external fun tuneSetSprt(handle: Long, enabled: Boolean, elo0: Double, elo1: Double, alpha: Double, beta: Double): Boolean
    /** {decision (0 go on, 1 H1 better, -1 H0 not better), LLR*1000, lower*1000, upper*1000, games, enabled 0/1} for the totals now. */
    @JvmStatic external fun tuneSprtInfo(handle: Long): IntArray
    @JvmStatic external fun tuneSprtText(handle: Long): String
    @JvmStatic external fun tuneInfo(handle: Long): IntArray            // {iteration, games, verifyW, verifyD, verifyL}
    @JvmStatic external fun tuneStop(handle: Long)
    @JvmStatic external fun tunePause(handle: Long, paused: Boolean)   // the games sleep at the next move (no CPU)
    @JvmStatic external fun tuneWaiting(handle: Long): Boolean         // true once every worker really sleeps
    @JvmStatic external fun tuneTable(handle: Long): String
    @JvmStatic external fun tuneVerifyText(handle: Long): String
    @JvmStatic external fun tuneExport(handle: Long, path: String): Boolean
    @JvmStatic external fun tuneDestroy(handle: Long)
    /** Makes a tuning file the default of every new searcher ("" = built-in defaults) and writes its style into joro.exp's header ("" = leave the file alone). */
    @JvmStatic external fun applyTuning(tuningPath: String, expPath: String): Boolean
    /** New JORO version: copies the engine file and puts the tuning (+ experience) + label INSIDE it (src/embed.h). tuningPath / expPath may be "". Returns "" or the error. */
    @JvmStatic external fun packEngine(inEngine: String, outEngine: String, tuningPath: String, expPath: String, label: String): String
    /** The tuned values as a C++ header (for the code); "" if the file cannot be read. */
    @JvmStatic external fun tuningHeader(tuningPath: String, label: String): String
}

fun moveFrom(m: Int): Int = m and 63
fun moveTo(m: Int): Int = (m shr 6) and 63
fun movePromo(m: Int): Int = (m shr 12) and 7   // 2 N, 3 B, 4 R, 5 Q

class BoardView(val cells: CharArray, val whiteToMove: Boolean, val status: Int)

fun parseBoard(s: String): BoardView? {
    if (s.length < 68 || s.startsWith("ERR")) return null
    return BoardView(s.substring(0, 64).toCharArray(), s[65] == 'w', s[67] - '0')
}
