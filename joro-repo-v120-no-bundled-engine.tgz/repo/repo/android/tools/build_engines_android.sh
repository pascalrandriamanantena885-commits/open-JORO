#!/usr/bin/env bash
# Builds the UCI executables for one or several ABIs.
#   JORO       -> dist/joro-<abi>            : NOT packed in the APK. Import it in the app (tab Import > Import moteur).
#   Stockfish  -> app/src/main/jniLibs/<abi>/libstockfish.so : the calibration opponent, packed in the APK (GPLv3, internet needed here only)
# (named lib*.so so that Gradle packs + extracts Stockfish into nativeLibraryDir.)
#   usage: ANDROID_NDK_HOME=/path/to/ndk [ABIS="arm64-v8a x86_64 armeabi-v7a"] android/tools/build_engines_android.sh [--joro-only|--sf-only]
# Default ABIS = arm64-v8a. Then build the APK with the same list:  ./gradlew assembleRelease -PjoroAbis=arm64-v8a,x86_64
# Stockfish ARCH per ABI (override with SF_ARCH_<abi, '-' as '_'>, e.g. SF_ARCH_x86_64=x86-64-sse41-popcnt):
#   arm64-v8a -> armv8 | armeabi-v7a -> armv7-neon | x86_64 -> x86-64 | x86 -> x86-32   (only arm64-v8a was ever tested here)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-}}"
[ -d "$NDK" ] || { echo "Set ANDROID_NDK_HOME"; exit 1; }
ABIS="${ABIS:-arm64-v8a}"
MODE="${1:-all}"
export PATH="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin:$PATH"

sf_arch() {
  local v="SF_ARCH_${1//-/_}"
  if [ -n "${!v:-}" ]; then echo "${!v}"; return; fi
  case "$1" in
    arm64-v8a) echo armv8 ;; armeabi-v7a) echo armv7-neon ;; x86_64) echo x86-64 ;; x86) echo x86-32 ;;
    *) echo "unsupported ABI $1" >&2; exit 1 ;;
  esac
}

mkdir -p "$ROOT/dist"
for ABI in $ABIS; do
  BLD="$ROOT/build-android-$ABI"
  if [ "$MODE" != "--sf-only" ]; then
    echo "== JORO ($ABI) -> dist/joro-$ABI"
    cmake -S "$ROOT" -B "$BLD" -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
      -DANDROID_ABI="$ABI" -DANDROID_PLATFORM=android-26
    cmake --build "$BLD" --target joro -j
    cp "$BLD/joro" "$ROOT/dist/joro-$ABI"
    llvm-strip "$ROOT/dist/joro-$ABI" || true
  fi
  if [ "$MODE" != "--joro-only" ]; then
    echo "== Stockfish ($ABI)"
    OUT="$ROOT/android/app/src/main/jniLibs/$ABI"
    mkdir -p "$OUT"
    SF_TAG="${SF_TAG:-sf_17}"
    if [ ! -d "$ROOT/build-android-stockfish-src" ]; then
      git clone --depth 1 --branch "$SF_TAG" https://github.com/official-stockfish/Stockfish.git "$ROOT/build-android-stockfish-src"
    fi
    mkdir -p "$BLD"; rm -rf "$BLD/Stockfish"; cp -r "$ROOT/build-android-stockfish-src" "$BLD/Stockfish"
    make -C "$BLD/Stockfish/src" -j build ARCH="$(sf_arch "$ABI")" COMP=ndk
    cp "$BLD/Stockfish/src/stockfish" "$OUT/libstockfish.so"
    llvm-strip "$OUT/libstockfish.so" || true
  fi
done
ls -la "$ROOT/dist" 2>/dev/null || true
