# JORO Calibrator (Android, offline)

Kotlin + Jetpack Compose app. Runs **JORO vs Stockfish (UCI_LimitStrength + UCI_Elo)** on the phone, for several
levels at once ("matrix"), and shows a summary with the estimated Elo of JORO. No INTERNET permission.

## How it works
* JORO and Stockfish are UCI **executables** (`libstockfish.so` in `jniLibs/<abi>`), started as child processes. **The APK carries no JORO engine**: until a JORO engine is imported
  (tab Import > Import moteur) the app behaves as if no engine existed (Calibrate, Training, Live and Tune refuse to start and say so).
* `MatchRunner` plays games between them (clocks, adjudication, 24 openings from `assets/openings.epd`, both colours).
* `Referee` (JNI, same board code as the engine) decides mate / stalemate / draw / illegal move.
* Matrix mode: games of all levels (e.g. 2500, 2600, 2700, 3000) are interleaved in one queue and played by N workers at once.
* `Elo.kt`: score -> Elo difference, 95% interval, inverse-variance weighted overall estimate. A level where JORO scores
  0% or 100% only gives a bound (shown as <= or >=): use levels close to JORO's strength to get a real number.
* Tab **Import**: new `joro.exp` (validated: header, version, size, style id) and new JORO engine binary (any ABI, UCI
  handshake tested before it is accepted). Each calibration is saved in **Tantara** with the engine name/experience.

## Training tab (no UCI)
The training runs **inside the app**: the C++ engine + trainer are called directly through JNI (`Native.kt` -> `appapi.cpp`),
there is no UCI engine, no process and no text protocol in this path. UCI is only used by the Calibrate tab (Stockfish).
* The opening is built on a **board** (tap a piece, tap the square) or taken from 23 named presets; it is shown in standard
  notation (`1. e4 e5 2. Nf3 Nc6`). A line can also be pasted in that notation.
* Self-play JORO vs JORO from that position; after each game: the loser's critical move (backtrack) -> BAD, and only the winner's verified *brilliant* moves are kept (ordinary winning moves are not stored).
  Stops on the games budget, N games with nothing new, or N consecutive wins of one side.
* The result is written to `joro.exp` after **every game** (atomic), in the app's private folder: the Calibrate tab uses
  the same file, and Import/Export of `.exp` works with it. An existing experience keeps its style.
* Keeps running in the background like the calibration (foreground service); Stop interrupts the current game at once.
* Calibrate and Training cannot run at the same time (one at a time, CPU and the experience file are shared).
* "Preset rehetra" trains the 23 openings one after another.

## Build
GitHub: run workflow `build_apk` -> artifacts `joro-calibrator-apk` (install it), `joro-engine-<abi>` (the JORO file for "Import moteur"; it is not inside the APK).
Local: `ANDROID_NDK_HOME=... android/tools/build_engines_android.sh` (JORO -> `dist/joro-<abi>` to import in the app, Stockfish -> `jniLibs`) then open `android/` in Android Studio.
Any ABI: `ABIS="arm64-v8a x86_64 armeabi-v7a" android/tools/build_engines_android.sh` then `./gradlew assembleRelease -PjoroAbis=arm64-v8a,x86_64,armeabi-v7a`
(default arm64-v8a). JORO builds for every ABI; Stockfish for the non-arm64 ABIs is best effort (NOT tested here).

## Notes / limits
* `targetSdk = 28` on purpose: Android 10+ blocks executing binaries from an app's own data folder for apps
  targeting 29+, and that is what "Import moteur" needs. Fine for a side-loaded tool, not for Google Play.
* Stockfish is GPLv3: if you share the APK, share the sources too (the JORO sources are in this repo).
* Stockfish's UCI_Elo scale is calibrated for another time control/hardware: compare JORO versions with each other.
* The phone throttles when hot: keep concurrency <= cores/2, same settings between runs.

## Runs in the background
The run is owned by `CalibrationController` (process level), not by the screen. Starting a calibration also starts
`CalibrationService` (foreground service + partial wake lock + notification with progress and an "Atsaha" button).
So the calibration keeps going when the screen is off, when you leave the app, and when you swipe it away from the
recents. The result is saved in "Tantara" and announced by a notification when it ends. Reopen the app at any time: it
shows the live progress.
* Stops only if you press "Atsaha", use "Force stop" in Android settings, or the system kills the process. In that case
  the games already played are kept as a partial result at the next launch (marked `[tapaka]`).
* Some brands (Xiaomi, Huawei, Samsung "sleeping apps", ...) kill background apps aggressively: use the
  "Battery: avelao hiasa foana ny app" button and allow auto-start / no restrictions for the app.
* It does not restart by itself after a reboot.

## PGN of the calibrations
Every finished game is appended to a PGN file of the run (one file per calibration, in the app's private folder): tags with
players (`JORO ...` / `Stockfish UCI_Elo N`), result, TimeControl, Termination (checkmate, adjudication, time forfeit...),
the start position (FEN) and the moves in SAN. In **Tantara** (and under the summary) each run has **Export PGN** (system
"save as": storage, Drive, ...) and **Fafao PGN** (delete). Deleting a PGN does not touch the Elo summary.

## JORO update (engine + experience)
When an experience raised the strength, accept it: **Ekena ho JORO update** (shown under a run that was played with the
experience currently installed) or **Mamorona update** in the Import tab. The app packs the engine in use and `joro.exp` into
`JORO-update-U<n>.zip` (with a manifest: version label, experience sha, entries, style, and the calibration result), which
you can export, delete, or import on another phone (**Import update**: the experience is validated, the engine is tested with
a UCI handshake, then both are installed and the version label becomes `U<n>`). The label is shown in the Calibrate tab,
in the history and in the PGN player names.

## Auto-level (summary of a calibration)
The summary no longer averages levels: it computes one **maximum-likelihood Elo over all levels together** (a level where JORO
scored 100% or 0% still carries information), with its 95% interval, then tells which levels to test next (those where JORO
should score 25-75%), how many games per level are needed for +-50 Elo, and a button applies the suggested levels to the input.
If every level is a clean sweep, only a bound (>= / <=) can be given and the suggestion moves the ladder up/down.


## Training: pause, live view, colours (v0.5)
* **Pause / Tohizo** (button in the Train tab and in the notification): the game sleeps at the next move, the wake lock is
  released, no CPU is used; resuming continues the same game. A pause survives the change of opening.
* **Live board**: while training runs the Train tab shows the game being played (moves polled every 400 ms, only while the
  tab is on screen). Training itself runs in the foreground service, with or without the app open.
* **Board and pieces (v0.8)**: the pieces are the SVGs of `design/svg/pieces` (with their shadow) and the squares are the four SVGs of
  `design/svg/board`. Two board themes, **Brown** (default) and **Gray**: the button "Loko board" under the board switches it, the choice is
  remembered. The same board is used by the opening builder and by the live view; the promotion buttons show the piece.
  Android cannot draw these SVGs (embedded shadow bitmap + `mix-blend-mode`), so `tools/svg_to_png.js` renders them once with Chromium into
  `app/src/main/res/drawable-nodpi/pc_wk.png ... pc_bp.png` at one common scale (0.8 px per SVG unit, a square = 450 units = 360 px; a pawn
  stays smaller than a king). To change a piece: edit its SVG, run `node android/tools/svg_to_png.js` (needs `playwright`), commit the PNGs.
  The board colours are plain colours (the squares are flat rectangles) copied into `BoardTheme` in `Board.kt`.
* Not compiled in this environment (no Android SDK): build with Gradle and test on a device.

## JORO vs Stockfish (v0.5)
Switch "JORO vs Stockfish" in the Train tab: choose the opening and JORO's colour (white/black) and Stockfish's time per
move. Stockfish plays at full strength (no UCI_LimitStrength); JORO chases checkmate, a draw is a failure. Only JORO's
moves are ever learned from (BAD when JORO loses or draws, brilliant/great when JORO mates); Stockfish's moves never enter
joro.exp. Same pause / live board / foreground service as JORO vs JORO. Needs libstockfish.so in the APK.
Games are decided by checkmate only (the 900 cp adjudication is off by default; `--adjudicate` on the CLI turns it on).
CLI: `joro_train --opening "e2e4 e7e5" --vs /path/to/stockfish --joro black --movetime 1000 --vs-opt Threads=1`.


## Training: mixed opponents, PGN, per-opening table (v0.6)
Same features as `joro_train` (see the main README), wired into the **Training** tab:
* **Fiovana %** : chance that JORO's first move after the opening is its 2nd best (default 5).
* **Mifangaro** switch (replaces the old "JORO vs Stockfish" switch and its colour buttons): weights JORO / Ladder / SF max
  (default 20 / 60 / 20), ladder rule "N wins in the last M games" (default 3 / 3), Stockfish ms per move. JORO's colour alternates
  every game over the whole run. The ladder level is kept in `files/experience/joro.ladder`. With the switch off: JORO vs JORO only.
* Every game is saved as PGN in `files/pgn/JORO_train_0001.pgn ...` (100 games per file) with `!!` `!` `?` `??` marks and `[%eval]`;
  the table per opening is appended to `files/pgn/JORO_train_stats.csv` at the end of each run and shown in the tab, compared with
  the previous run (UP / DOWN / = / NEW). Both are listed under the table with Export / Fafao buttons.
JNI additions: `runBegin`, `runEnd`, `trainSetMix`, `trainFinish`, `trainLastOpponent`; `trainCreate` takes `varyFirstPct` and the opening name;
`trainStep` returns 7 more ints (see `src/appapi.h`). `native_jni.cpp` had two `JNI_OnLoad` definitions: merged into one.
Not compiled here (no Gradle / Kotlin compiler available): the C++ side was built and run with a test harness, the Kotlin side was only reviewed.


## Tune tab: SPSA with pause / play (v0.7)
Tunes the style weights and the search constants by JORO-vs-JORO games, inside the app (JNI `tune*`, no UCI), see the main README.
* **Hanomboka / hanohy**, **Pause / Tohizo (play)**, **Atsaha**: the same buttons are in the notification. Pause = every game sleeps
  at its next move, the wake lock is released (about 0 % CPU). Stop or a killed process keeps everything up to the last finished iteration
  (`files/tuning/tune.state`, one CSV line per iteration in `tune.state.csv`).
* Inputs: openings per iteration (each played with both colours), ms per move, threads (keep <= cores / 2: a hot phone throttles and the
  results then depend on the heat), max iterations, which group to tune, resume or restart.
* **Fakafakao**: tuned vs starting values, with Elo and a 95 % interval. Apply only when it says "Nihatsara tokoa".
* **Ampiharo**: `tuned.style` becomes `active.style`; the in-app engine (training, A/B gate), the header of `joro.exp` and the Calibrate
  tab (UCI `StyleFile`) use it. `joro.exp.prestyle` keeps the previous file. **Averina ny tany am-boalohany** undoes it.
* **JORO update zip** (Import tab) now also packs `active.style` (style weights + search constants) when a tuning is applied; the manifest
  has `"tuned": true`. **Import update** installs it (validated: JSON with a `weights` object) and makes it the active tuning of that phone;
  an update WITHOUT `active.style` clears the local tuning (built-in values), so an update always reproduces its maker's JORO.
  The label shown after the import ends with "+ tuning". Updates made before v0.7 stay importable.
* Calibrate / Training / Tune never run together (shared CPU).
* Kotlin was not compiled here (no Android SDK): the C++ side is tested, the Kotlin side was syntax-checked and reviewed only.


## Release v* from the app (tune -> calibrate -> apply update -> export)
1. **Tune** tab: SPSA (style 14 + search 7 + **plans 18**: switch "plan A / B / C"). **Fakafakao** = tuned vs start values.
2. **Ampiharo ny tuning** (the tuned values become `active.style`; the Calibrate tab and the training use them).
3. **Calibrate** tab: play the matrix. When the run used the installed experience and is complete, the button **Ampiharo update (JORO v*)**
   appears under the run (also in the **Import** tab: *Ampiharo update*).
4. The app writes, in `files/updates/` (listed in the Import tab, each with **Export** = system "save as" and **Partager** = share sheet):
   * `joro-v<n>-<abi>` (one file per ABI: the active engine + every engine of another ABI kept in the library) : the engine with the tuning and `joro.exp` packed inside (src/embed.h), UCI name `JORO 0.4 v<n>`; the app
     starts it and checks the UCI handshake and the label before accepting the release. This is the file for another chess app / program.
   * `JORO-update-U<n>.zip` : the same release for another JORO Calibrator (Import update).
   * `joro-v<n>.style` and `joro_tuned_v<n>.h` : the tuned values (JSON and C++ constants) for the code.
* Share uses a `FileProvider` (`res/xml/file_paths.xml`, authority `<applicationId>.files`): no INTERNET permission needed.
* An engine file is an **Android/Linux ELF executable of one ABI** (`joro-v<n>-arm64-v8a`, `-x86_64`, `-armeabi-v7a`...). Import accepts any ABI:
  one this phone can run is validated by its UCI handshake and can become the active engine; another one (e.g. x86_64 on an arm64 phone) is kept
  in "Moteur voatahiry" and only used for export: packing the tuning + experience just appends data, so the exported file of that ABI is
  correct but could not be started here (no UCI check). A chess app can run it only if it supports external UCI engines and is allowed to
  execute it (Android 10+ forbids running binaries from an app's data folder for apps targeting 29+); on a PC/Linux arm64 it runs directly.
  The same tuning/experience can also be loaded by any UCI GUI through the options `StyleFile` / `ExperienceFile`.
* Kotlin and JNI changes were not compiled here (no Android SDK / NDK); the C++ side (embed, joro_pack, UCI) was built and tested.


## Live tab: watch a game (v1.8)
A separate tab, **Live**, plays ONE game just to watch how JORO plays. It has **no effect on the experience**: `joro.exp` is only read
(a private copy inside the native handle, `liveCreate` in `src/appapi.cpp`), nothing is learned, there is no BAD / brilliant mark, no PGN, no
statistics file and no A/B gate. Only the Training tab changes `joro.exp` (`tests/live_test.cpp` checks that the file keeps the same bytes and mtime).
* **Mode**: JORO vs JORO, or JORO vs Stockfish. Against Stockfish: JORO's colour, and Stockfish's strength = `UCI_Elo` (1320-3190, quick buttons
  1500 / 2000 / 2500 / 3000) or full strength, plus its ms per move.
* **JORO**: ms per move and a delay between moves (to follow the game). A switch turns the experience off (JORO without memory) - useful to see the
  engine itself, or to compare with / without memory.
* **Opening**: same builder as in Training (tap a piece, tap the square), the 22 presets, or a pasted line `1.e4 e5 2.Nf3 Nc6`. Empty = start position.
  **Hanomboka lalao** starts the game from it.
* **During the game**: live board, **Pause / Tohizo** (no CPU while paused), **Atsaha** (interrupts the search at once), **Reverse**. A card shows JORO's last move:
  evaluation (White's point of view), depth, the plan it follows (A / B / C, see `selectPlan`), "exp" when the move came from the experience, and how many
  moves the Variation Brain refused. Under it the last 12 moves with the same data. A finished game stays on screen until **Lalao vaovao**.
* The game ends by checkmate, stalemate, 50 moves, threefold repetition or insufficient material (400 plies at most = draw).
* One thing runs at a time: Live refuses to start while Calibrate / Training / Tune runs, and they refuse while a Live game runs (shared CPU).
* It is not a foreground service: it goes on when you change tab, but Android may stop it when the app is in the background.
* Needs `libstockfish.so` in the APK only for JORO vs Stockfish. Native API: `Native.liveCreate / liveNewGame / liveJoroMove / liveStop / liveOutcome / livePlans / liveDestroy`.
* Not compiled here (no Gradle / Kotlin compiler): the C++ side was built and tested (`g++ ... tests/live_test.cpp`, or the CMake target `joro_live_test`),
  the Kotlin side was only reviewed. The tab bar is now a `ScrollableTabRow` (6 tabs).


## Navigation and layout (v0.4)
* **Bottom navigation** with 5 items: Calibrate, Training, Live, Tantara, Hafa. "Hafa" opens two big cards: Import and Tune
  (back arrow / system Back returns to the menu). A chip in the top bar shows when a calibration or a training is running.
* Every tab is a `Page { ... }` (same margins) made of `JoroCard`s (see `Ui.kt`): rounded cards with an outline. A card that has an
  `onClick` reacts to touch ("hover" on a phone): it rises and shrinks very slightly while the finger is down.
* Shared pieces in `Ui.kt`: `Page`, `SectionHeader`, `JoroCard`, `Chip`, `InfoRow`, `BigStat`, `SwitchRow`.

## PNG of a Live game (v0.4)
In the **Live** tab, card **Sary PNG** (during the game or after it; it is only in Live, not in Training):
* **Tahiry PNG**: system "save as" (storage, Drive...).
* **Zarao PNG**: share sheet (Messenger, WhatsApp, ...), the file is written to `cache/live/` (only the latest one is kept).
The picture (1080 px wide, dark background) holds: both player names with a white/black dot (JORO's side at the bottom when it is
flipped that way), the board with the last move, the result, the opening, JORO's last move (eval, depth, plan or "experience") and all
the moves in standard notation. It uses the board colours chosen with "Loko board" and the orientation of "Reverse".
Code: `LivePng.kt` (drawn with `android.graphics`, independent of the screen).

## Board editor in Training (v0.4)
In **Training > Opening**, button **Edit board**: pick a piece in the palette (white row, black row, eraser), tap squares to put it
(tap the same piece again to remove it), choose who is to move, then **Ampiasao ity position ity**. Castling rights are derived from
the king/rook home squares. The position is refused (with the reason) when: not exactly one king per side, a pawn on the first/last
rank, more than 8 pawns or 16 pieces, kings next to each other, only two kings left, the side NOT to move is in check, or the
position is already mate / stalemate.
* The edited position becomes the start FEN of the training (`TrainOpening.fen`). You can still
  play moves on it before starting. It is trained like any opening: JORO vs JORO, or the Stockfish mix (ladder / full strength) when
  that switch is on, and the experience (`joro.exp`) is written after every game. It gets its own row in the per-opening table
  ("Position edited xxxx", xxxx = short hash of the FEN) and its games are in the PGN with the FEN tag.
* Preset / pasted line / Reset go back to the standard start.
* The A/B gate skips FEN starts : it only uses openings that start from the standard position.
* The native board helpers read ONE global start FEN, so `MainViewModel.withStart` loads the custom FEN only for the duration of a call
  and refuses while a training or a Live game is running (the board then shows a short notice instead).
* Code: `BoardEditor.kt` (validation + FEN, pure Kotlin), `MainViewModel` (state: `customFen`, `editCells`, ...), `TrainScreen.kt` (`BoardEditorPanel`).
