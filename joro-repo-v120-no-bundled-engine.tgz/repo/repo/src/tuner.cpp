#include "tuner.h"
#include "uciproc.h"
#include <chrono>
#include <functional>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <map>
#include <random>
#include <sstream>
#include <thread>

namespace joro {

// ------------------------------------------------------------------------------------------------ starts
std::vector<TuneStart> parseTuneStarts(const std::string& text) {
    std::vector<TuneStart> out;
    std::istringstream is(text);
    std::string line;
    while (std::getline(is, line)) {
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
        size_t a = line.find_first_not_of(' ');
        if (a == std::string::npos || line[a] == '#') continue;
        line = line.substr(a);
        TuneStart s;
        if (line.find('/') != std::string::npos) {                 // a FEN; complete a 4-field EPD with the clocks
            std::istringstream fs(line);
            std::vector<std::string> f;
            std::string t;
            while (fs >> t) f.push_back(t);
            if (f.size() < 4) continue;
            std::string fen = f[0] + " " + f[1] + " " + f[2] + " " + f[3] + " " + (f.size() > 4 ? f[4] : "0") + " " + (f.size() > 5 ? f[5] : "1");
            Board b;
            if (!b.setFen(fen)) continue;
            s.fen = fen;
        } else {                                                    // UCI moves from the standard start
            s.fen = START_FEN;
            std::istringstream ms(line);
            std::string t;
            Board b;
            b.setFen(s.fen);
            bool ok = true;
            while (ms >> t) {
                Move m = b.parseMove(t);
                if (!m) { ok = false; break; }
                b.makeMove(m);
                s.moves.push_back(t);
            }
            if (!ok) continue;
        }
        out.push_back(s);
    }
    return out;
}

// ------------------------------------------------------------------------------------------------ parameter list
static bool readNamed(const std::string& t, const std::string& name, int& v) {
    size_t k = t.find("\"" + name + "\"");
    if (k == std::string::npos) return false;
    size_t c = t.find(':', k);
    if (c == std::string::npos) return false;
    v = atoi(t.c_str() + c + 1);
    return true;
}

static TuneDef mkDef(const std::string& name, const std::string& uci, int group, bool style, int idx, int lo, int hi, double c, int init) {
    TuneDef d;
    d.name = name; d.uci = uci; d.group = group; d.style = style; d.idx = idx; d.lo = lo; d.hi = hi; d.c = c;
    d.init = std::max(lo, std::min(hi, init));
    return d;
}

// 0 = unknown name, 1 = known (range filled), 2 = known and never tuned (contempt)
static int knownRange(const std::string& n, int& lo, int& hi, double& c) {
    for (int i = 0; i < SP_COUNT; i++)
        if (n == Style::paramName(i)) {
            StyleTuneDef d = styleTuneDef(i);
            if (!d.tuned) return 2;
            lo = d.lo; hi = d.hi; c = d.c;
            return 1;
        }
    for (int i = 0; i < SPR_PLAN_FIRST; i++)
        if (n == SearchParams::paramName(i)) { lo = searchTuneDef(i).lo; hi = searchTuneDef(i).hi; c = searchTuneDef(i).c; return 1; }
    for (int i = 0; i < PP_COUNT; i++)
        if (n == planParamDef(i).name) { lo = planParamDef(i).lo; hi = planParamDef(i).hi; c = planParamDef(i).step; return 1; }
    return 0;
}

bool tuneDefs(const TuneConfig& cfg, const Style& base, const SearchParams& baseSp, std::vector<TuneDef>& out, std::string& engineName, std::string* err,
              std::vector<std::pair<std::string, int>>* fixed) {
    out.clear();
    if (cfg.enginePath.empty()) {                 // the compiled-in core: the counts follow SP_COUNT / SPR_PLAN_FIRST / PP_COUNT
        engineName = "built-in";
        if (cfg.tuneStyle)
            for (int i = 0; i < SP_COUNT; i++) {
                StyleTuneDef d = styleTuneDef(i);
                if (d.tuned) out.push_back(mkDef(Style::paramName(i), "", 0, true, i, d.lo, d.hi, d.c, base.w[i]));
            }
        if (cfg.tuneSearch)
            for (int i = 0; i < SPR_PLAN_FIRST; i++)
                out.push_back(mkDef(SearchParams::paramName(i), "", 1, false, i, searchTuneDef(i).lo, searchTuneDef(i).hi, searchTuneDef(i).c, baseSp.v[i]));
        if (cfg.tunePlans)
            for (int i = 0; i < PP_COUNT; i++) {
                const PlanParamDef& d = planParamDef(i);
                out.push_back(mkDef(d.name, "", 2, false, SPR_PLAN_FIRST + i, d.lo, d.hi, (double)d.step, baseSp.v[SPR_PLAN_FIRST + i]));
            }
        return true;
    }
    // An external engine: whatever Style_* / Search_* spin options it announces. The ranges of the names JORO knows are kept; a
    // parameter this build has never heard of gets a range around its default (+-12 steps of 15%), cut by the engine's own min / max.
    std::vector<UciOption> opts;
    if (!uciProbe(cfg.enginePath, engineName, opts, err)) return false;
    for (const UciOption& o : opts) {
        if (o.type != "spin") continue;
        int group;
        std::string name;
        if (o.name.compare(0, 6, "Style_") == 0) { group = 0; name = o.name.substr(6); }
        else if (o.name.compare(0, 7, "Search_") == 0) { name = o.name.substr(7); group = name.compare(0, 5, "plan_") == 0 ? 2 : 1; }
        else continue;
        int init = (int)o.def;
        bool hasStart = !cfg.startText.empty() && readNamed(cfg.startText, name, init);
        int lo = 0, hi = 0;
        double c = 1;
        int k = knownRange(name, lo, hi, c);
        bool tune = k != 2 && ((group == 0 && cfg.tuneStyle) || (group == 1 && cfg.tuneSearch) || (group == 2 && cfg.tunePlans));
        if (tune) {
            if (k == 0) {
                const int def = (int)o.def;
                c = std::max(1.0, 0.15 * std::max(std::abs(def), 6));
                lo = (int)std::lround(def - 12 * c);
                hi = (int)std::lround(def + 12 * c);
                if (def >= 0) lo = std::max(lo, 0);
            }
            if (o.hasMin) lo = std::max<long long>(lo, o.lo);
            if (o.hasMax) hi = std::min<long long>(hi, o.hi);
            tune = lo < hi;
        }
        if (tune) out.push_back(mkDef(name, o.name, group, group == 0, 0, lo, hi, c, init));
        else if (fixed && hasStart && k != 2) fixed->push_back({o.name, init});
    }
    if (out.empty()) { if (err && err->empty()) *err = "the engine exposes no Style_* / Search_* parameter to tune"; return false; }
    return true;
}

bool tuneCounts(const std::string& enginePath, int& style, int& search, int& plan, std::string* engineName, std::string* err) {
    TuneConfig cfg;
    cfg.enginePath = enginePath;
    std::vector<TuneDef> defs;
    std::string name;
    Style st;
    SearchParams sp;
    initTables();
    bool ok = tuneDefs(cfg, st, sp, defs, name, err);
    style = search = plan = 0;
    for (const TuneDef& d : defs) (d.group == 0 ? style : d.group == 1 ? search : plan)++;
    if (engineName) *engineName = name;
    return ok;
}

// ------------------------------------------------------------------------------------------------ players
namespace {

class InProcPlayer : public TunePlayer {
public:
    InProcPlayer(int hashMB, const Style& st, const SearchParams& sp, const std::vector<TuneDef>* defs) : base_(st), baseSp_(sp), defs_(defs) {
        s_.quiet = true;
        s_.setHash(hashMB);
        s_.moveOverhead = 2;          // movetime really is the time per move
        s_.useExperience = false;
    }
    bool configure(const std::vector<int>& vals) override {
        Style st = base_;
        SearchParams sp = baseSp_;
        for (size_t i = 0; i < defs_->size() && i < vals.size(); i++) {
            const TuneDef& d = (*defs_)[i];
            if (d.style) st.w[d.idx] = vals[i]; else sp.v[d.idx] = vals[i];
        }
        s_.style = st;
        s_.sp = sp;
        return true;
    }
    void newGame() override { s_.clear(); }
    int think(Board& b, const TuneStart&, const std::vector<std::string>&, const Limits& lim, Move& best, int& score) override {
        s_.stopFlag = false;
        SearchResult r = s_.go(b, lim);
        best = r.best;
        score = r.score;
        return r.best == MOVE_NONE ? 1 : 0;
    }
    void abort() override { s_.stopFlag = true; }
private:
    Searcher s_;
    Style base_;
    SearchParams baseSp_;
    const std::vector<TuneDef>* defs_;
};

class ExtPlayer : public TunePlayer {
public:
    bool init(const std::string& path, const std::vector<std::string>& names, const std::vector<std::pair<std::string, std::string>>& statics) {
        names_ = names;
        if (!p_.start(path)) return false;
        p_.send("uci");
        if (!p_.waitFor("uciok", 5000)) return false;
        for (auto& o : statics) p_.send("setoption name " + o.first + " value " + o.second);   // an unknown option is ignored by UCI
        return sync();
    }
    bool configure(const std::vector<int>& vals) override {
        for (size_t i = 0; i < names_.size() && i < vals.size(); i++) p_.send("setoption name " + names_[i] + " value " + std::to_string(vals[i]));
        return sync();
    }
    void newGame() override { p_.send("ucinewgame"); sync(); }
    int think(Board& b, const TuneStart& st, const std::vector<std::string>& played, const Limits& lim, Move& best, int& score) override {
        std::string cmd = "position fen " + st.fen;
        if (!played.empty()) { cmd += " moves"; for (const std::string& m : played) cmd += " " + m; }
        if (!p_.send(cmd)) return 3;
        if (!p_.send(lim.nodes > 0 ? "go nodes " + std::to_string((long long)lim.nodes) : "go movetime " + std::to_string((long long)lim.movetime))) return 3;
        const long long budget = lim.nodes > 0 ? 180000 : (long long)lim.movetime + 10000;
        const auto t0 = std::chrono::steady_clock::now();
        score = 0;
        for (;;) {
            if (ab_) { p_.send("stop"); p_.waitFor("bestmove", 1000); return 2; }
            std::string l;
            int r = p_.readLine(l, 50);
            if (r < 0) return 3;
            if (r == 0) {
                if (std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count() > budget) return 3;
                continue;
            }
            if (l.compare(0, 4, "info") == 0) {
                size_t k = l.find(" score cp ");
                if (k != std::string::npos) score = atoi(l.c_str() + k + 10);
                else if ((k = l.find(" score mate ")) != std::string::npos) score = atoi(l.c_str() + k + 12) > 0 ? 10000 : -10000;
            } else if (l.compare(0, 8, "bestmove") == 0) {
                std::istringstream is(l);
                std::string t, mv;
                is >> t >> mv;
                if (mv.empty() || mv == "0000" || mv == "(none)") { best = MOVE_NONE; return 1; }
                best = b.parseMove(mv);
                return best == MOVE_NONE ? 4 : 0;
            }
        }
    }
    void abort() override { ab_ = true; }
private:
    bool sync() { return p_.send("isready") && p_.waitFor("readyok", 10000); }
    UciProc p_;
    std::vector<std::string> names_;
    std::atomic<bool> ab_{false};
};

} // namespace

// ------------------------------------------------------------------------------------------------ parameters
Tuner::Tuner(const TuneConfig& cfg, std::vector<TuneStart> starts, const Style& base, const SearchParams& baseSp)
    : cfg_(cfg), starts_(std::move(starts)), baseStyle_(base), baseSp_(baseSp) {
    initTables();
    cfg_.threads = std::max(1, std::min(cfg_.threads, 8));
    cfg_.pairs = std::max(1, cfg_.pairs);
    cfg_.emaWindow = std::max(1, cfg_.emaWindow);
    if (!tuneDefs(cfg_, baseStyle_, baseSp_, defs_, engineName_, &error_, &fixed_)) { defs_.clear(); return; }
    for (auto& d : defs_) {
        init_.push_back(d.init);
        theta_.push_back(d.init);
        avg_.push_back(d.init);
    }
    std::vector<std::string> names;
    std::vector<std::pair<std::string, std::string>> statics = {{"Hash", std::to_string(cfg_.hashMB)}, {"MoveOverhead", "2"}, {"Threads", "1"},
                                                                {"UseExperience", "false"}, {"PlanD", "false"}};
    for (auto& d : defs_) names.push_back(d.uci);
    for (auto& f : fixed_) statics.push_back({f.first, std::to_string(f.second)});
    for (int t = 0; t < cfg_.threads; t++)
        for (auto* pool : {&poolA_, &poolB_}) {
            if (cfg_.enginePath.empty()) { pool->emplace_back(new InProcPlayer(cfg_.hashMB, baseStyle_, baseSp_, &defs_)); continue; }
            std::unique_ptr<ExtPlayer> e(new ExtPlayer());
            if (!e->init(cfg_.enginePath, names, statics)) {
                error_ = "cannot run " + cfg_.enginePath + " as a UCI engine";
                defs_.clear(); init_.clear(); theta_.clear(); avg_.clear(); poolA_.clear(); poolB_.clear();
                return;
            }
            pool->push_back(std::move(e));
        }
}

Tuner::~Tuner() {}

int Tuner::clampi(int i, int v) const { return std::max(defs_[i].lo, std::min(defs_[i].hi, v)); }

void Tuner::apply(const std::vector<int>& vals, Style& st, SearchParams& sp) const {
    for (size_t i = 0; i < defs_.size(); i++) {
        if (!defs_[i].uci.empty()) continue;                       // external engine: not a parameter of this build
        if (defs_[i].style) st.w[defs_[i].idx] = vals[i];
        else sp.v[defs_[i].idx] = vals[i];
    }
}

Style Tuner::tunedStyle() const {
    Style st = baseStyle_;
    SearchParams sp = baseSp_;
    std::vector<int> v;
    for (size_t i = 0; i < defs_.size(); i++) v.push_back(clampi((int)i, (int)std::lround(avg_[i])));
    apply(v, st, sp);
    st.name = "JORO-tuned";
    return st;
}
SearchParams Tuner::tunedSearch() const {
    Style st = baseStyle_;
    SearchParams sp = baseSp_;
    std::vector<int> v;
    for (size_t i = 0; i < defs_.size(); i++) v.push_back(clampi((int)i, (int)std::lround(avg_[i])));
    apply(v, st, sp);
    return sp;
}
bool Tuner::exportTuned(const std::string& path) const {
    if (cfg_.enginePath.empty()) return saveTuning(path, tunedStyle(), tunedSearch());
    // external engine: the names it announced (style weights under "weights", the rest under "search"); the others keep its values
    std::ofstream f(path);
    if (!f) return false;
    f << "{\n  \"name\": \"JORO-tuned\"";
    for (int part = 0; part < 2; part++) {
        std::string body;
        for (size_t i = 0; i < defs_.size(); i++) {
            if ((defs_[i].group == 0) != (part == 0)) continue;
            body += std::string(body.empty() ? "" : ",\n") + "    \"" + defs_[i].name + "\": " + std::to_string(clampi((int)i, (int)std::lround(avg_[i])));
        }
        if (!body.empty()) f << ",\n  \"" << (part == 0 ? "weights" : "search") << "\": {\n" << body << "\n  }";
    }
    f << "\n}\n";
    return (bool)f;
}

int Tuner::groupCount(int group) const {
    int n = 0;
    for (const TuneDef& d : defs_) if (d.group == group) n++;
    return n;
}
std::string Tuner::summary() const {
    return std::to_string(groupCount(0)) + " style + " + std::to_string(groupCount(1)) + " search + " + std::to_string(groupCount(2)) + " plan = " +
           std::to_string(defs_.size()) + " parameters (" + engineName_ + ")";
}
std::string Tuner::paramList() const {
    std::string out;
    char buf[200];
    static const char* G[] = {"style", "search", "plan"};
    for (const TuneDef& d : defs_) {
        snprintf(buf, sizeof buf, "%-7s %-18s start %4d  range %d..%d  step %g\n", G[d.group], d.name.c_str(), d.init, d.lo, d.hi, d.c);
        out += buf;
    }
    return out;
}

std::string Tuner::table() const {
    std::string out;
    char buf[160];
    for (size_t i = 0; i < defs_.size(); i++) {
        int a = clampi((int)i, (int)std::lround(avg_[i]));
        snprintf(buf, sizeof buf, "%-14s %4d -> %4d  (%+d)%s\n", defs_[i].name.c_str(), init_[i], a, a - init_[i], a != init_[i] ? "" : "");
        out += buf;
    }
    return out;
}

// ------------------------------------------------------------------------------------------------ pause / stop
void Tuner::stop() {
    stopped_ = true;
    for (auto& s : poolA_) s->abort();
    for (auto& s : poolB_) s->abort();
    std::lock_guard<std::mutex> lk(mu_);
    cv_.notify_all();
}
void Tuner::setPaused(bool p) {
    std::lock_guard<std::mutex> lk(mu_);
    paused_ = p;
    cv_.notify_all();
}
bool Tuner::isWaiting() const { return paused_ && active_ > 0 && sleeping_ >= active_; }

void Tuner::gate() {
    if (!paused_) return;
    std::unique_lock<std::mutex> lk(mu_);
    sleeping_++;
    cv_.wait(lk, [&] { return !paused_ || stopped_; });
    sleeping_--;
}

// ------------------------------------------------------------------------------------------------ games
// +1 A wins, -1 B wins, 0 draw, 2 aborted. A game decided for 6 moves in a row (|eval| >= 900 cp) is adjudicated.
int Tuner::playGame(TunePlayer& A, TunePlayer& B, const TuneStart& st, bool aWhite) {
    Board b;
    if (!b.setFen(st.fen)) return 0;
    std::vector<std::string> played;
    for (const std::string& s : st.moves) {
        Move m = b.parseMove(s);
        if (!m) return 0;
        b.makeMove(m);
        played.push_back(s);
    }
    TunePlayer& white = aWhite ? A : B;
    TunePlayer& black = aWhite ? B : A;
    white.newGame();
    black.newGame();
    int streak = 0, sign = 0;
    for (int ply = 0; ply < cfg_.maxPlies; ply++) {
        gate();
        if (stopped_) return 2;
        Move mv[256];
        if (b.genLegal(mv) == 0) {
            int w = b.inCheck() ? (b.side == WHITE ? -1 : 1) : 0;   // white's view
            return aWhite ? w : -w;
        }
        if (b.isDraw()) return 0;
        TunePlayer& s = b.side == WHITE ? white : black;
        Limits lim;
        if (cfg_.nodes > 0) lim.nodes = cfg_.nodes;
        else lim.movetime = cfg_.movetimeMs;
        Move best = MOVE_NONE;
        int score = 0;
        int rc = s.think(b, st, played, lim, best, score);
        if (stopped_ || rc == 2) return 2;
        if (rc == 3) return 3;
        if (rc == 4) return (b.side == WHITE) == aWhite ? -1 : 1;   // an illegal move loses
        int w = b.side == WHITE ? score : -score;
        if (std::abs(w) >= 900) {
            int sg = w > 0 ? 1 : -1;
            streak = sg == sign ? streak + 1 : 1;
            sign = sg;
        } else { streak = 0; sign = 0; }
        if (streak >= 6) return aWhite ? sign : -sign;
        if (rc == 1 || best == MOVE_NONE) return 0;
        played.push_back(Board::moveToStr(best));
        b.makeMove(best);
    }
    return 0;
}

bool Tuner::runGames(const std::vector<Game>& games, const std::vector<int>& valsA, const std::vector<int>& valsB, std::vector<int>& res) {
    res.assign(games.size(), 0);
    std::atomic<size_t> next{0};
    std::atomic<bool> aborted{false};
    const int nt = std::min<int>(cfg_.threads, (int)games.size());
    for (int t = 0; t < nt; t++)
        if (!poolA_[t]->configure(valsA) || !poolB_[t]->configure(valsB)) {
            error_ = "the engine does not answer (crashed or not UCI)";
            failed_ = true;
            return false;
        }
    active_ = nt;
    sleeping_ = 0;
    std::vector<std::thread> th;
    for (int t = 0; t < nt; t++)
        th.emplace_back([&, t] {
            for (;;) {
                size_t g = next++;
                if (g >= games.size() || stopped_ || aborted) break;
                int r = playGame(*poolA_[t], *poolB_[t], starts_[games[g].start], games[g].aWhite);
                if (r == 3) { error_ = "the engine stopped answering during a game (crash or timeout)"; failed_ = true; aborted = true; break; }
                if (r == 2) { aborted = true; break; }
                res[g] = r;
            }
        });
    for (auto& t : th) t.join();
    active_ = 0;
    return !aborted && !stopped_;
}

static void pickStarts(std::mt19937& rng, size_t n, int pairs, std::vector<int>& out) {
    std::vector<int> idx(n);
    for (size_t i = 0; i < n; i++) idx[i] = (int)i;
    std::shuffle(idx.begin(), idx.end(), rng);
    for (int i = 0; i < pairs; i++) out.push_back(idx[(size_t)i % n]);   // without repeats while there are enough starts
}

int Tuner::step(TuneStep& out) {
    if (stopped_) return 2;
    if (starts_.empty() || defs_.empty()) return -1;
    const int n = (int)defs_.size();
    std::mt19937 rng(cfg_.seed * 2654435761u + (unsigned)iter_ * 40503u + 17u);
    const double ck = 1.0 / std::pow(1.0 + iter_, 0.101);
    std::vector<int> plus(n), minus(n), dir(n);
    for (int i = 0; i < n; i++) {
        dir[i] = (rng() & 1) ? 1 : -1;
        double delta = std::max(0.5, defs_[i].c * ck);             // >= 0.5 so that the rounded + and - values differ
        plus[i] = clampi(i, (int)std::lround(theta_[i] + dir[i] * delta));
        minus[i] = clampi(i, (int)std::lround(theta_[i] - dir[i] * delta));
        if (plus[i] == minus[i]) {                                  // squeezed against a bound: keep the two sides apart
            if (plus[i] < defs_[i].hi) plus[i]++; else minus[i]--;
        }
    }
    std::vector<int> pick;
    pickStarts(rng, starts_.size(), cfg_.pairs, pick);
    std::vector<Game> games;
    for (int s : pick) { games.push_back({s, true}); games.push_back({s, false}); }
    std::vector<int> res;
    if (!runGames(games, plus, minus, res)) return failed_ ? -1 : 2;               // aborted: theta is left untouched
    int w = 0, d = 0, l = 0;
    for (int r : res) { if (r > 0) w++; else if (r < 0) l++; else d++; }
    const double G = (double)games.size();
    const double score = (w - l) / G;                                // A = theta+ ; in [-1, 1]
    const double ak = cfg_.eta / std::pow(1.0 + iter_ / cfg_.decay, 0.602);
    const double alpha = 2.0 / (cfg_.emaWindow + 1);
    for (int i = 0; i < n; i++) {
        theta_[i] += ak * defs_[i].c * dir[i] * score;
        theta_[i] = std::max((double)defs_[i].lo, std::min((double)defs_[i].hi, theta_[i]));
        avg_[i] += alpha * (theta_[i] - avg_[i]);
    }
    iter_++;
    vW_ = vD_ = vL_ = 0;     // the exported (averaged) values just changed: older verification games were about another candidate
    games_ += (long long)games.size();
    out.iter = iter_;
    out.games = games_;
    out.w = w; out.d = d; out.l = l;
    return 0;
}

int Tuner::verifyStep(int& w, int& d, int& l) {
    w = d = l = 0;
    if (stopped_) return 2;
    if (starts_.empty() || defs_.empty()) return -1;
    std::vector<int> tuned(defs_.size());
    for (size_t i = 0; i < defs_.size(); i++) tuned[i] = clampi((int)i, (int)std::lround(avg_[i]));
    std::mt19937 rng(cfg_.seed * 7919u + (unsigned)(vW_ + vD_ + vL_) + 99991u);
    std::vector<int> pick;
    pickStarts(rng, starts_.size(), cfg_.pairs, pick);
    std::vector<Game> games;
    for (int s : pick) { games.push_back({s, true}); games.push_back({s, false}); }
    std::vector<int> res;
    if (!runGames(games, tuned, init_, res)) return failed_ ? -1 : 2;
    for (int r : res) { if (r > 0) w++; else if (r < 0) l++; else d++; }
    vW_ += w; vD_ += d; vL_ += l;
    return 0;
}

std::string Tuner::verifyText() const {
    const int n = vW_ + vD_ + vL_;
    if (n == 0) return "no verification games yet";
    const double p = (vW_ + 0.5 * vD_) / n;
    const double var = (vW_ * (1 - p) * (1 - p) + vD_ * (0.5 - p) * (0.5 - p) + vL_ * p * p) / n;
    const double se = std::sqrt(var / n);
    auto elo = [](double q) { q = std::max(0.001, std::min(0.999, q)); return -400.0 * std::log10(1.0 / q - 1.0); };
    char buf[200];
    snprintf(buf, sizeof buf, "tuned vs start: +%d =%d -%d (%d games) score %.1f%%  Elo %+.0f  [%+.0f ; %+.0f] 95%%", vW_, vD_, vL_, n, 100 * p,
             elo(p), elo(p - 1.96 * se), elo(p + 1.96 * se));
    if (sprt_.enabled && sprtValid(sprt_)) return std::string(buf) + "\n" + sprtText(sprtEvaluate(vW_, vD_, vL_, sprt_), sprt_);
    return buf;
}

// ------------------------------------------------------------------------------------------------ state
bool Tuner::saveState(const std::string& path) const {
    std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp);
        if (!f) return false;
        f << "JTUNE 1\nengine " << engineName_ << "\niter " << iter_ << "\ngames " << games_ << "\nverify " << vW_ << " " << vD_ << " " << vL_ << "\n";
        char buf[200];
        for (size_t i = 0; i < defs_.size(); i++) {
            snprintf(buf, sizeof buf, "p %s %d %.6f %.6f\n", defs_[i].name.c_str(), init_[i], theta_[i], avg_[i]);
            f << buf;
        }
        f.flush();
        if (!f) return false;
    }
    return std::rename(tmp.c_str(), path.c_str()) == 0;
}

bool Tuner::loadState(const std::string& path, std::string* err) {
    std::ifstream f(path);
    if (!f) { if (err) *err = "no state file"; return false; }
    std::string line, tag;
    int ver = 0, it = 0, vw = 0, vd = 0, vl = 0;
    long long gm = 0;
    std::map<std::string, std::vector<double>> P;
    std::string eng;
    if (!std::getline(f, line) || sscanf(line.c_str(), "JTUNE %d", &ver) != 1 || ver != 1) { if (err) *err = "bad state file"; return false; }
    while (std::getline(f, line)) {
        std::istringstream is(line);
        is >> tag;
        if (tag == "engine") { std::getline(is, eng); while (!eng.empty() && eng[0] == ' ') eng.erase(0, 1); }
        else if (tag == "iter") is >> it;
        else if (tag == "games") is >> gm;
        else if (tag == "verify") is >> vw >> vd >> vl;
        else if (tag == "p") {
            std::string name; double a, b, c;
            if (is >> name >> a >> b >> c) P[name] = {a, b, c};
        }
    }
    iter_ = it; games_ = gm; vW_ = vw; vD_ = vd; vL_ = vl;
    for (size_t i = 0; i < defs_.size(); i++) {
        auto k = P.find(defs_[i].name);
        if (k == P.end()) continue;
        init_[i] = clampi((int)i, (int)std::lround(k->second[0]));
        theta_[i] = std::max((double)defs_[i].lo, std::min((double)defs_[i].hi, k->second[1]));
        avg_[i] = std::max((double)defs_[i].lo, std::min((double)defs_[i].hi, k->second[2]));
    }
    // The engine may have changed since the state was written (a newer JORO with more / fewer parameters): what it still has
    // continues, what is new starts at its default, what it lost is dropped. Say so.
    int fresh = 0, lost = 0;
    for (auto& d : defs_) if (!P.count(d.name)) fresh++;
    for (auto& kv : P) { bool have = false; for (auto& d : defs_) if (d.name == kv.first) { have = true; break; } if (!have) lost++; }
    stateNote_.clear();
    if (!eng.empty() && eng != engineName_) stateNote_ = "state written by \"" + eng + "\", now \"" + engineName_ + "\". ";
    if (fresh || lost) stateNote_ += std::to_string(fresh) + " new parameter(s) start at their default, " + std::to_string(lost) + " of the state no longer exist.";
    return true;
}

bool Tuner::appendCsv(const std::string& path, const TuneStep& s) const {
    bool fresh = false;
    { std::ifstream t(path); fresh = !t.good() || t.peek() == std::ifstream::traits_type::eof(); }
    std::ofstream f(path, std::ios::app);
    if (!f) return false;
    if (fresh) {
        f << "iter,W,D,L";
        for (auto& d : defs_) f << "," << d.name;
        f << "\n";
    }
    f << s.iter << "," << s.w << "," << s.d << "," << s.l;
    for (size_t i = 0; i < defs_.size(); i++) f << "," << clampi((int)i, (int)std::lround(avg_[i]));
    f << "\n";
    return (bool)f;
}

} // namespace joro
