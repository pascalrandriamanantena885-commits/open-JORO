// JORO - uciproc.h : a UCI engine as a child process (POSIX: Linux and Android native code), header only.
// Used by the SPSA tuner to (1) read which parameters an engine exposes and (2) play the tuning games against it.
#pragma once
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <sstream>
#include <string>
#include <vector>

namespace joro {

class UciProc {
public:
    UciProc() = default;
    UciProc(const UciProc&) = delete;
    UciProc& operator=(const UciProc&) = delete;
    ~UciProc() { close(); }

    bool start(const std::string& path) {
        ::signal(SIGPIPE, SIG_IGN);
        int a[2], b[2];
        if (::pipe(a)) return false;
        if (::pipe(b)) { ::close(a[0]); ::close(a[1]); return false; }
        for (int fd : {a[0], a[1], b[0], b[1]}) ::fcntl(fd, F_SETFD, FD_CLOEXEC);   // a sibling child must never inherit these ends
        pid_ = ::fork();
        if (pid_ < 0) { ::close(a[0]); ::close(a[1]); ::close(b[0]); ::close(b[1]); pid_ = -1; return false; }
        if (pid_ == 0) {                                  // child: only async-signal-safe calls until exec
            ::dup2(a[0], 0);
            ::dup2(b[1], 1);
            int nul = ::open("/dev/null", O_WRONLY);
            if (nul >= 0) ::dup2(nul, 2);
            ::execl(path.c_str(), path.c_str(), (char*)nullptr);
            ::_exit(127);
        }
        ::close(a[0]);
        ::close(b[1]);
        wfd_ = a[1];
        rfd_ = b[0];
        return true;
    }

    bool send(const std::string& s) {
        if (wfd_ < 0) return false;
        std::string t = s + "\n";
        size_t off = 0;
        while (off < t.size()) {
            ssize_t n = ::write(wfd_, t.data() + off, t.size() - off);
            if (n <= 0) return false;
            off += (size_t)n;
        }
        return true;
    }

    // 1 = a line was read, 0 = timeout, -1 = the engine is gone
    int readLine(std::string& line, int timeoutMs) {
        for (;;) {
            size_t nl = buf_.find('\n');
            if (nl != std::string::npos) {
                line = buf_.substr(0, nl);
                buf_.erase(0, nl + 1);
                while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
                return 1;
            }
            if (rfd_ < 0) return -1;
            struct pollfd p = {rfd_, POLLIN, 0};
            int r = ::poll(&p, 1, timeoutMs);
            if (r == 0) return 0;
            if (r < 0) { if (errno == EINTR) continue; return -1; }
            char tmp[4096];
            ssize_t n = ::read(rfd_, tmp, sizeof tmp);
            if (n <= 0) return -1;
            buf_.append(tmp, (size_t)n);
        }
    }

    // Reads until a line starts with `prefix` (returned in *found). false on timeout / the engine is gone.
    bool waitFor(const char* prefix, int timeoutMs, std::string* found = nullptr) {
        const size_t len = std::strlen(prefix);
        int left = timeoutMs;
        while (left > 0) {
            std::string l;
            int r = readLine(l, left < 50 ? left : 50);
            if (r < 0) return false;
            if (r == 0) { left -= 50; continue; }
            if (l.compare(0, len, prefix) == 0) { if (found) *found = l; return true; }
        }
        return false;
    }

    bool alive() const { return pid_ > 0 && rfd_ >= 0; }

    void close() {
        if (wfd_ >= 0) { send("quit"); ::close(wfd_); wfd_ = -1; }
        if (pid_ > 0) { ::kill(pid_, SIGKILL); ::waitpid(pid_, nullptr, 0); pid_ = -1; }
        if (rfd_ >= 0) { ::close(rfd_); rfd_ = -1; }
        buf_.clear();
    }

private:
    pid_t pid_ = -1;
    int wfd_ = -1, rfd_ = -1;
    std::string buf_;
};

// One "option name N type T [default D] [min A] [max B] [var V]..." line of the UCI handshake.
struct UciOption {
    std::string name, type;
    long long def = 0, lo = 0, hi = 0;
    bool hasMin = false, hasMax = false;
};

inline bool uciParseOption(const std::string& line, UciOption& o) {
    std::istringstream is(line);
    std::string t;
    if (!(is >> t) || t != "option") return false;
    std::vector<std::string> tok;
    while (is >> t) tok.push_back(t);
    size_t i = 0;
    if (i >= tok.size() || tok[i] != "name") return false;
    i++;
    o = UciOption();
    while (i < tok.size() && tok[i] != "type") { o.name += (o.name.empty() ? "" : " ") + tok[i]; i++; }
    if (i + 1 >= tok.size() || o.name.empty()) return false;
    o.type = tok[i + 1];
    i += 2;
    while (i + 1 < tok.size()) {
        if (tok[i] == "default") { o.def = atoll(tok[i + 1].c_str()); i += 2; }
        else if (tok[i] == "min") { o.lo = atoll(tok[i + 1].c_str()); o.hasMin = true; i += 2; }
        else if (tok[i] == "max") { o.hi = atoll(tok[i + 1].c_str()); o.hasMax = true; i += 2; }
        else i++;
    }
    return true;
}

// Starts the engine, sends "uci" and collects its name and its options. The process is closed again.
inline bool uciProbe(const std::string& path, std::string& idName, std::vector<UciOption>& opts, std::string* err = nullptr) {
    UciProc p;
    if (!p.start(path)) { if (err) *err = "cannot start " + path; return false; }
    p.send("uci");
    idName.clear();
    opts.clear();
    for (;;) {
        std::string l;
        int r = p.readLine(l, 5000);
        if (r <= 0) { if (err) *err = "no uciok from " + path; return false; }
        if (l == "uciok") break;
        if (l.compare(0, 8, "id name ") == 0) idName = l.substr(8);
        else if (l.compare(0, 7, "option ") == 0) { UciOption o; if (uciParseOption(l, o)) opts.push_back(o); }
    }
    return true;
}

} // namespace joro
