// JORO - tunables.h : search constants as parameters (so SPSA can tune them) + a combined style/search tuning file.
//
// SearchParams defaults reproduce EXACTLY the constants that used to be hard-coded in search.cpp.
// A tuning file is the usual style JSON plus a "search" object:
//   { "name": "JORO-tuned", "weights": { "own_king": 100, ... }, "search": { "rfp_margin": 120, ... } }
// Style::load() ignores the "search" part and loadTuning() reads both, so old style files keep working.
#pragma once
#include "eval.h"
#include <string>

namespace joro {

enum SearchParam {
    SPR_RFP_MARGIN,   // reverse futility: staticEval - margin*depth >= beta
    SPR_RFP_DEPTH,    // ... only for depth <= this
    SPR_NULL_BASE,    // null move reduction R = base + depth / div
    SPR_NULL_DIV,
    SPR_DELTA,        // quiescence delta pruning margin (cp)
    SPR_LMR_START,    // late move reductions start after this many legal moves
    SPR_LMR_MORE,     // ... one more ply of reduction after this many
    SPR_PLAN_FIRST,   // JORO plans A/B/C : PP_COUNT consecutive values (see PlanParam in eval.h), passed to evaluate()
    SPR_COUNT = SPR_PLAN_FIRST + PP_COUNT
};

struct SearchParams {
    int v[SPR_COUNT];
    SearchParams();
    static const char* paramName(int i);
    bool set(const std::string& name, int value);
};

// SPSA ranges. A parameter that has no row here is still tuned with a default range, so adding a style weight or a search
// constant never needs a change in the tuner: the number of parameters follows SP_COUNT / SPR_COUNT / PP_COUNT.
struct StyleTuneDef { bool tuned; int lo, hi; double c; };   // tuned=false : left alone (contempt interacts with draws)
StyleTuneDef styleTuneDef(int i);
struct SearchTuneDef { int lo, hi; double c; };              // i < SPR_PLAN_FIRST (the plan parameters carry their own range)
const SearchTuneDef& searchTuneDef(int i);

// Process-wide default used by every new Searcher (the app sets it from the "active" tuning file).
SearchParams& defaultSearchParams();

// Style weights + search parameters in one JSON file. Missing keys keep the value already in `st` / `sp`.
bool loadTuning(const std::string& path, Style& st, SearchParams& sp, std::string* err = nullptr);
bool loadTuningText(const std::string& json, Style& st, SearchParams& sp);
bool saveTuning(const std::string& path, const Style& st, const SearchParams& sp);

} // namespace joro
