// JORO - tuner.h : SPSA tuning of the style weights and of the search constants, by self-play (no UCI, in-process).
//
// One iteration (step):
//   1. every parameter theta_i gets a random direction D_i = +-1 and a perturbation delta_i (c_i * c_k, at least 0.5)
//   2. A plays with theta + delta*D, B with theta - delta*D: `pairs` openings x 2 colours, equal time per move
//   3. d = (wins - losses) / games, in [-1, 1].  theta_i += a_k * c_i * D_i * d   (a_k decays slowly)
//   4. an exponential moving average of theta is kept: it is the value that is exported (less noisy than theta)
// The state is written after every iteration (resume after a pause, a stop or a killed process). Pause / stop act at the
// next move, so a phone can be paused at any time without losing anything but the games of the current iteration.
//
// WHAT IS TUNED is never a fixed list: the parameters come from a list of TuneDef built at start-up.
//   * built-in (enginePath empty): every style weight (SP_COUNT, minus the untuned ones), every search constant (SPR_PLAN_FIRST)
//     and every plan parameter (PP_COUNT) of the compiled core. Adding one to the enums adds it to the tuning.
//   * external engine (enginePath = a UCI executable, e.g. a newer JORO imported into the app): the list is read from the
//     engine itself ("option name Style_x / Search_x type spin ..." after `uci`), so 12 or 20 style weights and 5 or 11 search
//     constants are tuned just as well as 14 and 7. The games are played through UCI (two processes per thread).
#pragma once
#include "search.h"
#include "tunables.h"
#include "sprt.h"
#include <atomic>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace joro {

struct TuneStart { std::string fen; std::vector<std::string> moves; };   // moves: UCI text, played from fen

// One start per line: a FEN (the line contains '/', 4 or 6 fields) or UCI moves from the standard start. '#' = comment.
std::vector<TuneStart> parseTuneStarts(const std::string& text);

struct TuneConfig {
    int pairs = 8;             // openings per iteration; each is played twice (A white, A black) -> 2*pairs games
    int movetimeMs = 40;       // per move
    int64_t nodes = 0;         // > 0 replaces movetimeMs (reproducible, independent of the CPU speed)
    int threads = 2;           // games played at the same time
    int hashMB = 8;            // per searcher
    unsigned seed = 1;
    double eta = 1.0;          // step size (1 = a unanimous win moves each theta by about c_i)
    double decay = 50;         // the step shrinks as (1 + iter / decay)^-0.602
    int emaWindow = 20;        // iterations averaged in the exported value
    int maxPlies = 300;
    bool tuneStyle = true;     // the 14 style weights (contempt is never tuned)
    bool tuneSearch = true;    // the search constants (tunables.h)
    bool tunePlans = true;     // the plan parameters (plan A / B / C, selection thresholds, LMR relief)
    std::string enginePath;    // "" = the compiled-in JORO core, in-process. Else a UCI engine: its parameters are discovered, games go through UCI
    std::string startText;     // external engine only: tuning/style JSON to start from (names without the Style_/Search_ prefix)
};

// One tuned parameter. group: 0 style weight, 1 search constant, 2 plan parameter.
struct TuneDef {
    std::string name;          // "own_king", "rfp_margin", "plan_a_check" (no prefix: this is also the key in the state / tuning files)
    std::string uci;           // external engine: the UCI option ("Style_own_king"); empty in-process
    int group = 0;
    bool style = false;        // in-process: lives in Style::w (else SearchParams::v)
    int idx = 0;               // in-process: index in Style::w / SearchParams::v
    int lo = 0, hi = 0;
    double c = 1.0;            // SPSA perturbation size
    int init = 0;              // starting value
};

// The parameters that would be tuned. enginePath empty = built-in (base / baseSp = starting values), else read from the engine.
// false: the engine cannot be started or exposes nothing (err filled). engineName = "JORO 0.4 v5" or "built-in".
bool tuneDefs(const TuneConfig& cfg, const Style& base, const SearchParams& baseSp, std::vector<TuneDef>& out, std::string& engineName, std::string* err = nullptr,
              std::vector<std::pair<std::string, int>>* fixed = nullptr);   // fixed: external options set by the start file but not tuned
// How many of each group an engine exposes (the app shows them next to the switches). "" = built-in.
bool tuneCounts(const std::string& enginePath, int& style, int& search, int& plan, std::string* engineName = nullptr, std::string* err = nullptr);

// One side of a tuning game: the compiled-in searcher, or a UCI process.
class TunePlayer {
public:
    virtual ~TunePlayer() {}
    virtual bool configure(const std::vector<int>& vals) = 0;   // values of the tuned parameters (same order as the TuneDefs)
    virtual void newGame() = 0;
    // 0 = move, 1 = no move, 2 = aborted, 3 = the engine failed, 4 = the engine played an illegal move.
    // `played` = UCI moves from st.fen, b = the position after them.
    virtual int think(Board& b, const TuneStart& st, const std::vector<std::string>& played, const Limits& lim, Move& best, int& score) = 0;
    virtual void abort() = 0;
};

struct TuneStep { int iter = 0; long long games = 0; int w = 0, d = 0, l = 0; };   // result of ONE iteration (A = theta+)

class Tuner {
public:
    // base: values of the parameters that are not tuned, and the starting point of the tuned ones.
    Tuner(const TuneConfig& cfg, std::vector<TuneStart> starts, const Style& base, const SearchParams& baseSp);
    ~Tuner();
    const std::string& initError() const { return error_; }   // why paramCount() is 0 (engine cannot start, ...); also the reason of a failed step

    bool loadState(const std::string& path, std::string* err = nullptr);   // resumes theta / average / counters
    bool saveState(const std::string& path) const;                          // atomic (tmp + rename)
    bool appendCsv(const std::string& path, const TuneStep& s) const;       // one line per iteration

    // 0 = ok, 2 = stopped (nothing was changed), -1 = error (no start positions / nothing to tune)
    int step(TuneStep& out);
    // One batch of verification games: the exported (averaged) values against the starting values. Adds to the totals.
    int verifyStep(int& w, int& d, int& l);
    // SPRT on the verification totals (tuned vs start): H1 = the tuned values are better by >= elo1, H0 = not better than elo0.
    // The test is computed from the totals (vW_/vD_/vL_ are in the state file), so it survives a pause / a restart.
    void setSprt(const SprtConfig& c) { sprt_ = c; }
    const SprtConfig& sprtConfig() const { return sprt_; }
    SprtResult sprtResult() const { return sprtEvaluate(vW_, vD_, vL_, sprt_); }

    void stop();                                   // thread-safe, final
    void setPaused(bool p);                        // thread-safe; workers sleep at the next move (no CPU)
    bool isPaused() const { return paused_; }
    bool isWaiting() const;                        // true when every worker really sleeps
    bool wasStopped() const { return stopped_; }

    int iteration() const { return iter_; }
    long long games() const { return games_; }
    void verifyTotals(int& w, int& d, int& l) const { w = vW_; d = vD_; l = vL_; }
    Style tunedStyle() const;                      // base + the averaged values, rounded
    SearchParams tunedSearch() const;
    bool exportTuned(const std::string& path) const;   // tuning file (style + search)
    std::string table() const;                     // "name  start -> averaged (current)" one per line
    std::string verifyText() const;                // "+W =D -L ... Elo ..." of the verification totals
    int paramCount() const { return (int)defs_.size(); }
    int groupCount(int group) const;                  // style (0), search (1) and plan (2) parameters tuned
    std::string summary() const;                      // "14 style + 7 search + 18 plan = 39 parameters (engine ...)"
    std::string paramList() const;                    // one line per parameter: group, name, start, range, step
    const std::string& engineName() const { return engineName_; }
    std::string stateNote() const { return stateNote_; }   // after loadState: parameters the state did not know / that the engine no longer has

private:
    struct Game { int start; bool aWhite; };
    TuneConfig cfg_;
    std::vector<TuneStart> starts_;
    Style baseStyle_;
    SearchParams baseSp_;
    std::vector<TuneDef> defs_;
    std::string engineName_ = "built-in", error_, stateNote_;
    std::vector<std::pair<std::string, int>> fixed_;    // external engine: options of the start file that are not tuned
    std::vector<double> theta_, avg_;
    std::vector<int> init_;
    int iter_ = 0;
    long long games_ = 0;
    int vW_ = 0, vD_ = 0, vL_ = 0;
    SprtConfig sprt_;
    std::vector<std::unique_ptr<TunePlayer>> poolA_, poolB_;

    std::atomic<bool> stopped_{false}, paused_{false}, failed_{false};
    std::atomic<int> active_{0}, sleeping_{0};
    mutable std::mutex mu_;
    std::condition_variable cv_;

    void apply(const std::vector<int>& vals, Style& st, SearchParams& sp) const;
    int clampi(int i, int v) const;
    bool runGames(const std::vector<Game>& games, const std::vector<int>& valsA, const std::vector<int>& valsB, std::vector<int>& res);
    int playGame(TunePlayer& A, TunePlayer& B, const TuneStart& st, bool aWhite);
    void gate();
};

} // namespace joro
