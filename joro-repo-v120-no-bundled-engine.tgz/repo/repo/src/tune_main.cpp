// JORO - tune_main.cpp : SPSA tuning from the command line (the Android app uses the same Tuner through JNI).
//   joro_tune --openings tools/lines.txt --iters 200 --state tuning/tune.state --out tuning/tuned.style
//   joro_tune --verify 20 --state tuning/tune.state        (tuned vs starting values, 20 batches)
#include "tuner.h"
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>

using namespace joro;

static Tuner* g_tuner = nullptr;
static void onSignal(int) { if (g_tuner) g_tuner->stop(); }

static void usage() {
    printf("joro_tune [options]\n"
           "  --openings F     start positions: UCI-move lines or FENs/EPD (default tools/lines.txt)\n"
           "  --start F        tuning/style file to start from (default: JORO defaults)\n"
           "  --state F        state file: written after every iteration, resumed when it exists (default tune.state)\n"
           "  --out F          tuning file written at the end (style + search), default tuned.style\n"
           "  --iters N        iterations to run in this call (default 100)\n"
           "  --pairs N        openings per iteration, each played twice (default 8)\n"
           "  --movetime MS    per move (default 40)   --nodes N  node limit per move instead of time\n"
           "  --threads N      games at the same time (default 2)   --hash MB per searcher (default 8)\n"
           "  --eta X          step size (default 1.0)   --decay N (default 50)   --ema N (default 20)\n"
           "  --engine PATH    tune a UCI engine (e.g. a newer JORO): its Style_* / Search_* options are discovered, so any number of\n"
           "                   style weights / search constants is tuned. Without it the compiled-in core is tuned in-process\n"
           "  --list-params    print the parameters that would be tuned (and how many) then exit\n"
           "  --seed N         --no-style / --no-search / --no-plans  skip a group;  --plans-only  tune only the plan parameters\n"
           "  --verify N       after the iterations (or alone with --iters 0): N batches of tuned-vs-start games\n"
           "  --sprt E0,E1[,A,B]  verification as a SPRT: stops as soon as it is decided (H1 = tuned is better by >= E1 Elo,\n"
           "                   H0 = not better than E0). A, B = risks (default 0.05). --verify N is then the maximum (default 300)\n");
}

int main(int argc, char** argv) {
    initTables();
    TuneConfig cfg;
    std::string openings = "tools/lines.txt", startFile, statePath = "tune.state", out = "tuned.style";
    int iters = 100, verify = 0;
    bool listOnly = false;
    SprtConfig sprt;
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        auto next = [&]() -> std::string { return i + 1 < argc ? argv[++i] : ""; };
        if (a == "--openings") openings = next();
        else if (a == "--start") startFile = next();
        else if (a == "--state") statePath = next();
        else if (a == "--out") out = next();
        else if (a == "--iters") iters = atoi(next().c_str());
        else if (a == "--pairs") cfg.pairs = atoi(next().c_str());
        else if (a == "--movetime") cfg.movetimeMs = atoi(next().c_str());
        else if (a == "--nodes") cfg.nodes = atoll(next().c_str());
        else if (a == "--threads") cfg.threads = atoi(next().c_str());
        else if (a == "--hash") cfg.hashMB = atoi(next().c_str());
        else if (a == "--eta") cfg.eta = atof(next().c_str());
        else if (a == "--decay") cfg.decay = atof(next().c_str());
        else if (a == "--ema") cfg.emaWindow = atoi(next().c_str());
        else if (a == "--seed") cfg.seed = (unsigned)atoi(next().c_str());
        else if (a == "--engine") cfg.enginePath = next();
        else if (a == "--list-params") listOnly = true;
        else if (a == "--no-style") cfg.tuneStyle = false;
        else if (a == "--no-search") cfg.tuneSearch = false;
        else if (a == "--no-plans") cfg.tunePlans = false;
        else if (a == "--plans-only") { cfg.tuneStyle = false; cfg.tuneSearch = false; cfg.tunePlans = true; }
        else if (a == "--verify") verify = atoi(next().c_str());
        else if (a == "--sprt") {
            if (!sprtParse(next(), sprt)) { printf("bad --sprt (use E0,E1[,ALPHA,BETA] with E0 < E1, 0 < ALPHA,BETA < 0.5)\n"); return 1; }
        }
        else { usage(); return 1; }
    }
    if (!cfg.enginePath.empty() && !startFile.empty()) {          // an external engine reads the start file by names, not by this build's enums
        std::ifstream sf(startFile);
        std::stringstream sss;
        sss << sf.rdbuf();
        cfg.startText = sss.str();
    }
    std::ifstream f(openings);
    if (!f) { printf("cannot open %s\n", openings.c_str()); return 1; }
    std::stringstream ss;
    ss << f.rdbuf();
    std::vector<TuneStart> starts = parseTuneStarts(ss.str());
    if (starts.empty()) { printf("no usable start position in %s\n", openings.c_str()); return 1; }

    Style st;
    SearchParams sp;
    if (!startFile.empty() && cfg.enginePath.empty()) {
        std::string err;
        if (!loadTuning(startFile, st, sp, &err)) { printf("cannot load %s: %s\n", startFile.c_str(), err.c_str()); return 1; }
    }
    if (sprt.enabled && verify <= 0) verify = 300;
    Tuner t(cfg, starts, st, sp);
    if (t.paramCount() == 0) { printf("nothing to tune: %s\n", t.initError().c_str()); return 1; }
    if (listOnly) { printf("%s\n%s", t.summary().c_str(), t.paramList().c_str()); return 0; }
    t.setSprt(sprt);
    g_tuner = &t;
    std::signal(SIGINT, onSignal);
    std::signal(SIGTERM, onSignal);
    std::string err;
    if (t.loadState(statePath, &err)) printf("resumed %s: iteration %d, %lld games\n", statePath.c_str(), t.iteration(), t.games());
    if (!t.stateNote().empty()) printf("note: %s\n", t.stateNote().c_str());
    printf("%s\n", t.summary().c_str());
    printf("%d starts, %d parameters, %d games/iteration, %d thread(s), %s\n", (int)starts.size(), t.paramCount(), cfg.pairs * 2, cfg.threads,
           cfg.nodes > 0 ? "node limit" : "time limit");

    int rc = 0;
    for (int k = 0; k < iters; k++) {
        TuneStep s;
        rc = t.step(s);
        if (rc != 0) break;
        t.saveState(statePath);
        t.appendCsv(statePath + ".csv", s);
        printf("iter %4d  A +%d =%d -%d   games %lld\n", s.iter, s.w, s.d, s.l, s.games);
        fflush(stdout);
    }
    if (rc == 2) printf("stopped (the state is saved)\n");
    if (rc == -1) { printf("error: %s\n", t.initError().empty() ? "nothing to tune or no start position" : t.initError().c_str()); return 1; }
    if (rc == 0 && verify > 0) {
        for (int k = 0; k < verify; k++) {
            if (sprt.enabled && t.sprtResult().decision != SPRT_CONTINUE) break;   // already decided (resumed state)
            int w, d, l;
            rc = t.verifyStep(w, d, l);
            if (rc != 0) break;
            t.saveState(statePath);
            if (sprt.enabled) {
                SprtResult r = t.sprtResult();
                printf("verify %3d  +%d =%d -%d   LLR %.2f  (%.2f ; %.2f)\n", k + 1, r.w, r.d, r.l, r.llr, r.lower, r.upper);
                fflush(stdout);
                if (r.decision != SPRT_CONTINUE) break;
            }
        }
        printf("%s\n", t.verifyText().c_str());
    }
    printf("\n%s", t.table().c_str());
    if (t.exportTuned(out)) printf("\nwritten: %s\n", out.c_str());
    return 0;
}
