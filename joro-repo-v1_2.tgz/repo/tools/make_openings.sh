#!/bin/sh
# usage: tools/make_openings.sh ./build/joro tools/lines.txt > openings/openings.epd
# turns lines of UCI moves into EPD positions (uses JORO's own "d" command)
ENGINE=${1:-./build/joro}; LINES=${2:-tools/lines.txt}
while read -r moves; do
  [ -z "$moves" ] && continue
  printf 'position startpos moves %s\nd\nquit\n' "$moves" | "$ENGINE" | sed -n 's/^Fen: //p' | cut -d' ' -f1-4
done < "$LINES"
