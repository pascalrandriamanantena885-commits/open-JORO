#!/usr/bin/env python3
"""Read fastchess PGNs (out/sf_<elo>.pgn) and estimate JORO's Elo.

usage: calib_report.py <pgn_dir> <commit> <exp_tag> <history_csv>
Writes a markdown summary to stdout and appends one row to history_csv.
"""
import glob, math, os, re, sys, datetime


def parse(path):
    w = d = l = 0
    for game in re.split(r"\n\n(?=\[Event )", open(path, encoding="utf-8", errors="ignore").read()):
        white = re.search(r'\[White "([^"]+)"\]', game)
        res = re.search(r'\[Result "([^"]+)"\]', game)
        if not white or not res:
            continue
        r = res.group(1)
        if r == "1/2-1/2":
            d += 1
        elif r in ("1-0", "0-1"):
            joro_white = white.group(1) == "JORO"
            if (r == "1-0") == joro_white:
                w += 1
            else:
                l += 1
    return w, d, l


def elo_from_score(s):
    return -400.0 * math.log10(1.0 / s - 1.0)


def main():
    pgn_dir, commit, tag, hist = sys.argv[1:5]
    rows, num, den = [], 0.0, 0.0
    for path in sorted(glob.glob(os.path.join(pgn_dir, "sf_*.pgn"))):
        sf = int(re.search(r"sf_(\d+)\.pgn", path).group(1))
        w, d, l = parse(path)
        n = w + d + l
        if n == 0:
            continue
        s = (w + 0.5 * d) / n
        s = min(max(s, 0.5 / n), 1 - 0.5 / n)  # clamp : avoid infinite Elo on 100% / 0%
        var = (w * (1 - s) ** 2 + d * (0.5 - s) ** 2 + l * s ** 2) / n
        err = 1.96 * math.sqrt(var / n)
        lo, hi = max(s - err, 0.5 / n), min(s + err, 1 - 0.5 / n)
        est = sf + elo_from_score(s)
        rows.append((sf, w, d, l, s, est, elo_from_score(hi) - elo_from_score(lo)))
        wt = n * s * (1 - s)  # inverse-variance weight : levels close to 50% are the most informative
        num += wt * est
        den += wt
    print("## JORO calibration vs Stockfish (UCI_Elo)\n")
    print(f"commit `{commit}` | experience `{tag}`\n")
    print("| SF Elo | W | D | L | score | JORO est. | 95% width |")
    print("|---:|--:|--:|--:|--:|--:|--:|")
    for sf, w, d, l, s, est, width in rows:
        print(f"| {sf} | {w} | {d} | {l} | {s*100:.1f}% | {est:.0f} | ±{width/2:.0f} |")
    overall = num / den if den else float("nan")
    print(f"\n**Estimated JORO Elo (weighted): {overall:.0f}**")
    print("\n_Note: Stockfish UCI_Elo is calibrated for its own time control; use the number to compare JORO versions with each other._")
    new = not os.path.exists(hist)
    with open(hist, "a") as f:
        if new:
            f.write("date,commit,experience,elo_estimate," + ",".join(f"sf{r[0]}_score" for r in rows) + "\n")
        f.write(f"{datetime.date.today()},{commit},{tag},{overall:.0f}," + ",".join(f"{r[4]:.3f}" for r in rows) + "\n")


if __name__ == "__main__":
    main()
