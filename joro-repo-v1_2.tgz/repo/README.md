# JORO v0.4

UCI chess engine (C++17) with a patchable **experience file** (`joro.exp`).

## Build
    cmake -S . -B build && cmake --build build -j      # or: g++ -O3 -std=c++17 -pthread src/*.cpp -o joro
    ./build/joro        # speaks UCI

## UCI options
| option | meaning |
|---|---|
| ExperienceFile | path to `joro.exp` (the patch produced by the trainer app) |
| UseExperience | on/off |
| ExperienceStyle | apply the style stored in the file |
| StyleFile | path to a style file |
| Style_<param> | one weight (own_king, enemy_king, ... contempt) |
| StrictStyle | ignore experience made with another style |
| Hash, MoveOverhead | usual |

Debug commands: `d` (FEN + key), `eval`, `perft N`.

## JORO style (`styles/joro.style`, from "JORO PLAYING STYLE v1.0")
One identity for all of JORO. Each module of the style document is an evaluation module with a weight (% , 100 = nominal):
| module | param(s) | implemented as |
|---|---|---|
| DKD dual king dominance | own_king, enemy_king | pawn shield, open files on own king; king-zone attack units on the enemy king |
| TBDA target behind defense | pins, loose | pins/x-rays on king & queen, hanging pieces, overloaded defenders |
| SI sacrifice intelligence | compensation | bonus offsetting a material deficit when attack/activity/development justify it |
| DSI deep square intelligence | outposts, potential | outposts, squares a knight can reach next, rooks on files toward the king |
| PASI phase-aware | opening, endgame | development/centre/castling early; mop-up, king vs passers, opposite bishops late |
| DPSI pawn structure | structure, passers | isolated/doubled/backward, chains, connected & free passers |
| IPC initiative | initiative | threats by lesser pieces, space, tempo |
| KHTI king hunting & trap | king_hunt | enemy king escape squares (free / controlled / blocked), isolation from its defenders, open lines & batteries aimed at it, mating-net bonus; in the search, a check that leaves the king at most one flight square is extended |
Search-level parts (tactics: deflection, decoy, clearance, interference, sacrifices) come from the search itself.
`styles/neutral.style` = ablation baseline. The experience file stores the style id: an experience made with another
style is ignored (`StrictStyle`), and `joro_train` refuses to continue a file of another style.
A/B test: `joro_match --a styles/joro.style --b styles/neutral.style --movetime 50`.
Measured here (48 games, 40 ms/move): JORO style 59% vs neutral - positive but small sample.
KHTI A/B (same style, only `king_hunt` changes, 48 games each, 40 ms/move): weight 100 -> 42% ; weight 100 without the search
extension -> 44% ; weight 50 -> 59%. The samples are small (+-70 Elo) but 50 is the default (`styles/joro.style`). The
weight can be changed (`--set king_hunt=N`, UCI `Style_king_hunt`). Pieces of KHTI that are only approximated by the static
evaluation: "king attraction" (sacrifices/forcing sequences are found by the search, not planned) and "unsafe square
prediction" (only squares already controlled are counted). An experience made before KHTI stays valid (its style id is the
KHTI-off id): the engine uses it with the current style; the trainer upgrades it to the current style on the next training.

## King Position Classifier (v0.5)
`classifyKing(board, color)` -> short-castled / long-castled / uncastled-center / exposed / edge / other, plus shield pawns,
missing shield pawns and open shield files (`eval` debug command prints it). KHTI uses it (middlegame only, scaled by
`king_hunt`): missing shield, rooks/queen/double rooks on the shield files, pawn storm, uncastled king facing open lines,
enemy rook shut in by its own king (Rh8+Kg8). Not A/B-tested yet: run `joro_match` before changing the default weight.

## Etudes (training by enemy-king type)
`tools/etudes.txt`: 10 categories (short, long, uncastled, exposed, shield, weakshield, edge, restricted, isolated,
matingnet), 2-3 start positions each; line format `category ; startpos|FEN ; moves`.
    ./build/joro_train --etudes tools/etudes.txt --depth 8 --games 40 --out experience/joro.exp
The run ends with a per-category table (games, W/B/D, new bad, new brilliant/great). The positions are seeds written by
hand: short/long/uncastled/exposed/edge/weakshield were checked with the classifier; restricted/isolated/matingnet are
only plausible positions, not verified.

## A/B gate and endgame etudes (v0.5)
* After a training the new experience plays the previous one (`joro_train --gate 2 --gate-ms 60`, on by default: 2 games per
  trained opening, both colours, at most 8 openings). Under 45% -> the previous file is restored and the new one is kept as
  `OUT.rejected`; the previous file is always kept as `OUT.bak`. It only catches big regressions (a few games are noisy).
  Endgame etudes are not gated (a won position gives the same result for both colours). The app does the same with its
  switch in the Train tab (only when an experience file existed before the training).
* `tools/etudes.txt` has 10 endgame etudes (`eg-*`: K+Q, K+R, K+2R, K+2B, K+2P, Q+R vs R, back-rank, Q vs pawns); in the app
  they are a switch in the Train tab. Every mating line is stored with its speed, so mates get faster over time.

## Self-play strength (v0.5)
`--depth-weak 5 --depth-strong 8` (defaults) or `--ms-weak 150 --ms-strong 400`; `--equal` = both sides alike. The strong
side alternates White/Black every game, so a rematch swaps roles. A mating line won against the strong defender gets a
quality bonus (+50, about 6 plies of speed) because it is more reliable than one won against the weak side. In the app
(Train tab) the same values are the prefilled inputs; a switch chooses depth or milliseconds.

## Variation memory (v0.5)
The experience is mainly a memory of **variations that end in checkmate**:
* A game won by checkmate stores EVERY move of the winner (any length - 10 plies or 150), indexed by position, with a
  quality = `30000 - 8 * plies_to_mate + forcing_bonus(0..7: checks + sacrifices)`. Winning material without ever mating is
  not stored; a sacrifice that ends in mate is. (`--no-lines` turns it off.)
* In play, a stored mating-line move is returned at once, with no search (bullet/blitz safe), and outranks every other
  good move; among several lines for one position the best quality (fastest, most forcing) wins.
* Progression: a better line found later raises the stored quality (max, not average); a line that loses in a rematch is
  blamed (BAD) at the cause of the defeat and the next best line, or a new search, takes over.
* **Variation Brain** (`VariationBrain` UCI option, `--no-brain`): before a move is played, a forcing-line analysis (the
  opponent plays only checks / captures / promotions, we answer with anything, 30000 nodes) refuses a move that allows a
  forced mate, a lost piece (unless the search itself says it is a sound sacrifice), a promotion, or a stalemate / draw
  while we stand clearly better. A forced mate found this way is stored as BAD. Not yet A/B-tested with `joro_match`.

## Experience file (`src/experience.h`)
Entries `(position key, move, kind GOOD/BAD, value, count)`.
* At the root JORO **removes every move marked BAD** (net count: bad > good) -> it never repeats the same error.
* If a **GOOD** move is known it is played directly (learned win).
* Header also stores the **style** (5 weights) so a patch can change how JORO plays.
Position keys use a fixed Zobrist seed, so the same file works on PC, CI and Android.

## Verified
perft: startpos d5, Kiwipete d4, pos3 d5, pos4 d4, pos5 d3, pos6 d3 : all exact. Incremental hash == full hash.
~1.2M nps, depth 14 in 2 s from startpos (single thread).

## CI
`.github/workflows/calibrate.yml` : JORO vs Stockfish (`UCI_LimitStrength`, `UCI_Elo` levels) via fastchess,
runs on every push touching `src/**` or `experience/**`; Elo estimate appended to `calibration/history.csv`.
Put the trained file at `experience/joro.exp`. Stockfish's minimum UCI_Elo is 1320.
`openings/openings.epd` is generated with `tools/make_openings.sh`.

## Trainer (`joro_train`)
    ./build/joro_train --opening "e2e4 e7e5 g1f3 b8c6" --depth 8 --out experience/joro.exp
    ./build/joro_train --openings tools/lines.txt --in experience/joro.exp --out experience/joro.exp
Self-play JORO vs JORO from the opening. After each game, for each side:
* **won** -> NO move is stored, except the **brilliant** ones (see below). (`--all-good` restores the old behaviour: every move GOOD.)
* **lost / drew** -> backtracking over its decisions: the move with the biggest eval drop (>= 100 cp) that still has
  untried alternatives is stored BAD (else the last decision with alternatives). Next game takes another variation.
Stops when: `--games` budget, `--stable` games without anything new, or `--confirm` consecutive wins by one side.
Games are deterministic (fixed depth, tables cleared) so a replay is identical until the first changed move.

## Opponents, PGN and per-opening table (v0.6)
**Mixed opponents** (`--vs ENGINE --mix self=20,ladder=60,max=20`): every game JORO plays JORO, Stockfish on the *ladder*, or
Stockfish at full strength, chosen by those proportions; JORO's colour alternates each game. The ladder uses `UCI_LimitStrength` +
`UCI_Elo` (levels `--ladder-levels`, default 1320..3190, clamped to the engine's range) and goes up one level when JORO won
`--ladder-need` of the last `--ladder-window` games at that level (default 3 of 3). The level is kept in `OUT.ladder` between
runs (`--ladder-reset` to restart). Without `--mix`, `--vs` behaves as before (full strength, fixed colour).
**First-move variety**: with probability `--vary-first` (default 5 %) JORO's first searched move after the opening is its 2nd best
(only if within `--vary-loss` cp, default 60) so the same opening does not replay the same game; `--seed` makes a run repeatable.
**PGN**: every game is written to `PREFIX_0001.pgn, _0002 ...` (`--pgn`, default `OUT_games`; `--pgn-split N` games per file,
default 100; `--no-pgn`). Moves carry `!!` brilliant, `!` great, `?` bad, `??` blunder (the BAD stored by the backtracking, drop >= 300 cp)
with `[%eval]` comments (white point of view). A sacrifice inside a mating line counts as brilliant when the mate follows within 15 moves.
**Table per opening** (`--stats`, default `OUT.stats.csv`, one row per opening and run, printed at the end of the run): games, result
vs Stockfish, mates won by JORO, shortest mate, mating variations stored (run / all runs), new bad / brilliant / great, and a progress mark
against the previous run of the same opening: +1 for a shorter mate (or the first one), +1 for at least one new mating variation, +-1 when the
share of games ending in mate moves by 10 points or more -> UP / DOWN / = / NEW. Mate length depends on the opponent met, so compare runs
that used the same `--mix`. The Android app is not wired to these yet (the code is in `trainer`, `opponent.h`, `pgn`, `opstats`).

## Next
Kotlin Android app: JNI around `joro_trainer` (start / stop / progress / export `joro.exp`).

## What the experience keeps
* **GREAT** moves of the winner (v0.5): no sacrifice needed, but a depth+1 search without that move is >= 60 cp worse
  (`--great-margin N`, `--no-great`). At most 8 verifications per side and game.
* **BAD** moves: the critical move of a lost/drawn game (backtracking). They are removed at the root, so the same mistake is never repeated.
* **Brilliant** moves of the winner, stored as GOOD and played directly: a move that gives up material (>= 2 pawns over the
  exchange) without the evaluation falling, or that starts a forced mate, AND that a deeper search (depth+1, the move excluded)
  confirms to beat every alternative by >= 120 cp. Ordinary winning moves are not stored: the search finds them again anyway,
  and a won game says little about each individual move. The experience file is therefore small and made of reliable facts.
