# JORO Calibrator (Android, offline)

Kotlin + Jetpack Compose app. Runs **JORO vs Stockfish (UCI_LimitStrength + UCI_Elo)** on the phone, for several
levels at once ("matrix"), and shows a summary with the estimated Elo of JORO. No INTERNET permission.

## How it works
* JORO and Stockfish are UCI **executables** (`libjoro.so`, `libstockfish.so` in `jniLibs/arm64-v8a`), started as child processes.
* `MatchRunner` plays games between them (clocks, adjudication, 24 openings from `assets/openings.epd`, both colours).
* `Referee` (JNI, same board code as the engine) decides mate / stalemate / draw / illegal move.
* Matrix mode: games of all levels (e.g. 2500, 2600, 2700, 3000) are interleaved in one queue and played by N workers at once.
* `Elo.kt`: score -> Elo difference, 95% interval, inverse-variance weighted overall estimate. A level where JORO scores
  0% or 100% only gives a bound (shown as <= or >=): use levels close to JORO's strength to get a real number.
* Tab **Import**: new `joro.exp` (validated: header, version, size, style id) and new JORO engine binary (arm64, UCI
  handshake tested before it is accepted). Each calibration is saved in **Tantara** with the engine name/experience.

## Training tab (no UCI)
The training runs **inside the app**: the C++ engine + trainer are called directly through JNI (`Native.kt` -> `appapi.cpp`),
there is no UCI engine, no process and no text protocol in this path. UCI is only used by the Calibrate tab (Stockfish).
* The opening is built on a **board** (tap a piece, tap the square) or taken from 23 named presets; it is shown in standard
  notation (`1. e4 e5 2. Nf3 Nc6`). A line can also be pasted in that notation.
* Self-play JORO vs JORO from that position; after each game: the loser's critical move (backtrack) -> BAD, and only the winner's verified *brilliant* moves are kept (ordinary winning moves are not stored).
  Stops on the games budget, N games with nothing new, or N consecutive wins of one side.
* The result is written to `joro.exp` after **every game** (atomic), in the app's private folder: the Calibrate tab uses
  the same file, and Import/Export of `.exp` works with it. An existing experience keeps its style.
* Keeps running in the background like the calibration (foreground service); Stop interrupts the current game at once.
* Calibrate and Training cannot run at the same time (one at a time, CPU and the experience file are shared).
* "Preset rehetra" trains the 23 openings one after another.

## Build
GitHub: run workflow `build_apk` -> artifacts `joro-calibrator-apk` (install it), `joro-engine-arm64` (file for "Import moteur").
Local: `ANDROID_NDK_HOME=... android/tools/build_engines_android.sh` then open `android/` in Android Studio.
Only arm64-v8a phones are supported (emulators x86 are not).

## Notes / limits
* `targetSdk = 28` on purpose: Android 10+ blocks executing binaries from an app's own data folder for apps
  targeting 29+, and that is what "Import moteur" needs. Fine for a side-loaded tool, not for Google Play.
* Stockfish is GPLv3: if you share the APK, share the sources too (the JORO sources are in this repo).
* Stockfish's UCI_Elo scale is calibrated for another time control/hardware: compare JORO versions with each other.
* The phone throttles when hot: keep concurrency <= cores/2, same settings between runs.

## Runs in the background
The run is owned by `CalibrationController` (process level), not by the screen. Starting a calibration also starts
`CalibrationService` (foreground service + partial wake lock + notification with progress and an "Atsaha" button).
So the calibration keeps going when the screen is off, when you leave the app, and when you swipe it away from the
recents. The result is saved in "Tantara" and announced by a notification when it ends. Reopen the app at any time: it
shows the live progress.
* Stops only if you press "Atsaha", use "Force stop" in Android settings, or the system kills the process. In that case
  the games already played are kept as a partial result at the next launch (marked `[tapaka]`).
* Some brands (Xiaomi, Huawei, Samsung "sleeping apps", ...) kill background apps aggressively: use the
  "Battery: avelao hiasa foana ny app" button and allow auto-start / no restrictions for the app.
* It does not restart by itself after a reboot.

## PGN of the calibrations
Every finished game is appended to a PGN file of the run (one file per calibration, in the app's private folder): tags with
players (`JORO ...` / `Stockfish UCI_Elo N`), result, TimeControl, Termination (checkmate, adjudication, time forfeit...),
the start position (FEN) and the moves in SAN. In **Tantara** (and under the summary) each run has **Export PGN** (system
"save as": storage, Drive, ...) and **Fafao PGN** (delete). Deleting a PGN does not touch the Elo summary.

## JORO update (engine + experience)
When an experience raised the strength, accept it: **Ekena ho JORO update** (shown under a run that was played with the
experience currently installed) or **Mamorona update** in the Import tab. The app packs the engine in use and `joro.exp` into
`JORO-update-U<n>.zip` (with a manifest: version label, experience sha, entries, style, and the calibration result), which
you can export, delete, or import on another phone (**Import update**: the experience is validated, the engine is tested with
a UCI handshake, then both are installed and the version label becomes `U<n>`). The label is shown in the Calibrate tab,
in the history and in the PGN player names.

## Auto-level (summary of a calibration)
The summary no longer averages levels: it computes one **maximum-likelihood Elo over all levels together** (a level where JORO
scored 100% or 0% still carries information), with its 95% interval, then tells which levels to test next (those where JORO
should score 25-75%), how many games per level are needed for +-50 Elo, and a button applies the suggested levels to the input.
If every level is a clean sweep, only a bound (>= / <=) can be given and the suggestion moves the ladder up/down.


## Training: pause, live view, colours (v0.5)
* **Pause / Tohizo** (button in the Train tab and in the notification): the game sleeps at the next move, the wake lock is
  released, no CPU is used; resuming continues the same game. A pause survives the change of opening.
* **Live board**: while training runs the Train tab shows the game being played (moves polled every 400 ms, only while the
  tab is on screen). Training itself runs in the foreground service, with or without the app open.
* **Colours**: cream / blue-grey board; white pieces = white with a thick black outline, black pieces = solid black with a
  thin white rim.
* Not compiled in this environment (no Android SDK): build with Gradle and test on a device.

## JORO vs Stockfish (v0.5)
Switch "JORO vs Stockfish" in the Train tab: choose the opening and JORO's colour (white/black) and Stockfish's time per
move. Stockfish plays at full strength (no UCI_LimitStrength); JORO chases checkmate, a draw is a failure. Only JORO's
moves are ever learned from (BAD when JORO loses or draws, brilliant/great when JORO mates); Stockfish's moves never enter
joro.exp. Same pause / live board / foreground service as JORO vs JORO. Needs libstockfish.so in the APK.
Games are decided by checkmate only (the 900 cp adjudication is off by default; `--adjudicate` on the CLI turns it on).
CLI: `joro_train --opening "e2e4 e7e5" --vs /path/to/stockfish --joro black --movetime 1000 --vs-opt Threads=1`.


## Training: mixed opponents, PGN, per-opening table (v0.6)
Same features as `joro_train` (see the main README), wired into the **Training** tab:
* **Fiovana %** : chance that JORO's first move after the opening is its 2nd best (default 5).
* **Mifangaro** switch (replaces the old "JORO vs Stockfish" switch and its colour buttons): weights JORO / Ladder / SF max
  (default 20 / 60 / 20), ladder rule "N wins in the last M games" (default 3 / 3), Stockfish ms per move. JORO's colour alternates
  every game over the whole run. The ladder level is kept in `files/experience/joro.ladder`. With the switch off: JORO vs JORO only.
* Every game is saved as PGN in `files/pgn/JORO_train_0001.pgn ...` (100 games per file) with `!!` `!` `?` `??` marks and `[%eval]`;
  the table per opening is appended to `files/pgn/JORO_train_stats.csv` at the end of each run and shown in the tab, compared with
  the previous run (UP / DOWN / = / NEW). Both are listed under the table with Export / Fafao buttons.
JNI additions: `runBegin`, `runEnd`, `trainSetMix`, `trainFinish`, `trainLastOpponent`; `trainCreate` takes `varyFirstPct` and the opening name;
`trainStep` returns 7 more ints (see `src/appapi.h`). `native_jni.cpp` had two `JNI_OnLoad` definitions: merged into one.
Not compiled here (no Gradle / Kotlin compiler available): the C++ side was built and run with a test harness, the Kotlin side was only reviewed.
