package com.joro.calibrator

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// High contrast on purpose: pure black on white (or white on near-black), strong blue accent, no faded greys.
private val LightColors = lightColorScheme(
    primary = Color(0xFF0A3A8C), onPrimary = Color.White,
    secondary = Color(0xFF0A3A8C), onSecondary = Color.White,
    background = Color.White, onBackground = Color.Black,
    surface = Color.White, onSurface = Color.Black,
    surfaceVariant = Color(0xFFE6EBF5), onSurfaceVariant = Color.Black,
    outline = Color(0xFF3A3A3A), error = Color(0xFFB00020), onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA9C8FF), onPrimary = Color(0xFF00102E),
    secondary = Color(0xFFA9C8FF), onSecondary = Color(0xFF00102E),
    background = Color(0xFF0B0B0D), onBackground = Color.White,
    surface = Color(0xFF0B0B0D), onSurface = Color.White,
    surfaceVariant = Color(0xFF26262C), onSurfaceVariant = Color.White,
    outline = Color(0xFFD0D0D0), error = Color(0xFFFF9A90), onError = Color.Black
)

// Larger text than the Material default (16/14/12 sp): nothing below 14 sp in the app.
private val JoroTypography = Typography(
    bodyLarge = TextStyle(fontSize = 17.sp, lineHeight = 24.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal),
    bodySmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontSize = 16.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
    titleMedium = TextStyle(fontSize = 18.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold)
)

@Composable
fun JoroTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = JoroTypography,
        content = content
    )
}
