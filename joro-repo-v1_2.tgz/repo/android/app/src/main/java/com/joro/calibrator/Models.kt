package com.joro.calibrator

/** Everything the user can set before a run. */
data class CalibConfig(
    val levels: List<Int>,        // Stockfish UCI_Elo values, e.g. 2500, 2600, 2700, 3000
    val gamesPerLevel: Int,       // even number (each opening is played with both colours)
    val baseMs: Long,             // time control: base time per side
    val incMs: Long,              // time control: increment per move
    val concurrency: Int,         // games played at the same time (matrix mode)
    val hashMb: Int,
    val useExperience: Boolean
)

data class LevelStats(val elo: Int, val planned: Int, val w: Int = 0, val d: Int = 0, val l: Int = 0) {
    val played: Int get() = w + d + l
}

enum class Bound { NONE, UPPER, LOWER }

data class LevelResult(
    val elo: Int, val w: Int, val d: Int, val l: Int,
    val score: Double,        // 0..1 from JORO's point of view
    val estimate: Double,     // estimated JORO Elo from this level
    val halfWidth: Double,    // 95% interval half width (Elo), only meaningful when bound == NONE
    val bound: Bound          // UPPER: JORO won nothing (estimate is a ceiling); LOWER: JORO lost nothing
)

data class Summary(
    val timestamp: Long,
    val engineName: String,   // "id name" reported by the JORO binary => tells which update was tested
    val experience: String,   // experience file description (entries, style id) or "none"
    val tcText: String,
    val levels: List<LevelResult>,
    val overall: Double?,
    val overallBound: Bound,
    val partial: Boolean,
    val pgn: String = "",         // file name of the games (PGN) of this run, "" if none
    val expSha: String = "none"   // short sha1 of the experience file that was tested
)
