package com.joro.calibrator

import java.util.Locale
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object Elo {
    private fun eloFromScore(s: Double): Double = -400.0 * log10(1.0 / s - 1.0)

    fun summarize(
        stats: Collection<LevelStats>, engineName: String, experience: String, tcText: String, partial: Boolean,
        pgn: String = "", expSha: String = "none"
    ): Summary {
        val results = ArrayList<LevelResult>()
        var num = 0.0
        var den = 0.0
        for (st in stats.sortedBy { it.elo }) {
            val n = st.played
            if (n == 0) continue
            val raw = (st.w + 0.5 * st.d) / n
            val bound = when {
                st.w == 0 && st.d == 0 -> Bound.UPPER
                st.l == 0 && st.d == 0 -> Bound.LOWER
                else -> Bound.NONE
            }
            val s = raw.coerceIn(0.5 / n, 1.0 - 0.5 / n)   // avoid infinite Elo on 0% / 100%
            val variance = (st.w * (1 - s) * (1 - s) + st.d * (0.5 - s) * (0.5 - s) + st.l * s * s) / n
            val err = 1.96 * sqrt(variance / n)
            val lo = max(s - err, 0.5 / n)
            val hi = min(s + err, 1.0 - 0.5 / n)
            val est = st.elo + eloFromScore(s)
            val half = if (bound == Bound.NONE) (eloFromScore(hi) - eloFromScore(lo)) / 2 else 0.0
            results.add(LevelResult(st.elo, st.w, st.d, st.l, raw, est, half, bound))
            if (bound == Bound.NONE) {            // inverse-variance weight: levels near 50% say the most
                val wt = n * s * (1 - s)
                num += wt * est
                den += wt
            }
        }
        var overall: Double? = null
        var ob = Bound.NONE
        if (den > 0) {
            overall = num / den
        } else {
            val uppers = results.filter { it.bound == Bound.UPPER }
            val lowers = results.filter { it.bound == Bound.LOWER }
            if (uppers.isNotEmpty()) { overall = uppers.minOf { it.estimate }; ob = Bound.UPPER }
            else if (lowers.isNotEmpty()) { overall = lowers.maxOf { it.estimate }; ob = Bound.LOWER }
        }
        return Summary(System.currentTimeMillis(), engineName, experience, tcText, results, overall, ob, partial, pgn, expSha)
    }

    fun fmt(x: Double): String = String.format(Locale.US, "%.0f", x)

    // ------------------------------------------------------------------ auto-level (calcul)
    /** Joint maximum-likelihood Elo over ALL levels (a 100% level still carries information). */
    class Mle(val elo: Double?, val half: Double, val bound: Bound, val inBand: Boolean, val games: Int)

    fun mle(levels: List<LevelResult>): Mle {
        val pts = levels.filter { it.w + it.d + it.l > 0 }
        if (pts.isEmpty()) return Mle(null, 0.0, Bound.NONE, false, 0)
        val games = pts.sumOf { it.w + it.d + it.l }
        val inBand = pts.any { it.score >= 0.25 && it.score <= 0.75 }
        if (pts.all { it.score >= 1.0 }) return Mle(pts.maxOf { it.estimate }, 0.0, Bound.LOWER, false, games)
        if (pts.all { it.score <= 0.0 }) return Mle(pts.minOf { it.estimate }, 0.0, Bound.UPPER, false, games)
        fun p(e: Double, l: Int): Double = 1.0 / (1.0 + Math.pow(10.0, (l - e) / 400.0))
        fun g(e: Double): Double {
            var s = 0.0
            for (r in pts) s += (r.w + r.d + r.l) * (r.score - p(e, r.elo))
            return s
        }
        var lo = pts.minOf { it.elo } - 2000.0
        var hi = pts.maxOf { it.elo } + 2000.0
        repeat(80) {
            val mid = (lo + hi) / 2
            if (g(mid) > 0) lo = mid else hi = mid
        }
        val e = (lo + hi) / 2
        val k = Math.log(10.0) / 400.0
        var info = 0.0
        for (r in pts) { val pp = p(e, r.elo); info += (r.w + r.d + r.l) * pp * (1 - pp) * k * k }
        val half = if (info > 1e-12) 1.96 / Math.sqrt(info) else 999.0
        return Mle(e, half, Bound.NONE, inBand, games)
    }

    /** Levels worth testing next: those where JORO should score between ~25% and ~75%. */
    fun suggestLevels(m: Mle, tested: List<Int>): List<Int> {
        val e = m.elo ?: return emptyList()
        val raw: List<Int> = when (m.bound) {
            Bound.LOWER -> { val top = tested.maxOrNull() ?: 2500; listOf(top + 200, top + 400, top + 600) }
            Bound.UPPER -> { val bot = tested.minOrNull() ?: 1320; listOf(bot - 600, bot - 400, bot - 200) }
            Bound.NONE -> { val c = (Math.round(e / 100.0) * 100).toInt(); listOf(c - 100, c, c + 100) }
        }
        return raw.map { it.coerceIn(1320, 3190) }.distinct().sorted()
    }

    fun advice(m: Mle, nLevels: Int): String {
        val e = m.elo ?: return ""
        return when {
            m.bound == Bound.LOWER -> "Avo loatra ny score amin'ny level rehetra: Elo ambany indrindra ihany no hita. Andramo level ambony kokoa."
            m.bound == Bound.UPPER -> "Ambany loatra ny score amin'ny level rehetra: Elo ambony indrindra ihany no hita. Andramo level ambany kokoa (farafahakeliny 1320)."
            !m.inBand -> "Tsy misy level eo anelanelan'ny 25% sy 75%: tsy dia marina. Andramo ny level natoro."
            m.half > 100 -> {
                val need = Math.ceil(m.games * (m.half / 50.0) * (m.half / 50.0) / Math.max(1, nLevels)).toInt()
                "Tsy ampy ny lalao (±${fmt(m.half)}). Ho ±50: ~${need + need % 2} lalao isaky ny level."
            }
            else -> "Tsara: ±${fmt(m.half)} Elo ary misy level eo anelanelan'ny 25-75%."
        }
    }

    fun overallText(sm: Summary): String {
        val m = mle(sm.levels)
        val o = m.elo ?: return "-"
        return when (m.bound) {
            Bound.UPPER -> "\u2264 ${fmt(o)}"
            Bound.LOWER -> "\u2265 ${fmt(o)}"
            Bound.NONE -> "\u2248 ${fmt(o)} \u00b1${fmt(m.half)}"
        }
    }

    fun levelText(r: LevelResult): String = when (r.bound) {
        Bound.UPPER -> "\u2264 ${fmt(r.estimate)}"
        Bound.LOWER -> "\u2265 ${fmt(r.estimate)}"
        Bound.NONE -> "${fmt(r.estimate)} \u00b1${fmt(r.halfWidth)}"
    }

    /** Plain-text summary used for sharing and for the history list. */
    fun toText(sm: Summary): String {
        val sb = StringBuilder()
        sb.append("JORO calibration").append(if (sm.partial) " (partiel)" else "").append('\n')
        sb.append("Engine: ").append(sm.engineName).append('\n')
        sb.append("Experience: ").append(sm.experience).append('\n')
        sb.append("TC: ").append(sm.tcText).append('\n')
        for (r in sm.levels) {
            sb.append(String.format(Locale.US, "SF %d : +%d =%d -%d  (%.1f%%)  JORO %s\n",
                r.elo, r.w, r.d, r.l, r.score * 100, levelText(r)))
        }
        sb.append("=> JORO ").append(overallText(sm)).append(" Elo (auto-level, MLE)\n")
        val m = mle(sm.levels)
        val next = suggestLevels(m, sm.levels.map { it.elo })
        if (next.isNotEmpty()) sb.append("Level natoro manaraka: ").append(next.joinToString(", ")).append('\n')
        if (m.elo != null) sb.append(advice(m, sm.levels.size)).append('\n')
        sb.append("(UCI_Elo of Stockfish is calibrated at its own time control: use it to compare JORO versions.)")
        return sb.toString()
    }
}
