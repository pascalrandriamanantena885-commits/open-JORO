package com.joro.calibrator

import android.app.Application
import android.net.Uri
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val running: Boolean = false,
    val stats: Map<Int, LevelStats> = emptyMap(),
    val summary: Summary? = null,
    val log: List<String> = emptyList(),
    val joroInfo: String = "",
    val expInfo: String = "",
    val importMessage: String = "",
    val history: List<Summary> = emptyList(),
    val message: String = "",
    val train: TrainState = TrainState(),
    val trainMessage: String = "",
    val exportMessage: String = "",
    val updates: List<String> = emptyList(),
    val release: String = "",
    val expSha: String = "none"
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val storage = Storage(app)

    // ---- inputs (kept here so they survive tab switches and rotation)
    var levelsText by mutableStateOf("2500, 2600, 2700, 3000")
    var gamesText by mutableStateOf("20")
    var baseSecText by mutableStateOf("10")
    var incMsText by mutableStateOf("100")
    var concurrencyText by mutableStateOf(defaultConcurrency().toString())
    var hashText by mutableStateOf("16")
    var useExperience by mutableStateOf(true)

    // ---- training inputs: the opening is built on the board (ints), not typed as UCI text
    var openingMoves by mutableStateOf<List<Int>>(emptyList())
    var openingName by mutableStateOf("Position de depart")
    var flipped by mutableStateOf(false)
    var sanInput by mutableStateOf("")
    // Self-play strength (defaults): the strong side alternates between White and Black every game.
    var trainDepthText by mutableStateOf("5")          // weak side, depth
    var trainDepthStrongText by mutableStateOf("8")    // strong side, depth
    var trainByTime by mutableStateOf(false)           // false = depth, true = milliseconds per move
    var trainMsWeakText by mutableStateOf("150")
    var trainMsStrongText by mutableStateOf("400")
    var trainGamesText by mutableStateOf("100")
    var trainStableText by mutableStateOf("3")
    var trainConfirmText by mutableStateOf("5")
    var trainHashText by mutableStateOf("16")
    var trainDrawFail by mutableStateOf(true)
    var trainBatch by mutableStateOf(false)
    var trainEndgames by mutableStateOf(false)      // train the endgame etudes (FEN) instead of / after the openings
    var trainGate by mutableStateOf(true)           // A/B gate after the training
    var trainVsSf by mutableStateOf(false)          // JORO vs Stockfish
    var trainMixSelfText by mutableStateOf("20")    // opponent mix (proportions): JORO itself / Stockfish ladder / Stockfish full strength
    var trainMixLadderText by mutableStateOf("60")
    var trainMixMaxText by mutableStateOf("20")
    var trainLadderNeedText by mutableStateOf("3")  // ladder: level up after N wins in the last M ladder games
    var trainLadderWindowText by mutableStateOf("3")
    var trainVaryText by mutableStateOf("5")        // % chance that JORO's first move after the opening is its 2nd best
    var trainFilesRev by mutableStateOf(0)          // bumped when a training file is deleted (the list is re-read)
    var trainSfTimeText by mutableStateOf("1000")   // ms per Stockfish move

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui

    init {
        CalibrationController.recoverIfNeeded(app)   // a run cut short by Android is kept as a partial result
        _ui.update { it.copy(history = storage.loadHistory().reversed()) }
        refreshInfo()
        // The run lives in CalibrationController (process + foreground service), not here: the UI only observes it.
        viewModelScope.launch {
            TrainingController.state.collect { ts ->
                val was = _ui.value.train.running
                _ui.update { it.copy(train = ts) }
                if (was && !ts.running) refreshInfo()       // the experience file changed
            }
        }
        viewModelScope.launch {
            CalibrationController.state.collect { rs ->
                _ui.update { it.copy(running = rs.running, stats = rs.stats, summary = rs.summary, log = rs.log, message = rs.message) }
                if (!rs.running) _ui.update { it.copy(history = storage.loadHistory().reversed()) }
            }
        }
    }

    private fun defaultConcurrency(): Int = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(1, 4)

    // ------------------------------------------------------------------ info
    fun refreshInfo() {
        viewModelScope.launch {
            val joroText = withContext(Dispatchers.IO) {
                val f = storage.joroFile()
                if (!f.exists()) return@withContext "JORO: tsy hita (${f.name})"
                val e = UciEngine(f.absolutePath, "info")
                val name = if (e.start() && e.handshake()) e.idName else "tsy mandeha"
                e.quit()
                "JORO (${storage.joroSource()}): $name"
            }
            val exp = storage.currentExpInfo()
            _ui.update {
                it.copy(joroInfo = joroText, expInfo = exp?.describe() ?: "tsy misy experience",
                    updates = storage.listUpdates(), release = storage.releaseLabel(), expSha = storage.expSha())
            }
        }
    }

    // ------------------------------------------------------------------ calibration
    fun parseLevels(text: String): List<Int> =
        text.split(',', ' ', ';', '/').mapNotNull { it.trim().toIntOrNull() }
            .map { it.coerceIn(1320, 3190) }   // range accepted by Stockfish UCI_Elo
            .distinct().sorted()

    fun start() {
        if (_ui.value.running) return
        val levels = parseLevels(levelsText)
        if (levels.isEmpty()) { msg("Ampidiro level iray farafahakeliny (ohatra 2500, 2600)"); return }
        var games = (gamesText.toIntOrNull() ?: 20).coerceIn(2, 400)
        if (games % 2 == 1) games++
        val cfg = CalibConfig(
            levels = levels,
            gamesPerLevel = games,
            baseMs = ((baseSecText.toDoubleOrNull() ?: 10.0) * 1000).toLong().coerceIn(500, 3_600_000),
            incMs = (incMsText.toLongOrNull() ?: 100L).coerceIn(0, 60_000),
            concurrency = (concurrencyText.toIntOrNull() ?: 1).coerceIn(1, 8),
            hashMb = (hashText.toIntOrNull() ?: 16).coerceIn(1, 256),
            useExperience = useExperience
        )
        val err = CalibrationController.start(getApplication(), cfg)
        if (err != null) msg(err)
    }

    fun stop() { CalibrationController.stop() }

    // ------------------------------------------------------------------ training
    fun playOpeningMove(m: Int) { openingMoves = openingMoves + m; openingName = "Opening manokana" }
    fun undoOpening() { if (openingMoves.isNotEmpty()) { openingMoves = openingMoves.dropLast(1); openingName = "Opening manokana" } }
    fun resetOpening() { openingMoves = emptyList(); openingName = "Position de depart"; _ui.update { it.copy(trainMessage = "") } }

    fun selectPreset(p: Preset) {
        val m = Native.parseSanLine(p.san)
        if (m == null) { _ui.update { it.copy(trainMessage = "Preset tsy mety: ${p.name}") }; return }
        openingMoves = m.toList()
        openingName = p.name
        _ui.update { it.copy(trainMessage = "") }
    }

    /** The user pastes a line in standard notation (1.e4 e5 2.Nf3 ...). */
    fun applySan() {
        val m = Native.parseSanLine(sanInput)
        if (m == null) { _ui.update { it.copy(trainMessage = "Tsy azoko io lalao io (SAN tsy mety na move tsy ara-dalana).") }; return }
        openingMoves = m.toList()
        openingName = "Opening manokana"
        _ui.update { it.copy(trainMessage = "") }
    }

    fun startTraining() {
        val endgames = EndgameEtudes.all.map { TrainOpening(it.name, emptyList(), it.fen) }
        val queue = when {
            trainEndgames && !trainBatch -> endgames
            trainBatch -> OpeningPresets.all.mapNotNull { p -> Native.parseSanLine(p.san)?.let { TrainOpening(p.name, it.toList()) } } +
                (if (trainEndgames) endgames else emptyList())
            else -> listOf(TrainOpening(openingName, openingMoves))
        }
        val params = TrainParams(
            depth = (trainDepthText.toIntOrNull() ?: 5).coerceIn(1, 20),
            depthStrong = (trainDepthStrongText.toIntOrNull() ?: 8).coerceIn(1, 24),
            msWeak = if (trainByTime) (trainMsWeakText.toIntOrNull() ?: 150).coerceIn(10, 60000) else 0,
            msStrong = if (trainByTime) (trainMsStrongText.toIntOrNull() ?: 400).coerceIn(10, 60000) else 0,
            maxGames = (trainGamesText.toIntOrNull() ?: 100).coerceIn(1, 5000),
            stable = (trainStableText.toIntOrNull() ?: 3).coerceIn(1, 100),
            confirm = (trainConfirmText.toIntOrNull() ?: 5).coerceIn(0, 100),
            drawFail = trainDrawFail,
            hashMb = (trainHashText.toIntOrNull() ?: 16).coerceIn(1, 256),
            gate = trainGate,
            vsStockfish = trainVsSf,
            mixSelf = (trainMixSelfText.toIntOrNull() ?: 20).coerceIn(0, 1000),
            mixLadder = (trainMixLadderText.toIntOrNull() ?: 60).coerceIn(0, 1000),
            mixMax = (trainMixMaxText.toIntOrNull() ?: 20).coerceIn(0, 1000),
            ladderNeed = (trainLadderNeedText.toIntOrNull() ?: 3).coerceIn(1, 20),
            ladderWindow = (trainLadderWindowText.toIntOrNull() ?: 3).coerceIn(1, 20),
            varyFirstPct = (trainVaryText.toDoubleOrNull() ?: 5.0).coerceIn(0.0, 100.0),
            sfMoveTimeMs = (trainSfTimeText.toIntOrNull() ?: 1000).coerceIn(50, 60000)
        )
        val err = TrainingController.start(getApplication(), queue, params)
        _ui.update { it.copy(trainMessage = err ?: "") }
    }

    fun stopTraining() { TrainingController.stop() }

    private fun msg(m: String) { _ui.update { it.copy(message = m) } }

    // ------------------------------------------------------------------ import / update
    private fun busy(): Boolean {
        val b = _ui.value.running || _ui.value.train.running
        if (b) _ui.update { it.copy(importMessage = "Mandeha ny calibrate na training: andraso ny faran'izany.") }
        return b
    }

    fun importExperience(uri: Uri) {
        if (busy()) return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { storage.importExperience(uri) }
            val text = r.fold({ "Experience vaovao nampidirina: ${it.describe()}" }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(importMessage = text) }
            refreshInfo()
        }
    }

    fun deleteExperience() {
        if (busy()) return
        storage.deleteExperience()
        _ui.update { it.copy(importMessage = "Experience nofafana.") }
        refreshInfo()
    }

    fun importEngine(uri: Uri) {
        if (busy()) return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { storage.importEngine(uri) }
            val text = r.fold({ "Moteur vaovao nampidirina: $it" }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(importMessage = text) }
            refreshInfo()
        }
    }

    fun removeImportedEngine() {
        storage.removeImportedEngine()
        _ui.update { it.copy(importMessage = "Miverina amin'ny moteur ao anaty APK.") }
        refreshInfo()
    }

    // ------------------------------------------------------------------ files: PGN, JORO updates
    private var pendingExport: File? = null

    fun trainFiles(): List<String> = storage.trainFiles()
    fun deleteTrainFile(name: String) { storage.deletePgn(name); trainFilesRev++ }
    fun pgnSize(name: String): Long = storage.pgnFile(name)?.length() ?: 0L
    fun pgnFileOf(name: String): File? = storage.pgnFile(name)
    fun updateFileOf(name: String): File? = storage.updateFile(name)

    fun prepareExport(f: File?) { pendingExport = f }

    fun exportTo(uri: Uri) {
        val f = pendingExport
        pendingExport = null
        if (f == null) return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { storage.copyTo(uri, f) } }
            val text = r.fold({ "Naharitra tany amin'ny storage: ${f.name}" }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(exportMessage = text) }
        }
    }

    fun deletePgn(name: String) {
        storage.deletePgn(name)
        _ui.update { it.copy(history = storage.loadHistory().reversed(), exportMessage = "Nofafana ny PGN.") }
    }

    /** JORO update = the JORO engine in use + the current experience (accepted because it raised the strength). */
    fun createUpdate(sm: Summary?) {
        if (busy()) return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { storage.createUpdate(sm) }
            val text = r.fold({ "JORO update vita: ${it.name}. Alefaso any amin'ny storage (Export)." }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(importMessage = text) }
            refreshInfo()
        }
    }

    fun importUpdate(uri: Uri) {
        if (busy()) return
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { storage.importUpdate(uri) }
            val text = r.fold({ "JORO update nampidirina: $it" }, { "Hadisoana: ${it.message}" })
            _ui.update { it.copy(importMessage = text) }
            refreshInfo()
        }
    }

    fun deleteUpdate(name: String) {
        storage.deleteUpdate(name)
        _ui.update { it.copy(updates = storage.listUpdates(), importMessage = "Nofafana ny update.") }
    }

    fun clearHistory() {
        storage.clearHistory()
        _ui.update { it.copy(history = emptyList()) }
    }
}
