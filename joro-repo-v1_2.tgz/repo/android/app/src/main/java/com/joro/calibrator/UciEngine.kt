package com.joro.calibrator

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** A UCI engine running as a child process (JORO and Stockfish are both plain executables). */
class UciEngine(private val path: String, private val label: String) {
    private var proc: Process? = null
    private var writer: BufferedWriter? = null
    private val lines = LinkedBlockingQueue<String>()
    @Volatile var alive: Boolean = false
        private set
    var idName: String = ""
        private set

    fun start(): Boolean {
        return try {
            val p = ProcessBuilder(path).redirectErrorStream(true).start()
            proc = p
            writer = BufferedWriter(OutputStreamWriter(p.outputStream))
            alive = true
            thread(isDaemon = true, name = "uci-$label") {
                try {
                    BufferedReader(InputStreamReader(p.inputStream)).use { r ->
                        while (true) {
                            val l = r.readLine() ?: break
                            lines.put(l)
                        }
                    }
                } catch (_: Exception) {
                }
                alive = false
                lines.put(EOF)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun send(cmd: String) {
        try {
            val w = writer ?: return
            w.write(cmd)
            w.write("\n")
            w.flush()
        } catch (e: Exception) {
            alive = false
        }
    }

    /**
     * Reads lines until one starts with [prefix]. Returns it, or null on timeout / crash / cancellation.
     * Every line read on the way is given to [onLine].
     */
    fun readUntil(
        prefix: String,
        timeoutMs: Long,
        cancelled: () -> Boolean = { false },
        onLine: (String) -> Unit = {}
    ): String? {
        val deadline = System.nanoTime() + timeoutMs * 1_000_000L
        while (true) {
            if (cancelled()) return null
            val left = (deadline - System.nanoTime()) / 1_000_000L
            if (left <= 0) return null
            val l = lines.poll(min50(left), TimeUnit.MILLISECONDS) ?: continue
            if (l === EOF) return null
            if (l.startsWith(prefix)) return l
            onLine(l)
        }
    }

    private fun min50(x: Long): Long = if (x < 50) x else 50

    /** uci handshake: fills [idName]; false if the binary does not speak UCI. */
    fun handshake(timeoutMs: Long = 5000): Boolean {
        send("uci")
        val ok = readUntil("uciok", timeoutMs) { l ->
            if (l.startsWith("id name ")) idName = l.substring(8).trim()
        }
        return ok != null
    }

    fun isReady(timeoutMs: Long = 5000, cancelled: () -> Boolean = { false }): Boolean {
        send("isready")
        return readUntil("readyok", timeoutMs, cancelled) != null
    }

    fun setOption(name: String, value: String) = send("setoption name $name value $value")

    fun quit() {
        try {
            send("quit")
            proc?.waitFor(300, TimeUnit.MILLISECONDS)
        } catch (_: Exception) {
        }
        proc?.destroyForcibly()
        alive = false
    }

    private companion object {
        val EOF = String(charArrayOf('\u0000'))   // identity-compared sentinel
    }
}
