package com.joro.calibrator

/**
 * The external side of "JORO vs Stockfish" training. Stockfish plays at full strength (a fixed time per move, no
 * UCI_LimitStrength). The native trainer calls [bestMove] through JNI every time it is Stockfish's turn.
 */
class StockfishOpponent(
    private val engine: UciEngine,
    private val moveTimeMs: Int,
    private val cancelled: () -> Boolean
) {
    private fun uciOf(m: Int): String {
        val f = moveFrom(m); val t = moveTo(m)
        val sq = { s: Int -> "" + ('a' + (s and 7)) + ('1' + (s shr 3)) }
        val promo = when (movePromo(m)) { 5 -> "q"; 4 -> "r"; 3 -> "b"; 2 -> "n"; else -> "" }
        return sq(f) + sq(t) + promo
    }

    private var currentElo = -1   // -1 = nothing set yet, 0 = full strength

    /** Called by the native trainer before each game against Stockfish: [elo] > 0 limits it (UCI_Elo), 0 = full strength. */
    fun prepare(elo: Int): Boolean {
        if (!engine.alive || cancelled()) return false
        if (elo != currentElo) {
            if (elo > 0) { engine.setOption("UCI_LimitStrength", "true"); engine.setOption("UCI_Elo", elo.toString()) }
            else engine.setOption("UCI_LimitStrength", "false")
            currentElo = elo
        }
        engine.send("ucinewgame")
        return engine.isReady(10_000, cancelled)
    }

    /** Called from the native trainer thread. [moves] = every move since the standard start position. 0 = no move. */
    fun bestMove(fen: String, moves: IntArray): Int {
        if (!engine.alive || cancelled()) return 0
        val pos = if (moves.isEmpty()) "position fen $fen" else "position fen $fen moves " + moves.joinToString(" ") { uciOf(it) }
        engine.send(pos)
        engine.send("go movetime $moveTimeMs")
        val line = engine.readUntil("bestmove", moveTimeMs + 60_000L, cancelled) ?: return 0
        val txt = line.trim().split(" ").getOrNull(1) ?: return 0
        return Native.legalMoves(moves).firstOrNull { uciOf(it) == txt } ?: 0
    }
}
