package com.joro.calibrator

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class RunState(
    val running: Boolean = false,
    val stats: Map<Int, LevelStats> = emptyMap(),
    val summary: Summary? = null,
    val log: List<String> = emptyList(),
    val message: String = ""
)

/**
 * Owns the calibration run. It lives in the *process*, not in the Activity: the run goes on when the screen
 * is off, when the app is closed or swiped away from the recents, because [CalibrationService] keeps the process
 * alive (foreground service + wake lock). The UI only observes [state].
 */
object CalibrationController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow(RunState())
    val state: StateFlow<RunState> = _state
    private var job: Job? = null
    @Volatile private var latest: Map<Int, LevelStats> = emptyMap()
    private val fileLock = Any()

    /** Returns an error message, or null when the run was started. */
    @Synchronized
    fun start(ctx: Context, cfg: CalibConfig): String? {
        if (_state.value.running) return "Efa mandeha ny calibrate."
        if (TrainingController.state.value.running) return "Mandeha ny training: andraso ny faran'izany."
        val app = ctx.applicationContext
        val storage = Storage(app)
        val sf = storage.stockfish
        val joro = storage.joroFile()
        if (!sf.exists()) return "Tsy hita ny Stockfish ao anaty APK (libstockfish.so). Jereo ny README."
        if (!joro.exists()) return "Tsy hita ny moteur JORO."
        val openings = app.assets.open("openings.epd").bufferedReader().use { it.readLines() }
            .map { it.trim() }.filter { it.isNotEmpty() }
        val expPath = if (storage.expFile.exists()) storage.expFile.absolutePath else null
        val expText = if (expPath != null && cfg.useExperience) (storage.currentExpInfo()?.describe() ?: "?") else "none"
        val tcText = "${cfg.baseMs / 1000.0}s+${cfg.incMs}ms, ${cfg.gamesPerLevel} lalao/level, x${cfg.concurrency}"

        val ts = System.currentTimeMillis()
        val pgn = storage.newPgnFile(ts)
        val sha = if (expPath != null && cfg.useExperience) storage.expSha() else "none"
        val rel = storage.releaseLabel()
        val label = "JORO" + (if (rel.isNotEmpty()) " $rel" else "") + (if (sha != "none") " +exp $sha" else "")

        latest = cfg.levels.associateWith { LevelStats(it, cfg.gamesPerLevel) }
        _state.value = RunState(running = true, stats = latest)

        lateinit var runner: MatchRunner
        runner = MatchRunner(joro.absolutePath, sf.absolutePath, expPath, cfg, openings, pgn, label,
            onStats = { s ->
                latest = s
                _state.update { it.copy(stats = s) }
                persist(app, runner.joroName, expText, tcText, s)
            },
            onLog = { line -> _state.update { it.copy(log = (it.log + line).takeLast(40)) } })

        job = scope.launch {
            var partial = false
            try {
                withContext(Dispatchers.IO) { runner.run() }
            } catch (e: CancellationException) {
                partial = true
            }
            withContext(NonCancellable + Dispatchers.IO) {
                val done = latest.values.sumOf { it.played }
                if (done > 0) {
                    val name = (if (runner.joroName.isNotEmpty()) runner.joroName else "JORO") + " [" + storage.joroSource() + "]" +
                        (if (rel.isNotEmpty()) " $rel" else "")
                    val pgnName = if (pgn.exists() && pgn.length() > 0) pgn.name else ""
                    val sm = Elo.summarize(latest.values, name, expText, tcText, partial, pgnName, sha)
                    storage.addHistory(sm)
                    _state.update { it.copy(running = false, summary = sm) }
                } else {
                    _state.update { it.copy(running = false, message = "Tsy nisy lalao vita (jereo ny log).") }
                }
                progressFile(app).delete()
            }
        }
        // the service keeps the process alive and shows the notification; it stops itself when the run ends
        ContextCompat.startForegroundService(app, Intent(app, CalibrationService::class.java))
        return null
    }

    fun stop() { job?.cancel() }

    // ---- if Android killed the process in the middle of a run, keep what had been played
    private fun progressFile(ctx: Context) = File(ctx.filesDir, "run_progress.json")

    private fun persist(ctx: Context, engine: String, exp: String, tc: String, stats: Map<Int, LevelStats>) {
        synchronized(fileLock) {
            try {
                val o = JSONObject()
                o.put("engine", engine.ifEmpty { "JORO" }); o.put("exp", exp); o.put("tc", tc)
                val a = JSONArray()
                for (s in stats.values) {
                    val j = JSONObject()
                    j.put("elo", s.elo); j.put("planned", s.planned); j.put("w", s.w); j.put("d", s.d); j.put("l", s.l)
                    a.put(j)
                }
                o.put("stats", a)
                progressFile(ctx).writeText(o.toString())
            } catch (_: Exception) {
            }
        }
    }

    /** Call once when the app starts: a progress file without a live run means the process was killed. */
    fun recoverIfNeeded(ctx: Context) {
        if (_state.value.running) return
        val app = ctx.applicationContext
        val f = progressFile(app)
        if (!f.exists()) return
        try {
            val o = JSONObject(f.readText())
            val a = o.getJSONArray("stats")
            val list = (0 until a.length()).map {
                val j = a.getJSONObject(it)
                LevelStats(j.getInt("elo"), j.getInt("planned"), j.getInt("w"), j.getInt("d"), j.getInt("l"))
            }
            if (list.sumOf { it.played } > 0) {
                val sm = Elo.summarize(list, o.getString("engine") + " [tapaka]", o.getString("exp"), o.getString("tc"), true)
                Storage(app).addHistory(sm)
                _state.update { it.copy(summary = sm) }
            }
        } catch (_: Exception) {
        }
        f.delete()
    }
}
