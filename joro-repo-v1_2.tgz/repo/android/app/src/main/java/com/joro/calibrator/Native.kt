package com.joro.calibrator

/** Engine code running inside the app (same C++ as the UCI engine, but called directly: no UCI, no process). */
object Native {
    init { System.loadLibrary("joro_native") }

    // ---- board / opening (moves are ints: from | to<<6 | promo<<12 | flag<<15)
    @JvmStatic external fun boardInfo(moves: IntArray): String          // "64 cells|w|status"
    @JvmStatic external fun legalMoves(moves: IntArray): IntArray
    @JvmStatic external fun movesToSan(moves: IntArray): String         // "1. e4 e5 2. Nf3"
    @JvmStatic external fun parseSanLine(text: String): IntArray?       // null if the text is not a legal line

    // ---- calibration only: the engines speak UCI, the PGN needs SAN
    @JvmStatic external fun sanFromUci(fen: String, uciMoves: String): String

    // ---- training (one handle = one opening)
    @JvmStatic external fun trainCreate(
        moves: IntArray, expPath: String, depth: Int, depthStrong: Int, msWeak: Int, msStrong: Int, maxGames: Int, stable: Int, confirm: Int,
        drawFail: Boolean, hashMb: Int, varyFirstPct: Double, label: String
    ): Long
    @JvmStatic external fun trainStep(handle: Long): IntArray           // see appapi.h for the layout
    @JvmStatic external fun trainStop(handle: Long)
    /** Start position for the board helpers and the NEXT trainCreate ("" = standard start). Used by the endgame etudes. */
    @JvmStatic external fun setStartFen(fen: String)
    /** A/B gate: candidate vs base experience. openingsFlat = moves of each start, separated by -1. Returns [wins, draws, losses] (candidate) or empty. */
    @JvmStatic external fun gateRun(basePath: String, candPath: String, openingsFlat: IntArray, gamesPerStart: Int, movetimeMs: Int): IntArray
    @JvmStatic external fun gateStop(stop: Boolean)
    /** JORO vs an external engine: [cb] must have  fun bestMove(fen: String, moves: IntArray): Int  (0 = no move). */
    @JvmStatic external fun trainSetOpponent(handle: Long, joroSide: Int, cb: Any?)
    /** Mixed opponents: [cb] must have  fun bestMove(fen: String, moves: IntArray): Int  and  fun prepare(elo: Int): Boolean (elo 0 = full strength). */
    @JvmStatic external fun trainSetMix(handle: Long, cb: Any)
    /** A run = all openings of one start: PGN files (prefix_0001.pgn ...), per-opening table (CSV) and opponent weights are shared. */
    @JvmStatic external fun runBegin(statsPath: String, pgnPrefix: String, pgnSplit: Int, wSelf: Int, wLadder: Int, wMax: Int,
                                     need: Int, window: Int, ladderFile: String, ladderReset: Boolean)
    @JvmStatic external fun runEnd(): String                            // saves the table, returns it as text
    @JvmStatic external fun trainFinish(handle: Long)                   // after the last step of an opening
    @JvmStatic external fun trainLastOpponent(handle: Long): String
    @JvmStatic external fun trainPause(handle: Long, paused: Boolean)   // sleeps at the next move (no CPU)
    @JvmStatic external fun trainWaiting(handle: Long): Boolean         // true once it really sleeps
    @JvmStatic external fun trainLive(handle: Long): IntArray           // moves of the game being played now
    @JvmStatic external fun trainDestroy(handle: Long)
}

fun moveFrom(m: Int): Int = m and 63
fun moveTo(m: Int): Int = (m shr 6) and 63
fun movePromo(m: Int): Int = (m shr 12) and 7   // 2 N, 3 B, 4 R, 5 Q

class BoardView(val cells: CharArray, val whiteToMove: Boolean, val status: Int)

fun parseBoard(s: String): BoardView? {
    if (s.length < 68 || s.startsWith("ERR")) return null
    return BoardView(s.substring(0, 64).toCharArray(), s[65] == 'w', s[67] - '0')
}
