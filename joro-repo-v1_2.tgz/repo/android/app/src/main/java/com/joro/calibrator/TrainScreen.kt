package com.joro.calibrator

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun glyph(ch: Char): String {
    val g = when (ch.lowercaseChar()) {
        'k' -> "\u265A"; 'q' -> "\u265B"; 'r' -> "\u265C"; 'b' -> "\u265D"; 'n' -> "\u265E"; else -> "\u265F"
    }
    return g + "\uFE0E"   // force the text (not emoji) presentation
}

@Composable
fun ChessBoard(
    view: BoardView, flipped: Boolean, selected: Int?, targets: Set<Int>, last: Pair<Int, Int>?, onTap: (Int) -> Unit
) {
    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1f)) {
        val cell = maxWidth / 8
        val fs = with(LocalDensity.current) { (cell * 0.72f).toSp() }
        Column {
            for (row in 0 until 8) {
                Row {
                    for (col in 0 until 8) {
                        val file = if (flipped) 7 - col else col
                        val rank = if (flipped) row else 7 - row
                        val sq = rank * 8 + file
                        val dark = (file + rank) % 2 == 0
                        // blue-grey / cream board: neither square colour is white or black, so both piece colours stand out
                        var bg = if (dark) Color(0xFF6F93BA) else Color(0xFFF1E7C8)
                        if (last != null && (sq == last.first || sq == last.second)) bg = if (dark) Color(0xFFC8D45A) else Color(0xFFF3EE6E)
                        if (sq == selected) bg = Color(0xFFF6F669)
                        Box(Modifier.size(cell).background(bg).clickable { onTap(sq) }, contentAlignment = Alignment.Center) {
                            val ch = view.cells[sq]
                            if (ch != '.') {
                                val white = ch.isUpperCase()
                                // White pieces: pure white with a thick black outline. Black pieces: solid black with a thin white rim.
                                val px = with(LocalDensity.current) { cell.toPx() }
                                Text(glyph(ch), fontSize = fs,
                                    style = TextStyle(color = if (white) Color.Black else Color.White,
                                        drawStyle = Stroke(width = px * (if (white) 0.075f else 0.035f))))
                                Text(glyph(ch), fontSize = fs, color = if (white) Color.White else Color.Black)
                            }
                            if (sq in targets) Box(Modifier.size(cell / 3).background(Color(0x66000000), CircleShape))
                        }
                    }
                }
            }
        }
    }
}

private fun digits(v: String) = v.filter { it.isDigit() }

@Composable
fun TrainTab(vm: MainViewModel, s: UiState, exporter: Exporter) {
    val t = s.train
    val running = t.running
    var menuOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var pending by remember { mutableStateOf<List<Int>>(emptyList()) }

    val moves = vm.openingMoves
    val arr = remember(moves) { moves.toIntArray() }
    val board = remember(moves) { parseBoard(Native.boardInfo(arr)) }
    val legal = remember(moves) { Native.legalMoves(arr).toList() }
    val san = remember(moves) { Native.movesToSan(arr) }
    val lastMove = moves.lastOrNull()?.let { Pair(moveFrom(it), moveTo(it)) }
    // live view: while the training runs the board follows the game being played (moves polled only while this tab is shown)
    DisposableEffect(running) {
        if (running) TrainingController.setWatching(true)
        onDispose { TrainingController.setWatching(false) }
    }
    val liveArr = remember(t.live) { t.live.toIntArray() }
    val liveBoard = remember(t.live) { if (t.live.isEmpty()) null else parseBoard(Native.boardInfo(liveArr)) }
    val liveSan = remember(t.live) { if (t.live.isEmpty()) "" else Native.movesToSan(liveArr) }
    val liveLast = t.live.lastOrNull()?.let { Pair(moveFrom(it), moveTo(it)) }
    val sel = selected
    val targets = if (sel == null) emptySet() else legal.filter { moveFrom(it) == sel }.map { moveTo(it) }.toSet()

    val onTap: (Int) -> Unit = tap@{ sq ->
        if (running || board == null) return@tap
        val from = selected
        if (from != null) {
            val cand = legal.filter { moveFrom(it) == from && moveTo(it) == sq }
            if (cand.size == 1) { vm.playOpeningMove(cand[0]); selected = null; return@tap }
            if (cand.size > 1) { pending = cand; selected = null; return@tap }
        }
        val piece = board.cells[sq]
        val own = piece != '.' && (piece.isUpperCase() == board.whiteToMove)
        selected = if (own && legal.any { moveFrom(it) == sq }) sq else null
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Opening: ${vm.openingName}", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box {
                OutlinedButton(onClick = { menuOpen = true }, enabled = !running) { Text("Preset") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    OpeningPresets.all.forEach { p ->
                        DropdownMenuItem(text = { Text(p.name) }, onClick = { vm.selectPreset(p); selected = null; menuOpen = false })
                    }
                }
            }
            OutlinedButton(onClick = { vm.undoOpening(); selected = null }, enabled = !running) { Text("Hanafoana") }
            OutlinedButton(onClick = { vm.resetOpening(); selected = null }, enabled = !running) { Text("Reset") }
            OutlinedButton(onClick = { vm.flipped = !vm.flipped }) { Text("Reverse") }
        }

        if (running && liveBoard != null) {
            ChessBoard(liveBoard, vm.flipped, null, emptySet(), liveLast, {})
            Text(
                (if (t.paused) (if (t.sleeping) "PAUSE - natory ny training" else "Pause: miandry ny dingana farany...") else "Live: lalao ${t.game + 1}") +
                    "   ${t.live.size} plies",
                fontWeight = FontWeight.Bold, fontSize = 14.sp
            )
            Text(liveSan.takeLast(160), fontFamily = FontFamily.Monospace, fontSize = 14.sp)
        } else if (board != null) {
            ChessBoard(board, vm.flipped, selected, targets, lastMove, onTap)
            val st = when (board.status) {
                1 -> "Check"; 2 -> "Checkmate"; 3 -> "Stalemate"; else -> ""
            }
            Text((if (board.whiteToMove) "White no mandroso" else "Black no mandroso") + if (st.isNotEmpty()) " - $st" else "", fontSize = 14.sp)
        }
        if (pending.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Promotion:")
                pending.forEach { m ->
                    val label = when (movePromo(m)) { 5 -> "Dame"; 4 -> "Tour"; 3 -> "Fou"; else -> "Cavalier" }
                    Button(onClick = { vm.playOpeningMove(m); pending = emptyList() }) { Text(label) }
                }
            }
        }
        Text(if (san.isEmpty()) "(position de depart)" else san, fontFamily = FontFamily.Monospace, fontSize = 15.sp)

        OutlinedTextField(
            value = vm.sanInput, onValueChange = { vm.sanInput = it }, enabled = !running,
            label = { Text("Apetaho eto ny lalao (ohatra 1.e4 e5 2.Nf3 Nc6)") }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedButton(onClick = { vm.applySan(); selected = null }, enabled = !running) { Text("Ampiasao ity lalao ity") }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = vm.trainByTime, onCheckedChange = { vm.trainByTime = it }, enabled = !running)
            Text(if (vm.trainByTime) "Fotoana isaky ny hetsika (ms)" else "Depth isaky ny hetsika")
        }
        Text("Ny mpilalao mahery (lalina kokoa) dia mifandimby fotsy/mainty isaky ny lalao: tsy mitovy ny hetsika, tsy dia misy draw.", fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (vm.trainByTime) {
                OutlinedTextField(vm.trainMsWeakText, { vm.trainMsWeakText = digits(it) }, label = { Text("ms malemy") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(vm.trainMsStrongText, { vm.trainMsStrongText = digits(it) }, label = { Text("ms mahery") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            } else {
                OutlinedTextField(vm.trainDepthText, { vm.trainDepthText = digits(it) }, label = { Text("Depth malemy") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(vm.trainDepthStrongText, { vm.trainDepthStrongText = digits(it) }, label = { Text("Depth mahery") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(vm.trainGamesText, { vm.trainGamesText = digits(it) }, label = { Text("Lalao max") },
                enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(vm.trainConfirmText, { vm.trainConfirmText = digits(it) }, label = { Text("Fandresena misesy") },
                enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(vm.trainStableText, { vm.trainStableText = digits(it) }, label = { Text("Lalao tsy mampianatra") },
                enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(vm.trainHashText, { vm.trainHashText = digits(it) }, label = { Text("Hash MB") },
                enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = vm.trainEndgames, onCheckedChange = { vm.trainEndgames = it }, enabled = !running)
            Text("Études endgame (K+Q, K+R, ... mat haingana). Raha misy ihany koa ny preset rehetra, dia arahina aorian'ireo.")
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = vm.trainGate, onCheckedChange = { vm.trainGate = it }, enabled = !running)
            Text("Fanamarinana A/B aorian'ny training: raha ratsy kokoa ny experience vaovao dia miverina ny taloha.")
        }
        OutlinedTextField(vm.trainVaryText, { vm.trainVaryText = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Fiovana % amin'ny hetsika voalohany (faharoa tsara indrindra)") },
            enabled = !running, singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = vm.trainVsSf, onCheckedChange = { vm.trainVsSf = it }, enabled = !running)
            Text("Mifangaro: JORO vs JORO + Stockfish ambaratonga (ladder) + Stockfish heriny rehetra. Ny hetsika Stockfish dia tsy ianarana; mifandimby fotsy/mainty isaky ny lalao.")
        }
        if (vm.trainVsSf) {
            Text("Ny tahan'ny lalao (isa fotsiny, mifampitaha):", fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(vm.trainMixSelfText, { vm.trainMixSelfText = digits(it) }, label = { Text("JORO") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(vm.trainMixLadderText, { vm.trainMixLadderText = digits(it) }, label = { Text("Ladder") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(vm.trainMixMaxText, { vm.trainMixMaxText = digits(it) }, label = { Text("SF max") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(vm.trainLadderNeedText, { vm.trainLadderNeedText = digits(it) }, label = { Text("Ladder: fandresena") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(vm.trainLadderWindowText, { vm.trainLadderWindowText = digits(it) }, label = { Text("amin'ny lalao farany") },
                    enabled = !running, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
            Text("Miakatra ny ambaratonga Stockfish (UCI_Elo 1320 ... 3190) rehefa nandresy ${vm.trainLadderNeedText} amin'ny ${vm.trainLadderWindowText} lalao farany teo amin'io ambaratonga io i JORO. Tazonina ny ambaratonga eo anelanelan'ny training.", fontSize = 13.sp)
            OutlinedTextField(vm.trainSfTimeText, { vm.trainSfTimeText = digits(it) }, label = { Text("Stockfish: ms isaky ny hetsika") },
                enabled = !running, singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = vm.trainDrawFail, onCheckedChange = { vm.trainDrawFail = it }, enabled = !running)
            Text("Ny draw dia tsy fandresena (mitady variation hafa)")
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = vm.trainBatch, onCheckedChange = { vm.trainBatch = it }, enabled = !running)
            Text("Ny preset ${OpeningPresets.all.size} rehetra, miandalana")
        }
        Text("Experience: ${s.expInfo}", fontSize = 14.sp)

        if (!running) Button(onClick = { vm.startTraining() }, modifier = Modifier.fillMaxWidth()) { Text("Hanomboka training") }
        else {
            Button(onClick = { TrainingController.setPaused(!t.paused) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (t.paused) "Tohizo" else "Pause (hitsitsy battery)")
            }
            OutlinedButton(onClick = { vm.stopTraining() }, modifier = Modifier.fillMaxWidth()) { Text("Atsaha (voatahiry ny efa nianarana)") }
        }
        if (running) Text("Mitohy ao ambadika ny training (notification, misy Pause/Tohizo), na dia akatona aza ny app. Tsy mihinana batterie ny Pause.", fontSize = 14.sp)
        if (s.trainMessage.isNotEmpty()) Text(s.trainMessage, color = MaterialTheme.colorScheme.error)
        if (!running && t.message.isNotEmpty()) Text(t.message)

        if (running || t.openingTotal > 0) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${t.openingName}  (${t.openingIndex}/${t.openingTotal})", fontWeight = FontWeight.Bold)
                    Text("Lalao ${t.game}/${t.maxGames}   White ${t.white}  Black ${t.black}  Draw ${t.draws}", fontFamily = FontFamily.Monospace, fontSize = 14.sp)
                    LinearProgressIndicator(progress = { if (t.maxGames == 0) 0f else (t.game.toFloat() / t.maxGames).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Text("Vaovao: +${t.newBad} BAD  +${t.newGood} brilliant/great   Entries: ${t.entries}", fontSize = 14.sp)
                }
            }
        }
        t.results.forEach { r ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(r.name, fontWeight = FontWeight.Bold)
                    Text("${r.games} lalao  W${r.white} B${r.black} D${r.draws}  +${r.newBad} BAD  +${r.newGood} brilliant", fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                    Text(r.verdict, fontSize = 14.sp)
                }
            }
        }
        if (!running && t.table.isNotEmpty()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Tabilao isaky ny opening (ampitahaina amin'ny training teo aloha)", fontWeight = FontWeight.Bold)
                    Box(Modifier.horizontalScroll(rememberScrollState())) {
                        Text(t.table, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                    Text("UP = nandroso, DOWN = nihemotra, = tsy niova, NEW = opening vaovao. Mat fohy kokoa na variation mat vaovao = fandrosoana.", fontSize = 12.sp)
                }
            }
        }
        val files = remember(t.running, t.table, vm.trainFilesRev) { vm.trainFiles() }
        if (!running && files.isNotEmpty()) {
            Text("Lalao voatahiry (PGN misy marika !! ! ? ??) sy tabilao CSV", fontWeight = FontWeight.Bold)
            files.forEach { name ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("$name (${vm.pgnSize(name) / 1024} KB)", fontSize = 13.sp, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { if (name.endsWith(".csv")) exporter.csv(name) else exporter.pgn(name) }) { Text("Export") }
                    OutlinedButton(onClick = { vm.deleteTrainFile(name) }) { Text("Fafao") }
                }
            }
        }
        if (t.log.isNotEmpty()) {
            Text("Log", fontWeight = FontWeight.Bold)
            t.log.takeLast(8).forEach { Text(it, fontSize = 12.sp, fontFamily = FontFamily.Monospace) }
        }
    }
}
