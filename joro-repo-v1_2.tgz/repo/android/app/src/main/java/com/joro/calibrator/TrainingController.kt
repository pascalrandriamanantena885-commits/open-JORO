package com.joro.calibrator

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import java.io.File
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TrainOpening(val name: String, val moves: List<Int>, val fen: String = "")   // fen "" = standard start (endgame etudes use a FEN)

data class TrainParams(
    val depth: Int, val depthStrong: Int = 0, val msWeak: Int = 0, val msStrong: Int = 0, val maxGames: Int, val stable: Int, val confirm: Int, val drawFail: Boolean, val hashMb: Int,
    val vsStockfish: Boolean = false,      // mix of opponents (JORO / Stockfish ladder / Stockfish full) instead of JORO vs JORO only
    val mixSelf: Int = 20, val mixLadder: Int = 60, val mixMax: Int = 20,   // weights of the three opponents (proportions)
    val ladderNeed: Int = 3, val ladderWindow: Int = 3,                     // ladder: level up after N wins in the last M games
    val varyFirstPct: Double = 5.0,        // chance that JORO's first move after the opening is its 2nd best
    val pgnSplit: Int = 100,               // games per PGN file
    val sfMoveTimeMs: Int = 1000,
    val gate: Boolean = true               // A/B gate after the training: new experience vs the previous one
)

data class OpeningResult(
    val name: String, val games: Int, val white: Int, val black: Int, val draws: Int,
    val newBad: Int, val newGood: Int, val verdict: String
)

data class TrainState(
    val running: Boolean = false,
    val openingName: String = "",
    val openingIndex: Int = 0,
    val openingTotal: Int = 0,
    val game: Int = 0,
    val maxGames: Int = 0,
    val white: Int = 0, val black: Int = 0, val draws: Int = 0,
    val newBad: Int = 0, val newGood: Int = 0,     // since the start of the run, all openings
    val entries: Int = 0,
    val log: List<String> = emptyList(),
    val results: List<OpeningResult> = emptyList(),
    val message: String = "",
    val table: String = "",               // per-opening table of the last run (with the comparison to the previous run)
    val paused: Boolean = false,          // pause requested
    val sleeping: Boolean = false,        // the engine really sleeps (no CPU)
    val live: List<Int> = emptyList()     // moves of the game being played (only filled while the UI watches)
)

/**
 * The training runs inside the app process: the C++ engine/trainer is called directly through JNI (no UCI).
 * Like the calibration it is owned by the process and kept alive by [TrainingService].
 * Every finished game is written to joro.exp, so a killed process loses at most one game.
 */
object TrainingController {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow(TrainState())
    val state: StateFlow<TrainState> = _state
    private var job: Job? = null
    private val lock = Any()
    private var handle = 0L
    @Volatile private var stopRequested = false
    @Volatile private var pausedFlag = false
    @Volatile private var watching = false

    private val reasons = listOf("mat", "pat", "50 move", "repetition", "material tsy ampy", "max plies", "adjudicated", "?")

    @Synchronized
    fun start(ctx: Context, queue: List<TrainOpening>, p: TrainParams): String? {
        if (_state.value.running) return "Efa mandeha ny training."
        if (CalibrationController.state.value.running) return "Mandeha ny calibrate: andraso ny faran'izany."
        if (queue.isEmpty()) return "Tsy misy opening hanaovana training."
        val app = ctx.applicationContext
        val storage = Storage(app)
        storage.expFile.parentFile?.mkdirs()
        val expPath = storage.expFile.absolutePath
        var sf: UciEngine? = null
        var opponent: StockfishOpponent? = null
        if (p.vsStockfish) {
            val f = storage.stockfish
            if (!f.exists()) return "Tsy hita ny Stockfish ao anaty APK (libstockfish.so). Jereo ny README."
            val e = UciEngine(f.absolutePath, "train-sf")
            if (!e.start() || !e.handshake() || !e.isReady()) { e.quit(); return "Tsy afaka nandeha ny Stockfish." }
            e.setOption("Hash", "64")
            e.setOption("Threads", "1")
            if (!e.isReady()) { e.quit(); return "Tsy afaka nandeha ny Stockfish." }
            sf = e
            opponent = StockfishOpponent(e, p.sfMoveTimeMs) { stopRequested }
        }
        stopRequested = false
        pausedFlag = false
        _state.value = TrainState(running = true, openingTotal = queue.size, maxGames = p.maxGames,
            entries = storage.currentExpInfo()?.entries?.toInt() ?: 0)

        // Live board + "really asleep" flag. Cheap: one JNI call every 400 ms, and the moves only while the UI watches.
        scope.launch(Dispatchers.IO) {
            while (_state.value.running) {
                val h = synchronized(lock) { handle }
                if (h != 0L) {
                    val sleeping = Native.trainWaiting(h)
                    val live = if (watching) Native.trainLive(h).toList() else null
                    _state.update {
                        if (it.sleeping == sleeping && (live == null || live == it.live)) it
                        else it.copy(sleeping = sleeping, live = live ?: it.live)
                    }
                }
                delay(400)
            }
        }
        val expFile = File(expPath)
        val bakFile = File("$expPath.bak")
        val hadBase = expFile.exists()
        // PGN of every game, per-opening table and ladder level are shared by all openings of this run
        val w = if (p.vsStockfish) Triple(p.mixSelf, p.mixLadder, p.mixMax) else Triple(100, 0, 0)
        Native.runBegin(storage.trainStatsFile.absolutePath, storage.trainPgnPrefix, p.pgnSplit, w.first, w.second, w.third,
            p.ladderNeed, p.ladderWindow, storage.ladderFile.absolutePath, false)
        if (hadBase) runCatching { expFile.copyTo(bakFile, overwrite = true) }     // the A/B gate compares with this copy
        val gateStarts = ArrayList<List<Int>>()
        job = scope.launch(Dispatchers.IO) {
            val results = ArrayList<OpeningResult>()
            var totalBad = 0
            var totalGood = 0
            for ((idx, op) in queue.withIndex()) {
                if (stopRequested) break
                Native.setStartFen(op.fen)                                  // "" = standard start; endgame etudes use a FEN
                val h = Native.trainCreate(op.moves.toIntArray(), expPath, p.depth, p.depthStrong, p.msWeak, p.msStrong, p.maxGames, p.stable, p.confirm, p.drawFail, p.hashMb, p.varyFirstPct, op.name)
                if (h == 0L) {
                    log("Tsy afaka nanomboka ny training (experience simba na opening tsy mety).")
                    break
                }
                synchronized(lock) { handle = h }
                if (opponent != null) Native.trainSetMix(h, opponent)
                if (pausedFlag) Native.trainPause(h, true)              // a pause survives the change of opening
                _state.update { it.copy(openingName = op.name, openingIndex = idx + 1, game = 0, white = 0, black = 0, draws = 0) }
                var last: IntArray? = null
                var opBad = 0
                var opGood = 0
                while (true) {
                    val r = Native.trainStep(h)
                    if (r.isEmpty() || r[0] < 0 || r[0] == 2) break          // error or stopped
                    last = r
                    opBad += r[3]; opGood += r[4]; totalBad += r[3]; totalGood += r[4]
                    val res = when (r[1]) { 1 -> "1-0"; -1 -> "0-1"; else -> "1/2" }
                    val opp = Native.trainLastOpponent(h)
                    val extra = if (r.size >= 23) (if (r[20] >= 0) " [hetsika voalohany navaozina]" else "") + (if (r[22] == 1) "  LADDER: miakatra" else "") else ""
                    val line = "${op.name} #${r[9]}: $res ${r[2]} plies (${reasons[r[10].coerceIn(0, 7)]}) vs $opp  +bad ${r[3]} +brilliant ${r[4]}$extra"
                    _state.update {
                        it.copy(game = r[9], white = r[6], black = r[7], draws = r[8], entries = r[5],
                            newBad = totalBad, newGood = totalGood, log = (it.log + line).takeLast(40))
                    }
                    if (r[0] == 1 || stopRequested) break
                }
                synchronized(lock) { handle = 0 }
                Native.trainFinish(h)                                       // this opening's row of the table
                Native.trainDestroy(h)
                val l = last
                if (l != null) {
                    val verdict = when {
                        p.confirm > 0 && l[13] >= p.confirm && l[12] == 1 -> "White nandresy ${l[13]} lalao misesy"
                        p.confirm > 0 && l[13] >= p.confirm && l[12] == -1 -> "Black nandresy ${l[13]} lalao misesy"
                        l[14] >= p.stable -> "tsy nisy zava-baovao intsony"
                        l[9] >= p.maxGames -> "tapitra ny budget lalao"
                        else -> "natsahana"
                    }
                    results.add(OpeningResult(op.name, l[9], l[6], l[7], l[8], opBad, opGood, verdict))
                    if (op.fen.isEmpty() && l[9] > 0) gateStarts.add(op.moves)
                } else {
                    results.add(OpeningResult(op.name, 0, 0, 0, 0, 0, 0, "tsy nisy lalao vita"))
                }
                _state.update { it.copy(results = results.toList()) }
            }
            sf?.quit()
            Native.setStartFen("")
            val table = Native.runEnd()                                      // saves the table (CSV), returns it as text
            // ---- A/B gate: the new experience must not play worse than the previous one (a big regression is rolled back)
            var gateMsg = ""
            if (p.gate && hadBase && gateStarts.isNotEmpty() && results.any { it.games > 0 }) {
                _state.update { it.copy(message = "Fanamarinana A/B: experience vaovao vs taloha...") }
                val picked = gateStarts.filterIndexed { i, _ -> i % maxOf(1, (gateStarts.size + 7) / 8) == 0 }
                val flat = ArrayList<Int>()
                for (m in picked) { flat.addAll(m); flat.add(-1) }
                val g = Native.gateRun(bakFile.absolutePath, expPath, flat.toIntArray(), 2, 60)
                if (g.size == 3) {
                    val total = g[0] + g[1] + g[2]
                    val score = if (total > 0) (g[0] + 0.5 * g[1]) / total else 0.5
                    val pct = (score * 1000).toInt() / 10.0
                    if (score < 0.45) {
                        runCatching { expFile.copyTo(File("$expPath.rejected"), overwrite = true); bakFile.copyTo(expFile, overwrite = true) }
                        gateMsg = " A/B: +${g[0]} =${g[1]} -${g[2]} ($pct%) -> VOAVELA ny experience taloha (ny vaovao: joro.exp.rejected)."
                    } else gateMsg = " A/B: +${g[0]} =${g[1]} -${g[2]} ($pct%) -> ekena."
                } else gateMsg = " A/B: tsy vita ny fanamarinana."
                log(gateMsg.trim())
            }
            _state.update {
                it.copy(running = false, paused = false, sleeping = false, live = emptyList(), results = results.toList(), table = table,
                    message = (if (stopRequested) "Natsahana. Voatahiry ao amin'ny joro.exp ny efa nianarana." else "Training vita.") + gateMsg)
            }
        }
        ContextCompat.startForegroundService(app, Intent(app, TrainingService::class.java))
        return null
    }

    /** Pause: the game sleeps at the next move (no CPU, wake lock released by the service). Resume continues the same game. */
    fun setPaused(p: Boolean) {
        pausedFlag = p
        synchronized(lock) { if (handle != 0L) Native.trainPause(handle, p) }
        _state.update { it.copy(paused = p, sleeping = if (p) it.sleeping else false) }
    }

    /** The training screen tells whether it shows the live board (then the moves are polled). */
    fun setWatching(w: Boolean) { watching = w }

    fun stop() {
        pausedFlag = false
        Native.gateStop(true)
        stopRequested = true
        synchronized(lock) { if (handle != 0L) { Native.trainPause(handle, false); Native.trainStop(handle) } }   // interrupts the game being played
    }

    private fun log(line: String) { _state.update { it.copy(log = (it.log + line).takeLast(40)) } }
}
