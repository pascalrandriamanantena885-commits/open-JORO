package com.joro.calibrator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground service: keeps the calibration alive when the app is not open (screen off, app closed or swiped
 * away). Shows a notification with the progress and a "Atsaha" button; stops itself when the run is over.
 */
class CalibrationService : Service() {
    companion object {
        const val ACTION_STOP = "com.joro.calibrator.STOP"
        private const val CHANNEL = "calibrate"
        private const val ID_RUN = 1
        private const val ID_DONE = 2
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wake: PowerManager.WakeLock? = null
    private var lastUpdate = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "JORO calibrate", NotificationManager.IMPORTANCE_LOW))
        startForeground(ID_RUN, build("JORO calibrate", "Manomboka...", 0, 0, true))

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "joro:calibrate").apply {
            setReferenceCounted(false)
            acquire(8L * 60 * 60 * 1000)   // safety timeout: 8 h
        }

        scope.launch {
            CalibrationController.state.collect { st ->
                if (st.running) {
                    val now = System.currentTimeMillis()
                    if (now - lastUpdate >= 1500) {
                        lastUpdate = now
                        val total = st.stats.values.sumOf { it.planned }
                        val done = st.stats.values.sumOf { it.played }
                        nm.notify(ID_RUN, build("JORO calibrate: $done/$total lalao", levelsLine(st), done, total, true))
                    }
                } else {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    val text = st.summary?.let { "JORO ${Elo.overallText(it)} Elo" + if (it.partial) " (ampahany)" else "" }
                        ?: st.message.ifEmpty { "Vita" }
                    nm.notify(ID_DONE, build("Calibrate vita", text, 0, 0, false))
                    stopSelf()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) CalibrationController.stop()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    private fun levelsLine(st: RunState): String =
        st.stats.values.sortedBy { it.elo }.joinToString("  ") { "${it.elo}: ${it.played}/${it.planned}" }

    private fun build(title: String, text: String, done: Int, total: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
        if (ongoing) {
            b.setProgress(total, done, total == 0)
            val stop = PendingIntent.getService(
                this, 1, Intent(this, CalibrationService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
            )
            b.addAction(0, "Atsaha", stop)
        } else {
            b.setAutoCancel(true)
        }
        return b.build()
    }
}
