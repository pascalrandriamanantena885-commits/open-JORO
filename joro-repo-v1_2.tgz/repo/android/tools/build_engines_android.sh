#!/usr/bin/env bash
# Builds the two UCI executables that the app runs as child processes, for arm64-v8a:
#   libjoro.so       (JORO, from ../../src)
#   libstockfish.so  (official Stockfish, GPLv3 - needs internet only here, at build time)
# They are plain executables named lib*.so so that Gradle packs + extracts them into nativeLibraryDir.
#   usage: ANDROID_NDK_HOME=/path/to/ndk android/tools/build_engines_android.sh [--joro-only]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-}}"
[ -d "$NDK" ] || { echo "Set ANDROID_NDK_HOME"; exit 1; }
OUT="$ROOT/android/app/src/main/jniLibs/arm64-v8a"
mkdir -p "$OUT"

echo "== JORO"
cmake -S "$ROOT" -B "$ROOT/build-android" -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26
cmake --build "$ROOT/build-android" --target joro -j
cp "$ROOT/build-android/joro" "$OUT/libjoro.so"

if [ "${1:-}" = "--joro-only" ]; then echo "done (JORO only)"; exit 0; fi

echo "== Stockfish"
SF_TAG="${SF_TAG:-sf_17}"
export PATH="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin:$PATH"
if [ ! -d "$ROOT/build-android/Stockfish" ]; then
  git clone --depth 1 --branch "$SF_TAG" https://github.com/official-stockfish/Stockfish.git "$ROOT/build-android/Stockfish"
fi
make -C "$ROOT/build-android/Stockfish/src" -j build ARCH=armv8 COMP=ndk
cp "$ROOT/build-android/Stockfish/src/stockfish" "$OUT/libstockfish.so"
llvm-strip "$OUT/libstockfish.so" "$OUT/libjoro.so" || true
ls -la "$OUT"
