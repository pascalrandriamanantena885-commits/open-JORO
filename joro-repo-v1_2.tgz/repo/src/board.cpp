// JORO - board.cpp
#include "board.h"
#include <cctype>
#include <cstdlib>
#include <sstream>

namespace joro {

const char* START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

U64 zPiece[16][64], zSide, zCastle[16], zEp[8];
int knightN[64], knightTo[64][8], kingN[64], kingTo[64][8];
static int castMask[64];

static const int DIRS[8][2] = {{1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}};  // (df, dr)
static const int KN[8][2] = {{1, 2}, {2, 1}, {2, -1}, {1, -2}, {-1, -2}, {-2, -1}, {-2, 1}, {-1, 2}};

static U64 splitmix(U64& x) {
    x += 0x9E3779B97F4A7C15ULL;
    U64 z = x;
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}

static void doInitTables() {
    U64 seed = 0x4A4F524FULL;  // "JORO" : fixed seed => position keys are stable across runs/devices
    for (int p = 0; p < 16; p++)
        for (int s = 0; s < 64; s++) zPiece[p][s] = splitmix(seed);
    zSide = splitmix(seed);
    for (int i = 0; i < 16; i++) zCastle[i] = splitmix(seed);
    for (int i = 0; i < 8; i++) zEp[i] = splitmix(seed);
    for (int s = 0; s < 64; s++) {
        int f = s & 7, r = s >> 3;
        knightN[s] = kingN[s] = 0;
        for (int i = 0; i < 8; i++) {
            int nf = f + KN[i][0], nr = r + KN[i][1];
            if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) knightTo[s][knightN[s]++] = nr * 8 + nf;
            nf = f + DIRS[i][0];
            nr = r + DIRS[i][1];
            if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) kingTo[s][kingN[s]++] = nr * 8 + nf;
        }
        castMask[s] = 15;
    }
    castMask[0] &= ~CR_WQ;
    castMask[4] &= ~(CR_WK | CR_WQ);
    castMask[7] &= ~CR_WK;
    castMask[56] &= ~CR_BQ;
    castMask[60] &= ~(CR_BK | CR_BQ);
    castMask[63] &= ~CR_BK;
}

void initTables() {  // thread-safe, idempotent (several worker threads may create boards at once)
    static const bool ok = (doInitTables(), true);
    (void)ok;
}

Board::Board() {
    initTables();
    setFen(START_FEN);
}

U64 Board::computeHash() const {
    U64 h = 0;
    for (int s = 0; s < 64; s++)
        if (sq[s]) h ^= zPiece[sq[s]][s];
    if (side == BLACK) h ^= zSide;
    h ^= zCastle[castling];
    if (ep >= 0) h ^= zEp[ep & 7];
    return h;
}

bool Board::setFen(const std::string& fen) {
    std::istringstream is(fen);
    std::string pos, stm, cs = "-", eps = "-";
    int hm = 0, fm = 1;
    if (!(is >> pos >> stm)) return false;
    is >> cs >> eps >> hm >> fm;
    for (int i = 0; i < 64; i++) sq[i] = 0;
    kingSq[0] = kingSq[1] = -1;
    int r = 7, f = 0;
    for (char ch : pos) {
        if (ch == '/') { r--; f = 0; continue; }
        if (isdigit((unsigned char)ch)) { f += ch - '0'; continue; }
        int c = isupper((unsigned char)ch) ? WHITE : BLACK, t = 0;
        switch (tolower((unsigned char)ch)) {
            case 'p': t = PAWN; break;
            case 'n': t = KNIGHT; break;
            case 'b': t = BISHOP; break;
            case 'r': t = ROOK; break;
            case 'q': t = QUEEN; break;
            case 'k': t = KING; break;
            default: return false;
        }
        if (r < 0 || f > 7) return false;
        sq[r * 8 + f] = mkPiece(c, t);
        if (t == KING) kingSq[c] = r * 8 + f;
        f++;
    }
    if (kingSq[0] < 0 || kingSq[1] < 0) return false;
    side = (stm == "b") ? BLACK : WHITE;
    castling = 0;
    for (char ch : cs) {
        if (ch == 'K') castling |= CR_WK;
        if (ch == 'Q') castling |= CR_WQ;
        if (ch == 'k') castling |= CR_BK;
        if (ch == 'q') castling |= CR_BQ;
    }
    ep = -1;
    if (eps.size() == 2 && eps[0] >= 'a' && eps[0] <= 'h' && eps[1] >= '1' && eps[1] <= '8')
        ep = (eps[0] - 'a') + (eps[1] - '1') * 8;
    halfmove = hm;
    fullmove = fm < 1 ? 1 : fm;
    hist.clear();
    hash = computeHash();
    return true;
}

std::string Board::fen() const {
    std::string s;
    const char* pc = " pnbrqk";
    for (int r = 7; r >= 0; r--) {
        int empty = 0;
        for (int f = 0; f < 8; f++) {
            int p = sq[r * 8 + f];
            if (!p) { empty++; continue; }
            if (empty) { s += char('0' + empty); empty = 0; }
            char ch = pc[typeOf(p)];
            s += colorOf(p) == WHITE ? (char)toupper(ch) : ch;
        }
        if (empty) s += char('0' + empty);
        if (r) s += '/';
    }
    s += side == WHITE ? " w " : " b ";
    std::string cs;
    if (castling & CR_WK) cs += 'K';
    if (castling & CR_WQ) cs += 'Q';
    if (castling & CR_BK) cs += 'k';
    if (castling & CR_BQ) cs += 'q';
    s += cs.empty() ? "-" : cs;
    s += ' ';
    if (ep >= 0) { s += char('a' + (ep & 7)); s += char('1' + (ep >> 3)); } else s += '-';
    s += ' ' + std::to_string(halfmove) + ' ' + std::to_string(fullmove);
    return s;
}

bool Board::attacked(int s, int by) const {
    int f = s & 7, r = s >> 3;
    // pawns
    int pr = (by == WHITE) ? r - 1 : r + 1;
    if (pr >= 0 && pr < 8) {
        int pp = mkPiece(by, PAWN);
        if (f > 0 && sq[pr * 8 + f - 1] == pp) return true;
        if (f < 7 && sq[pr * 8 + f + 1] == pp) return true;
    }
    int np = mkPiece(by, KNIGHT);
    for (int i = 0; i < knightN[s]; i++)
        if (sq[knightTo[s][i]] == np) return true;
    int kp = mkPiece(by, KING);
    for (int i = 0; i < kingN[s]; i++)
        if (sq[kingTo[s][i]] == kp) return true;
    int bp = mkPiece(by, BISHOP), rp = mkPiece(by, ROOK), qp = mkPiece(by, QUEEN);
    for (int d = 0; d < 8; d++) {
        bool diag = d & 1;
        int nf = f + DIRS[d][0], nr = r + DIRS[d][1];
        while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
            int p = sq[nr * 8 + nf];
            if (p) {
                if (p == qp || p == (diag ? bp : rp)) return true;
                break;
            }
            nf += DIRS[d][0];
            nr += DIRS[d][1];
        }
    }
    return false;
}

int Board::genMoves(Move* mv, bool caps) const {
    int n = 0;
    const int us = side, them = side ^ 1;
    const int dr = us == WHITE ? 1 : -1;
    const int startR = us == WHITE ? 1 : 6, promoR = us == WHITE ? 7 : 0;
    for (int s = 0; s < 64; s++) {
        int p = sq[s];
        if (!p || colorOf(p) != us) continue;
        int t = typeOf(p), f = s & 7, r = s >> 3;
        if (t == PAWN) {
            int r1 = r + dr, to = r1 * 8 + f;
            if (!sq[to]) {
                if (r1 == promoR) {
                    for (int pr = QUEEN; pr >= KNIGHT; pr--) mv[n++] = mkMove(s, to, 0, pr);
                } else if (!caps) {
                    mv[n++] = mkMove(s, to);
                    if (r == startR && !sq[to + 8 * dr]) mv[n++] = mkMove(s, to + 8 * dr, F_DOUBLE);
                }
            }
            for (int df = -1; df <= 1; df += 2) {
                int nf = f + df;
                if (nf < 0 || nf > 7) continue;
                int tt = r1 * 8 + nf, tp = sq[tt];
                if (tp && colorOf(tp) == them) {
                    if (r1 == promoR) {
                        for (int pr = QUEEN; pr >= KNIGHT; pr--) mv[n++] = mkMove(s, tt, 0, pr);
                    } else mv[n++] = mkMove(s, tt);
                } else if (!tp && tt == ep) {
                    mv[n++] = mkMove(s, tt, F_EP);
                }
            }
        } else if (t == KNIGHT || t == KING) {
            const int cnt = t == KNIGHT ? knightN[s] : kingN[s];
            const int* tab = t == KNIGHT ? knightTo[s] : kingTo[s];
            for (int i = 0; i < cnt; i++) {
                int to = tab[i], tp = sq[to];
                if (tp ? colorOf(tp) == them : !caps) mv[n++] = mkMove(s, to);
            }
            if (t == KING && !caps) {
                if (us == WHITE) {
                    if ((castling & CR_WK) && !sq[5] && !sq[6] && sq[7] == mkPiece(WHITE, ROOK) &&
                        !attacked(4, BLACK) && !attacked(5, BLACK) && !attacked(6, BLACK))
                        mv[n++] = mkMove(4, 6, F_CASTLE);
                    if ((castling & CR_WQ) && !sq[1] && !sq[2] && !sq[3] && sq[0] == mkPiece(WHITE, ROOK) &&
                        !attacked(4, BLACK) && !attacked(3, BLACK) && !attacked(2, BLACK))
                        mv[n++] = mkMove(4, 2, F_CASTLE);
                } else {
                    if ((castling & CR_BK) && !sq[61] && !sq[62] && sq[63] == mkPiece(BLACK, ROOK) &&
                        !attacked(60, WHITE) && !attacked(61, WHITE) && !attacked(62, WHITE))
                        mv[n++] = mkMove(60, 62, F_CASTLE);
                    if ((castling & CR_BQ) && !sq[57] && !sq[58] && !sq[59] && sq[56] == mkPiece(BLACK, ROOK) &&
                        !attacked(60, WHITE) && !attacked(59, WHITE) && !attacked(58, WHITE))
                        mv[n++] = mkMove(60, 58, F_CASTLE);
                }
            }
        } else {
            int d0 = (t == BISHOP) ? 1 : 0, dstep = (t == QUEEN) ? 1 : 2;
            for (int d = d0; d < 8; d += dstep) {
                int nf = f + DIRS[d][0], nr = r + DIRS[d][1];
                while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                    int to = nr * 8 + nf, tp = sq[to];
                    if (!tp) {
                        if (!caps) mv[n++] = mkMove(s, to);
                    } else {
                        if (colorOf(tp) == them) mv[n++] = mkMove(s, to);
                        break;
                    }
                    nf += DIRS[d][0];
                    nr += DIRS[d][1];
                }
            }
        }
    }
    return n;
}

void Board::makeMove(Move m) {
    Undo u{m, 0, castling, ep, halfmove, hash};
    const int f = mFrom(m), t = mTo(m), fl = mFlag(m), c = side;
    const int p = sq[f];
    int cap = sq[t];
    if (ep >= 0) hash ^= zEp[ep & 7];
    ep = -1;
    halfmove++;
    if (typeOf(p) == PAWN) halfmove = 0;
    if (fl == F_EP) {
        int cs = t + (c == WHITE ? -8 : 8);
        cap = sq[cs];
        sq[cs] = 0;
        hash ^= zPiece[cap][cs];
    } else if (cap) {
        hash ^= zPiece[cap][t];
    }
    if (cap) halfmove = 0;
    u.captured = cap;
    hash ^= zPiece[p][f];
    sq[f] = 0;
    int np = mPromo(m) ? mkPiece(c, mPromo(m)) : p;
    sq[t] = np;
    hash ^= zPiece[np][t];
    if (typeOf(p) == KING) kingSq[c] = t;
    if (fl == F_DOUBLE) {
        ep = (f + t) / 2;
        hash ^= zEp[ep & 7];
    }
    if (fl == F_CASTLE) {
        int rf, rt;
        if (t > f) { rf = f + 3; rt = f + 1; } else { rf = f - 4; rt = f - 1; }
        int rk = sq[rf];
        sq[rf] = 0;
        sq[rt] = rk;
        hash ^= zPiece[rk][rf] ^ zPiece[rk][rt];
    }
    hash ^= zCastle[castling];
    castling &= castMask[f] & castMask[t];
    hash ^= zCastle[castling];
    side ^= 1;
    hash ^= zSide;
    if (c == BLACK) fullmove++;
    hist.push_back(u);
}

void Board::unmakeMove() {
    Undo u = hist.back();
    hist.pop_back();
    side ^= 1;
    const int c = side;
    const Move m = u.move;
    const int f = mFrom(m), t = mTo(m), fl = mFlag(m);
    int p = sq[t];
    if (mPromo(m)) p = mkPiece(c, PAWN);
    sq[f] = p;
    sq[t] = 0;
    if (typeOf(p) == KING) kingSq[c] = f;
    if (fl == F_EP) sq[t + (c == WHITE ? -8 : 8)] = u.captured;
    else sq[t] = u.captured;
    if (fl == F_CASTLE) {
        int rf, rt;
        if (t > f) { rf = f + 3; rt = f + 1; } else { rf = f - 4; rt = f - 1; }
        sq[rf] = sq[rt];
        sq[rt] = 0;
    }
    castling = u.castling;
    ep = u.ep;
    halfmove = u.halfmove;
    hash = u.hash;
    if (c == BLACK) fullmove--;
}

bool Board::makeLegal(Move m) {
    int c = side;
    makeMove(m);
    if (attacked(kingSq[c], c ^ 1)) {
        unmakeMove();
        return false;
    }
    return true;
}

void Board::makeNull() {
    hist.push_back(Undo{0, 0, castling, ep, halfmove, hash});
    if (ep >= 0) hash ^= zEp[ep & 7];
    ep = -1;
    halfmove++;
    side ^= 1;
    hash ^= zSide;
}

void Board::unmakeNull() {
    Undo u = hist.back();
    hist.pop_back();
    side ^= 1;
    ep = u.ep;
    halfmove = u.halfmove;
    hash = u.hash;
}

bool Board::isRepetition() const {
    int n = (int)hist.size();
    int lim = halfmove < n ? halfmove : n;
    for (int i = 2; i <= lim; i += 2)
        if (hist[n - i].hash == hash) return true;
    return false;
}

int Board::genLegal(Move* out) {
    Move tmp[256];
    int n = genMoves(tmp), k = 0;
    for (int i = 0; i < n; i++)
        if (makeLegal(tmp[i])) {
            unmakeMove();
            out[k++] = tmp[i];
        }
    return k;
}

std::string Board::moveToStr(Move m) {
    std::string s;
    s += char('a' + (mFrom(m) & 7));
    s += char('1' + (mFrom(m) >> 3));
    s += char('a' + (mTo(m) & 7));
    s += char('1' + (mTo(m) >> 3));
    if (mPromo(m)) s += " pnbrqk"[mPromo(m)];
    return s;
}

Move Board::parseMove(const std::string& str) {
    Move mv[256];
    int n = genLegal(mv);
    for (int i = 0; i < n; i++)
        if (moveToStr(mv[i]) == str) return mv[i];
    return MOVE_NONE;
}

U64 Board::perft(int depth) {
    if (depth == 0) return 1;
    Move mv[256];
    int n = genMoves(mv);
    U64 total = 0;
    for (int i = 0; i < n; i++) {
        if (!makeLegal(mv[i])) continue;
        total += depth == 1 ? 1 : perft(depth - 1);
        unmakeMove();
    }
    return total;
}

} // namespace joro
