// JORO - experience.cpp
#include "experience.h"
#include <algorithm>
#include <cstdio>
#include <cstring>

namespace joro {

static const uint32_t EXP_VERSION = 2;

void Experience::clear() {
    map.clear();
    total = 0;
    styleSet = false;
}

void Experience::add(U64 key, Move m, int kind, int value, int inc) {
    auto& v = map[key];
    for (auto& e : v) {
        if (e.move == m && e.kind == kind) {
            int oc = e.count, nc = std::min(255, oc + inc);
            e.value = (int16_t)((e.value * oc + value * inc) / std::max(1, oc + inc));
            e.count = (uint8_t)nc;
            return;
        }
    }
    ExpEntry e;
    e.key = key;
    e.move = m;
    e.value = (int16_t)value;
    e.kind = (uint8_t)kind;
    e.count = (uint8_t)std::min(255, std::max(1, inc));
    v.push_back(e);
    total++;
}

void Experience::addLine(U64 key, Move m, int value) {
    auto& v = map[key];
    for (auto& e : v) {
        if (e.move == m && e.kind == EXP_GOOD) {
            e.value = (int16_t)(e.value >= MATE_LINE_MIN ? std::max<int>(e.value, value) : value);   // keep the best line
            e.count = (uint8_t)std::min(255, e.count + 1);
            return;
        }
    }
    ExpEntry n;
    n.key = key; n.move = m; n.value = (int16_t)value; n.kind = EXP_GOOD; n.count = 1;
    v.push_back(n);
    total++;
}

static int countOf(const std::unordered_map<U64, std::vector<ExpEntry>>& map, U64 key, Move m, int kind) {
    auto it = map.find(key);
    if (it == map.end()) return 0;
    for (auto& e : it->second)
        if (e.move == m && e.kind == kind) return e.count;
    return 0;
}
int Experience::goodCount(U64 key, Move m) const { return countOf(map, key, m, EXP_GOOD); }
int Experience::badCount(U64 key, Move m) const { return countOf(map, key, m, EXP_BAD); }

Move Experience::bestGood(U64 key, const Move* cands, int n, int* value) const {
    auto it = map.find(key);
    if (it == map.end()) return MOVE_NONE;
    Move best = MOVE_NONE;
    int bestNet = 0, bestVal = -32768;
    bool bestLine = false;
    for (auto& e : it->second) {
        if (e.kind != EXP_GOOD) continue;
        bool legal = false;
        for (int i = 0; i < n; i++)
            if (cands[i] == e.move) { legal = true; break; }
        if (!legal) continue;
        int net = e.count - badCount(key, e.move);
        if (net <= 0) continue;
        const bool line = e.value >= MATE_LINE_MIN;
        bool better;
        if (line != bestLine && best != MOVE_NONE) better = line;                       // a mating line beats anything else
        else if (line) better = e.value > bestVal;                                      // between lines: the best quality
        else better = net > bestNet || (net == bestNet && e.value > bestVal);
        if (better) {
            best = e.move;
            bestNet = net;
            bestVal = e.value;
            bestLine = line;
        }
    }
    if (value) *value = bestVal;
    return best;
}

void Experience::merge(const Experience& o) {
    for (auto& kv : o.map)
        for (auto& e : kv.second) add(e.key, e.move, e.kind, e.value, e.count);
    if (o.styleSet && !styleSet) { styleSet = true; std::memcpy(st, o.st, sizeof st); styleIdv = o.styleIdv; std::memcpy(styleName, o.styleName, 16); }
}

void Experience::setStyle(const Style& s) {
    styleSet = true;
    std::memset(st, 0, sizeof st);
    for (int i = 0; i < SP_COUNT; i++) st[i] = s.w[i];
    styleIdv = s.id();
    std::memset(styleName, 0, 16);
    std::strncpy(styleName, s.name.c_str(), 15);
}
bool Experience::getStyle(Style& s) const {
    if (!styleSet) return false;
    for (int i = 0; i < SP_COUNT; i++) s.w[i] = st[i];
    s.name = std::string(styleName, strnlen(styleName, 16));
    return true;
}

bool Experience::save(const std::string& path) const {
    std::vector<ExpEntry> all;
    all.reserve(total);
    for (auto& kv : map)
        for (auto& e : kv.second) all.push_back(e);
    std::sort(all.begin(), all.end(), [](const ExpEntry& a, const ExpEntry& b) {
        if (a.key != b.key) return a.key < b.key;
        if (a.move != b.move) return a.move < b.move;
        return a.kind < b.kind;
    });
    FILE* f = fopen(path.c_str(), "wb");
    if (!f) return false;
    uint32_t ver = EXP_VERSION, n = (uint32_t)all.size(), flags = styleSet ? 1 : 0;
    bool ok = fwrite("JEXP", 1, 4, f) == 4 && fwrite(&ver, 4, 1, f) == 1 && fwrite(&n, 4, 1, f) == 1 &&
              fwrite(&flags, 4, 1, f) == 1 && fwrite(&styleIdv, 8, 1, f) == 1 &&
              fwrite(styleName, 1, 16, f) == 16 && fwrite(st, 4, 16, f) == 16;
    if (ok && n) ok = fwrite(all.data(), sizeof(ExpEntry), n, f) == n;
    fclose(f);
    return ok;
}

bool Experience::load(const std::string& path, std::string* err) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) { if (err) *err = "cannot open " + path; return false; }
    char magic[4];
    uint32_t ver = 0, n = 0, flags = 0;
    int32_t s[16];
    uint64_t sid = 0;
    char sname[16];
    bool ok = fread(magic, 1, 4, f) == 4 && memcmp(magic, "JEXP", 4) == 0 && fread(&ver, 4, 1, f) == 1 &&
              fread(&n, 4, 1, f) == 1 && fread(&flags, 4, 1, f) == 1 &&
              fread(&sid, 8, 1, f) == 1 && fread(sname, 1, 16, f) == 16 && fread(s, 4, 16, f) == 16;
    if (!ok || ver != EXP_VERSION) {
        fclose(f);
        if (err) *err = "bad header / version in " + path;
        return false;
    }
    std::vector<ExpEntry> all(n);
    if (n && fread(all.data(), sizeof(ExpEntry), n, f) != n) {
        fclose(f);
        if (err) *err = "truncated file " + path;
        return false;
    }
    fclose(f);
    clear();
    for (auto& e : all) add(e.key, e.move, e.kind, e.value, e.count);
    if (flags & 1) { styleSet = true; std::memcpy(st, s, sizeof st); styleIdv = sid; std::memcpy(styleName, sname, 16); }
    return true;
}

} // namespace joro
