// JORO - referee.h : game-state judge used by the Android calibrator (through JNI).
// Given a start FEN and the UCI moves played, tells whether the game goes on or how it ended.
#pragma once
#include "board.h"
#include <sstream>
#include <string>

namespace joro {

enum RefStatus {
    REF_ONGOING = 0,
    REF_WHITE_MATES = 1,   // white won by checkmate
    REF_BLACK_MATES = 2,   // black won by checkmate
    REF_STALEMATE = 3,
    REF_FIFTY = 4,
    REF_REPETITION = 5,    // threefold
    REF_INSUFFICIENT = 6,
    REF_ILLEGAL = 9        // a move in the list is illegal (the side that played it loses)
};

inline int refereeStatus(const std::string& fen, const std::string& moves) {
    Board b;
    if (!b.setFen(fen)) return REF_ILLEGAL;
    std::istringstream is(moves);
    std::string m;
    while (is >> m) {
        Move mv = b.parseMove(m);
        if (mv == MOVE_NONE) return REF_ILLEGAL;
        b.makeMove(mv);
    }
    Move l[256];
    if (b.genLegal(l) == 0) return b.inCheck() ? (b.side == WHITE ? REF_BLACK_MATES : REF_WHITE_MATES) : REF_STALEMATE;
    if (b.halfmove >= 100) return REF_FIFTY;
    int reps = 1;
    for (auto& u : b.hist) if (u.hash == b.hash) reps++;
    if (reps >= 3) return REF_REPETITION;
    int minors = 0;
    bool material = false;
    for (int s = 0; s < 64 && !material; s++) {
        int t = typeOf(b.sq[s]);
        if (t == PAWN || t == ROOK || t == QUEEN) material = true;
        else if (t == KNIGHT || t == BISHOP) minors++;
    }
    if (!material && minors <= 1) return REF_INSUFFICIENT;
    return REF_ONGOING;
}

} // namespace joro
