#pragma once
namespace joro { void uciLoop(); }
