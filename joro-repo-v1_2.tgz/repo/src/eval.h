// JORO - eval.h : static evaluation driven by the JORO playing style (see styles/joro.style)
#pragma once
#include "board.h"
#include <string>

namespace joro {

// One weight per module of the JORO style document. Weights are percentages (100 = nominal),
// except contempt (centipawns).
enum StyleParam {
    SP_OWN_KING,    // DKD  : own king safety
    SP_ENEMY_KING,  // DKD  : pressure on the enemy king
    SP_PINS,        // TBDA : pins / x-rays against valuable pieces
    SP_LOOSE,       // TBDA : hanging pieces, overloaded defenders
    SP_COMP,        // SI   : compensation for sacrificed material
    SP_OUTPOST,     // DSI  : outposts
    SP_POTENTIAL,   // DSI  : squares that can be prepared (potential outposts, files toward the king)
    SP_OPENING,     // PASI : opening principles (development, centre, castling)
    SP_ENDGAME,     // PASI : endgame (king activity, conversion, drawish scaling)
    SP_STRUCT,      // DPSI : pawn structure
    SP_PASSERS,     // DPSI : passed pawns
    SP_INITIATIVE,  // IPC  : threats, space, tempo
    SP_ACTIVITY,    // piece activity / mobility
    SP_CONTEMPT,    // cp, > 0 avoids draws
    SP_KING_HUNT,   // KHTI : king hunting & trap intelligence (escape squares, isolation, mating nets)
    SP_COUNT
};

struct Style {
    std::string name = "JORO";
    int w[SP_COUNT];

    Style();
    static const char* paramName(int i);        // e.g. "own_king"
    uint64_t id() const;                        // hash of the weights : ties experience <-> style
    uint64_t legacyId() const;                  // id of the same style without the modules added after v0.3 (KHTI)
    bool load(const std::string& path, std::string* err = nullptr);  // simple JSON
    bool save(const std::string& path) const;
    bool set(const std::string& param, int value);
    int& contempt() { return w[SP_CONTEMPT]; }
    int contempt() const { return w[SP_CONTEMPT]; }
};

// ---- King Position Classifier (JORO study: where is the enemy king and how good is its shield?)
enum KingPos { KP_SHORT, KP_LONG, KP_CENTER, KP_EXPOSED, KP_EDGE, KP_OTHER };

struct KingProfile {
    int type = KP_OTHER;     // KingPos
    int shieldPawns = 0;     // own pawns on the 3 shield files, ranks 2-3 (relative to the king's side)
    int shieldMissing = 3;   // 3 - shieldPawns
    int openFiles = 0;       // shield files without any own pawn
    int fileLo = 0, fileHi = 0;   // the 3 files that make the shield region
};

KingProfile classifyKing(const Board& b, int color);
const char* kingPosName(int t);

// score in centipawns from the side-to-move point of view
int evaluate(const Board& b, const Style& st);

extern const int PIECE_VAL[7];

} // namespace joro
