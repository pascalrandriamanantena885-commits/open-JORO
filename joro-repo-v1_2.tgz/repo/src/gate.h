// JORO - gate.h : A/B gate for a freshly trained experience (new vs the previous one)
#pragma once
#include "search.h"
#include <atomic>
#include <string>
#include <vector>

namespace joro {

struct GateStart { std::string fen; std::vector<Move> moves; };   // start position + opening moves

struct GateResult {
    int wins = 0, draws = 0, losses = 0;          // from the candidate's point of view
    int games() const { return wins + draws + losses; }
    double score() const { return games() ? (wins + 0.5 * draws) / games() : 0.5; }
};

// Plays candidate-vs-base games from every start (the candidate has each colour in turn), equal time per move.
// Both sides use the base's style. Stops early when *stop becomes true.
GateResult gateExperience(const Experience& cand, const Experience& base, const std::vector<GateStart>& starts,
                          int gamesPerStart, int movetimeMs, std::atomic<bool>* stop = nullptr);

} // namespace joro
