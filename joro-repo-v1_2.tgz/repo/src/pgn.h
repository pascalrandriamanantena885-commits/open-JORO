// JORO - pgn.h : games of the trainer as PGN (splittable), with brilliant / great / bad marks.
#pragma once
#include "trainer.h"
#include <string>

namespace joro {

// One game as PGN text. Marks: !! brilliant (NAG 3), ! great (NAG 1), ? bad (NAG 2), ?? blunder (NAG 4);
// every searched move carries [%eval ..] (white point of view); a short comment says what the mark means.
std::string gameToPgn(const GameRecord& rec, const std::string& event, int round, const std::string& date);

// Appends games to PREFIX_0001.pgn, PREFIX_0002.pgn ... a new file every `splitEvery` games (0 = one file).
// Existing files are never overwritten: numbering continues after the last existing file.
class PgnWriter {
public:
    PgnWriter(const std::string& prefix, int splitEvery);
    bool add(const GameRecord& rec, const std::string& event);   // false = cannot write
    int games() const { return total; }
    std::string currentFile() const { return cur; }
    int files() const { return fileCount; }
private:
    std::string prefix, cur;
    int splitEvery, inFile = 0, total = 0, fileNo = 0, fileCount = 0;
    std::string pathFor(int n) const;
};

} // namespace joro
