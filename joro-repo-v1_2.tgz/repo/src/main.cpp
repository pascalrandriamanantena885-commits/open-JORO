#include "uci.h"
int main() { joro::uciLoop(); return 0; }
