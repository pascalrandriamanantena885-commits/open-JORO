#include "san.h"

namespace joro {

std::string moveToSan(Board& b, Move m) {
    const int f = mFrom(m), t = mTo(m), fl = mFlag(m);
    const int pt = typeOf(b.sq[f]);
    const char* letters = " PNBRQK";
    std::string s;
    if (fl == F_CASTLE) {
        s = t > f ? "O-O" : "O-O-O";
    } else {
        const bool cap = b.sq[t] != 0 || fl == F_EP;
        if (pt == PAWN) {
            if (cap) { s += char('a' + (f & 7)); s += 'x'; }
        } else {
            s += letters[pt];
            Move mv[256];
            int n = b.genLegal(mv);
            bool other = false, sameFile = false, sameRank = false;
            for (int i = 0; i < n; i++) {
                int of = mFrom(mv[i]);
                if (mv[i] == m || mTo(mv[i]) != t || of == f || typeOf(b.sq[of]) != pt) continue;
                other = true;
                if ((of & 7) == (f & 7)) sameFile = true;
                if ((of >> 3) == (f >> 3)) sameRank = true;
            }
            if (other) {
                if (!sameFile) s += char('a' + (f & 7));
                else if (!sameRank) s += char('1' + (f >> 3));
                else { s += char('a' + (f & 7)); s += char('1' + (f >> 3)); }
            }
            if (cap) s += 'x';
        }
        s += char('a' + (t & 7));
        s += char('1' + (t >> 3));
        if (mPromo(m)) { s += '='; s += letters[mPromo(m)]; }
    }
    b.makeMove(m);
    if (b.inCheck()) {
        Move mv[256];
        s += b.genLegal(mv) == 0 ? "#" : "+";
    }
    b.unmakeMove();
    return s;
}

static std::string norm(const std::string& in) {
    std::string r;
    for (char c : in)
        if (c != 'x' && c != 'X' && c != '=' && c != '+' && c != '#' && c != '!' && c != '?' && c != ' ' && c != ':') r += c;
    return r;
}

Move parseSan(Board& b, const std::string& san) {
    std::string in = san;
    for (size_t p; (p = in.find("0-0-0")) != std::string::npos;) in.replace(p, 5, "O-O-O");
    for (size_t p; (p = in.find("0-0")) != std::string::npos;) in.replace(p, 3, "O-O");
    const std::string key = norm(in);
    if (key.empty()) return MOVE_NONE;
    Move mv[256];
    int n = b.genLegal(mv);
    for (int i = 0; i < n; i++)
        if (norm(moveToSan(b, mv[i])) == key) return mv[i];
    return MOVE_NONE;
}

} // namespace joro
