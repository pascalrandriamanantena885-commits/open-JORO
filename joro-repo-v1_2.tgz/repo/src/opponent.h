// JORO - opponent.h : who JORO trains against, game after game (header only, no UCI here).
//
//   SELF    JORO vs JORO (the usual self-play)
//   LADDER  Stockfish limited with UCI_Elo; the level goes up when JORO has beaten it `need` times out of the last
//           `window` games at that level (default 3 of 3)
//   MAX     Stockfish at full strength
// The three are mixed with percentage weights. The ladder level can be saved between runs.
#pragma once
#include <cstdio>
#include <cstdlib>
#include <deque>
#include <random>
#include <sstream>
#include <string>
#include <vector>

namespace joro {

struct OpponentSpec {
    enum Kind { SELF, LADDER, MAX } kind = SELF;
    int elo = 0;                 // LADDER: UCI_Elo
    int levelIdx = 0;            // LADDER: index in the ladder
    std::string label = "JORO";
};

class OpponentPlan {
public:
    int wSelf = 100, wLadder = 0, wMax = 0;   // weights (any positive numbers, used as proportions)
    std::vector<int> levels{1320, 1500, 1700, 1900, 2100, 2300, 2500, 2700, 2900, 3190};
    int need = 3, window = 3;                  // promote after `need` wins in the last `window` ladder games
    int level = 0;                             // current ladder index

    explicit OpponentPlan(unsigned seed = 0) : rng(seed ? seed : std::random_device{}()) {}

    // "self=20,ladder=60,max=20"
    bool parseMix(const std::string& s) {
        wSelf = wLadder = wMax = 0;
        std::stringstream ss(s);
        std::string tok;
        while (std::getline(ss, tok, ',')) {
            size_t eq = tok.find('=');
            if (eq == std::string::npos) return false;
            std::string k = tok.substr(0, eq);
            int v = atoi(tok.c_str() + eq + 1);
            if (v < 0) return false;
            if (k == "self") wSelf = v; else if (k == "ladder") wLadder = v; else if (k == "max") wMax = v; else return false;
        }
        return wSelf + wLadder + wMax > 0;
    }
    bool parseLevels(const std::string& s) {
        std::vector<int> v;
        std::stringstream ss(s);
        std::string tok;
        while (std::getline(ss, tok, ',')) { int x = atoi(tok.c_str()); if (x <= 0) return false; v.push_back(x); }
        if (v.empty()) return false;
        levels = v;
        level = 0;
        return true;
    }
    // keep only the levels the engine accepts (UCI_Elo min/max read from its options)
    void clampLevels(int lo, int hi) {
        for (int& l : levels) l = l < lo ? lo : (l > hi ? hi : l);
        std::vector<int> u;
        for (int l : levels) if (u.empty() || u.back() != l) u.push_back(l);
        levels = u;
        if (level >= (int)levels.size()) level = (int)levels.size() - 1;
    }

    OpponentSpec next() {
        OpponentSpec sp;
        int total = wSelf + wLadder + wMax;
        int r = std::uniform_int_distribution<int>(0, total - 1)(rng);
        if (r < wSelf) return sp;
        if (r < wSelf + wLadder) {
            sp.kind = OpponentSpec::LADDER;
            sp.levelIdx = level;
            sp.elo = levels[level];
            sp.label = "Stockfish " + std::to_string(sp.elo);
            return sp;
        }
        sp.kind = OpponentSpec::MAX;
        sp.label = "Stockfish max";
        return sp;
    }

    // score of JORO in the game just played (1 win, 0.5 draw, 0 loss). Returns true when the ladder moved up.
    bool report(const OpponentSpec& sp, double joroScore) {
        if (sp.kind != OpponentSpec::LADDER || sp.levelIdx != level) return false;   // a stale game of another level
        recent.push_back(joroScore >= 1.0 ? 1 : 0);
        while ((int)recent.size() > window) recent.pop_front();
        int wins = 0;
        for (int x : recent) wins += x;
        if ((int)recent.size() >= window && wins >= need && level + 1 < (int)levels.size()) {
            level++;
            recent.clear();
            return true;
        }
        return false;
    }
    int ladderGames() const { return (int)recent.size(); }

    bool loadLevel(const std::string& path) {
        FILE* f = fopen(path.c_str(), "r");
        if (!f) return false;
        int l = 0;
        bool ok = fscanf(f, "%d", &l) == 1;
        fclose(f);
        if (ok && l >= 0 && l < (int)levels.size()) level = l;
        return ok;
    }
    bool saveLevel(const std::string& path) const {
        FILE* f = fopen(path.c_str(), "w");
        if (!f) return false;
        fprintf(f, "%d\n", level);
        fclose(f);
        return true;
    }

private:
    std::mt19937 rng;
    std::deque<int> recent;
};

} // namespace joro
