// JORO - appapi.h : everything the Android app needs for the board and the TRAINING, as plain C++ (no JNI, no UCI).
// native_jni.cpp only wraps these functions. Moves travel as ints (the engine's own move encoding).
#pragma once
#include "trainer.h"
#include "opponent.h"
#include "opstats.h"
#include <functional>
#include <string>
#include <vector>

namespace joro { namespace app {

// "64 chars (a1..h8, FEN letters, '.' = empty)|w or b|status" status: 0 ok, 1 check, 2 checkmate, 3 stalemate; "ERR" if invalid
std::string boardInfo(const std::vector<int>& moves);
std::vector<int> legalMoves(const std::vector<int>& moves);
std::string sanLine(const std::vector<int>& moves);                 // "1. e4 e5 2. Nf3 Nc6"
bool parseSanLine(const std::string& text, std::vector<int>& out);  // "1.e4 e5 2.Nf3" -> moves

// Calibration games only: the engines speak UCI, so the game record arrives as UCI text; the PGN needs SAN.
std::string sanFromUci(const std::string& fen, const std::string& uciMoves);

struct TrainHandle {
    Experience exp;
    TrainConfig cfg;
    Trainer* trainer = nullptr;
    TrainSession sess;
    std::vector<Move> opening;
    std::string path;
    std::string startFen;      // start position of this training (set by setStartFen before trainCreate)
    std::string label;         // name of the opening (PGN event, per-opening table)
    OpeningAcc* acc = nullptr; // per-opening statistics of this run
    OpponentSpec curSpec;      // opponent of the game being played (mixed mode)
    std::string lastOpponent;  // label of the opponent of the last finished game
    ~TrainHandle() { delete trainer; delete acc; }
};

// Loads (or creates) the experience file and prepares the training of one opening. nullptr on error.
// varyFirstPct: chance (percent) that JORO's first move after the opening is its 2nd best. label: name of the opening.
TrainHandle* trainCreate(const std::vector<int>& moves, const std::string& expPath, int depth, int depthStrong, int msWeak, int msStrong, int maxGames,
                         int stable, int confirm, bool drawFail, int hashMb, double varyFirstPct, const std::string& label, std::string* err);
// One game. Returns {status, result, plies, newBad, newGood, entries, W, B, D, games, reasonCode, exhausted,
//                    streakSide, streakLen, stable, brilliantThisGame,
//                    joroSide (-1 = JORO vs JORO, 0/1 = colour of JORO vs an engine), mateLineNew, brilliantMarks, greatMarks,
//                    variedPly (-1 = none), opponentElo (0 = none / full strength), ladderMoved (1 = the ladder went up)}; status: 0 go on, 1 finished, 2 stopped, -1 error.
std::vector<int> trainStep(TrainHandle* h);
void trainStop(TrainHandle* h);
// Start position used by the board helpers and by the NEXT trainCreate (empty = the standard start). Endgame etudes use it.
void setStartFen(const std::string& fen);
// A/B gate: candidate experience file vs base file. openingsFlat = moves of each start separated by -1 (startpos only).
// Returns {wins, draws, losses} of the candidate, or {} on error. gateStop() aborts a running gate.
std::vector<int> gateRun(const std::string& basePath, const std::string& candPath, const std::vector<int>& openingsFlat,
                         int gamesPerStart, int movetimeMs);
void gateStop(bool stop);
// JORO vs an external engine: joroSide 0 = white, 1 = black; fn(startFen, moves so far) returns the engine's move.
void trainSetOpponent(TrainHandle* h, int joroSide, std::function<int(const std::string&, const std::vector<int>&)> fn);
// ---- a RUN = all the openings of one press on "Hanomboka": opponents, PGN and the per-opening table are shared by them.
// Mixed opponents (needs trainSetMix on every handle): weights of JORO itself / Stockfish ladder / Stockfish full strength.
void runBegin(const std::string& statsPath, const std::string& pgnPrefix, int pgnSplit, int wSelf, int wLadder, int wMax,
              int ladderNeed, int ladderWindow, const std::string& ladderFile, bool ladderReset);
// Writes the table to the CSV and returns it as text (with the per-opponent summary); "" if nothing was played.
std::string runEnd();
// engineFn(fen, moves) = the external engine's move; prepareFn(elo) puts the engine at that UCI_Elo (0 = full strength), false = engine dead.
void trainSetMix(TrainHandle* h, std::function<int(const std::string&, const std::vector<int>&)> engineFn, std::function<bool(int)> prepareFn);
std::string trainLastOpponent(TrainHandle* h);
void trainFinish(TrainHandle* h);                      // call after the last step of an opening (before trainDestroy)
void trainPause(TrainHandle* h, bool paused);          // thread-safe; the game sleeps at the next move
bool trainWaiting(TrainHandle* h);                     // true once it really sleeps
std::vector<int> trainLive(TrainHandle* h);            // moves of the game being played (opening + moves so far)
void trainDestroy(TrainHandle* h);

}} // namespace joro::app
