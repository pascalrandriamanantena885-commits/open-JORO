// JORO - pgn.cpp
#include "pgn.h"
#include "san.h"
#include <cstdio>
#include <cstdlib>
#include <ctime>

namespace joro {

static std::string evalTag(int mover, int score) {   // score: mover point of view -> "[%eval 0.35]" / "[%eval #3]"
    int w = mover == WHITE ? score : -score;
    char buf[32];
    if (std::abs(score) >= MATE_BOUND) {
        int plies = MATE - std::abs(score);
        int m = (plies + 1) / 2;
        snprintf(buf, sizeof buf, "[%%eval #%s%d]", w < 0 ? "-" : "", m);
    } else {
        snprintf(buf, sizeof buf, "[%%eval %.2f]", w / 100.0);
    }
    return buf;
}

std::string gameToPgn(const GameRecord& rec, const std::string& event, int round, const std::string& date) {
    std::string white = "JORO", black = "JORO";
    if (rec.joroSide == WHITE) black = rec.opponent;
    else if (rec.joroSide == BLACK) white = rec.opponent;
    const char* res = rec.result == 1 ? "1-0" : (rec.result == -1 ? "0-1" : "1/2-1/2");
    std::string term = rec.reason;
    std::string out;
    auto tag = [&](const char* k, const std::string& v) { out += std::string("[") + k + " \"" + v + "\"]\n"; };
    tag("Event", event);
    tag("Site", "JORO trainer");
    tag("Date", date);
    tag("Round", std::to_string(round));
    tag("White", white);
    tag("Black", black);
    tag("Result", res);
    tag("Opponent", rec.opponent);
    tag("Termination", term);
    if (rec.rootFen != START_FEN) { tag("SetUp", "1"); tag("FEN", rec.rootFen); }
    out += "\n";

    Board b;
    b.setFen(rec.rootFen);
    std::string text;
    bool needNum = true;
    auto push = [&](const std::string& tok) { text += tok; text += ' '; };
    auto emit = [&](Move m, int mark, const std::string& comment) {
        std::string t;
        if (b.side == WHITE) t = std::to_string(b.fullmove) + ". ";
        else if (needNum) t = std::to_string(b.fullmove) + "... ";
        t += moveToSan(b, m);
        if (mark == MK_BRILLIANT) t += "!!"; else if (mark == MK_GREAT) t += "!";
        else if (mark == MK_BAD) t += "?"; else if (mark == MK_BLUNDER) t += "??";
        push(t);
        needNum = false;
        b.makeMove(m);
        if (!comment.empty()) { push("{" + comment + "}"); needNum = true; }
    };
    for (size_t i = 0; i < rec.opening.size(); i++)
        emit(rec.opening[i], MK_NONE, i + 1 == rec.opening.size() ? "opening end" : "");
    for (size_t i = 0; i < rec.moves.size(); i++) {
        const int mark = i < rec.marks.size() ? rec.marks[i] : MK_NONE;
        std::string c;
        if (rec.scores[i] != NO_SCORE) c = evalTag(rec.movers[i], rec.scores[i]);
        else if (rec.joroSide < 0 || rec.movers[i] == rec.joroSide) c = "from experience";   // (the engine's own moves carry no comment)
        const char* what = nullptr;
        if (mark == MK_BRILLIANT) what = "brilliant";
        else if (mark == MK_GREAT) what = "great";
        else if (mark == MK_BAD) what = "bad: stored as BAD in the experience";
        else if (mark == MK_BLUNDER) what = "blunder: stored as BAD in the experience";
        if (what) c += std::string(c.empty() ? "" : " ") + what;
        if ((int)i == rec.variedPly) c += std::string(c.empty() ? "" : " ") + "varied first move";
        emit(rec.moves[i], mark, c);
    }
    text += res;
    // wrap at 80 columns
    size_t lineStart = 0, lastSpace = std::string::npos;
    for (size_t i = 0; i < text.size(); i++) {
        if (text[i] == ' ') lastSpace = i;
        if (i - lineStart >= 80 && lastSpace != std::string::npos && lastSpace > lineStart) {
            text[lastSpace] = '\n';
            lineStart = lastSpace + 1;
            lastSpace = std::string::npos;
        }
    }
    return out + text + "\n\n";
}

PgnWriter::PgnWriter(const std::string& p, int split) : prefix(p), splitEvery(split) {}

std::string PgnWriter::pathFor(int n) const {
    char buf[32];
    snprintf(buf, sizeof buf, "_%04d.pgn", n);
    return prefix + buf;
}

bool PgnWriter::add(const GameRecord& rec, const std::string& event) {
    if (cur.empty() || (splitEvery > 0 && inFile >= splitEvery)) {
        fileNo++;
        cur = pathFor(fileNo);
        while (true) {                       // never overwrite: skip numbers that already exist
            FILE* t = fopen(cur.c_str(), "rb");
            if (!t) break;
            fclose(t);
            fileNo++;
            cur = pathFor(fileNo);
        }
        inFile = 0;
        fileCount++;
    }
    char date[16];
    time_t now = time(nullptr);
    strftime(date, sizeof date, "%Y.%m.%d", localtime(&now));
    FILE* f = fopen(cur.c_str(), "ab");
    if (!f) return false;
    std::string s = gameToPgn(rec, event, total + 1, date);
    bool ok = fwrite(s.data(), 1, s.size(), f) == s.size();
    fclose(f);
    inFile++;
    total++;
    return ok;
}

} // namespace joro
