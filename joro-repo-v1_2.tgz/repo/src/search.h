// JORO - search.h : alpha-beta search + experience-aware root
#pragma once
#include "board.h"
#include "eval.h"
#include "experience.h"
#include <atomic>
#include <chrono>
#include <utility>
#include <vector>

namespace joro {

const int MAXPLY = 128, INF_SCORE = 32000, MATE = 31000, MATE_BOUND = MATE - MAXPLY;

struct Limits {
    int depth = 0;           // 0 = no depth limit
    int64_t movetime = 0;    // ms
    int64_t time[2] = {0, 0};
    int64_t inc[2] = {0, 0};
    int movestogo = 0;
    int64_t nodes = 0;
    bool infinite = false;
};

struct SearchResult {
    Move best = MOVE_NONE;
    Move ponder = MOVE_NONE;
    int score = 0;
    int depth = 0;
    int64_t nodes = 0;
    bool fromExperience = false;
    // Variation Brain report
    int brainRejected = 0;                                     // candidate moves refused because of a dangerous variation
    std::vector<std::pair<U64, Move>> mateTraps;               // (position key, move) refused because it allows a forced mate
};

struct TTEntry { U64 key; Move move; int16_t score; int8_t depth; uint8_t bound; };

class Searcher {
public:
    Style style;
    bool useExperience = true;
    bool strictStyle = true;   // experience made with another style is ignored
    Move excluded = MOVE_NONE; // root move left out of the search (verification of brilliant moves)
    bool quiet = false;        // true = no "info" output (trainer / JNI)
    int moveOverhead = 30;     // ms
    // ---- Variation Brain: after the search, the chosen move is checked by a forcing-line analysis (opponent plays only
    // checks / captures / promotions, we answer with everything). A move that allows a forced mate, a lost piece, a
    // promotion, or a stalemate / draw while we are clearly better is refused and the search is redone without it.
    bool brain = true;
    int brainNodes = 30000;    // node budget of one analysis
    int brainTries = 3;        // candidates examined at most
    int brainLoss = 300;       // cp: material the opponent must win by force for the move to be refused
    int brainSacrificeOK = 150; // cp: a material "loss" is accepted when the search itself says we are this much better
    std::atomic<bool> stopFlag;

    Searcher();
    void setHash(int mb);
    void clear();
    void setExperience(const Experience* e) { exp = e; }

    // Caller must set stopFlag=false before calling.
    SearchResult go(Board& board, const Limits& lim);

private:
    Board* b = nullptr;
    const Experience* exp = nullptr;
    std::vector<TTEntry> tt;
    size_t ttMask = 0;
    Move killers[MAXPLY][2];
    int history[2][64][64];
    Move pv[MAXPLY][MAXPLY];
    int pvLen[MAXPLY];
    std::vector<Move> rootMoves;
    Limits lim;
    int64_t nodes = 0, softMs = 0, hardMs = 0;
    std::chrono::steady_clock::time_point t0;
    bool halt = false, canStop = false, warnedStyle = false;

    int64_t elapsedMs() const;
    void checkTime();
    int search(int depth, int alpha, int beta, int ply, bool nullOk);
    int qsearch(int alpha, int beta, int ply);
    int drawScore(int ply) const { return (ply & 1) ? style.contempt() : -style.contempt(); }
    int scoreMove(Move m, Move ttMove, int ply) const;
    bool hasNonPawn(int c) const;
    SearchResult iterate(int maxDepth, SearchResult res);
    // Variation Brain internals (masks: 1 mate, 2 draw/stalemate, 4 material, 8 promotion)
    std::vector<Move> banned;
    int64_t brainUsed = 0;
    int brainUs = 0, brainT = 0, brainDrawVal = 0;
    int matDiff() const;
    int brainOppWins(int d);
    int brainUsLoses(int d);
    int dangerOf(Move cand, int candScore, int m0);
};

} // namespace joro
