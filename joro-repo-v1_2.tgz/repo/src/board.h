// JORO - board.h : position, move generation, make/unmake
#pragma once
#include "types.h"
#include <string>
#include <vector>

namespace joro {

extern const char* START_FEN;
void initTables();  // idempotent

extern int knightN[64], knightTo[64][8], kingN[64], kingTo[64][8];
extern U64 zPiece[16][64], zSide, zCastle[16], zEp[8];

struct Undo { Move move; int captured; int castling; int ep; int halfmove; U64 hash; };

class Board {
public:
    int sq[64];
    int side = WHITE, castling = 0, ep = -1, halfmove = 0, fullmove = 1;
    int kingSq[2] = {-1, -1};
    U64 hash = 0;
    std::vector<Undo> hist;

    Board();
    bool setFen(const std::string& fen);
    std::string fen() const;
    U64 computeHash() const;

    bool attacked(int s, int by) const;
    bool inCheck() const { return attacked(kingSq[side], side ^ 1); }

    int genMoves(Move* out, bool capsOnly = false) const;  // pseudo-legal
    int genLegal(Move* out);                               // legal only

    void makeMove(Move m);
    void unmakeMove();
    bool makeLegal(Move m);  // make; if illegal, unmake and return false
    void makeNull();
    void unmakeNull();

    bool isRepetition() const;
    bool isDraw() const { return halfmove >= 100 || isRepetition(); }

    Move parseMove(const std::string& s);
    static std::string moveToStr(Move m);
    U64 perft(int depth);
};

} // namespace joro
