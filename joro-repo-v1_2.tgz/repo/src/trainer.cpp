// JORO - trainer.cpp
#include "trainer.h"
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <random>
#include <thread>

namespace joro {

static bool insufficientMaterial(const Board& b) {
    int minors = 0;
    for (int s = 0; s < 64; s++) {
        int t = typeOf(b.sq[s]);
        if (t == PAWN || t == ROOK || t == QUEEN) return false;
        if (t == KNIGHT || t == BISHOP) minors++;
    }
    return minors <= 1;
}

Trainer::Trainer(Experience& e, const TrainConfig& c) : exp(e), cfg(c), stopped(false), rng(c.seed ? c.seed : std::random_device{}()) {
    sv.quiet = true;
    sv.style = cfg.style;
    sv.setHash(8);
    sv.useExperience = false;   // the verification must judge the position, not the memory
    for (Searcher* s : {&sw, &sb}) {
        s->quiet = true;
        s->style = cfg.style;
        s->setHash(cfg.hashMB);
        s->setExperience(&exp);
        s->useExperience = true;
        s->brain = cfg.brain;
    }
    sv.brain = false;
}

void Trainer::stop() {
    stopped = true;
    sw.stopFlag = true;
    sb.stopFlag = true;
}

bool Trainer::playGame(const std::string& startFen, const std::vector<std::string>& opening, GameRecord& rec,
                       std::string* err) {
    Board b;
    if (!b.setFen(startFen)) { if (err) *err = "bad FEN"; return false; }
    std::vector<Move> mv;
    for (auto& s : opening) {
        Move m = b.parseMove(s);
        if (m == MOVE_NONE) { if (err) *err = "illegal opening move " + s; return false; }
        b.makeMove(m);
        mv.push_back(m);
    }
    return playGame(startFen, mv, rec, err);
}

bool Trainer::playGame(const std::string& startFen, const std::vector<Move>& opening, GameRecord& rec,
                       std::string* err) {
    Board b;
    if (!b.setFen(startFen)) { if (err) *err = "bad FEN"; return false; }
    for (Move m : opening) {
        Move mv[256];
        int n = b.genLegal(mv);
        bool ok = false;
        for (int i = 0; i < n; i++) if (mv[i] == m) { ok = true; break; }
        if (!ok) { if (err) *err = "illegal opening move"; return false; }
        b.makeMove(m);
    }
    rec = GameRecord();
    rec.startFen = b.fen();
    rec.rootFen = startFen;
    rec.opening = opening;
    if (beforeGame) rec.opponent = beforeGame(gameIdx);   // may switch the opponent (setOpponent) for this game
    rec.joroSide = opp ? joroSide_ : -1;
    const bool alt = cfg.depthStrong > 0 || cfg.moveTimeStrong > 0;
    rec.strongSide = !alt ? -1 : opp ? (joroSide_ ^ 1) : ((gameIdx & 1) ? BLACK : WHITE);   // vs an engine: the engine is the strong one
    gameIdx++;
    { std::lock_guard<std::mutex> g(liveMu); live = opening; }
    sw.clear();
    sb.clear();  // fresh tables => a replayed game is identical until the first experience change
    Searcher* ss[2] = {&sw, &sb};
    std::vector<Move> played = opening;   // opening + every move so far (the external opponent needs the whole game)
    int streak = 0, streakSign = 0;
    bool firstDone[2] = {false, false};   // has this side already made its first searched move?
    for (int ply = 0;; ply++) {
        Move mv[256];
        int nl = b.genLegal(mv);
        if (nl == 0) {
            if (b.inCheck()) { rec.result = b.side == WHITE ? -1 : 1; rec.reason = "checkmate"; }
            else { rec.result = 0; rec.reason = "stalemate"; }
            break;
        }
        if (b.halfmove >= 100) { rec.result = 0; rec.reason = "50-move"; break; }
        int reps = 1;
        for (auto& u : b.hist) if (u.hash == b.hash) reps++;
        if (reps >= 3) { rec.result = 0; rec.reason = "repetition"; break; }
        if (insufficientMaterial(b)) { rec.result = 0; rec.reason = "insufficient material"; break; }
        if (ply >= cfg.maxPlies) { rec.result = 0; rec.reason = "max plies"; break; }
        if (stopped) return false;
        if (paused) {                                   // sleep until resumed or stopped
            waiting = true;
            while (paused && !stopped) std::this_thread::sleep_for(std::chrono::milliseconds(150));
            waiting = false;
            if (stopped) return false;
        }

        if (opp && b.side != joroSide_) {              // the external engine (Stockfish) moves
            Move om = opp(startFen, played);
            if (stopped) return false;
            bool ok = false;
            for (int i = 0; i < nl; i++) if (mv[i] == om) { ok = true; break; }
            if (!ok) { if (err) *err = "opponent engine gave no legal move"; return false; }
            rec.keys.push_back(b.hash);
            rec.moves.push_back(om);
            rec.movers.push_back(b.side);
            rec.scores.push_back(NO_SCORE);
            b.makeMove(om);
            played.push_back(om);
            { std::lock_guard<std::mutex> g(liveMu); live.push_back(om); }
            continue;
        }

        Searcher& s = *ss[b.side];
        s.stopFlag = false;
        Limits lim;
        const bool strong = alt && (opp ? b.side == joroSide_ : b.side == rec.strongSide);   // JORO itself uses its full strength vs an engine
        lim.depth = (strong && cfg.depthStrong > 0) ? cfg.depthStrong : cfg.depth;
        const int mt = strong ? cfg.moveTimeStrong : cfg.moveTimeWeak;
        if (mt > 0) { lim.movetime = mt; lim.depth = 0; }
        SearchResult r = s.go(b, lim);
        if (stopped) return false;
        if (!firstDone[b.side]) {                       // variety: sometimes the 2nd best first move
            firstDone[b.side] = true;
            std::uniform_real_distribution<double> u(0.0, 100.0);
            if (cfg.varyFirstPct > 0 && nl > 1 && !r.fromExperience && u(rng) < cfg.varyFirstPct) {
                s.excluded = r.best;
                s.stopFlag = false;
                s.clear();
                SearchResult r2 = s.go(b, lim);
                s.excluded = MOVE_NONE;
                if (stopped) return false;
                if (r2.best != MOVE_NONE && !r2.fromExperience && r2.score >= r.score - cfg.varyMaxLoss) {
                    r = r2;
                    rec.variedPly = (int)rec.moves.size();
                }
            }
        }
        for (auto& mt : r.mateTraps) exp.add(mt.first, mt.second, EXP_BAD, 0, 1);   // proven forced mate against us: remembered
        rec.keys.push_back(b.hash);
        rec.moves.push_back(r.best);
        rec.movers.push_back(b.side);
        rec.scores.push_back(r.fromExperience ? NO_SCORE : r.score);
        if (cfg.adjudicate && !r.fromExperience) {
            int w = b.side == WHITE ? r.score : -r.score;  // white point of view
            if (std::abs(w) >= 900) {
                int sg = w > 0 ? 1 : -1;
                streak = (sg == streakSign) ? streak + 1 : 1;
                streakSign = sg;
            } else { streak = 0; streakSign = 0; }
            if (streak >= 6) { rec.result = streakSign; rec.reason = "adjudicated"; break; }
        }
        b.makeMove(r.best);
        played.push_back(r.best);
        { std::lock_guard<std::mutex> g(liveMu); live.push_back(r.best); }
    }
    rec.marks.assign(rec.moves.size(), MK_NONE);
    return true;
}

std::vector<Move> Trainer::liveMoves() const {
    std::lock_guard<std::mutex> g(liveMu);
    return live;
}

static int clampScore(int s) { return std::max(-1000, std::min(1000, s)); }

// Backtracking : walk back over the decisions of the failing side, find the critical move.
void Trainer::blame(GameRecord& rec, int side, int resultForSide, int& newBad, int& exhausted) {
    const size_t n = rec.moves.size();
    std::vector<int> untried(n, 0);
    std::vector<size_t> dec;  // decision indices of this side
    Board b;
    b.setFen(rec.startFen);
    for (size_t i = 0; i < n; i++) {
        if (rec.movers[i] == side) {
            Move mv[256];
            int nl = b.genLegal(mv), u = 0;
            for (int k = 0; k < nl; k++)
                if (mv[k] != rec.moves[i] && !exp.isBad(rec.keys[i], mv[k])) u++;
            untried[i] = u;
            dec.push_back(i);
        }
        b.makeMove(rec.moves[i]);
    }
    int terminal = resultForSide < 0 ? -1000 : 0;
    int bestJ = -1, bestDrop = -100000, lastJ = -1;
    std::vector<int> drop(dec.size(), 0);
    for (size_t j = 0; j < dec.size(); j++) {
        int e0 = rec.scores[dec[j]];
        int e1 = (j + 1 < dec.size()) ? rec.scores[dec[j + 1]] : terminal;
        drop[j] = (e0 == NO_SCORE || e1 == NO_SCORE) ? 0 : clampScore(e0) - clampScore(e1);
        if (untried[dec[j]] > 0) {
            lastJ = (int)j;
            if (drop[j] > bestDrop) { bestDrop = drop[j]; bestJ = (int)j; }
        }
    }
    int pick = (bestJ >= 0 && bestDrop >= cfg.blameThreshold) ? bestJ : lastJ;  // else: plain backtrack
    if (pick < 0) { exhausted++; return; }  // nothing left to vary for this side
    size_t i = dec[pick];
    int inc = exp.goodCount(rec.keys[i], rec.moves[i]) + 1;  // must outweigh an old "good" mark
    bool had = exp.badCount(rec.keys[i], rec.moves[i]) > 0;
    exp.add(rec.keys[i], rec.moves[i], EXP_BAD, -std::max(0, drop[pick]), inc);
    if (!had) newBad++;
    if (i < rec.marks.size()) rec.marks[i] = drop[pick] >= 300 ? MK_BLUNDER : MK_BAD;
}

static int materialOf(const Board& b, int c) {
    int m = 0;
    for (int s = 0; s < 64; s++) {
        int p = b.sq[s];
        if (p && colorOf(p) == c && typeOf(p) != KING) m += PIECE_VAL[typeOf(p)];
    }
    return m;
}

// A game won by CHECKMATE: every move of the winner is a move of a mating variation, whatever its length. Moves that
// win material but never end in mate are NOT kept; a sacrifice that ends in mate is. The quality stored with each move
// is "how fast is the mate from here" plus a bonus for forcing play (checks, sacrifices), so that when several mating
// lines exist for a position the fastest, most forcing / aggressive one is the one that gets played from memory.
void Trainer::storeMatingLine(GameRecord& rec, int side, int& newGood) {
    const size_t n = rec.moves.size();
    std::vector<size_t> dec;                 // indices of the winner's moves
    std::vector<int> mat;                    // material balance (winner - loser) before each of them
    std::vector<char> forcing;               // gave check
    Board b;
    b.setFen(rec.startFen);
    for (size_t i = 0; i < n; i++) {
        if (rec.movers[i] == side) {
            dec.push_back(i);
            mat.push_back(materialOf(b, side) - materialOf(b, side ^ 1));
        }
        b.makeMove(rec.moves[i]);
        if (rec.movers[i] == side) forcing.push_back(b.inCheck() ? 1 : 0);
    }
    const size_t k = dec.size();
    std::vector<int> force(k + 1, 0);        // forcing moves from decision j to the end (checks + sacrifices)
    for (size_t j = k; j-- > 0;) {
        bool sac = j + 1 < k && mat[j] - mat[j + 1] >= 200;
        force[j] = force[j + 1] + ((forcing[j] || sac) ? 1 : 0);
    }
    for (size_t j = 0; j < k; j++) {
        const size_t i = dec[j];
        int plies = (int)(n - i);                                   // plies until the mate, this move included
        int value = Experience::MATE_LINE_BASE - std::min(plies, 255) * 8 + std::min(force[j], 7);
        if (rec.strongSide == (side ^ 1)) value += 50;      // won against the deeper-thinking defender: more reliable
        bool had = exp.goodCount(rec.keys[i], rec.moves[i]) > 0;
        exp.addLine(rec.keys[i], rec.moves[i], value);
        if (!had) { newGood++; rec.mateLineNew++; }
        // a sacrifice that leads to the mate within 15 moves is brilliant (a sacrifice far from the mate is not marked)
        const bool sac = j + 1 < k && mat[j] - mat[j + 1] >= 200 && plies <= 30;
        if (sac && i < rec.marks.size()) rec.marks[i] = MK_BRILLIANT;
    }
}

// A winner's move is kept only if it is VERIFIED by a deeper search (depth+1, the move excluded):
//  * BRILLIANT: gives up material (>= 2 pawns over the exchange) without the evaluation falling, or starts a
//    forced mate, and beats every alternative by cfg.brilliantMargin cp;
//  * GREAT: no sacrifice needed, the position is not already decided, and the move beats every alternative by
//    cfg.greatMargin cp (a clearly best move, not just one of several good ones).
// Ordinary winning moves are not stored - the search finds them again anyway.
void Trainer::findBrilliant(GameRecord& rec, int side, int& newGood) {
    const size_t n = rec.moves.size();
    std::vector<size_t> dec;
    std::vector<int> mat;
    std::vector<std::string> fens;
    Board b;
    b.setFen(rec.startFen);
    for (size_t i = 0; i < n; i++) {
        if (rec.movers[i] == side) {
            dec.push_back(i);
            mat.push_back(materialOf(b, side) - materialOf(b, side ^ 1));
            fens.push_back(b.fen());
        }
        b.makeMove(rec.moves[i]);
    }
    struct Cand { size_t j; bool brilliant; int gain; };
    std::vector<Cand> cands;
    for (size_t j = 0; j + 1 < dec.size(); j++) {
        const size_t i = dec[j];
        const int sc0 = rec.scores[i], sc1 = rec.scores[dec[j + 1]];
        if (sc0 == NO_SCORE || sc1 == NO_SCORE) continue;                // played from experience: no evidence
        const int lost = mat[j] - mat[j + 1];                              // material given up over the exchange
        const bool sacrifice = lost >= 200 && sc1 >= sc0 - 60 && sc0 >= -50;
        const bool mateStart = sc0 >= MATE_BOUND && (j == 0 || rec.scores[dec[j - 1]] < MATE_BOUND);
        if (sacrifice || mateStart) cands.push_back({j, true, 0});
        else if (cfg.great && sc0 >= -50 && sc0 < 600 && sc1 >= sc0 - 30) cands.push_back({j, false, sc1 - sc0});
    }
    // great candidates: only the most promising ones are verified (each costs a depth+1 search)
    std::vector<Cand> chosen, great;
    for (auto& c : cands) (c.brilliant ? chosen : great).push_back(c);
    std::sort(great.begin(), great.end(), [](const Cand& a, const Cand& b) { return a.gain > b.gain; });
    if ((int)great.size() > cfg.greatMaxPerGame) great.resize(cfg.greatMaxPerGame);
    chosen.insert(chosen.end(), great.begin(), great.end());
    for (auto& c : chosen) {
        if (stopped) break;
        const size_t j = c.j, i = dec[j];
        Board vb;
        if (!vb.setFen(fens[j])) continue;
        sv.clear();
        sv.excluded = rec.moves[i];
        sv.stopFlag = false;
        Limits lim;
        lim.depth = std::max(cfg.depth, cfg.depthStrong) + 1;
        SearchResult alt = sv.go(vb, lim);
        sv.excluded = MOVE_NONE;
        if (alt.best == MOVE_NONE) continue;                               // it was the only legal move: not exceptional
        int played = clampScore(rec.scores[i]), other = clampScore(alt.score);
        const int need = c.brilliant ? cfg.brilliantMargin : cfg.greatMargin;
        if (played - other < need) continue;                               // an alternative is nearly as good
        bool had = exp.goodCount(rec.keys[i], rec.moves[i]) > 0;
        exp.add(rec.keys[i], rec.moves[i], EXP_GOOD, played, 1);
        if (i < rec.marks.size()) rec.marks[i] = c.brilliant ? MK_BRILLIANT : MK_GREAT;
        if (!had) newGood++;
    }
}

void Trainer::learn(GameRecord& rec, int& newBad, int& newGood, int& exhausted) {
    for (int side = 0; side < 2; side++) {
        if (opp && side != joroSide_) continue;          // never learn from the external engine's moves
        int rs = rec.result == 0 ? 0 : (((rec.result == 1) == (side == WHITE)) ? 1 : -1);
        if (rs == 1) {
            if (cfg.mateLines && rec.reason == "checkmate") {
                storeMatingLine(rec, side, newGood);   // the whole mating variation, any length
            } else if (cfg.brilliantOnly) {
                findBrilliant(rec, side, newGood);   // only exceptional moves are kept
            } else {
                for (size_t i = 0; i < rec.moves.size(); i++) {
                    if (rec.movers[i] != side) continue;
                    bool had = exp.goodCount(rec.keys[i], rec.moves[i]) > 0;
                    int v = rec.scores[i] == NO_SCORE ? 0 : clampScore(rec.scores[i]);
                    exp.add(rec.keys[i], rec.moves[i], EXP_GOOD, v, 1);
                    if (!had) newGood++;
                }
            }
        } else if (rs == -1 || cfg.drawIsFail) {
            blame(rec, side, rs, newBad, exhausted);
        }
    }
}

bool Trainer::step(const std::string& startFen, const std::vector<Move>& opening, TrainSession& s, GameRecord& rec,
                   int& newBad, int& newGood, std::string* err) {
    if (stopped) return false;
    if (!playGame(startFen, opening, rec, err)) return false;
    size_t before = exp.size();
    int nb = 0, ng = 0, ex = 0;
    learn(rec, nb, ng, ex);
    newBad = nb;
    newGood = ng;
    s.stats.games++;
    s.stats.newBad += nb;
    s.stats.newGood += ng;
    s.stats.exhausted += ex;
    if (rec.result == 1) s.stats.whiteWins++; else if (rec.result == -1) s.stats.blackWins++; else s.stats.draws++;
    s.stable = (exp.size() == before) ? s.stable + 1 : 0;
    if (rec.result != 0 && rec.result == s.streakSide) s.streakLen++;
    else { s.streakSide = rec.result; s.streakLen = rec.result != 0 ? 1 : 0; }
    s.finished = s.stats.games >= cfg.maxGames || s.stable >= cfg.stableLimit ||
                 (cfg.confirmWins > 0 && s.streakLen >= cfg.confirmWins);
    return true;
}

TrainStats Trainer::trainOpening(const std::string& startFen, const std::vector<std::string>& opening,
                                 std::string* err) {
    TrainSession s;
    Board b;
    std::vector<Move> mv;
    b.setFen(startFen);
    for (auto& t : opening) {
        Move m = b.parseMove(t);
        if (m == MOVE_NONE) { if (err) *err = "illegal opening move " + t; return s.stats; }
        b.makeMove(m);
        mv.push_back(m);
    }
    while (!s.finished && !stopped) {
        GameRecord rec;
        int nb = 0, ng = 0;
        if (!step(startFen, mv, s, rec, nb, ng, err)) break;
        if (onGame) onGame(s.stats.games, rec, nb, ng);
    }
    return s.stats;
}

} // namespace joro
