#include "gate.h"

namespace joro {

// +1 white wins, -1 black wins, 0 draw. A decided game (|eval| >= 900 cp for 6 moves) is adjudicated to keep the gate short.
static int playOne(Searcher& white, Searcher& black, const GateStart& st, int movetime, std::atomic<bool>* stop) {
    Board b;
    if (!b.setFen(st.fen)) return 0;
    for (Move m : st.moves) {
        Move mv[256];
        int n = b.genLegal(mv);
        bool ok = false;
        for (int i = 0; i < n; i++) if (mv[i] == m) { ok = true; break; }
        if (!ok) return 0;
        b.makeMove(m);
    }
    white.clear(); black.clear();
    int streak = 0, sign = 0;
    for (int ply = 0; ply < 300; ply++) {
        if (stop && *stop) return 0;
        Move mv[256];
        if (b.genLegal(mv) == 0) return b.inCheck() ? (b.side == WHITE ? -1 : 1) : 0;
        if (b.isDraw()) return 0;
        Searcher& s = b.side == WHITE ? white : black;
        s.stopFlag = false;
        Limits lim;
        lim.movetime = movetime;
        SearchResult r = s.go(b, lim);
        int w = b.side == WHITE ? r.score : -r.score;
        if (std::abs(w) >= 900) { int sg = w > 0 ? 1 : -1; streak = sg == sign ? streak + 1 : 1; sign = sg; }
        else { streak = 0; sign = 0; }
        if (streak >= 6) return sign;
        b.makeMove(r.best);
    }
    return 0;
}

GateResult gateExperience(const Experience& cand, const Experience& base, const std::vector<GateStart>& starts,
                          int gamesPerStart, int movetimeMs, std::atomic<bool>* stop) {
    GateResult res;
    Searcher A, B;
    A.quiet = B.quiet = true;
    Style st;
    if (base.hasStyle()) base.getStyle(st);
    else if (cand.hasStyle()) cand.getStyle(st);
    A.style = B.style = st;
    A.setHash(16); B.setHash(16);
    A.setExperience(&cand);
    B.setExperience(&base);
    A.useExperience = B.useExperience = true;
    for (const GateStart& s : starts) {
        for (int g = 0; g < gamesPerStart; g++) {
            if (stop && *stop) return res;
            int r = (g % 2 == 0) ? playOne(A, B, s, movetimeMs, stop) : -playOne(B, A, s, movetimeMs, stop);
            if (r > 0) res.wins++; else if (r < 0) res.losses++; else res.draws++;
        }
    }
    return res;
}

} // namespace joro
