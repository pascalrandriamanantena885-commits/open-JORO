#include "appapi.h"
#include "gate.h"
#include "pgn.h"
#include "san.h"
#include <atomic>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <map>

namespace joro { namespace app {

static std::string g_startFen;                 // empty = START_FEN
static std::atomic<bool> g_gateStop{false};
static const char* startFenC() { return g_startFen.empty() ? START_FEN : g_startFen.c_str(); }
void setStartFen(const std::string& fen) { g_startFen = fen; }
void gateStop(bool s) { g_gateStop = s; }

static bool replay(Board& b, const std::vector<int>& moves) {
    if (!b.setFen(startFenC())) return false;
    for (int mi : moves) {
        Move m = (Move)mi, mv[256];
        int n = b.genLegal(mv);
        bool ok = false;
        for (int k = 0; k < n; k++) if (mv[k] == m) { ok = true; break; }
        if (!ok) return false;
        b.makeMove(m);
    }
    return true;
}

std::string boardInfo(const std::vector<int>& moves) {
    Board b;
    if (!replay(b, moves)) return "ERR";
    std::string out(64, '.');
    const char* pc = " pnbrqk";
    for (int s = 0; s < 64; s++) {
        int p = b.sq[s];
        if (!p) continue;
        char c = pc[typeOf(p)];
        out[s] = colorOf(p) == WHITE ? (char)toupper(c) : c;
    }
    Move mv[256];
    int n = b.genLegal(mv);
    int status = n == 0 ? (b.inCheck() ? 2 : 3) : (b.inCheck() ? 1 : 0);
    out += '|';
    out += b.side == WHITE ? 'w' : 'b';
    out += '|';
    out += char('0' + status);
    return out;
}

std::vector<int> legalMoves(const std::vector<int>& moves) {
    Board b;
    std::vector<int> r;
    if (!replay(b, moves)) return r;
    Move mv[256];
    int n = b.genLegal(mv);
    for (int i = 0; i < n; i++) r.push_back((int)mv[i]);
    return r;
}

std::string sanLine(const std::vector<int>& moves) {
    Board b;
    b.setFen(startFenC());
    std::string out;
    for (size_t i = 0; i < moves.size(); i++) {
        Move m = (Move)moves[i];
        if (b.side == WHITE) out += std::to_string(b.fullmove) + ". ";
        else if (i == 0) out += std::to_string(b.fullmove) + "... ";
        out += moveToSan(b, m);
        out += ' ';
        b.makeMove(m);
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    return out;
}

bool parseSanLine(const std::string& text, std::vector<int>& out) {
    out.clear();
    Board b;
    b.setFen(START_FEN);
    std::string tok;
    auto flush = [&]() -> bool {
        if (tok.empty()) return true;
        std::string t = tok;
        tok.clear();
        size_t dot = t.rfind('.');          // "1.e4" or "12..." : drop the move number
        if (dot != std::string::npos) t = t.substr(dot + 1);
        if (t.empty()) return true;
        if (t == "1-0" || t == "0-1" || t == "1/2-1/2" || t == "*") return true;
        Move m = parseSan(b, t);
        if (m == MOVE_NONE) return false;
        out.push_back((int)m);
        b.makeMove(m);
        return true;
    };
    for (char c : text) {
        if (isspace((unsigned char)c)) { if (!flush()) return false; }
        else tok += c;
    }
    return flush();
}

std::string sanFromUci(const std::string& fen, const std::string& uciMoves) {
    Board b;
    if (!b.setFen(fen)) return "";
    std::string out, tok;
    size_t i = 0;
    int shown = 0;
    while (i <= uciMoves.size()) {
        if (i == uciMoves.size() || uciMoves[i] == ' ') {
            if (!tok.empty()) {
                Move m = b.parseMove(tok);
                if (m == MOVE_NONE) break;                  // an illegal move is not part of the record
                if (b.side == WHITE) out += std::to_string(b.fullmove) + ". ";
                else if (shown == 0) out += std::to_string(b.fullmove) + "... ";
                out += moveToSan(b, m) + " ";
                b.makeMove(m);
                shown++;
                tok.clear();
            }
        } else tok += uciMoves[i];
        i++;
    }
    while (!out.empty() && out.back() == ' ') out.pop_back();
    return out;
}

// ------------------------------------------------------------------ training
static int reasonCode(const std::string& r) {
    if (r == "checkmate") return 0;
    if (r == "stalemate") return 1;
    if (r == "50-move") return 2;
    if (r == "repetition") return 3;
    if (r == "insufficient material") return 4;
    if (r == "max plies") return 5;
    if (r == "adjudicated") return 6;
    return 7;
}

static bool fileExists(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb");
    if (!f) return false;
    fclose(f);
    return true;
}

// ---- state of the current run (one training thread: no lock needed)
namespace {
struct OppSum { int games = 0, w = 0, d = 0, l = 0; };
struct RunState {
    bool on = false;
    OpponentPlan* plan = nullptr;
    PgnWriter* pgn = nullptr;
    OpeningStats* stats = nullptr;
    std::vector<OpeningRow> rows;
    std::map<std::string, OppSum> perOpp;
    int runNo = 0, games = 0;
    std::string date, ladderFile;
    void clear() { delete plan; delete pgn; delete stats; plan = nullptr; pgn = nullptr; stats = nullptr; rows.clear(); perOpp.clear(); on = false; games = 0; }
} g_run;
}

void runBegin(const std::string& statsPath, const std::string& pgnPrefix, int pgnSplit, int wSelf, int wLadder, int wMax,
              int ladderNeed, int ladderWindow, const std::string& ladderFile, bool ladderReset) {
    g_run.clear();
    g_run.plan = new OpponentPlan();
    g_run.plan->wSelf = wSelf; g_run.plan->wLadder = wLadder; g_run.plan->wMax = wMax;
    if (wSelf + wLadder + wMax <= 0) g_run.plan->wSelf = 100;
    g_run.plan->need = ladderNeed > 0 ? ladderNeed : 3;
    g_run.plan->window = ladderWindow > 0 ? ladderWindow : 3;
    g_run.plan->clampLevels(1320, 3190);
    g_run.ladderFile = ladderFile;
    if (!ladderReset && !ladderFile.empty()) g_run.plan->loadLevel(ladderFile);
    if (!pgnPrefix.empty()) g_run.pgn = new PgnWriter(pgnPrefix, pgnSplit);
    if (!statsPath.empty()) { g_run.stats = new OpeningStats(statsPath); g_run.stats->load(); g_run.runNo = g_run.stats->nextRun(); }
    char buf[16];
    time_t now = time(nullptr);
    strftime(buf, sizeof buf, "%Y-%m-%d", localtime(&now));
    g_run.date = buf;
    g_run.on = true;
}

std::string runEnd() {
    std::string out;
    if (g_run.on && g_run.stats && !g_run.rows.empty()) {
        out = "Run " + std::to_string(g_run.runNo) + "  (mat: halavany amin'ny hetsika, taloha > ankehitriny)\n" + g_run.stats->table(g_run.rows);
        g_run.stats->append(g_run.rows);
    }
    if (g_run.on && !g_run.perOpp.empty()) {
        out += "\nIsaky ny opponent:\n";
        char buf[160];
        for (auto& kv : g_run.perOpp) {
            const OppSum& o = kv.second;
            if (kv.first == "JORO") snprintf(buf, sizeof buf, "  %-16s %4d lalao  fotsy %d, mainty %d, draw %d\n", kv.first.c_str(), o.games, o.w, o.l, o.d);
            else snprintf(buf, sizeof buf, "  %-16s %4d lalao  JORO +%d =%d -%d (%.0f%%)\n", kv.first.c_str(), o.games, o.w, o.d, o.l,
                          o.games ? 100.0 * (o.w + 0.5 * o.d) / o.games : 0.0);
            out += buf;
        }
        if (g_run.plan && g_run.plan->wLadder > 0) out += "  Ambaratonga ankehitriny: UCI_Elo " + std::to_string(g_run.plan->levels[g_run.plan->level]) + "\n";
    }
    g_run.clear();
    return out;
}

static std::string openingIdOf(const std::string& fen, const std::vector<int>& moves) {
    Board b;
    std::vector<std::string> mv;
    if (b.setFen(fen)) for (int m : moves) { mv.push_back(Board::moveToStr((Move)m)); b.makeMove((Move)m); }
    return openingId(fen, mv);
}

TrainHandle* trainCreate(const std::vector<int>& moves, const std::string& expPath, int depth, int depthStrong, int msWeak, int msStrong, int maxGames,
                         int stable, int confirm, bool drawFail, int hashMb, double varyFirstPct, const std::string& label, std::string* err) {
    initTables();
    Board b;
    if (!replay(b, moves)) { if (err) *err = "opening not legal"; return nullptr; }
    TrainHandle* h = new TrainHandle();
    for (int m : moves) h->opening.push_back((Move)m);
    h->path = expPath;
    h->startFen = startFenC();
    if (fileExists(expPath)) {
        std::string e;
        if (!h->exp.load(expPath, &e)) { if (err) *err = e; delete h; return nullptr; }
    }
    Style st;                                  // an existing experience keeps its style: same JORO everywhere
    if (h->exp.hasStyle() && !h->exp.isLegacy()) h->exp.getStyle(st);   // (a pre-KHTI experience is upgraded)
    h->exp.setStyle(st);
    h->cfg.style = st;
    h->cfg.depth = depth;
    h->cfg.depthStrong = depthStrong;
    h->cfg.moveTimeWeak = msWeak;
    h->cfg.moveTimeStrong = msStrong;
    h->cfg.maxGames = maxGames;
    h->cfg.stableLimit = stable;
    h->cfg.confirmWins = confirm;
    h->cfg.drawIsFail = drawFail;
    h->cfg.hashMB = hashMb;
    h->cfg.varyFirstPct = varyFirstPct;
    h->label = label;
    h->acc = new OpeningAcc(openingIdOf(h->startFen, moves), label);
    h->trainer = new Trainer(h->exp, h->cfg);
    return h;
}

static bool saveAtomic(const Experience& e, const std::string& path) {
    std::string tmp = path + ".tmp";
    if (!e.save(tmp)) return false;
    return std::rename(tmp.c_str(), path.c_str()) == 0;
}

std::vector<int> trainStep(TrainHandle* h) {
    GameRecord rec;
    int nb = 0, ng = 0;
    std::string err;
    bool ok = h->trainer->step(h->startFen, h->opening, h->sess, rec, nb, ng, &err);
    if (!ok) return {h->trainer->wasStopped() ? 2 : -1};
    saveAtomic(h->exp, h->path);                // after every game: nothing is lost if Android kills the process
    h->lastOpponent = rec.opponent;
    int elo = h->curSpec.kind == OpponentSpec::LADDER ? h->curSpec.elo : 0;
    int promoted = 0, brill = 0, great = 0;
    for (uint8_t m : rec.marks) { if (m == MK_BRILLIANT) brill++; else if (m == MK_GREAT) great++; }
    if (h->acc) h->acc->add(rec, nb, elo);
    if (g_run.on) {
        OppSum& os = g_run.perOpp[rec.opponent];
        os.games++;
        g_run.games++;
        int sc = rec.result;                    // white point of view
        if (rec.joroSide >= 0) sc = rec.result == 0 ? 0 : (((rec.result == 1) == (rec.joroSide == WHITE)) ? 1 : -1);
        if (rec.joroSide < 0) { if (sc > 0) os.w++; else if (sc < 0) os.l++; else os.d++; }   // self-play: w = white wins, l = black wins
        else { if (sc > 0) os.w++; else if (sc < 0) os.l++; else os.d++; }
        if (rec.joroSide >= 0 && g_run.plan && g_run.plan->report(h->curSpec, sc > 0 ? 1.0 : (sc == 0 ? 0.5 : 0.0))) {
            promoted = 1;
            if (!g_run.ladderFile.empty()) g_run.plan->saveLevel(g_run.ladderFile);
        }
        if (g_run.pgn) g_run.pgn->add(rec, "JORO training: " + h->label);
    }
    const TrainStats& s = h->sess.stats;
    return {h->sess.finished ? 1 : 0, rec.result, (int)rec.moves.size(), nb, ng, (int)h->exp.size(),
            s.whiteWins, s.blackWins, s.draws, s.games, reasonCode(rec.reason), s.exhausted,
            h->sess.streakSide, h->sess.streakLen, h->sess.stable, ng,
            rec.joroSide, rec.mateLineNew, brill, great, rec.variedPly, elo, promoted};
}

void trainFinish(TrainHandle* h) {
    if (!h || !h->acc || !g_run.on || !g_run.stats || h->acc->row.games == 0) return;
    OpeningRow r = h->acc->row;
    r.run = g_run.runNo;
    r.date = g_run.date;
    g_run.stats->compare(r);
    g_run.rows.push_back(r);
}

std::string trainLastOpponent(TrainHandle* h) { return h ? h->lastOpponent : std::string(); }

void trainSetMix(TrainHandle* h, std::function<int(const std::string&, const std::vector<int>&)> engineFn, std::function<bool(int)> prepareFn) {
    if (!h || !h->trainer) return;
    Trainer* tr = h->trainer;
    Trainer::OpponentFn ef = [engineFn](const std::string& fen, const std::vector<Move>& mv) -> Move {
        std::vector<int> v(mv.begin(), mv.end());
        return (Move)engineFn(fen, v);
    };
    tr->beforeGame = [h, tr, ef, prepareFn](int) -> std::string {
        static int counter = 0;                 // colour alternates over the whole run, not per opening
        h->curSpec = (g_run.on && g_run.plan) ? g_run.plan->next() : OpponentSpec();
        if (h->curSpec.kind != OpponentSpec::SELF && !prepareFn(h->curSpec.kind == OpponentSpec::LADDER ? h->curSpec.elo : 0))
            h->curSpec = OpponentSpec();        // the engine is dead: JORO plays itself
        if (h->curSpec.kind == OpponentSpec::SELF) { tr->setOpponent(WHITE, Trainer::OpponentFn()); return h->curSpec.label; }
        tr->setOpponent((counter++ & 1) ? BLACK : WHITE, ef);
        return h->curSpec.label;
    };
}

void trainSetOpponent(TrainHandle* h, int joroSide, std::function<int(const std::string&, const std::vector<int>&)> fn) {
    if (!h || !h->trainer) return;
    h->trainer->setOpponent(joroSide, [fn](const std::string& fen, const std::vector<Move>& mv) -> Move {
        std::vector<int> v(mv.begin(), mv.end());
        return (Move)fn(fen, v);
    });
}

void trainStop(TrainHandle* h) { if (h && h->trainer) h->trainer->stop(); }
void trainPause(TrainHandle* h, bool p) { if (h && h->trainer) h->trainer->setPaused(p); }
bool trainWaiting(TrainHandle* h) { return h && h->trainer && h->trainer->isWaiting(); }
std::vector<int> trainLive(TrainHandle* h) {
    std::vector<int> out;
    if (h && h->trainer) for (Move m : h->trainer->liveMoves()) out.push_back((int)m);
    return out;
}
void trainDestroy(TrainHandle* h) { delete h; }

std::vector<int> gateRun(const std::string& basePath, const std::string& candPath, const std::vector<int>& openingsFlat,
                         int gamesPerStart, int movetimeMs) {
    initTables();
    Experience base, cand;
    std::string err;
    if (fileExists(basePath) && !base.load(basePath, &err)) return {};
    if (!cand.load(candPath, &err)) return {};
    std::vector<GateStart> starts;
    GateStart cur; cur.fen = START_FEN;
    bool any = false;
    for (int m : openingsFlat) {
        if (m == -1) { starts.push_back(cur); cur.moves.clear(); any = false; }
        else { cur.moves.push_back((Move)m); any = true; }
    }
    if (any) starts.push_back(cur);
    if (starts.empty()) return {};
    g_gateStop = false;
    GateResult r = gateExperience(cand, base, starts, gamesPerStart, movetimeMs, &g_gateStop);
    return {r.wins, r.draws, r.losses};
}

}} // namespace joro::app
