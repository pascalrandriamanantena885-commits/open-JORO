// JORO - san.h : standard algebraic notation (e4, Nf3, O-O, exd5, e8=Q+ ...). Used by the app, no UCI involved.
#pragma once
#include "board.h"
#include <string>
#include <vector>

namespace joro {

// b must be in the position BEFORE m, and m legal.
std::string moveToSan(Board& b, Move m);
// Tolerant parser: accepts missing 'x', '=', check marks, 0-0. Returns MOVE_NONE if no legal move matches.
Move parseSan(Board& b, const std::string& san);

} // namespace joro
