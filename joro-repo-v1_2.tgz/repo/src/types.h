// JORO - types.h
#pragma once
#include <cstdint>
#include <string>

namespace joro {

typedef uint64_t U64;
typedef uint32_t Move;

enum Color { WHITE = 0, BLACK = 1 };
enum PieceType { NO_PIECE = 0, PAWN = 1, KNIGHT, BISHOP, ROOK, QUEEN, KING };
enum MoveFlag { F_NORMAL = 0, F_DOUBLE = 1, F_EP = 2, F_CASTLE = 3 };

// piece = color<<3 | type ; square 0 = a1 ... 63 = h8
inline int mkPiece(int c, int t) { return (c << 3) | t; }
inline int colorOf(int p) { return p >> 3; }
inline int typeOf(int p) { return p & 7; }
inline int fileOf(int s) { return s & 7; }
inline int rankOf(int s) { return s >> 3; }

// move = from(6) | to(6)<<6 | promo(3)<<12 | flag(3)<<15
inline Move mkMove(int f, int t, int flag = 0, int promo = 0) {
    return (Move)(f | (t << 6) | (promo << 12) | (flag << 15));
}
inline int mFrom(Move m) { return m & 63; }
inline int mTo(Move m) { return (m >> 6) & 63; }
inline int mPromo(Move m) { return (m >> 12) & 7; }
inline int mFlag(Move m) { return (m >> 15) & 7; }
const Move MOVE_NONE = 0;

enum { CR_WK = 1, CR_WQ = 2, CR_BK = 4, CR_BQ = 8 };

} // namespace joro
