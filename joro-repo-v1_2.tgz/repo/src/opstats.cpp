// JORO - opstats.cpp
#include "opstats.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>

namespace joro {

std::string openingId(const std::string& fen, const std::vector<std::string>& moves) {
    uint64_t h = 1469598103934665603ULL;           // FNV-1a
    auto mix = [&](const std::string& s) { for (unsigned char c : s) { h ^= c; h *= 1099511628211ULL; } h ^= 0xff; h *= 1099511628211ULL; };
    mix(fen);
    for (auto& m : moves) mix(m);
    char buf[20];
    snprintf(buf, sizeof buf, "%08llx", (unsigned long long)(h & 0xffffffffULL));
    return buf;
}

void OpeningAcc::add(const GameRecord& rec, int newBad, int opponentElo) {
    row.games++;
    row.newBad += newBad;
    for (uint8_t m : rec.marks) { if (m == MK_BRILLIANT) row.brilliant++; else if (m == MK_GREAT) row.great++; }
    if (rec.joroSide < 0) row.selfGames++;
    else {
        row.sfGames++;
        int s = rec.result == 0 ? 0 : (((rec.result == 1) == (rec.joroSide == WHITE)) ? 1 : -1);
        if (s > 0) row.sfWin++; else if (s < 0) row.sfLoss++; else row.sfDraw++;
        if (opponentElo > row.maxLadder) row.maxLadder = opponentElo;
    }
    if (rec.reason == "checkmate") {
        // won by JORO: always in self-play, or when JORO is the winning colour against an engine
        bool joroWon = rec.joroSide < 0 || ((rec.result == 1) == (rec.joroSide == WHITE));
        if (joroWon) {
            row.mates++;
            int plies = (int)rec.moves.size();
            if (row.shortestMate == 0 || plies < row.shortestMate) row.shortestMate = plies;
            row.mateLinesRun += rec.mateLineNew > 0 ? 1 : 0;
        }
    }
}

static std::vector<std::string> split(const std::string& s, char sep) {
    std::vector<std::string> v;
    std::string t;
    std::stringstream ss(s);
    while (std::getline(ss, t, sep)) v.push_back(t);
    return v;
}

static const char* HEADER = "run,date,id,label,games,self,sf_games,sf_win,sf_draw,sf_loss,max_ladder,mates,shortest_mate,mate_lines_run,mate_lines_total,new_bad,brilliant,great";

bool OpeningStats::load() {
    history.clear(); lastIdx.clear(); lastRun = 0;
    std::ifstream f(path);
    if (!f) return true;
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty() || line.compare(0, 4, "run,") == 0) continue;
        auto c = split(line, ',');
        if (c.size() < 18) continue;
        OpeningRow r;
        r.run = atoi(c[0].c_str()); r.date = c[1]; r.id = c[2]; r.label = c[3];
        r.games = atoi(c[4].c_str()); r.selfGames = atoi(c[5].c_str());
        r.sfGames = atoi(c[6].c_str()); r.sfWin = atoi(c[7].c_str()); r.sfDraw = atoi(c[8].c_str()); r.sfLoss = atoi(c[9].c_str());
        r.maxLadder = atoi(c[10].c_str()); r.mates = atoi(c[11].c_str()); r.shortestMate = atoi(c[12].c_str());
        r.mateLinesRun = atoi(c[13].c_str()); r.mateLinesTotal = atoi(c[14].c_str());
        r.newBad = atoi(c[15].c_str()); r.brilliant = atoi(c[16].c_str()); r.great = atoi(c[17].c_str());
        history.push_back(r);
        lastIdx[r.id] = history.size() - 1;
        if (r.run > lastRun) lastRun = r.run;
    }
    return true;
}

const OpeningRow* OpeningStats::previous(const std::string& id) const {
    auto it = lastIdx.find(id);
    return it == lastIdx.end() ? nullptr : &history[it->second];
}

// Progress of this run against the previous run of the same opening (each criterion: +1 / -1 / 0):
//  * shortest mate: shorter (or the first mate ever) +1, longer -1
//  * new mating variations stored in this run: at least one +1
//  * share of games that ended in a mate: up / down by 10 points or more
void OpeningStats::compare(OpeningRow& r, OpeningRow* prevOut) const {
    const OpeningRow* p = previous(r.id);
    r.mateLinesTotal = (p ? p->mateLinesTotal : 0) + r.mateLinesRun;
    r.hasPrev = p != nullptr;
    r.progress = 0;
    if (!p) return;
    if (prevOut) *prevOut = *p;
    if (r.shortestMate > 0 && (p->shortestMate == 0 || r.shortestMate < p->shortestMate)) r.progress++;
    else if (r.shortestMate > 0 && r.shortestMate > p->shortestMate) r.progress--;
    if (r.mateLinesRun > 0) r.progress++;
    double d = r.mateRate() - p->mateRate();
    if (d >= 0.10) r.progress++; else if (d <= -0.10) r.progress--;
}

bool OpeningStats::append(const std::vector<OpeningRow>& rows) const {
    bool fresh = true;
    if (FILE* t = fopen(path.c_str(), "rb")) { fclose(t); fresh = false; }
    FILE* f = fopen(path.c_str(), "ab");
    if (!f) return false;
    if (fresh) fprintf(f, "%s\n", HEADER);
    for (auto& r : rows) {
        std::string label = r.label;
        for (char& ch : label) if (ch == ',' || ch == '\n' || ch == '\r') ch = ' ';
        fprintf(f, "%d,%s,%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", r.run, r.date.c_str(), r.id.c_str(), label.c_str(),
                r.games, r.selfGames, r.sfGames, r.sfWin, r.sfDraw, r.sfLoss, r.maxLadder, r.mates, r.shortestMate,
                r.mateLinesRun, r.mateLinesTotal, r.newBad, r.brilliant, r.great);
    }
    fclose(f);
    return true;
}

static std::string pad(std::string s, size_t n) {
    if (s.size() > n) s = s.substr(0, n - 1) + "~";
    return s + std::string(n - s.size(), ' ');
}

std::string OpeningStats::table(const std::vector<OpeningRow>& rows) const {
    std::string o;
    char buf[256];
    o += pad("opening", 22) + " games  vs SF W-D-L  mates  shortest mate (prev>now)  mate lines (run/all)  bad  !!  !   progress\n";
    for (auto& r : rows) {
        const OpeningRow* p = previous(r.id);
        std::string sf = r.sfGames ? std::to_string(r.sfWin) + "-" + std::to_string(r.sfDraw) + "-" + std::to_string(r.sfLoss) : "-";
        auto mv = [](int plies) { return plies ? std::to_string((plies + 1) / 2) + "m" : std::string("-"); };
        std::string sm = (p ? mv(p->shortestMate) : std::string("?")) + " > " + mv(r.shortestMate);
        std::string pr = !p ? "NEW" : (r.progress > 0 ? "UP +" + std::to_string(r.progress) : (r.progress < 0 ? "DOWN " + std::to_string(r.progress) : "="));
        snprintf(buf, sizeof buf, " %5d  %-12s %5d  %-24s  %3d / %-12d %4d %3d %3d   %s\n", r.games, sf.c_str(), r.mates, sm.c_str(),
                 r.mateLinesRun, r.mateLinesTotal, r.newBad, r.brilliant, r.great, pr.c_str());
        o += pad(r.label, 22) + buf;
    }
    return o;
}

} // namespace joro
