// JORO - trainer.h : self-play learning loop (JORO vs JORO) that writes the experience file.
//
// For one opening, games are replayed until the variations are exhausted (or a budget is hit):
//   * a side that WON  -> every move it played is stored as GOOD  (kept in "memory")
//   * a side that LOST -> backtracking finds the critical move; it is stored as BAD, so the
//                         next game tries another variation and never repeats the same error.
#pragma once
#include "search.h"
#include <atomic>
#include <functional>
#include <mutex>
#include <random>
#include <string>
#include <vector>

namespace joro {

const int NO_SCORE = -32768;

struct TrainConfig {
    // Self-play strength. depth/moveTimeWeak = the weaker side, depthStrong/moveTimeStrong = the deeper-thinking side
    // (0 = same as the weak one: no alternation). The strong side alternates between White and Black every game, so a
    // rematch swaps the roles and the two sides never play the same moves. moveTime > 0 replaces the depth limit.
    int depth = 5;             // weak side: search depth per move (also used by the verifications as a base)
    int depthStrong = 8;       // strong side: search depth per move
    int moveTimeWeak = 0;      // ms per move (0 = use the depth)
    int moveTimeStrong = 0;

    int maxPlies = 300;        // game is a draw after this
    int maxGames = 200;        // budget per opening
    int stableLimit = 3;       // stop after N games that taught nothing new
    int confirmWins = 5;       // stop when the same side wins N games in a row (the other side found no refutation)
    bool drawIsFail = true;    // a draw is not a win -> the side tries another variation
    int blameThreshold = 100;  // cp: eval drop that marks a move as the "critical" one
    bool adjudicate = false;   // off: only a real CHECKMATE counts as a win (on: |eval| >= 900cp for 6 moves decides the game)
    int hashMB = 16;
    bool brilliantOnly = true; // winners' moves are NOT stored; only brilliant ones (verified sacrifices / only moves) are
    int brilliantMargin = 120; // cp: the move must beat the best alternative by this much to be called brilliant
    bool mateLines = true;     // a game won by CHECKMATE: the whole winning line (any length) goes into the experience
    bool brain = true;         // Variation Brain in the self-play searchers (refuses moves that allow a forced mate / loss)
    bool great = true;         // also keep GREAT moves: no sacrifice needed, but a verified clearly-best move
    int greatMargin = 60;      // cp: must beat the best alternative by this much (below brilliantMargin)
    int greatMaxPerGame = 8;   // verification budget per side and game (each one is a depth+1 search)
    Style style;               // style used by both sides (stored in the exported file)
    // Variety: with this probability (percent) JORO's FIRST move after the opening is not the search's best move but the
    // second best, if that one is within varyMaxLoss cp. Without it two games of the same opening would start alike.
    double varyFirstPct = 5.0;
    int varyMaxLoss = 60;
    unsigned seed = 0;         // 0 = random (std::random_device)
};

// Mark attached to a move of a played game (shown in the PGN: brilliant !!, great !, bad ?, blunder ??)
enum Mark : uint8_t { MK_NONE = 0, MK_GREAT = 1, MK_BRILLIANT = 2, MK_BAD = 3, MK_BLUNDER = 4 };

struct GameRecord {
    std::string startFen;           // position after the opening
    std::vector<Move> moves;        // moves played after the opening
    std::vector<U64> keys;          // position key before each move
    std::vector<int> scores;        // search score (mover point of view) or NO_SCORE if played from experience
    std::vector<int> movers;        // side that played each move
    int strongSide = -1;            // side that searched deeper in this game (-1 = both equal)
    int result = 0;                 // +1 white won, -1 black won, 0 draw
    std::string reason;
    // ---- for the PGN / the per-opening table
    std::string rootFen;            // position BEFORE the opening moves
    std::vector<Move> opening;      // the opening moves (not in `moves`)
    std::string opponent = "JORO";  // label of the opposing side ("JORO", "Stockfish 1500", "Stockfish max")
    int joroSide = -1;              // side played by JORO against an external engine; -1 = JORO vs JORO
    std::vector<uint8_t> marks;     // one Mark per move of `moves`
    int variedPly = -1;             // index in `moves` of a first move chosen by the variety rule (-1 = none)
    int mateLineNew = 0;            // new mating-line entries stored from this game
};

struct TrainStats {
    int games = 0, whiteWins = 0, blackWins = 0, draws = 0;
    int newBad = 0, newGood = 0, exhausted = 0;   // newGood = new GOOD entries (brilliant moves)
};

// State of the training of ONE opening, advanced one game at a time (used by the app and by trainOpening).
struct TrainSession {
    int stable = 0, streakSide = 0, streakLen = 0;
    TrainStats stats;
    bool finished = false;   // a stop rule fired (budget / nothing new / confirmed wins)
};

class Trainer {
public:
    Trainer(Experience& exp, const TrainConfig& cfg);

    // called after every game (progress for the CLI / the Android UI)
    std::function<void(int gameNo, const GameRecord&, int newBad, int newGood)> onGame;

    // JORO vs an external engine (Stockfish): JORO plays joroSide with its own search + experience, the other side's
    // moves come from fn(startFen, allMovesSoFar). Only JORO's moves are ever learned from (blame / brilliant / great);
    // the opponent's moves never enter the experience. Pass an empty fn to go back to JORO vs JORO.
    using OpponentFn = std::function<Move(const std::string& startFen, const std::vector<Move>& moves)>;
    void setOpponent(int joroSide, OpponentFn fn) { joroSide_ = joroSide; opp = std::move(fn); }
    // Called at the start of every game (gameNo counts from 0). It may call setOpponent() to choose who JORO plays this
    // time (JORO itself, a Stockfish level, Stockfish at full strength) and returns the label stored in the record.
    std::function<std::string(int gameNo)> beforeGame;

    void stop();  // thread-safe, can be called from the UI
    // Pause / resume (thread-safe): the game stops at the next move boundary and the thread sleeps (no CPU, saves battery).
    void setPaused(bool p) { paused = p; }
    bool isPaused() const { return paused; }
    bool isWaiting() const { return waiting; }                  // true while really sleeping in a pause
    std::vector<Move> liveMoves() const;                        // moves of the game being played now (for the live board)

    TrainStats trainOpening(const std::string& startFen, const std::vector<std::string>& openingMoves,
                            std::string* err = nullptr);
    bool playGame(const std::string& startFen, const std::vector<std::string>& openingMoves, GameRecord& rec,
                  std::string* err = nullptr);   // text version (command line only)
    bool playGame(const std::string& startFen, const std::vector<Move>& opening, GameRecord& rec,
                  std::string* err = nullptr);
    // Plays ONE game, learns from it, updates the session. false = aborted (stop()) or error.
    bool step(const std::string& startFen, const std::vector<Move>& opening, TrainSession& s, GameRecord& rec,
              int& newBad, int& newGood, std::string* err = nullptr);
    bool wasStopped() const { return stopped; }
    void learn(GameRecord& rec, int& newBad, int& newGood, int& exhausted);

private:
    Experience& exp;
    TrainConfig cfg;
    Searcher sw, sb, sv;   // sv: verifier for brilliant moves
    void storeMatingLine(GameRecord& rec, int side, int& newGood);
    void findBrilliant(GameRecord& rec, int side, int& newGood);
    std::atomic<bool> stopped;
    std::mt19937 rng;
    int gameIdx = 0;                // counts games: the strong side alternates with it
    OpponentFn opp;
    int joroSide_ = WHITE;
    std::atomic<bool> paused{false}, waiting{false};
    mutable std::mutex liveMu;
    std::vector<Move> live;
    void blame(GameRecord& rec, int side, int resultForSide, int& newBad, int& exhausted);
};

} // namespace joro
