#!/usr/bin/env python3
"""Mamorona fens/joro_positions.epd avy amin'ny andalana UCI, amin'ny alalan'ny binary JORO (baiko 'fen').
Manamarina koa fa ara-dalàna ny move rehetra (skipped == 0).   Usage: python3 tools/gen_fens.py ./joro_cpp
"""
import subprocess, sys

# (id, joro_color, family, moves)  -- OPENING : position farany amin'ny prefix, ny JORO no hihetsika
OPENING = [
    # ---- WHITE : King's Gambit
    ("kg-1", "white", "Kings Gambit", "e2e4 e7e5 f2f4 e5f4"),
    ("kg-2", "white", "Kings Gambit", "e2e4 e7e5 f2f4 e5f4 g1f3 g7g5"),
    ("kg-3", "white", "Kings Gambit", "e2e4 e7e5 f2f4 e5f4 g1f3 d7d6"),
    ("kg-4", "white", "Kings Gambit", "e2e4 e7e5 f2f4 e5f4 g1f3 g8f6"),
    ("kg-5", "white", "Kings Gambit", "e2e4 e7e5 f2f4 f8c5"),
    # ---- WHITE : Italian
    ("it-1", "white", "Italian", "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5"),
    ("it-2", "white", "Italian", "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6"),
    ("it-3", "white", "Italian", "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6"),
    ("it-4", "white", "Italian", "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 c2c3 g8f6 d2d4 e5d4 c3d4 c5b4"),
    # ---- WHITE : Scotch
    ("sc-1", "white", "Scotch", "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4"),
    ("sc-2", "white", "Scotch", "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f3d4 g8f6"),
    ("sc-3", "white", "Scotch", "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f3d4 f8c5"),
    ("sc-4", "white", "Scotch", "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f3d4 d8h4"),
    # ---- BLACK : Sicilian
    ("si-1", "black", "Sicilian", "e2e4"),
    ("si-2", "black", "Sicilian", "e2e4 c7c5 g1f3"),
    ("si-3", "black", "Sicilian", "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4"),
    ("si-4", "black", "Sicilian", "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3"),
    ("si-5", "black", "Sicilian", "e2e4 c7c5 b1c3"),
    # ---- BLACK : King's Indian
    ("ki-1", "black", "Kings Indian", "d2d4"),
    ("ki-2", "black", "Kings Indian", "d2d4 g8f6 c2c4"),
    ("ki-3", "black", "Kings Indian", "d2d4 g8f6 c2c4 g7g6 b1c3"),
    ("ki-4", "black", "Kings Indian", "d2d4 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4"),
    ("ki-5", "black", "Kings Indian", "c2c4"),
    ("ki-6", "black", "Kings Indian", "g1f3"),
    # ---- BLACK : French
    ("fr-1", "black", "French", "e2e4 e7e6 d2d4"),
    ("fr-2", "black", "French", "e2e4 e7e6 d2d4 d7d5 b1c3"),
    ("fr-3", "black", "French", "e2e4 e7e6 d2d4 d7d5 e4e5"),
    ("fr-4", "black", "French", "e2e4 e7e6 d2d4 d7d5 b1d2"),
    ("fr-5", "black", "French", "e2e4 e7e6 d2d4 d7d5 e4d5"),
]

# STYLE : attaque / fomba filalaovan'i JORO (middlegame). Ny position dia tapahina mba hihetsika ny JORO.
# (id, joro_color, family, full_moves, plies_to_keep)
STYLE = [
    ("st-kg-muzio", "white", "Kings Gambit", "e2e4 e7e5 f2f4 e5f4 g1f3 g7g5 f1c4 g5g4 e1g1 g4f3 d1f3 d8f6 e4e5 f6e5 c4f7 e8f7 f3f4", 16),
    ("st-kg-classic", "white", "Kings Gambit", "e2e4 e7e5 f2f4 e5f4 g1f3 d7d6 f1c4 g8f6 b1c3 c8g4 d2d4 b8c6", 12),
    ("st-it-evans", "white", "Italian", "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 b2b4 c5b4 c2c3 b4a5 d2d4 e5d4 e1g1 d4c3 d1b3 d8f6 e4e5 f6g6", 18),
    ("st-it-ng5", "white", "Italian", "e2e4 e7e5 g1f3 b8c6 f1c4 g8f6 f3g5 d7d5 e4d5 c6a5 c4b5 c7c6 d5c6 b7c6 b5e2 h7h6 g5f3 e5e4", 18),
    ("st-sc-gambit", "white", "Scotch", "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f1c4 g8f6 e4e5 d7d5 c4b5 f6e4 f3d4 f8c5", 14),
    ("st-sc-main", "white", "Scotch", "e2e4 e7e5 g1f3 b8c6 d2d4 e5d4 f3d4 g8f6 d4c6 b7c6 e4e5 d8e7 d1e2 f6d5 c2c4 c8a6", 16),
    ("st-si-6bg5", "black", "Sicilian", "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 a7a6 c1g5 e7e6 f2f4 d8b6 d1d2 b6b2 a1b1 b2a3", 17),
    ("st-si-najdorf", "black", "Sicilian", "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4 g8f6 b1c3 a7a6 c1e3 e7e5 d4b3 c8e6 f2f3 b8d7 d1d2", 17),
    ("st-ki-mdp", "black", "Kings Indian", "d2d4 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6 g1f3 e8g8 f1e2 e7e5 e1g1 b8c6 d4d5 c6e7 f3e1 f6d7 c1e3 f7f5", 19),
    ("st-ki-fianchetto", "black", "Kings Indian", "d2d4 g8f6 c2c4 g7g6 g2g3 f8g7 f1g2 e8g8 b1c3 d7d6 g1f3 b8d7 e1g1 e7e5 e2e4 c7c6", 15),
    ("st-fr-classical", "black", "French", "e2e4 e7e6 d2d4 d7d5 b1c3 g8f6 e4e5 f6d7 f2f4 c7c5 g1f3 b8c6 c1e3 a7a6 d1d2 c5d4 f3d4", 15),
    ("st-fr-advance", "black", "French", "e2e4 e7e6 d2d4 d7d5 e4e5 c7c5 c2c3 b8c6 g1f3 d8b6 a2a3 c5c4 b2b4 c4b3", 11),
]

def fen_of(engine, moves):
    inp = f"position startpos moves {moves}\nfen\nquit\n" if moves else "position startpos\nfen\nquit\n"
    out = subprocess.run([engine], input=inp, capture_output=True, text=True).stdout
    fen = next(l[4:] for l in out.splitlines() if l.startswith("fen "))
    skipped = int(next(l.split()[1] for l in out.splitlines() if l.startswith("skipped ")))
    return fen.strip(), skipped

def main():
    engine = sys.argv[1] if len(sys.argv) > 1 else "./joro_cpp"
    rows, seen = [], set()
    def add(pid, color, fam, tag, moves):
        fen, sk = fen_of(engine, moves)
        want = "w" if color == "white" else "b"
        if sk:
            raise SystemExit(f"{pid}: move tsy ara-dalàna ({sk}) ao amin'ny: {moves}")
        if fen.split()[1] != want:
            raise SystemExit(f"{pid}: tsy ny {color} no hihetsika ao amin'ny {fen}")
        key = fen.split()[0:4]
        if tuple(key) in seen:
            return
        seen.add(tuple(key))
        rows.append(f"{fen} ; id={pid} ; joro={color} ; family={fam} ; tag={tag}")
    for pid, color, fam, mv in OPENING:
        add(pid, color, fam, "opening", mv)
    for pid, color, fam, mv, keep in STYLE:
        ms = mv.split()[:keep]
        add(pid, color, fam, "style", " ".join(ms))
    with open("fens/joro_positions.epd", "w") as f:
        f.write("# FEN ; id ; joro=white|black ; family ; tag=opening|style\n")
        f.write("# opening = position avy amin'ny repertoire (JORO no hihetsika) ; style = middlegame attaque (fomba filalaovana)\n")
        f.write("\n".join(rows) + "\n")
    print(f"{len(rows)} position voasoratra")

if __name__ == "__main__":
    main()
