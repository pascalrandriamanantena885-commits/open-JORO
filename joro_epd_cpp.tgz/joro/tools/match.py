#!/usr/bin/env python3
"""JORO match runner (python-chess).
  selfplay : JORO(A, safidy default)  vs  JORO(B, safidy --opt-b)   -> ho an'ny fampitahana ny module (School, Ghost, Race ...)
  stockfish: JORO  vs  Stockfish (UCI_Elo = --sf-elo)               -> ho an'ny calibration
Suite : fen (position avy ao amin'ny fens/joro_positions.epd ; ny JORO no manana ny loko voasoratra)  /  startpos (book + repertoire ; loko miodina)
"""
import argparse, json, os, random, sys, time
import concurrent.futures as cf
import chess, chess.engine, chess.pgn

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from joro_stats import wdl_stats, classify_opening, parse_epd

PV = {chess.PAWN: 1, chess.KNIGHT: 3, chess.BISHOP: 3, chess.ROOK: 5, chess.QUEEN: 9, chess.KING: 100}

def parse_opts(items):
    d = {}
    for it in items or []:
        k, v = it.split("=", 1)
        if v.lower() in ("true", "false"):
            d[k] = v.lower() == "true"
        else:
            try:
                d[k] = int(v)
            except ValueError:
                d[k] = v
    return d

def start_engine(cmd, opts, seed=None):
    eng = chess.engine.SimpleEngine.popen_uci(cmd, timeout=30)
    o = dict(opts)
    if seed is not None and "Seed" in eng.options:
        o["Seed"] = seed
    for k, v in list(o.items()):
        if k not in eng.options:
            print(f"[warn] safidy '{k}' tsy fantatry ny {cmd}", file=sys.stderr)
            o.pop(k)
    if o:
        eng.configure(o)
    return eng

def min_val(board, sqs):
    return min(PV[board.piece_type_at(s)] for s in sqs)

def play_game(job):
    cfg = job["cfg"]
    board = chess.Board(job["fen"])
    start_fen = board.fen()
    a_color = chess.WHITE if job["a_white"] else chess.BLACK       # A = JORO (stockfish mode) na JORO "A" (selfplay)
    rec = dict(id=job["id"], fen=start_fen, tag=job.get("tag", "startpos"), family=job.get("family", ""),
               a_white=job["a_white"], moves=[], term="", result=0.5, checks=0, sac_offers=0, castle=None, opp_castle=None, error="")
    eA = eB = None
    try:
        eA = start_engine(cfg["cmdA"], cfg["optsA"], seed=job["seed"])
        eB = start_engine(cfg["cmdB"], cfg["optsB"], seed=job["seed"] + 7919)
        limit = chess.engine.Limit(time=cfg["movetime"] / 1000.0)
        recent = []
        while len(rec["moves"]) < cfg["maxplies"]:
            if board.is_game_over(claim_draw=True):
                break
            mover = board.turn
            eng = eA if mover == a_color else eB
            try:
                res = eng.play(board, limit, info=chess.engine.INFO_SCORE)
            except (chess.engine.EngineError, chess.engine.EngineTerminatedError, TimeoutError) as ex:
                rec["term"] = "crash-" + ("A" if mover == a_color else "B")
                rec["error"] = str(ex)[:200]
                rec["result"] = 0.0 if mover == a_color else 1.0
                break
            mv = res.move
            if mv is None or mv not in board.legal_moves:
                rec["term"] = "illegal-" + ("A" if mover == a_color else "B")
                rec["result"] = 0.0 if mover == a_color else 1.0
                break
            sc = res.info.get("score")
            recent.append(sc.white().score(mate_score=100000) if sc is not None else None)
            recent = recent[-6:]
            if mover == a_color:
                if board.gives_check(mv):
                    rec["checks"] += 1
                if board.is_castling(mv) and rec["castle"] is None:
                    rec["castle"] = "short" if chess.square_file(mv.to_square) >= 5 else "long"
                pt = board.piece_type_at(mv.from_square)
                cap = 0
                if board.is_en_passant(mv):
                    cap = 1
                elif board.piece_at(mv.to_square):
                    cap = PV[board.piece_type_at(mv.to_square)]
                board.push(mv)
                if len(rec["moves"]) < 40 and pt not in (chess.KING, None):
                    att = board.attackers(board.turn, mv.to_square)
                    dfd = board.attackers(not board.turn, mv.to_square)
                    if att and PV[pt] - cap >= 1 and (not dfd or min_val(board, att) < PV[pt] - cap):
                        rec["sac_offers"] += 1
            else:
                if board.is_castling(mv) and rec["opp_castle"] is None:
                    rec["opp_castle"] = "short" if chess.square_file(mv.to_square) >= 5 else "long"
                board.push(mv)
            rec["moves"].append(mv.uci())
            # adjudication : score 900+ efa mitovy amin'ny roa tonta
            if len(rec["moves"]) > 30 and len(recent) >= 6 and all(x is not None for x in recent):
                if all(x >= 900 for x in recent) or all(x <= -900 for x in recent):
                    white_wins = recent[-1] > 0
                    rec["term"] = "adjudicated"
                    rec["result"] = 1.0 if white_wins == (a_color == chess.WHITE) else 0.0
                    break
        if not rec["term"]:
            if board.is_game_over(claim_draw=True):
                out = board.outcome(claim_draw=True)
                rec["term"] = out.termination.name.lower() if out else "over"
                if out and out.winner is not None:
                    rec["result"] = 1.0 if out.winner == a_color else 0.0
                else:
                    rec["result"] = 0.5
            else:
                rec["term"] = "maxplies"
                rec["result"] = 0.5
    finally:
        for e in (eA, eB):
            try:
                if e:
                    e.quit()
            except Exception:
                try:
                    e.close()
                except Exception:
                    pass
    if rec["term"] == "checkmate" and rec["result"] == 1.0:
        rec["mate_win"] = True
    return rec

def to_pgn(rec, white_name, black_name):
    g = chess.pgn.Game()
    b = chess.Board(rec["fen"])
    g.headers["White"], g.headers["Black"] = white_name, black_name
    g.headers["Result"] = "*"
    if rec["fen"] != chess.STARTING_FEN:
        g.setup(b)
    node = g
    for u in rec["moves"]:
        mv = chess.Move.from_uci(u)
        node = node.add_variation(mv)
    g.headers["Event"] = f"{rec['id']} {rec['tag']} {rec['family']}".strip()
    g.headers["Termination"] = rec["term"]
    return str(g)

def build_jobs(a, cfg):
    rng = random.Random(a.seed)
    jobs = []
    pos = parse_epd(a.fens, None if a.tag == "all" else a.tag)
    rng.shuffle(pos)
    if a.mode == "selfplay" or a.suite == "fen":
        if not pos:
            raise SystemExit("tsy misy position ao amin'ny " + a.fens)
    if a.mode == "selfplay":
        n = max(1, a.games // 2)
        for i in range(n):
            p = pos[i % len(pos)]
            for k, aw in enumerate((True, False)):
                jobs.append(dict(cfg=cfg, fen=p["fen"], a_white=aw, id=p.get("id", f"p{i}"), tag=p.get("tag", ""),
                                 family=p.get("family", ""), seed=a.seed + i * 2 + k + 1))
    else:
        for i in range(a.games):
            if a.suite == "fen":
                p = pos[i % len(pos)]
                aw = p.get("joro", "white") == "white"
                if i >= len(pos) and (i // len(pos)) % 2 == 1:
                    aw = not aw          # miverimbena ny loko rehefa mihodina ny lisitra (calibration tsy mitanila)
                jobs.append(dict(cfg=cfg, fen=p["fen"], a_white=aw, id=p.get("id", f"p{i}"), tag=p.get("tag", ""),
                                 family=p.get("family", ""), seed=a.seed + i + 1))
            else:
                jobs.append(dict(cfg=cfg, fen=chess.STARTING_FEN, a_white=(i % 2 == 0), id=f"start{i}", tag="startpos",
                                 family="", seed=a.seed + i + 1))
    return jobs

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["selfplay", "stockfish"])
    ap.add_argument("--engine", default="./joro_cpp")
    ap.add_argument("--stockfish", default="/usr/games/stockfish")
    ap.add_argument("--sf-elo", default="2000", help="UCI_Elo 1320..3190 na 'max' (Stockfish tsy voafetra)")
    ap.add_argument("--suite", choices=["fen", "startpos"], default="fen")
    ap.add_argument("--fens", default="fens/joro_positions.epd")
    ap.add_argument("--tag", default="all", help="opening | style | all")
    ap.add_argument("--games", type=int, default=20)
    ap.add_argument("--movetime", type=int, default=200, help="ms isaky ny move")
    ap.add_argument("--maxplies", type=int, default=240)
    ap.add_argument("--concurrency", type=int, default=1)
    ap.add_argument("--opt-a", action="append", default=[])
    ap.add_argument("--opt-b", action="append", default=[])
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--label", default=None)
    ap.add_argument("--out-dir", default="results")
    a = ap.parse_args()

    optsA = parse_opts(a.opt_a)
    optsA.setdefault("Hash", 16)
    if a.mode == "selfplay":
        optsB = parse_opts(a.opt_b)
        optsB.setdefault("Hash", 16)
        cmdB = a.engine
        label = a.label or "selfplay"
    else:
        if str(a.sf_elo).lower() == "max":
            a.sf_elo = "max"
            optsB = {"UCI_LimitStrength": False, "Threads": 1, "Hash": 16}      # Stockfish full strength
        else:
            a.sf_elo = int(a.sf_elo)
            optsB = {"UCI_LimitStrength": True, "UCI_Elo": max(1320, min(3190, a.sf_elo)), "Threads": 1, "Hash": 16}
        cmdB = a.stockfish
        label = a.label or f"sf{a.sf_elo}-{a.suite}"
    cfg = dict(cmdA=a.engine, cmdB=cmdB, optsA=optsA, optsB=optsB, movetime=a.movetime, maxplies=a.maxplies)
    jobs = build_jobs(a, cfg)
    print(f"[{label}] {len(jobs)} lalao, movetime {a.movetime} ms, concurrency {a.concurrency}", flush=True)
    t0 = time.time()
    recs = []
    with cf.ProcessPoolExecutor(max_workers=max(1, a.concurrency)) as ex:
        for i, r in enumerate(ex.map(play_game, jobs), 1):
            recs.append(r)
            res = {1.0: "A-win", 0.5: "draw", 0.0: "A-loss"}[r["result"]]
            print(f"  game {i:3d} {r['id']:<14} A={'W' if r['a_white'] else 'B'}  {res:<7} {r['term']:<16} {len(r['moves'])} plies", flush=True)

    w = sum(1 for r in recs if r["result"] == 1.0)
    d = sum(1 for r in recs if r["result"] == 0.5)
    l = sum(1 for r in recs if r["result"] == 0.0)
    st = wdl_stats(w, d, l)
    crashes = [r for r in recs if r["term"].startswith(("crash-A", "illegal-A"))]
    for r in recs:
        if a.mode == "stockfish" or True:
            fam, status = classify_opening(r["moves"], r["a_white"]) if r["tag"] == "startpos" else (r["family"], "ok")
            r["family"], r["opening_status"] = fam, status
    summary = dict(label=label, mode=a.mode, suite=a.suite, sf_elo=a.sf_elo if a.mode == "stockfish" else None,
                   movetime=a.movetime, optsA=optsA, optsB=optsB, wins=w, draws=d, losses=l, **st,
                   a_crashes=len(crashes), seconds=round(time.time() - t0, 1), records=recs)
    os.makedirs(a.out_dir, exist_ok=True)
    with open(os.path.join(a.out_dir, label + ".json"), "w", encoding="utf-8") as f:
        json.dump(summary, f)
    with open(os.path.join(a.out_dir, label + ".pgn"), "w", encoding="utf-8") as f:
        an, bn = ("JORO", "Stockfish" if a.mode == "stockfish" else "JORO-B")
        for r in recs:
            f.write(to_pgn(r, an if r["a_white"] else bn, bn if r["a_white"] else an) + "\n\n")
    print(f"[{label}] +{w} ={d} -{l}  score {st['score']*100:.1f}%  Elo {st['elo']:+.0f} +/- {st['ci']:.0f}  LOS {st['los']*100:.0f}%")
    if crashes:
        print(f"[{label}] ATTENTION : JORO crash/illegal x{len(crashes)}", file=sys.stderr)

if __name__ == "__main__":
    main()
