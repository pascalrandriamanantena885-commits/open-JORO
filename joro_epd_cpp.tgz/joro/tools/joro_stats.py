"""Fampiasa iombonana (tsy mila python-chess) : Elo, famakafakana opening, famakiana ny rakitra FEN."""
import math

def clip_score(s, n):
    lo = 1.0 / (2 * max(n, 1))
    return min(max(s, lo), 1 - lo)

def elo_from_score(s, n=100):
    s = clip_score(s, n)
    return -400.0 * math.log10(1.0 / s - 1.0)

def expected_score(rating, opp):
    return 1.0 / (1.0 + 10 ** ((opp - rating) / 400.0))

def wdl_stats(w, d, l):
    n = w + d + l
    if n == 0:
        return dict(n=0, score=0.0, elo=0.0, lo=0.0, hi=0.0, ci=0.0, los=0.5)
    s = (w + 0.5 * d) / n
    var = (w * (1 - s) ** 2 + d * (0.5 - s) ** 2 + l * (0 - s) ** 2) / n
    se = math.sqrt(var / n)
    z = 1.96 * se
    elo = elo_from_score(s, n)
    lo, hi = elo_from_score(s - z, n), elo_from_score(s + z, n)
    los = 0.5 if w + l == 0 else 0.5 * (1 + math.erf((w - l) / math.sqrt(2.0 * (w + l))))
    return dict(n=n, score=s, elo=elo, lo=lo, hi=hi, ci=(hi - lo) / 2, los=los)

def classify_opening(moves, joro_white):
    """moves = lisitry UCI avy amin'ny startpos. Miverina (family, status) ; status = ok | deviation (mpanohitra) | violation (JORO)."""
    m = moves
    def g(i):
        return m[i] if i < len(m) else None
    if joro_white:
        if g(0) is None:
            return ("?", "ok")
        if g(0) != "e2e4":
            return ("off-repertoire", "violation")
        if g(1) is None:
            return ("e4", "ok")
        if g(1) != "e7e5":
            return ("vs-" + g(1), "deviation")
        if g(2) is None:
            return ("e4-e5", "ok")
        if g(2) == "f2f4":
            return ("Kings Gambit", "ok")
        if g(2) != "g1f3":
            return ("off-repertoire", "violation")
        if g(3) is None:
            return ("e4-e5-Nf3", "ok")
        if g(3) != "b8c6":
            return ("vs-" + g(3), "deviation")
        if g(4) is None:
            return ("e4-e5-Nf3-Nc6", "ok")
        if g(4) == "f1c4":
            return ("Italian", "ok")
        if g(4) == "d2d4":
            return ("Scotch", "ok")
        return ("off-repertoire", "violation")
    # JORO = black
    if g(0) is None:
        return ("?", "ok")
    if g(1) is None:
        return ("?", "ok")
    if g(0) == "e2e4":
        if g(1) == "c7c5":
            return ("Sicilian", "ok")
        if g(1) == "e7e6":
            if g(3) is not None and g(3) != "d7d5":
                return ("off-repertoire", "violation")
            return ("French", "ok")
        return ("off-repertoire", "violation")
    if g(1) in ("g8f6", "g7g6"):
        return ("Kings Indian", "ok")
    return ("off-repertoire", "violation")

def parse_epd(path, tag=None):
    out = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = [x.strip() for x in line.split(";")]
            d = {"fen": parts[0]}
            for p in parts[1:]:
                if "=" in p:
                    k, v = p.split("=", 1)
                    d[k.strip()] = v.strip()
            if tag in (None, "all") or d.get("tag") == tag:
                out.append(d)
    return out
