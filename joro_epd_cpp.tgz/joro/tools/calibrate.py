#!/usr/bin/env python3
"""Fanangonana ny vokatra (selfplay + vs Stockfish) -> tabilao calibration (matrix), Elo ML, repertoire, fomba filalaovana.
Usage: python3 tools/calibrate.py results   ->  results/summary.md + results/summary.json
Exit code 1 raha misy repertoire violation na crash an'i JORO.
"""
import glob, json, math, os, sys
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from joro_stats import wdl_stats, expected_score

def load(d):
    out = []
    for f in sorted(glob.glob(os.path.join(d, "**", "*.json"), recursive=True)):
        if os.path.basename(f).startswith("summary"):
            continue
        try:
            with open(f, encoding="utf-8") as fh:
                j = json.load(fh)
            if "records" in j and "mode" in j:
                out.append(j)
        except Exception as ex:
            print(f"[warn] {f}: {ex}", file=sys.stderr)
    return out

def ml_rating(levels):
    """levels = [(sf_elo, n, points)] -> (Elo, se) amin'ny ML (bisection)."""
    tot_n = sum(n for _, n, _ in levels)
    if tot_n == 0:
        return None, None
    pts = sum(p for _, _, p in levels)
    lo, hi = 0.0, 4000.0
    for _ in range(80):
        mid = (lo + hi) / 2
        exp = sum(n * expected_score(mid, e) for e, n, _ in levels)
        if exp < pts:
            lo = mid
        else:
            hi = mid
    r = (lo + hi) / 2
    k = math.log(10) / 400.0
    info = sum(n * k * k * expected_score(r, e) * (1 - expected_score(r, e)) for e, n, _ in levels)
    se = 1 / math.sqrt(info) if info > 0 else None
    return r, se

def pct(x):
    return f"{100 * x:.0f}%"

def main():
    d = sys.argv[1] if len(sys.argv) > 1 else "results"
    runs = load(d)
    selfplay = [r for r in runs if r["mode"] == "selfplay"]
    sfruns = [r for r in runs if r["mode"] == "stockfish"]
    md, js = [], {}
    bad = 0

    md.append("# JORO : vokatra CI\n")
    # ------------------------------------------------ selfplay
    if selfplay:
        md.append("## Selfplay A/B (A = default, B = module iray (na rehetra) atsahatra)\n")
        md.append("| Module | Lalao | +W =D -L | Score | Elo (A-B) | LOS | Fanamarihana |")
        md.append("|---|---:|---|---:|---:|---:|---|")
        js["selfplay"] = []
        for r in sorted(selfplay, key=lambda x: x["label"]):
            off = ", ".join(f"{k}={v}" for k, v in r["optsB"].items() if k != "Hash")
            note = "OK" if r["elo"] - r["ci"] > 0 else ("MIDINA (regression ?)" if r["elo"] + r["ci"] < 0 else "tsy mazava (mila lalao maro)")
            md.append(f"| {r['label'].replace('selfplay-', '')} (B: {off}) | {r['n']} | +{r['wins']} ={r['draws']} -{r['losses']} | {pct(r['score'])} | {r['elo']:+.0f} ±{r['ci']:.0f} | {pct(r['los'])} | {note} |")
            js["selfplay"].append({k: r[k] for k in ("label", "n", "wins", "draws", "losses", "score", "elo", "ci", "los")})
            bad += r.get("a_crashes", 0)
        md.append("")

    # ------------------------------------------------ matrix vs Stockfish
    if sfruns:
        md.append("## Calibration vs Stockfish (matrix : UCI_Elo × suite)\n")
        suites = sorted({r["suite"] for r in sfruns})
        elos = sorted({r["sf_elo"] for r in sfruns if r["sf_elo"] != "max"}) + (["max"] if any(r["sf_elo"] == "max" for r in sfruns) else [])
        md.append("| SF Elo | " + " | ".join(f"{s}: score (W-D-L)" for s in suites) + " | Tontolo : score | Performance Elo |")
        md.append("|---:|" + "---|" * (len(suites) + 2))
        levels = []
        js["matrix"] = []
        for e in elos:
            cells, W, D, L = [], 0, 0, 0
            for s in suites:
                rr = [r for r in sfruns if r["sf_elo"] == e and r["suite"] == s]
                w = sum(r["wins"] for r in rr); dd = sum(r["draws"] for r in rr); l = sum(r["losses"] for r in rr)
                W += w; D += dd; L += l
                cells.append(f"{pct((w + 0.5 * dd) / (w + dd + l))} ({w}-{dd}-{l})" if w + dd + l else "-")
            st = wdl_stats(W, D, L)
            if st["n"] and e == "max":
                md.append(f"| max (tsy voafetra) | " + " | ".join(cells) + f" | {pct(st['score'])} | n/a (ambonin'ny 3190) |")
                js["matrix"].append(dict(sf_elo="max", w=W, d=D, l=L, score=st["score"], perf=None, ci=None))
            elif st["n"]:
                levels.append((e, st["n"], W + 0.5 * D))
                md.append(f"| {e} | " + " | ".join(cells) + f" | {pct(st['score'])} | {e + st['elo']:.0f} ±{st['ci']:.0f} |")
                js["matrix"].append(dict(sf_elo=e, w=W, d=D, l=L, score=st["score"], perf=e + st["elo"], ci=st["ci"]))
            bad += sum(r.get("a_crashes", 0) for r in sfruns if r["sf_elo"] == e)
        est, se = ml_rating(levels)
        if est is not None:
            md.append(f"\n**Elo tombanana an'i JORO (ML, SF Elo voafetra ihany, tsy ao ny max) : {est:.0f} ± {1.96 * se:.0f}**" if se else f"\n**Elo tombanana : {est:.0f}**")
            md.append("\n> Indikativa : ny UCI_Elo an'i Stockfish dia voasokajy amin'ny fotoana lava kokoa noho ny movetime eto, ka manao fampitahana mifandraika fa tsy Elo CCRL tanteraka.\n")
            js["elo_estimate"] = dict(elo=est, ci=1.96 * se if se else None)

        # ---- ny fomba filalaovana + opening
        recs = [x for r in sfruns for x in r["records"]]
        md.append("## Fomba filalaovana sy opening\n")
        by_tag = defaultdict(lambda: [0, 0, 0])
        by_fam = defaultdict(lambda: [0, 0, 0])
        for x in recs:
            idx = {1.0: 0, 0.5: 1, 0.0: 2}[x["result"]]
            by_tag[x["tag"]][idx] += 1
            if x["tag"] != "startpos" and x["family"]:
                by_fam[x["family"]][idx] += 1
        md.append("| Karazana | Lalao | Score | +W =D -L |")
        md.append("|---|---:|---:|---|")
        for k, (w, dd, l) in sorted(by_tag.items()):
            md.append(f"| {k} | {w + dd + l} | {pct((w + 0.5 * dd) / max(1, w + dd + l))} | +{w} ={dd} -{l} |")
        for k, (w, dd, l) in sorted(by_fam.items()):
            md.append(f"| ↳ {k} | {w + dd + l} | {pct((w + 0.5 * dd) / max(1, w + dd + l))} | +{w} ={dd} -{l} |")
        n = max(1, len(recs))
        wins = [x for x in recs if x["result"] == 1.0]
        md.append("")
        md.append(f"- Check isaky ny lalao : **{sum(x['checks'] for x in recs) / n:.1f}** ; sacrifice offers (ply<40) : **{sum(x['sac_offers'] for x in recs) / n:.2f}**")
        md.append(f"- Fandresena amin'ny mate : **{sum(1 for x in wins if x.get('mate_win'))}/{len(wins)}**")
        oc = [x for x in recs if x.get("castle") and x.get("opp_castle")]
        if oc:
            opp = sum(1 for x in oc if x["castle"] != x["opp_castle"])
            md.append(f"- Opposite-side castling (rehefa nanao castle ny roa) : **{opp}/{len(oc)}**")
        sp = [x for x in recs if x["tag"] == "startpos"]
        if sp:
            fams = defaultdict(int)
            viol = []
            for x in sp:
                fams[x["family"]] += 1
                if x.get("opening_status") == "violation":
                    viol.append(x)
            md.append("\n**Repertoire (suite startpos)** : " + ", ".join(f"{k} ×{v}" for k, v in sorted(fams.items())))
            if viol:
                bad += len(viol)
                md.append(f"\n:x: **{len(viol)} lalao nivoaka tamin'ny repertoire** (fotsy: KG/Italian/Scotch ; mainty: Sicilian/KID/French):")
                for x in viol[:10]:
                    md.append(f"- `{' '.join(x['moves'][:10])}`")
            else:
                md.append("\n:white_check_mark: Tsy nisy violation amin'ny repertoire.")
            js["repertoire"] = dict(games=len(sp), families=dict(fams), violations=len(viol))
        md.append("")

    if bad:
        md.append(f"\n:warning: **{bad}** olana lehibe (crash / move tsy ara-dalàna / repertoire violation).")
    text = "\n".join(md) + "\n"
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "summary.md"), "w", encoding="utf-8") as f:
        f.write(text)
    with open(os.path.join(d, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(js, f, indent=1)
    print(text)
    sys.exit(1 if bad else 0)

if __name__ == "__main__":
    main()
